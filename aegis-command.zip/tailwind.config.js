/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        aegis: {
          bg: '#030508',
          panel: '#060b10',
          border: '#0a1828',
          cyan: '#00d4ff',
          red: '#ff2d55',
          amber: '#ffd60a',
          green: '#00ff99',
          text: '#e8eaf0',
          muted: '#4a5568',
        },
      },
      fontFamily: {
        mono: ['IBM Plex Mono', 'Consolas', 'monospace'],
        tactical: ['Rajdhani', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'threat-pulse': 'threat-pulse 1.5s ease-in-out infinite',
      },
      keyframes: {
        'threat-pulse': {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.5', transform: 'scale(1.3)' },
        },
      },
    },
  },
  plugins: [],
};
