import { create } from 'zustand';
import { ActionType } from '@aegis/shared';
import { getSocket } from '@/lib/socket';
import { apiGet } from '@/lib/api';

interface HCSLogEntry {
  sequenceNumber: number;
  consensusTimestamp: string;
  topicId: string;
  transactionId: string;
  droneId: string;
  actionType: ActionType;
  operatorId: string;
  missionId: string;
  aiConfidence: number | null;
  payload: Record<string, unknown>;
  complianceLog: string;
  hashscanUrl?: string;
}

interface AIIntelUpdate {
  type: string;
  missionId: string;
  missionName?: string;
  riskScore: number;
  riskDelta?: number;
  weather?: {
    condition: string;
    windSpeedMs: number;
    visibilityM: number;
    thunderstorm: boolean;
  };
  threatLevel?: string;
  timestamp: string;
}

interface ThreatUpdate {
  threatId: string;
  type: string;
  position: { lat: number; lon: number; alt: number };
  radiusKm: number;
  confidence: number;
  description: string;
  active: boolean;
}

export type ModelTier = 'CLOUD_GPT4O' | 'LOCAL_70B' | 'LOCAL_7B' | 'RULE_ENGINE';

export interface ModelStatus {
  activeTier: ModelTier;
  lastRouting: { tier: ModelTier; reason: string; timestamp: string; latencyMs: number } | null;
  tiers: Record<string, { status: string }>;
}

export interface IntelFeedSummary {
  openSky: { available: boolean; source: string; count: number };
  adsbExchange: { available: boolean; source: string; count: number };
  openMeteo: { available: boolean; source: string };
  openWeatherMap: { available: boolean; source: string };
  noaaWeather: { available: boolean; source: string; alerts: number };
  faaTFR: { available: boolean; source: string; tfrs: number };
  noaaSpaceWeather: { available: boolean; source: string; kpIndex: number };
  openTopo: { available: boolean; source: string };
  usgs3dep: { available: boolean; source: string };
  radioRef: { available: boolean; source: string; frequencies: number };
  airLabs: { available: boolean; source: string; flights: number };
  airspaceLink: { available: boolean; source: string };
  aloftLAANC: { available: boolean; source: string };
}

export interface SpaceWeatherData {
  kpIndex: number;
  timeTag: string;
  gpsConfidence: string;
  riskDelta: number;
}

export interface CommandValidation {
  droneId: string;
  command: string;
  operatorId: string;
  approved: boolean;
  reasoning: string;
  timestamp: string;
}

export interface RILayerStatus {
  active: boolean;
  currentVersion: number;
  totalIterations: number;
  lastImprovement: string | null;
  accuracy: number;
  pendingApproval: boolean;
}

export interface RISystemStatus {
  enabled: boolean;
  layers: {
    prompt: RILayerStatus;
    capability: RILayerStatus;
    routing: RILayerStatus;
  };
  safety: {
    containmentIntact: boolean;
    goalInvariant: boolean;
    pendingHumanGates: number;
    rollbacksTriggered: number;
  };
  totalIterations: number;
  lastRefinement: string | null;
  successRate: number;
}

export interface RIRefinementEvent {
  layer: 'PROMPT' | 'CAPABILITY' | 'ROUTING';
  iteration: number;
  accepted: boolean;
  timestamp: string;
  accuracy?: number;
  improvement?: number;
  missionId?: string;
}

export interface RISafetyEvent {
  eventId: string;
  type: string;
  layer: string;
  severity: string;
  description: string;
  timestamp: string;
  resolved: boolean;
}

interface FeedStoreState {
  hcsLog: HCSLogEntry[];
  aiIntelFeed: AIIntelUpdate[];
  threats: ThreatUpdate[];
  autoScroll: boolean;
  actionTypeFilter: ActionType | null;
  missionFilter: string | null;
  maxLogEntries: number;
  modelStatus: ModelStatus | null;
  intelFeedSummary: IntelFeedSummary | null;
  spaceWeather: SpaceWeatherData | null;
  commandValidations: CommandValidation[];
  isLoadingFeeds: boolean;
  riStatus: RISystemStatus | null;
  riRefinements: RIRefinementEvent[];
  riSafetyEvents: RISafetyEvent[];
  addHCSEntry: (entry: HCSLogEntry) => void;
  addAIIntelUpdate: (update: AIIntelUpdate) => void;
  updateThreats: (threat: ThreatUpdate) => void;
  addCommandValidation: (v: CommandValidation) => void;
  setModelStatus: (status: ModelStatus) => void;
  setAutoScroll: (enabled: boolean) => void;
  setActionTypeFilter: (type: ActionType | null) => void;
  setMissionFilter: (missionId: string | null) => void;
  fetchInitialLog: () => Promise<void>;
  fetchThreats: () => Promise<void>;
  fetchModelStatus: () => Promise<void>;
  fetchIntelFeeds: (lat?: number, lon?: number) => Promise<void>;
  fetchSpaceWeather: () => Promise<void>;
  fetchRIStatus: () => Promise<void>;
  addRIRefinement: (event: RIRefinementEvent) => void;
  addRISafetyEvent: (event: RISafetyEvent) => void;
  startFeedListeners: () => void;
  getFilteredLog: () => HCSLogEntry[];
  detectSequenceGaps: () => number[];
}

export const useFeedStore = create<FeedStoreState>((set, get) => ({
  hcsLog: [],
  aiIntelFeed: [],
  threats: [],
  autoScroll: true,
  actionTypeFilter: null,
  missionFilter: null,
  maxLogEntries: 500,
  modelStatus: null,
  intelFeedSummary: null,
  spaceWeather: null,
  commandValidations: [],
  isLoadingFeeds: false,
  riStatus: null,
  riRefinements: [],
  riSafetyEvents: [],

  addHCSEntry: (entry) => {
    set((state) => {
      const updated = [entry, ...state.hcsLog].slice(0, state.maxLogEntries);
      return { hcsLog: updated };
    });
  },

  addAIIntelUpdate: (update) => {
    set((state) => ({
      aiIntelFeed: [update, ...state.aiIntelFeed].slice(0, 100),
    }));
  },

  updateThreats: (threat) => {
    set((state) => {
      const existing = state.threats.findIndex((t) => t.threatId === threat.threatId);
      if (existing >= 0) {
        const updated = [...state.threats];
        updated[existing] = threat;
        return { threats: updated };
      }
      return { threats: [...state.threats, threat] };
    });
  },

  setAutoScroll: (enabled) => set({ autoScroll: enabled }),
  setActionTypeFilter: (type) => set({ actionTypeFilter: type }),
  setMissionFilter: (missionId) => set({ missionFilter: missionId }),

  fetchInitialLog: async () => {
    try {
      const res = await apiGet<{ data: HCSLogEntry[] }>('/api/v1/log?pageSize=100');
      if (res.success && res.data?.data) {
        set({ hcsLog: res.data.data });
      }
    } catch {
      // Will populate via WebSocket
    }
  },

  fetchThreats: async () => {
    try {
      const res = await apiGet<{ threats: ThreatUpdate[] }>('/api/v1/intel/threats');
      if (res.success && res.data?.threats) {
        set({ threats: res.data.threats });
      }
    } catch {
      // Will populate via WebSocket
    }
  },

  addCommandValidation: (v) => {
    set((state) => ({
      commandValidations: [v, ...state.commandValidations].slice(0, 50),
    }));
  },

  setModelStatus: (status) => set({ modelStatus: status }),

  fetchModelStatus: async () => {
    try {
      const res = await apiGet<ModelStatus>('/api/v1/intel/model-status');
      if (res.success && res.data) {
        set({ modelStatus: res.data });
      }
    } catch { /* noop */ }
  },

  fetchIntelFeeds: async (lat = 34.052, lon = -118.244) => {
    set({ isLoadingFeeds: true });
    try {
      const res = await apiGet<{ feeds: unknown; summary: IntelFeedSummary }>(`/api/v1/intel/feeds?lat=${lat}&lon=${lon}`);
      if (res.success && res.data?.summary) {
        set({ intelFeedSummary: res.data.summary, isLoadingFeeds: false });
      } else {
        set({ isLoadingFeeds: false });
      }
    } catch {
      set({ isLoadingFeeds: false });
    }
  },

  fetchSpaceWeather: async () => {
    try {
      const res = await apiGet<SpaceWeatherData>('/api/v1/intel/space-weather');
      if (res.success && res.data) {
        set({ spaceWeather: res.data });
      }
    } catch { /* noop */ }
  },

  fetchRIStatus: async () => {
    try {
      const res = await apiGet<RISystemStatus>('/api/v1/intel/ri/status');
      if (res.success && res.data) {
        set({ riStatus: res.data });
      }
    } catch { /* noop */ }
  },

  addRIRefinement: (event) => {
    set((state) => ({
      riRefinements: [event, ...state.riRefinements].slice(0, 50),
    }));
  },

  addRISafetyEvent: (event) => {
    set((state) => ({
      riSafetyEvents: [event, ...state.riSafetyEvents].slice(0, 50),
    }));
  },

  startFeedListeners: () => {
    const missionSocket = getSocket('missionFeed');
    const aiSocket = getSocket('aiIntel');
    const threatSocket = getSocket('threats');

    if (missionSocket) {
      missionSocket.on('action:new', (data: HCSLogEntry) => {
        get().addHCSEntry(data);
      });
    }

    if (aiSocket) {
      aiSocket.on('ai:update', (data: AIIntelUpdate) => {
        get().addAIIntelUpdate(data);
      });
      aiSocket.on('ai:tier_change', (data: { tier: ModelTier; reason: string; timestamp: string; latencyMs: number }) => {
        set((state) => ({
          modelStatus: state.modelStatus
            ? { ...state.modelStatus, activeTier: data.tier, lastRouting: data }
            : { activeTier: data.tier, lastRouting: data, tiers: {} },
        }));
      });

      aiSocket.on('ri:status', (data: RISystemStatus) => {
        set({ riStatus: data });
      });

      aiSocket.on('ri:refinement', (data: RIRefinementEvent) => {
        get().addRIRefinement(data);
      });

      aiSocket.on('ri:safety', (data: RISafetyEvent) => {
        get().addRISafetyEvent(data);
      });

      aiSocket.on('ri:prompt_analysis', (data: RIRefinementEvent) => {
        get().addRIRefinement({ ...data, layer: 'PROMPT' });
      });
    }

    if (threatSocket) {
      threatSocket.on('threat:update', (data: ThreatUpdate) => {
        get().updateThreats(data);
      });
    }

    if (missionSocket) {
      missionSocket.on('command:validation', (data: CommandValidation) => {
        get().addCommandValidation(data);
      });
    }
  },

  getFilteredLog: () => {
    const { hcsLog, actionTypeFilter, missionFilter } = get();
    let result = hcsLog;
    if (actionTypeFilter) {
      result = result.filter((e) => e.actionType === actionTypeFilter);
    }
    if (missionFilter) {
      result = result.filter((e) => e.missionId === missionFilter);
    }
    return result;
  },

  detectSequenceGaps: () => {
    const { hcsLog } = get();
    const gaps: number[] = [];
    const sorted = [...hcsLog].sort((a, b) => a.sequenceNumber - b.sequenceNumber);
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i].sequenceNumber - sorted[i - 1].sequenceNumber > 1) {
        for (let g = sorted[i - 1].sequenceNumber + 1; g < sorted[i].sequenceNumber; g++) {
          gaps.push(g);
        }
      }
    }
    return gaps;
  },
}));
