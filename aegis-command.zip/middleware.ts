import { Request, Response, NextFunction, RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { redis } from '../redis';
import { logger } from '../logger';
import {
  OperatorRole,
  ROLE_PERMISSIONS,
  ROLE_HIERARCHY,
  CRITICAL_COMMANDS,
} from '@aegis/shared';

export interface JWTPayload {
  sub: string;
  username: string;
  callsign: string;
  role: OperatorRole;
  clearanceLevel: string;
  sessionId: string;
  type: 'access' | 'refresh';
  iat: number;
  exp: number;
}

declare global {
  namespace Express {
    interface Request {
      operator?: JWTPayload;
    }
  }
}

export function authMiddleware(requiredRole?: OperatorRole): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith('Bearer ')) {
        res.status(401).json({ success: false, error: 'Missing authorization header', timestamp: new Date().toISOString() });
        return;
      }

      const token = authHeader.slice(7);
      const decoded = jwt.verify(token, config.jwt.publicKey, {
        algorithms: ['RS256'],
      }) as JWTPayload;

      if (decoded.type !== 'access') {
        res.status(401).json({ success: false, error: 'Invalid token type', timestamp: new Date().toISOString() });
        return;
      }

      const sessionKey = `session:${decoded.sub}:${decoded.sessionId}`;
      const sessionExists = await redis.exists(sessionKey);
      if (!sessionExists) {
        res.status(401).json({ success: false, error: 'Session revoked or expired', timestamp: new Date().toISOString() });
        return;
      }

      if (requiredRole) {
        const userLevel = ROLE_HIERARCHY[decoded.role];
        const requiredLevel = ROLE_HIERARCHY[requiredRole];
        if (userLevel < requiredLevel) {
          res.status(403).json({ success: false, error: 'Insufficient role privileges', timestamp: new Date().toISOString() });
          return;
        }
      }

      req.operator = decoded;
      next();
    } catch (err) {
      if (err instanceof jwt.TokenExpiredError) {
        res.status(401).json({ success: false, error: 'Token expired', timestamp: new Date().toISOString() });
        return;
      }
      if (err instanceof jwt.JsonWebTokenError) {
        res.status(401).json({ success: false, error: 'Invalid token', timestamp: new Date().toISOString() });
        return;
      }
      logger.error({ err }, 'Auth middleware error');
      res.status(500).json({ success: false, error: 'Authentication error', timestamp: new Date().toISOString() });
    }
  };
}

export function rbacGuard(permission: string): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const permissions = ROLE_PERMISSIONS[req.operator.role];
    if (!permissions.includes(permission)) {
      logger.warn({ operatorId: req.operator.sub, permission, role: req.operator.role }, 'Permission denied');
      res.status(403).json({ success: false, error: `Permission '${permission}' required`, timestamp: new Date().toISOString() });
      return;
    }

    next();
  };
}

export function mfaChallenge(): RequestHandler {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const sessionKey = `session:${req.operator.sub}:${req.operator.sessionId}`;
    const mfaVerified = await redis.hget(sessionKey, 'mfa_verified_at');

    if (!mfaVerified) {
      res.status(403).json({ success: false, error: 'MFA verification required', timestamp: new Date().toISOString() });
      return;
    }

    const verifiedAt = new Date(mfaVerified).getTime();
    const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;

    if (verifiedAt < fiveMinutesAgo) {
      res.status(403).json({ success: false, error: 'MFA re-verification required for critical action', timestamp: new Date().toISOString() });
      return;
    }

    next();
  };
}

export async function sessionRevoke(operatorId: string): Promise<void> {
  const keys = await redis.keys(`session:${operatorId}:*`);
  if (keys.length > 0) {
    await redis.del(...keys);
  }
  logger.info({ operatorId, revokedCount: keys.length }, 'All sessions revoked');
}

export function isCriticalAction(action: string): boolean {
  return CRITICAL_COMMANDS.has(action);
}
