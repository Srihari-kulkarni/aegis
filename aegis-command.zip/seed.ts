import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { Pool } from 'pg';

const DATABASE_URL = process.env.DATABASE_URL ?? 'postgresql://aegis:aegis_secret@localhost:5432/aegis_command';
const pool = new Pool({ connectionString: DATABASE_URL });

interface SeedOperator {
  id: string;
  username: string;
  callsign: string;
  role: string;
  clearance: string;
  email: string;
  password: string;
}

const operators: SeedOperator[] = [
  { id: uuidv4(), username: 'admin', callsign: 'OVERLORD', role: 'SUPER_ADMIN', clearance: 'SCI', email: 'admin@aegis.mil', password: 'AegisAdmin!2025' },
  { id: uuidv4(), username: 'cmdr_hawk', callsign: 'HAWK-6', role: 'MISSION_COMMANDER', clearance: 'TOP_SECRET', email: 'hawk@aegis.mil', password: 'HawkCmdr!2025' },
  { id: uuidv4(), username: 'op_viper', callsign: 'VIPER-1', role: 'OPERATOR', clearance: 'SECRET', email: 'viper@aegis.mil', password: 'ViperOp!2025' },
  { id: uuidv4(), username: 'analyst_raven', callsign: 'RAVEN-3', role: 'ANALYST', clearance: 'SECRET', email: 'raven@aegis.mil', password: 'RavenAnalyst!2025' },
  { id: uuidv4(), username: 'ai_system', callsign: 'AEGIS-AI', role: 'AI_SYSTEM', clearance: 'TOP_SECRET', email: 'ai@aegis.mil', password: 'AegisAI!System' },
  { id: uuidv4(), username: 'auditor_eagle', callsign: 'EAGLE-9', role: 'AUDITOR', clearance: 'CONFIDENTIAL', email: 'eagle@aegis.mil', password: 'EagleAudit!2025' },
];

interface SeedDrone {
  id: string;
  callsign: string;
  droneClass: string;
  model: string;
  manufacturer: string;
  serial: string;
  lat: number;
  lon: number;
  alt: number;
  metrics: Record<string, unknown>;
}

const drones: SeedDrone[] = [
  { id: uuidv4(), callsign: 'SHADOW-1', droneClass: 'RECON', model: 'RQ-180', manufacturer: 'Northrop Grumman', serial: 'NG-RQ180-0001', lat: 34.052, lon: -118.244, alt: 12000, metrics: { sensors: ['EO', 'IR', 'SAR', 'SIGINT'], stealthMode: false, groundResolutionCm: 15, recordingHours: 24 } },
  { id: uuidv4(), callsign: 'STRIKER-1', droneClass: 'OFFENSE', model: 'MQ-9B', manufacturer: 'General Atomics', serial: 'GA-MQ9B-0001', lat: 34.055, lon: -118.248, alt: 8000, metrics: { armingState: 'SAFE', payloadKg: 250, seekerLocked: false, loiteringMunition: false, dualOperatorConfirmed: false } },
  { id: uuidv4(), callsign: 'MULE-1', droneClass: 'DELIVERY', model: 'K-MAX', manufacturer: 'Kaman', serial: 'KM-KMAX-0001', lat: 34.060, lon: -118.240, alt: 500, metrics: { payloadBays: [{ bay: 1, status: 'LOADED', weightKg: 45 }, { bay: 2, status: 'EMPTY', weightKg: 0 }], casevacMode: false } },
  { id: uuidv4(), callsign: 'PHANTOM-1', droneClass: 'EW', model: 'EA-18G', manufacturer: 'Boeing', serial: 'BA-EA18G-0001', lat: 34.048, lon: -118.250, alt: 15000, metrics: { jammingActive: false, activeBands: [], eirpWatts: 5000, targetsInRange: 0, drfmSpoofing: false } },
  { id: uuidv4(), callsign: 'NEXUS-1', droneClass: 'RELAY', model: 'RQ-7B', manufacturer: 'AAI Corp', serial: 'AAI-RQ7B-0001', lat: 34.058, lon: -118.238, alt: 6000, metrics: { meshPeers: 3, bandwidthUtilization: 0.35, satcomBridge: true, tethered: false, loiterAlt: 6000 } },
  { id: uuidv4(), callsign: 'HIVE-1', droneClass: 'SWARM', model: 'OFFSET-S', manufacturer: 'DARPA', serial: 'DA-OFFS-0001', lat: 34.053, lon: -118.242, alt: 300, metrics: { swarmId: 'SWARM-ALPHA', nodeIndex: 0, consensusProtocol: 'RAFT', autonomyLevel: 'SUPERVISED', neighborCount: 5, syncLatencyMs: 12 } },
  { id: uuidv4(), callsign: 'HAZMAT-1', droneClass: 'CBRN', model: 'DR-X1', manufacturer: 'Chemring', serial: 'CH-DRX1-0001', lat: 34.050, lon: -118.246, alt: 100, metrics: { chemicalDetectors: { Sarin: false, VX: false, Mustard: false, Novichok: false }, bioSamplerCount: 6, radiationMsv: 0.02, contaminationZone: null } },
  { id: uuidv4(), callsign: 'DEPTH-1', droneClass: 'UNDERWATER', model: 'Orca XLUUV', manufacturer: 'Boeing', serial: 'BA-ORCA-0001', lat: 33.750, lon: -118.400, alt: -50, metrics: { depthMeters: 50, sonarActive: true, mineDetectionConfidence: 0.0, subsurfaceComms: 'ELF', surfaceIntervalMin: 120 } },
  { id: uuidv4(), callsign: 'SENTINEL-1', droneClass: 'LARGE_ALTITUDE', model: 'RQ-4B', manufacturer: 'Northrop Grumman', serial: 'NG-RQ4B-0001', lat: 34.070, lon: -118.260, alt: 55000, metrics: { classification: 'HALE', serviceCeilingFt: 60000, persistentISRHours: 32, strategicRelay: true, blosCertified: true } },
  { id: uuidv4(), callsign: 'BUG-1', droneClass: 'MICRO', model: 'Black Hornet 4', manufacturer: 'FLIR', serial: 'FL-BH4-0001', lat: 34.051, lon: -118.243, alt: 30, metrics: { urbanMode: true, covertOps: true, singleUse: false, indoorNav: true, acousticSignatureDb: 25 } },
];

async function seed(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    console.log('Seeding operators...');
    for (const op of operators) {
      const hash = await bcrypt.hash(op.password, 12);
      await client.query(
        `INSERT INTO operators (operator_id, username, callsign, role, clearance_level, email, password_hash, active)
         VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE)
         ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = EXCLUDED.role`,
        [op.id, op.username, op.callsign, op.role, op.clearance, op.email, hash]
      );
      console.log(`  ✓ ${op.callsign} (${op.role}) — username: ${op.username}, password: ${op.password}`);
    }

    console.log('\nSeeding drones...');
    for (const d of drones) {
      await client.query(
        `INSERT INTO drones (drone_id, callsign, drone_class, model, manufacturer, serial_number, position_lat, position_lon, position_alt, type_metrics)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         ON CONFLICT (callsign) DO UPDATE SET type_metrics = EXCLUDED.type_metrics`,
        [d.id, d.callsign, d.droneClass, d.model, d.manufacturer, d.serial, d.lat, d.lon, d.alt, JSON.stringify(d.metrics)]
      );
      console.log(`  ✓ ${d.callsign} (${d.droneClass}) — ${d.model}`);
    }

    console.log('\nSeeding no-fly zones...');
    await client.query(
      `INSERT INTO no_fly_zones (name, polygon, floor_ft, ceiling_ft, permanent, reason)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT DO NOTHING`,
      [
        'LAX TFR',
        JSON.stringify({ type: 'Polygon', coordinates: [[[-118.42, 33.93], [-118.42, 33.96], [-118.38, 33.96], [-118.38, 33.93], [-118.42, 33.93]]] }),
        0, 18000, true, 'LAX Class B Airspace — No UAS without ATC clearance',
      ]
    );
    console.log('  ✓ LAX TFR zone');

    console.log('\nSeeding threats...');
    await client.query(
      `INSERT INTO threats (type, position_lat, position_lon, radius_km, confidence, hostile_unit_id, description, active)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      ['COUNTER_UAS', 34.045, -118.255, 2.5, 0.72, 'HU-001', 'Suspected C-UAS radar system detected via SIGINT', true]
    );
    console.log('  ✓ Counter-UAS threat');

    await client.query('COMMIT');
    console.log('\n✅ Seed completed successfully');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Seed failed:', err);
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
