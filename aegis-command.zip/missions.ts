import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';
import { query, withTransaction } from '../db/pool';
import { redis } from '../redis';
import { config } from '../config';
import { authMiddleware, rbacGuard, mfaChallenge } from '../auth/middleware';
import { hcsService } from '../hedera/HCSService';
import { aiEngine } from '../ai/AIMissionApprovalEngine';
import { telemetrySimulator } from '../simulator/TelemetrySimulator';
import { logger } from '../logger';
import {
  ActionType,
  MissionStatus,
  MissionType,
  ClearanceLevel,
  OperatorRole,
  zuluTimestamp,
  type Mission,
  type AIAssessment,
  type MissionContext,
  type PaginatedResponse,
  type HCSMessage,
} from '@aegis/shared';

const router = Router();

const demoMissionStore: Mission[] = [];
let demoMissionsInitialized = false;

function initDemoMissions(): void {
  if (demoMissionsInitialized) return;
  demoMissionsInitialized = true;
  const now = new Date();
  const later = new Date(now.getTime() + 3600000);

  demoMissionStore.push(
    {
      missionId: 'demo-mission-001',
      name: 'OVERWATCH ALPHA',
      type: MissionType.PERSISTENT_SURVEILLANCE,
      status: MissionStatus.ACTIVE,
      commanderId: 'demo-commander',
      commanderCallsign: 'AEGIS-CMD',
      description: 'Persistent ISR surveillance over sector 7-G. Monitoring critical infrastructure.',
      areaOfOperations: { type: 'Polygon', coordinates: [[[-118.3, 34.1], [-118.2, 34.1], [-118.2, 34.0], [-118.3, 34.0], [-118.3, 34.1]]] },
      waypoints: [
        { index: 0, position: { lat: 34.05, lon: -118.25, alt: 300 }, action: 'FLY_TO' as const, reached: false },
        { index: 1, position: { lat: 34.07, lon: -118.22, alt: 350 }, action: 'LOITER' as const, loiterDurationSec: 600, reached: false },
        { index: 2, position: { lat: 34.04, lon: -118.28, alt: 300 }, action: 'SURVEY' as const, reached: false },
      ],
      assignedDroneIds: ['demo-recon-001', 'demo-sigint-001'],
      hcsTopicId: '0.0.demo-topic-1',
      aiAssessmentId: 'demo-assessment-001',
      plannedStartTime: now.toISOString(),
      plannedEndTime: later.toISOString(),
      actualStartTime: now.toISOString(),
      actualEndTime: null,
      clearanceLevel: ClearanceLevel.SECRET,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      missionId: 'demo-mission-002',
      name: 'IRON RELAY',
      type: MissionType.LOGISTICS,
      status: MissionStatus.AI_APPROVED,
      commanderId: 'demo-commander',
      commanderCallsign: 'AEGIS-CMD',
      description: 'Emergency resupply to forward operating base. Priority cargo delivery.',
      areaOfOperations: { type: 'Polygon', coordinates: [[[-118.35, 34.12], [-118.25, 34.12], [-118.25, 34.02], [-118.35, 34.02], [-118.35, 34.12]]] },
      waypoints: [
        { index: 0, position: { lat: 34.06, lon: -118.30, alt: 200 }, action: 'FLY_TO' as const, reached: false },
        { index: 1, position: { lat: 34.08, lon: -118.27, alt: 150 }, action: 'DELIVER' as const, reached: false },
        { index: 2, position: { lat: 34.06, lon: -118.30, alt: 200 }, action: 'RETURN' as const, reached: false },
      ],
      assignedDroneIds: ['demo-delivery-001'],
      hcsTopicId: '0.0.demo-topic-2',
      aiAssessmentId: 'demo-assessment-002',
      plannedStartTime: new Date(now.getTime() + 1800000).toISOString(),
      plannedEndTime: new Date(now.getTime() + 5400000).toISOString(),
      actualStartTime: null,
      actualEndTime: null,
      clearanceLevel: ClearanceLevel.CONFIDENTIAL,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      missionId: 'demo-mission-003',
      name: 'PHANTOM WATCH',
      type: MissionType.ISR,
      status: MissionStatus.PENDING_AI_REVIEW,
      commanderId: 'demo-commander',
      commanderCallsign: 'AEGIS-CMD',
      description: 'Deep-area reconnaissance of suspected hostile staging zone.',
      areaOfOperations: null,
      waypoints: [
        { index: 0, position: { lat: 34.09, lon: -118.20, alt: 500 }, action: 'FLY_TO' as const, reached: false },
        { index: 1, position: { lat: 34.10, lon: -118.18, alt: 500 }, action: 'SURVEY' as const, reached: false },
      ],
      assignedDroneIds: ['demo-recon-001'],
      hcsTopicId: null,
      aiAssessmentId: null,
      plannedStartTime: new Date(now.getTime() + 7200000).toISOString(),
      plannedEndTime: new Date(now.getTime() + 14400000).toISOString(),
      actualStartTime: null,
      actualEndTime: null,
      clearanceLevel: ClearanceLevel.TOP_SECRET,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
  );
}

// ---------------------------------------------------------------------------
// Zod schemas
// ---------------------------------------------------------------------------

const geoPositionSchema = z.object({
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  alt: z.number(),
  mgrs: z.string().optional(),
});

const waypointSchema = z.object({
  index: z.number().int().min(0),
  position: geoPositionSchema,
  action: z.enum(['FLY_TO', 'LOITER', 'SURVEY', 'DELIVER', 'RETURN', 'LAND']),
  loiterDurationSec: z.number().int().min(0).optional(),
  speedKnots: z.number().min(0).optional(),
  altitudeOverride: z.number().optional(),
});

const polygonSchema = z.object({
  type: z.literal('Polygon'),
  coordinates: z.array(z.array(z.array(z.number()).min(2).max(3))).min(1),
});

const createMissionSchema = z.object({
  name: z.string().min(1).max(200),
  type: z.nativeEnum(MissionType),
  description: z.string().min(1).max(5000),
  areaOfOperations: polygonSchema.nullable(),
  waypoints: z.array(waypointSchema).min(1),
  assignedDroneIds: z.array(z.string()).min(1),
  plannedStartTime: z.string().datetime(),
  plannedEndTime: z.string().datetime(),
  clearanceLevel: z.nativeEnum(ClearanceLevel),
});

const missionListQuerySchema = z.object({
  status: z.nativeEnum(MissionStatus).optional(),
  type: z.nativeEnum(MissionType).optional(),
  commanderId: z.string().uuid().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

const overrideBodySchema = z.object({
  reason: z.string().min(10).max(2000),
  secondConfirmOperatorId: z.string().uuid(),
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function apiResponse<T>(data: T, success = true) {
  return { success, data, timestamp: new Date().toISOString() };
}

function apiError(error: string, status: number, res: Response): void {
  res.status(status).json({ success: false, error, timestamp: new Date().toISOString() });
}

function missionRowToEntity(row: Record<string, unknown>): Mission {
  return {
    missionId: row.mission_id as string,
    name: row.name as string,
    type: row.type as MissionType,
    status: row.status as MissionStatus,
    commanderId: row.commander_id as string,
    commanderCallsign: row.commander_callsign as string,
    description: row.description as string,
    areaOfOperations: (row.area_of_operations as Mission['areaOfOperations']) ?? null,
    waypoints: (row.waypoints as Mission['waypoints']) ?? [],
    assignedDroneIds: (row.assigned_drone_ids as string[]) ?? [],
    hcsTopicId: (row.hcs_topic_id as string) ?? null,
    aiAssessmentId: (row.ai_assessment_id as string) ?? null,
    plannedStartTime: row.planned_start_time as string,
    plannedEndTime: row.planned_end_time as string,
    actualStartTime: (row.actual_start_time as string) ?? null,
    actualEndTime: (row.actual_end_time as string) ?? null,
    clearanceLevel: row.clearance_level as ClearanceLevel,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

// ---------------------------------------------------------------------------
// POST /api/v1/missions — create mission + auto-trigger AI assessment
// ---------------------------------------------------------------------------

router.post(
  '/',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = createMissionSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const operator = req.operator!;
      const body = parsed.data;
      const missionId = uuidv4();

      if (new Date(body.plannedEndTime) <= new Date(body.plannedStartTime)) {
        apiError('plannedEndTime must be after plannedStartTime', 400, res);
        return;
      }

      const waypointsWithState = body.waypoints.map((wp) => ({
        ...wp,
        reached: false,
        reachedAt: undefined,
      }));

      // In demo mode, create directly in the in-memory store
      if (config.demoMode) {
        initDemoMissions();
        const now = new Date();
        const newMission: Mission = {
          missionId,
          name: body.name,
          type: body.type,
          status: MissionStatus.PENDING_AI_REVIEW,
          commanderId: operator.sub,
          commanderCallsign: operator.callsign,
          description: body.description,
          areaOfOperations: body.areaOfOperations ?? null,
          waypoints: waypointsWithState as Mission['waypoints'],
          assignedDroneIds: body.assignedDroneIds,
          hcsTopicId: null,
          aiAssessmentId: null,
          plannedStartTime: body.plannedStartTime,
          plannedEndTime: body.plannedEndTime,
          actualStartTime: null,
          actualEndTime: null,
          clearanceLevel: body.clearanceLevel,
          createdAt: now.toISOString(),
          updatedAt: now.toISOString(),
        };
        demoMissionStore.push(newMission);
        logger.info({ missionId, name: body.name, commanderId: operator.sub }, 'Demo mission created');
        res.status(201).json(apiResponse({ mission: newMission, assessment: null }));
        return;
      }

      const droneCheck = await query<{ drone_id: string }>(
        `SELECT drone_id FROM drones WHERE drone_id = ANY($1::uuid[])`,
        [body.assignedDroneIds],
      );
      if (droneCheck.rowCount !== body.assignedDroneIds.length) {
        const found = new Set(droneCheck.rows.map((r) => r.drone_id));
        const missing = body.assignedDroneIds.filter((id) => !found.has(id));
        apiError(`Unknown drone IDs: ${missing.join(', ')}`, 400, res);
        return;
      }

      const hcsTopicId = await hcsService.createMissionTopic(missionId, operator.sub);

      const result = await withTransaction(async (client) => {
        const insertResult = await client.query(
          `INSERT INTO missions
           (mission_id, name, type, status, commander_id, commander_callsign,
            description, area_of_operations, waypoints, assigned_drone_ids,
            hcs_topic_id, planned_start_time, planned_end_time, clearance_level)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
           RETURNING *`,
          [
            missionId,
            body.name,
            body.type,
            MissionStatus.PENDING_AI_REVIEW,
            operator.sub,
            operator.callsign,
            body.description,
            body.areaOfOperations ? JSON.stringify(body.areaOfOperations) : null,
            JSON.stringify(waypointsWithState),
            body.assignedDroneIds,
            hcsTopicId,
            body.plannedStartTime,
            body.plannedEndTime,
            body.clearanceLevel,
          ],
        );
        return insertResult.rows[0];
      });

      const mission = missionRowToEntity(result as Record<string, unknown>);

      logger.info({ missionId, name: body.name, commanderId: operator.sub }, 'Mission created');

      const missionContext: MissionContext = {
        mission,
        assignedDrones: [],
        weatherData: null,
        airspaceData: null,
        threatData: null,
        operatorClearance: operator.clearanceLevel as ClearanceLevel,
        commanderCallsign: operator.callsign,
      };

      let assessment: AIAssessment | null = null;
      try {
        assessment = await aiEngine.assessMission(missionContext);
      } catch (err) {
        logger.error({ err, missionId }, 'AI assessment failed after mission creation');
      }

      const refreshed = await query(
        'SELECT * FROM missions WHERE mission_id = $1',
        [missionId],
      );
      const updatedMission = missionRowToEntity(refreshed.rows[0] as Record<string, unknown>);

      res.status(201).json(apiResponse({ mission: updatedMission, assessment }));
    } catch (err) {
      logger.error({ err }, 'Create mission error');
      apiError('Failed to create mission', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /api/v1/missions — list with query filters + pagination
// ---------------------------------------------------------------------------

router.get(
  '/',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = missionListQuerySchema.safeParse(req.query);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Invalid query parameters',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { status, type, commanderId, page, pageSize } = parsed.data;
      const conditions: string[] = [];
      const params: unknown[] = [];
      let paramIdx = 1;

      if (status) {
        conditions.push(`status = $${paramIdx++}`);
        params.push(status);
      }
      if (type) {
        conditions.push(`type = $${paramIdx++}`);
        params.push(type);
      }
      if (commanderId) {
        conditions.push(`commander_id = $${paramIdx++}`);
        params.push(commanderId);
      }

      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      const countResult = await query<{ count: string }>(
        `SELECT COUNT(*) as count FROM missions ${whereClause}`,
        params,
      );
      const total = countResult.rows[0] ? parseInt(countResult.rows[0].count, 10) : 0;

      let missions: Mission[];

      if (total > 0) {
        const offset = (page - 1) * pageSize;
        const dataResult = await query(
          `SELECT * FROM missions ${whereClause}
           ORDER BY created_at DESC
           LIMIT $${paramIdx++} OFFSET $${paramIdx}`,
          [...params, pageSize, offset],
        );
        missions = dataResult.rows.map((r) => missionRowToEntity(r as Record<string, unknown>));
      } else if (config.demoMode) {
        initDemoMissions();
        let filtered = [...demoMissionStore];
        if (status) filtered = filtered.filter((m) => m.status === status);
        if (type) filtered = filtered.filter((m) => m.type === type);
        if (commanderId) filtered = filtered.filter((m) => m.commanderId === commanderId);
        missions = filtered.slice((page - 1) * pageSize, page * pageSize);
      } else {
        missions = [];
      }

      const finalTotal = total > 0 ? total : missions.length;
      const payload: PaginatedResponse<Mission> = {
        data: missions,
        total: finalTotal,
        page,
        pageSize,
        totalPages: Math.ceil(finalTotal / pageSize) || 1,
      };

      res.json(apiResponse(payload));
    } catch (err) {
      logger.error({ err }, 'List missions error');
      apiError('Failed to list missions', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /api/v1/missions/:id — full detail with AI assessment + HCS messages
// ---------------------------------------------------------------------------

router.get(
  '/:id',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;

      const missionResult = await query('SELECT * FROM missions WHERE mission_id = $1', [id]);
      let mission: Mission;

      if (missionResult.rowCount === 0 || missionResult.rows.length === 0) {
        if (config.demoMode) {
          initDemoMissions();
          const demoMission = demoMissionStore.find((m) => m.missionId === id);
          if (!demoMission) {
            apiError('Mission not found', 404, res);
            return;
          }
          mission = demoMission;
        } else {
          apiError('Mission not found', 404, res);
          return;
        }
      } else {
        mission = missionRowToEntity(missionResult.rows[0] as Record<string, unknown>);
      }

      let assessment: AIAssessment | null = null;
      if (mission.aiAssessmentId) {
        const assessResult = await query(
          `SELECT assessment_id, mission_id, recommendation, confidence, risk_score,
                  reasoning, risk_factors, mitigations, weather_data, airspace_data,
                  threat_data, fleet_status, model_version, hcs_transaction_id,
                  created_at as assessed_at
           FROM ai_assessments WHERE assessment_id = $1`,
          [mission.aiAssessmentId],
        );
        if (assessResult.rowCount! > 0) {
          const row = assessResult.rows[0] as Record<string, unknown>;
          assessment = {
            assessmentId: row.assessment_id as string,
            missionId: row.mission_id as string,
            recommendation: row.recommendation as AIAssessment['recommendation'],
            confidence: parseFloat(String(row.confidence)),
            riskScore: parseFloat(String(row.risk_score)),
            reasoning: row.reasoning as string,
            riskFactors: row.risk_factors as AIAssessment['riskFactors'],
            mitigations: row.mitigations as string[],
            weatherData: row.weather_data as AIAssessment['weatherData'],
            airspaceData: row.airspace_data as AIAssessment['airspaceData'],
            threatData: row.threat_data as AIAssessment['threatData'],
            fleetStatus: row.fleet_status as AIAssessment['fleetStatus'],
            modelVersion: row.model_version as string,
            assessedAt: row.assessed_at as string,
            hcsTransactionId: (row.hcs_transaction_id as string) ?? null,
          };
        }
      }

      let hcsMessages: HCSMessage[] = [];
      if (mission.hcsTopicId) {
        hcsMessages = await hcsService.getTopicMessages(mission.hcsTopicId);
      }

      res.json(apiResponse({ mission, assessment, hcsMessages }));
    } catch (err) {
      logger.error({ err }, 'Get mission detail error');
      apiError('Failed to retrieve mission', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /api/v1/missions/:id/approve — commander approval
// ---------------------------------------------------------------------------

router.post(
  '/:id/approve',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const operator = req.operator!;

      const missionResult = await query<{
        mission_id: string; status: string; hcs_topic_id: string | null;
      }>(
        'SELECT mission_id, status, hcs_topic_id FROM missions WHERE mission_id = $1',
        [id],
      );

      let currentStatus: string;
      let topicId: string | null;
      let isDemo = false;

      if (missionResult.rowCount === 0 || missionResult.rows.length === 0) {
        if (config.demoMode) {
          initDemoMissions();
          const dm = demoMissionStore.find((m) => m.missionId === id);
          if (!dm) { apiError('Mission not found', 404, res); return; }
          currentStatus = dm.status;
          topicId = dm.hcsTopicId;
          isDemo = true;
        } else {
          apiError('Mission not found', 404, res);
          return;
        }
      } else {
        const row = missionResult.rows[0];
        currentStatus = row.status;
        topicId = row.hcs_topic_id;
      }

      const validStatuses = [MissionStatus.AI_APPROVED, MissionStatus.PENDING_AI_REVIEW];
      if (!validStatuses.includes(currentStatus as MissionStatus)) {
        apiError(
          `Cannot approve mission in status '${currentStatus}'. Must be AI_APPROVED or PENDING_AI_REVIEW.`,
          409,
          res,
        );
        return;
      }

      if (isDemo) {
        const dm = demoMissionStore.find((m) => m.missionId === id)!;
        dm.status = MissionStatus.ACTIVE;
        dm.actualStartTime = new Date().toISOString();
        dm.updatedAt = new Date().toISOString();

        const missionWaypoints = (dm.waypoints ?? []).map((wp) => ({
          lat: wp.position.lat,
          lon: wp.position.lon,
          alt: wp.position.alt,
        }));

        if (missionWaypoints.length > 0) {
          telemetrySimulator.dispatchDronesToMission(id, dm.assignedDroneIds, missionWaypoints);
        }
      } else {
        await query(
          `UPDATE missions SET status = $1, actual_start_time = NOW(), updated_at = NOW() WHERE mission_id = $2`,
          [MissionStatus.ACTIVE, id],
        );
      }

      let hcsRecord: HCSMessage | null = null;
      if (topicId) {
        hcsRecord = await hcsService.submitAction({
          topicId,
          droneId: 'SYSTEM',
          actionType: ActionType.MISSION_APPROVED,
          operatorId: operator.sub,
          missionId: id,
          payload: { approvedBy: operator.callsign, role: operator.role },
        });
      }

      logger.info({ missionId: id, approvedBy: operator.callsign }, 'Mission approved and activated');

      let mission: Mission;
      if (isDemo) {
        mission = demoMissionStore.find((m) => m.missionId === id)!;
      } else {
        const updated = await query('SELECT * FROM missions WHERE mission_id = $1', [id]);
        mission = missionRowToEntity(updated.rows[0] as Record<string, unknown>);
      }

      res.json(apiResponse({ mission, hcsRecord }));
    } catch (err) {
      logger.error({ err }, 'Approve mission error');
      apiError('Failed to approve mission', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /api/v1/missions/:id/abort — abort active mission
// ---------------------------------------------------------------------------

router.post(
  '/:id/abort',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const operator = req.operator!;

      const missionResult = await query<{
        mission_id: string; status: string; hcs_topic_id: string | null;
        assigned_drone_ids: string[];
      }>(
        'SELECT mission_id, status, hcs_topic_id, assigned_drone_ids FROM missions WHERE mission_id = $1',
        [id],
      );

      let currentStatus: string;
      let topicId: string | null;
      let isDemo = false;
      let assignedDroneIds: string[] = [];

      if (missionResult.rowCount === 0 || missionResult.rows.length === 0) {
        if (config.demoMode) {
          initDemoMissions();
          const dm = demoMissionStore.find((m) => m.missionId === id);
          if (!dm) { apiError('Mission not found', 404, res); return; }
          currentStatus = dm.status;
          topicId = dm.hcsTopicId;
          assignedDroneIds = dm.assignedDroneIds;
          isDemo = true;
        } else {
          apiError('Mission not found', 404, res);
          return;
        }
      } else {
        const row = missionResult.rows[0];
        currentStatus = row.status;
        topicId = row.hcs_topic_id;
        assignedDroneIds = row.assigned_drone_ids ?? [];
      }

      const abortable = [
        MissionStatus.ACTIVE,
        MissionStatus.PAUSED,
        MissionStatus.COMMANDER_APPROVED,
        MissionStatus.AI_APPROVED,
        MissionStatus.PENDING_AI_REVIEW,
      ];
      if (!abortable.includes(currentStatus as MissionStatus)) {
        apiError(`Cannot abort mission in status '${currentStatus}'`, 409, res);
        return;
      }

      if (isDemo) {
        const dm = demoMissionStore.find((m) => m.missionId === id)!;
        dm.status = MissionStatus.ABORTED;
        dm.actualEndTime = new Date().toISOString();
        dm.updatedAt = new Date().toISOString();
        telemetrySimulator.recallDronesFromMission(id);
      } else {
        await withTransaction(async (client) => {
          await client.query(
            `UPDATE missions SET status = $1, actual_end_time = NOW(), updated_at = NOW()
             WHERE mission_id = $2`,
            [MissionStatus.ABORTED, id],
          );

          if (assignedDroneIds.length) {
            await client.query(
              `UPDATE drones SET current_mission_id = NULL, status = 'RETURNING'
               WHERE drone_id = ANY($1::uuid[]) AND current_mission_id = $2`,
              [assignedDroneIds, id],
            );
          }
        });
      }

      let hcsRecord: HCSMessage | null = null;
      if (topicId) {
        hcsRecord = await hcsService.submitAction({
          topicId,
          droneId: 'SYSTEM',
          actionType: ActionType.MISSION_ABORTED,
          operatorId: operator.sub,
          missionId: id,
          payload: { abortedBy: operator.callsign, previousStatus: currentStatus },
        });
      }

      await redis.del(`mission:active:${id}`);

      logger.warn({ missionId: id, abortedBy: operator.callsign }, 'Mission aborted');

      let mission: Mission;
      if (isDemo) {
        mission = demoMissionStore.find((m) => m.missionId === id)!;
      } else {
        const updated = await query('SELECT * FROM missions WHERE mission_id = $1', [id]);
        mission = missionRowToEntity(updated.rows[0] as Record<string, unknown>);
      }

      res.json(apiResponse({ mission, hcsRecord }));
    } catch (err) {
      logger.error({ err }, 'Abort mission error');
      apiError('Failed to abort mission', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /api/v1/missions/:id/override — override AI rejection (dual-operator MFA)
// ---------------------------------------------------------------------------

router.post(
  '/:id/override',
  authMiddleware(OperatorRole.MISSION_COMMANDER),
  rbacGuard('mission:override'),
  mfaChallenge(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const operator = req.operator!;

      const parsed = overrideBodySchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { reason, secondConfirmOperatorId } = parsed.data;

      if (secondConfirmOperatorId === operator.sub) {
        apiError('Second confirming operator must be a different person', 400, res);
        return;
      }

      const secondOpResult = await query<{
        operator_id: string; role: string; callsign: string; mfa_enabled: boolean;
      }>(
        `SELECT operator_id, role, callsign, mfa_enabled FROM operators
         WHERE operator_id = $1 AND active = TRUE`,
        [secondConfirmOperatorId],
      );

      if (secondOpResult.rowCount === 0) {
        apiError('Second confirming operator not found or inactive', 404, res);
        return;
      }

      const secondOp = secondOpResult.rows[0];
      const validRoles: string[] = [OperatorRole.SUPER_ADMIN, OperatorRole.MISSION_COMMANDER];
      if (!validRoles.includes(secondOp.role)) {
        apiError(
          'Second confirming operator must hold SUPER_ADMIN or MISSION_COMMANDER role',
          403,
          res,
        );
        return;
      }

      const secondMfaKey = `override:mfa:${id}:${secondConfirmOperatorId}`;
      const secondMfaVerified = await redis.get(secondMfaKey);
      if (!secondMfaVerified) {
        apiError(
          'Second operator MFA confirmation required. They must verify MFA for this override first.',
          403,
          res,
        );
        return;
      }

      const missionResult = await query<{
        mission_id: string; status: string; hcs_topic_id: string | null;
        ai_assessment_id: string | null;
      }>(
        'SELECT mission_id, status, hcs_topic_id, ai_assessment_id FROM missions WHERE mission_id = $1',
        [id],
      );

      if (missionResult.rowCount === 0) {
        apiError('Mission not found', 404, res);
        return;
      }

      const row = missionResult.rows[0];
      if (row.status !== MissionStatus.AI_REJECTED) {
        apiError(
          `Override only applicable to AI_REJECTED missions. Current status: '${row.status}'`,
          409,
          res,
        );
        return;
      }

      await query(
        `UPDATE missions SET status = $1, updated_at = NOW() WHERE mission_id = $2`,
        [MissionStatus.COMMANDER_APPROVED, id],
      );

      let hcsRecord: HCSMessage | null = null;
      if (row.hcs_topic_id) {
        hcsRecord = await hcsService.submitAction({
          topicId: row.hcs_topic_id,
          droneId: 'SYSTEM',
          actionType: ActionType.AI_OVERRIDE,
          operatorId: operator.sub,
          missionId: id,
          payload: {
            overriddenBy: operator.callsign,
            secondConfirm: secondOp.callsign,
            secondConfirmOperatorId,
            reason,
            previousAssessmentId: row.ai_assessment_id,
          },
        });
      }

      await redis.del(secondMfaKey);

      logger.warn(
        { missionId: id, overriddenBy: operator.callsign, secondConfirm: secondOp.callsign },
        'AI rejection overridden by dual-operator authorization',
      );

      const updated = await query('SELECT * FROM missions WHERE mission_id = $1', [id]);
      const mission = missionRowToEntity(updated.rows[0] as Record<string, unknown>);

      res.json(apiResponse({ mission, hcsRecord, overrideDetails: { reason, secondConfirm: secondOp.callsign } }));
    } catch (err) {
      logger.error({ err }, 'Override mission error');
      apiError('Failed to override AI rejection', 500, res);
    }
  },
);

export { router as missionRouter };
