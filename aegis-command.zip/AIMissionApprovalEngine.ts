import OpenAI from 'openai';
import { config } from '../config';
import { redis, redisPub } from '../redis';
import { query, withTransaction } from '../db/pool';
import { hcsService } from '../hedera/HCSService';
import { logger } from '../logger';
import { modelRouter } from './model-router';
import { intelInjector } from './airllm-intel-injector';
import { riSystem, type MissionOutcome } from './recursive-improvement';
import {
  ActionType,
  AIAssessment,
  AirspaceData,
  FleetDroneStatus,
  MissionContext,
  MissionStatus,
  RiskFactor,
  ThreatIntel,
  WeatherData,
  DroneStatus,
  ThreatType,
  zuluTimestamp,
} from '@aegis/shared';
import { v4 as uuidv4 } from 'uuid';

const MODEL_VERSION = 'gpt-4o';

const AEGIS_SYSTEM_PROMPT = `You are AEGIS AI — a military-grade mission approval engine for unmanned aerial systems. You assess mission plans against environmental, threat, fleet readiness, and airspace conditions.

ABORT THRESHOLDS (hard rules — override your assessment):
- Wind speed > 15 m/s → REJECT (ABORT)
- Visibility < 1000m → REJECT (restricted ops only)
- Active TFR within AO without exemption → REJECT
- Threat level HIGH within 10km of AO → HOLD (require commander decision)
- Any assigned drone health < 0.6 → remove from roster (HOLD if critical asset)
- Thunderstorm detected within AO → REJECT (ground all)
- If your confidence in approval < 0.70 → output HOLD (escalate to commander)
- Risk score > 0.75 → REJECT

Respond ONLY with valid JSON matching this schema:
{
  "recommendation": "APPROVE" | "REJECT" | "HOLD",
  "confidence": 0.0-1.0,
  "riskScore": 0.0-1.0,
  "reasoning": "detailed explanation",
  "riskFactors": [{"category": "WEATHER|AIRSPACE|THREAT|FLEET|TERRAIN|POLITICAL|COMMS", "severity": "LOW|MEDIUM|HIGH|CRITICAL", "description": "...", "score": 0.0-1.0}],
  "mitigations": ["mitigation 1", "mitigation 2"]
}`;

export class AIMissionApprovalEngine {
  private openai: OpenAI | null;

  constructor() {
    if (config.openai.apiKey) {
      this.openai = new OpenAI({ apiKey: config.openai.apiKey });
    } else {
      this.openai = null;
      logger.warn('OpenAI API key not set — AI engine will use rule-based fallback');
    }
  }

  async assessMission(context: MissionContext): Promise<AIAssessment> {
    const { mission } = context;
    logger.info({ missionId: mission.missionId, name: mission.name }, 'Starting AI mission assessment (AirLLM-integrated pipeline)');

    const [weatherData, airspaceData, threatData, fleetStatus] = await Promise.all([
      this.fetchWeatherData(
        mission.waypoints[0]?.position.lat ?? 34.052,
        mission.waypoints[0]?.position.lon ?? -118.244
      ),
      this.fetchAirspaceData(
        mission.waypoints[0]?.position.lat ?? 34.052,
        mission.waypoints[0]?.position.lon ?? -118.244
      ),
      this.fetchThreatData(
        mission.waypoints[0]?.position.lat ?? 34.052,
        mission.waypoints[0]?.position.lon ?? -118.244
      ),
      this.getFleetStatus(mission.assignedDroneIds),
    ]);

    const enrichedContext: MissionContext = {
      ...context,
      weatherData,
      airspaceData,
      threatData,
      assignedDrones: fleetStatus,
    };

    let assessment: AIAssessment;

    try {
      const allFeeds = await intelInjector.fetchAndCacheAllFeeds(enrichedContext);
      const promptContext = intelInjector.buildAirLLMContext(allFeeds, enrichedContext);
      const truncatedContext = intelInjector.validateAndTruncate(promptContext, 4096);

      logger.info({
        missionId: mission.missionId,
        feedSources: truncatedContext.feed_sources.length,
        preRiskScore: truncatedContext.computed_risk_score,
      }, 'Intel feeds aggregated for AI assessment');

      assessment = await modelRouter.routeInference(
        enrichedContext,
        truncatedContext as unknown as Record<string, unknown>,
        AEGIS_SYSTEM_PROMPT,
      );
    } catch (err) {
      logger.warn({ err }, 'AirLLM pipeline failed — falling back to legacy assessment');
      if (this.openai) {
        assessment = await this.runGPTAssessment(context, weatherData, airspaceData, threatData, fleetStatus);
      } else {
        assessment = this.runRuleBasedAssessment(context, weatherData, airspaceData, threatData, fleetStatus);
      }
    }

    await this.persistAssessment(assessment);
    await this.updateMissionStatus(mission.missionId, assessment);

    if (mission.hcsTopicId) {
      try {
        const hcsMsg = await hcsService.submitAction({
          topicId: mission.hcsTopicId,
          droneId: 'SYSTEM',
          actionType: ActionType.AI_ASSESSMENT,
          operatorId: 'AEGIS-AI',
          missionId: mission.missionId,
          aiConfidence: assessment.confidence,
          payload: {
            recommendation: assessment.recommendation,
            riskScore: assessment.riskScore,
            riskFactorCount: assessment.riskFactors.length,
            modelVersion: assessment.modelVersion,
          },
        });
        assessment.hcsTransactionId = hcsMsg.transactionId;
      } catch (err) {
        logger.error({ err }, 'Failed to submit AI assessment to HCS');
      }
    }

    await redisPub.publish('mission:ai_decision', JSON.stringify({
      missionId: mission.missionId,
      assessment: {
        assessmentId: assessment.assessmentId,
        recommendation: assessment.recommendation,
        confidence: assessment.confidence,
        riskScore: assessment.riskScore,
        reasoning: assessment.reasoning,
      },
      timestamp: zuluTimestamp(),
    }));

    logger.info({
      missionId: mission.missionId,
      recommendation: assessment.recommendation,
      confidence: assessment.confidence,
      riskScore: assessment.riskScore,
    }, 'AI assessment completed');

    return assessment;
  }

  async fetchWeatherData(lat: number, lon: number): Promise<WeatherData> {
    if (config.openWeather.apiKey) {
      try {
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${config.openWeather.apiKey}&units=metric`;
        const response = await fetch(url);
        const data = await response.json() as {
          main: { temp: number; humidity: number };
          wind: { speed: number; deg: number };
          visibility: number;
          clouds: { all: number };
          weather: Array<{ main: string }>;
          rain?: { '1h': number };
        };

        return {
          lat, lon,
          tempC: data.main.temp,
          humidity: data.main.humidity,
          windSpeedMs: data.wind.speed,
          windDirection: data.wind.deg,
          visibilityM: data.visibility,
          cloudCoverPercent: data.clouds.all,
          weatherCondition: data.weather[0]?.main ?? 'Clear',
          thunderstorm: data.weather.some((w: { main: string }) => w.main === 'Thunderstorm'),
          precipitationMm: data.rain?.['1h'] ?? 0,
          fetchedAt: zuluTimestamp(),
        };
      } catch (err) {
        logger.warn({ err }, 'OpenWeatherMap fetch failed — using simulated data');
      }
    }

    return this.simulateWeather(lat, lon);
  }

  private simulateWeather(lat: number, lon: number): WeatherData {
    return {
      lat, lon,
      tempC: 18 + Math.random() * 15,
      humidity: 40 + Math.random() * 40,
      windSpeedMs: 2 + Math.random() * 12,
      windDirection: Math.random() * 360,
      visibilityM: 5000 + Math.random() * 10000,
      cloudCoverPercent: Math.random() * 80,
      weatherCondition: Math.random() > 0.85 ? 'Rain' : 'Clear',
      thunderstorm: Math.random() > 0.92,
      precipitationMm: Math.random() > 0.7 ? Math.random() * 5 : 0,
      fetchedAt: zuluTimestamp(),
    };
  }

  async fetchAirspaceData(lat: number, lon: number): Promise<AirspaceData> {
    const activeTFRs = Math.random() > 0.7
      ? [{
        tfrId: `TFR-${Math.floor(Math.random() * 10000)}`,
        type: 'MILITARY' as const,
        center: { lat: lat + (Math.random() - 0.5) * 0.1, lon: lon + (Math.random() - 0.5) * 0.1, alt: 0 },
        radiusKm: 5 + Math.random() * 10,
        floorFt: 0,
        ceilingFt: 18000,
        startTime: new Date(Date.now() - 3600000).toISOString(),
        endTime: new Date(Date.now() + 7200000).toISOString(),
        exemptionHeld: Math.random() > 0.5,
      }]
      : [];

    const adsbContacts = Array.from({ length: Math.floor(Math.random() * 5) }, (_, i) => ({
      icao24: `A${(10000 + i).toString(16).toUpperCase()}`,
      callsign: `UAL${1000 + Math.floor(Math.random() * 9000)}`,
      altitudeFt: 10000 + Math.random() * 30000,
      speedKnots: 200 + Math.random() * 300,
      heading: Math.random() * 360,
      position: { lat: lat + (Math.random() - 0.5) * 0.5, lon: lon + (Math.random() - 0.5) * 0.5, alt: 10000 + Math.random() * 30000 },
      verticalRate: (Math.random() - 0.5) * 2000,
      squawk: `${1200 + Math.floor(Math.random() * 6600)}`,
      onGround: false,
    }));

    return {
      lat, lon,
      activeTFRs,
      activeNOTAMs: [{
        notamId: `NOTAM-${Math.floor(Math.random() * 100000)}`,
        type: 'FDC',
        description: 'Temporary flight restriction for military operations',
        affectedArea: `${lat.toFixed(2)}N ${Math.abs(lon).toFixed(2)}W`,
        effectiveFrom: new Date(Date.now() - 86400000).toISOString(),
        effectiveTo: new Date(Date.now() + 86400000).toISOString(),
      }],
      adsbContacts,
      fetchedAt: zuluTimestamp(),
    };
  }

  async fetchThreatData(lat: number, lon: number): Promise<ThreatIntel> {
    const result = await query<{
      threat_id: string; type: ThreatType; position_lat: number; position_lon: number;
      position_alt: number; radius_km: number; confidence: number; hostile_unit_id: string;
      description: string; first_detected: string; last_updated: string; active: boolean;
    }>('SELECT * FROM threats WHERE active = TRUE');

    const dbThreats = result.rows.map((row) => ({
      threatId: row.threat_id,
      type: row.type,
      position: { lat: row.position_lat, lon: row.position_lon, alt: row.position_alt },
      radiusKm: row.radius_km,
      confidence: parseFloat(row.confidence.toString()),
      hostileUnitId: row.hostile_unit_id,
      description: row.description,
      firstDetected: row.first_detected,
      lastUpdated: row.last_updated,
      active: row.active,
    }));

    const simThreats = Math.random() > 0.6
      ? [{
        threatId: uuidv4(),
        type: ThreatType.COUNTER_UAS,
        position: { lat: lat + (Math.random() - 0.5) * 0.05, lon: lon + (Math.random() - 0.5) * 0.05, alt: 0 },
        radiusKm: 1 + Math.random() * 5,
        confidence: 0.5 + Math.random() * 0.5,
        hostileUnitId: `HU-SIM-${Math.floor(Math.random() * 1000)}`,
        description: 'Simulated threat detection from SIGINT feed',
        firstDetected: zuluTimestamp(),
        lastUpdated: zuluTimestamp(),
        active: true,
      }]
      : [];

    const allThreats = [...dbThreats, ...simThreats];
    const maxConf = Math.max(...allThreats.map((t) => t.confidence), 0);
    const overallLevel = maxConf > 0.8 ? 'CRITICAL' : maxConf > 0.6 ? 'HIGH' : maxConf > 0.3 ? 'MEDIUM' : 'LOW';

    return {
      threats: allThreats,
      overallThreatLevel: overallLevel as 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL',
      fetchedAt: zuluTimestamp(),
    };
  }

  async getFleetStatus(droneIds: string[]): Promise<FleetDroneStatus[]> {
    const statuses: FleetDroneStatus[] = [];

    for (const droneId of droneIds) {
      const redisData = await redis.hgetall(`drone:live:${droneId}`);

      if (redisData && redisData.callsign) {
        statuses.push({
          droneId,
          callsign: redisData.callsign,
          droneClass: redisData.droneClass as FleetDroneStatus['droneClass'],
          status: redisData.status as DroneStatus,
          health: parseFloat(redisData.health ?? '1'),
          batteryPercent: parseFloat(redisData.batteryPercent ?? '100'),
          fuelPercent: parseFloat(redisData.fuelPercent ?? '100'),
          position: { lat: parseFloat(redisData.lat ?? '0'), lon: parseFloat(redisData.lon ?? '0'), alt: parseFloat(redisData.alt ?? '0') },
          linkQuality: parseFloat(redisData.linkQuality ?? '1'),
          available: redisData.status === DroneStatus.STANDBY || redisData.status === DroneStatus.AIRBORNE,
        });
      } else {
        const dbResult = await query<{
          drone_id: string; callsign: string; drone_class: string; status: DroneStatus;
          health: number; battery_percent: number; fuel_percent: number;
          position_lat: number; position_lon: number; position_alt: number; link_quality: number;
        }>(
          'SELECT drone_id, callsign, drone_class, status, health, battery_percent, fuel_percent, position_lat, position_lon, position_alt, link_quality FROM drones WHERE drone_id = $1',
          [droneId]
        );

        if (dbResult.rows[0]) {
          const d = dbResult.rows[0];
          statuses.push({
            droneId: d.drone_id,
            callsign: d.callsign,
            droneClass: d.drone_class as FleetDroneStatus['droneClass'],
            status: d.status,
            health: parseFloat(d.health.toString()),
            batteryPercent: parseFloat(d.battery_percent.toString()),
            fuelPercent: parseFloat(d.fuel_percent.toString()),
            position: { lat: d.position_lat, lon: d.position_lon, alt: d.position_alt },
            linkQuality: parseFloat(d.link_quality.toString()),
            available: d.status === DroneStatus.STANDBY || d.status === DroneStatus.AIRBORNE,
          });
        }
      }
    }

    return statuses;
  }

  private async runGPTAssessment(
    context: MissionContext,
    weather: WeatherData,
    airspace: AirspaceData,
    threats: ThreatIntel,
    fleet: FleetDroneStatus[]
  ): Promise<AIAssessment> {
    const systemPrompt = `You are AEGIS AI — a military-grade mission approval engine for unmanned aerial systems. You assess mission plans against environmental, threat, fleet readiness, and airspace conditions.

ABORT THRESHOLDS (hard rules — override your assessment):
- Wind speed > 15 m/s → REJECT (ABORT)
- Visibility < 1000m → REJECT (restricted ops only)
- Active TFR within AO without exemption → REJECT
- Threat level HIGH within 10km of AO → HOLD (require commander decision)
- Any assigned drone health < 0.6 → remove from roster (HOLD if critical asset)
- Thunderstorm detected within AO → REJECT (ground all)
- If your confidence in approval < 0.70 → output HOLD (escalate to commander)
- Risk score > 0.75 → REJECT

Respond ONLY with valid JSON matching this schema:
{
  "recommendation": "APPROVE" | "REJECT" | "HOLD",
  "confidence": 0.0-1.0,
  "riskScore": 0.0-1.0,
  "reasoning": "detailed explanation",
  "riskFactors": [{"category": "WEATHER|AIRSPACE|THREAT|FLEET|TERRAIN|POLITICAL|COMMS", "severity": "LOW|MEDIUM|HIGH|CRITICAL", "description": "...", "score": 0.0-1.0}],
  "mitigations": ["mitigation 1", "mitigation 2"]
}`;

    const userPrompt = `MISSION ASSESSMENT REQUEST
========================
Mission: ${context.mission.name}
Type: ${context.mission.type}
Commander: ${context.commanderCallsign}
Clearance: ${context.operatorClearance}
Planned Start: ${context.mission.plannedStartTime}
Planned End: ${context.mission.plannedEndTime}
Description: ${context.mission.description}

ASSIGNED FLEET (${fleet.length} assets):
${fleet.map((d) => `  - ${d.callsign} (${d.droneClass}) — Status: ${d.status}, Health: ${(d.health * 100).toFixed(0)}%, Battery: ${d.batteryPercent.toFixed(0)}%, Link: ${(d.linkQuality * 100).toFixed(0)}%`).join('\n')}

WEATHER CONDITIONS:
  Temperature: ${weather.tempC.toFixed(1)}°C
  Wind: ${weather.windSpeedMs.toFixed(1)} m/s @ ${weather.windDirection.toFixed(0)}°
  Visibility: ${weather.visibilityM}m
  Cloud Cover: ${weather.cloudCoverPercent}%
  Condition: ${weather.weatherCondition}
  Thunderstorm: ${weather.thunderstorm ? 'YES — ACTIVE' : 'No'}
  Precipitation: ${weather.precipitationMm.toFixed(1)}mm/h

AIRSPACE:
  Active TFRs: ${airspace.activeTFRs.length}
${airspace.activeTFRs.map((t) => `    - ${t.tfrId} (${t.type}) — Radius: ${t.radiusKm}km, Exemption: ${t.exemptionHeld ? 'YES' : 'NO'}`).join('\n')}
  ADS-B Contacts: ${airspace.adsbContacts.length}
  Active NOTAMs: ${airspace.activeNOTAMs.length}

THREAT INTELLIGENCE:
  Overall Threat Level: ${threats.overallThreatLevel}
  Active Threats: ${threats.threats.length}
${threats.threats.map((t) => `    - ${t.type} @ ${t.position.lat.toFixed(4)},${t.position.lon.toFixed(4)} — Confidence: ${(t.confidence * 100).toFixed(0)}%, Radius: ${t.radiusKm}km — ${t.description}`).join('\n')}

WAYPOINTS: ${context.mission.waypoints.length}
${context.mission.waypoints.map((w) => `  WP${w.index}: ${w.position.lat.toFixed(6)},${w.position.lon.toFixed(6)} @ ${w.position.alt}ft — ${w.action}`).join('\n')}

Assess this mission. Apply all abort thresholds.`;

    try {
      const completion = await this.openai!.chat.completions.create({
        model: MODEL_VERSION,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.2,
        max_tokens: 2000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0]?.message?.content ?? '{}';
      const parsed = JSON.parse(content) as {
        recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
        confidence: number;
        riskScore: number;
        reasoning: string;
        riskFactors: RiskFactor[];
        mitigations: string[];
      };

      return {
        assessmentId: uuidv4(),
        missionId: context.mission.missionId,
        recommendation: parsed.recommendation,
        confidence: Math.max(0, Math.min(1, parsed.confidence)),
        riskScore: Math.max(0, Math.min(1, parsed.riskScore)),
        reasoning: parsed.reasoning,
        riskFactors: parsed.riskFactors,
        mitigations: parsed.mitigations,
        weatherData: weather,
        airspaceData: airspace,
        threatData: threats,
        fleetStatus: fleet,
        modelVersion: MODEL_VERSION,
        assessedAt: zuluTimestamp(),
        hcsTransactionId: null,
      };
    } catch (err) {
      logger.error({ err }, 'GPT assessment failed — falling back to rule-based');
      return this.runRuleBasedAssessment(context, weather, airspace, threats, fleet);
    }
  }

  private runRuleBasedAssessment(
    context: MissionContext,
    weather: WeatherData,
    airspace: AirspaceData,
    threats: ThreatIntel,
    fleet: FleetDroneStatus[]
  ): AIAssessment {
    const riskFactors: RiskFactor[] = [];
    let riskScore = 0;

    if (weather.thunderstorm) {
      riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: 'Active thunderstorm in AO', score: 1.0 });
      riskScore = Math.max(riskScore, 1.0);
    }

    if (weather.windSpeedMs > 15) {
      riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: `Wind speed ${weather.windSpeedMs.toFixed(1)} m/s exceeds 15 m/s limit`, score: 0.9 });
      riskScore = Math.max(riskScore, 0.9);
    } else if (weather.windSpeedMs > 10) {
      riskFactors.push({ category: 'WEATHER', severity: 'HIGH', description: `Elevated wind speed ${weather.windSpeedMs.toFixed(1)} m/s`, score: 0.6 });
      riskScore = Math.max(riskScore, 0.6);
    }

    if (weather.visibilityM < 1000) {
      riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: `Visibility ${weather.visibilityM}m below 1000m minimum`, score: 0.85 });
      riskScore = Math.max(riskScore, 0.85);
    }

    const unexemptTFRs = airspace.activeTFRs.filter((t) => !t.exemptionHeld);
    if (unexemptTFRs.length > 0) {
      riskFactors.push({ category: 'AIRSPACE', severity: 'CRITICAL', description: `${unexemptTFRs.length} active TFR(s) without exemption`, score: 0.95 });
      riskScore = Math.max(riskScore, 0.95);
    }

    if (threats.overallThreatLevel === 'HIGH' || threats.overallThreatLevel === 'CRITICAL') {
      const score = threats.overallThreatLevel === 'CRITICAL' ? 0.9 : 0.7;
      riskFactors.push({ category: 'THREAT', severity: threats.overallThreatLevel, description: `${threats.overallThreatLevel} threat level — ${threats.threats.length} active threat(s)`, score });
      riskScore = Math.max(riskScore, score);
    }

    const unhealthyDrones = fleet.filter((d) => d.health < 0.6);
    if (unhealthyDrones.length > 0) {
      riskFactors.push({
        category: 'FLEET',
        severity: 'HIGH',
        description: `${unhealthyDrones.length} drone(s) below health threshold: ${unhealthyDrones.map((d) => `${d.callsign}(${(d.health * 100).toFixed(0)}%)`).join(', ')}`,
        score: 0.65,
      });
      riskScore = Math.max(riskScore, 0.65);
    }

    const lowBatteryDrones = fleet.filter((d) => d.batteryPercent < 30);
    if (lowBatteryDrones.length > 0) {
      riskFactors.push({
        category: 'FLEET',
        severity: 'MEDIUM',
        description: `${lowBatteryDrones.length} drone(s) with low battery`,
        score: 0.4,
      });
      riskScore = Math.max(riskScore, 0.4);
    }

    const mitigations: string[] = [];
    if (weather.windSpeedMs > 10 && weather.windSpeedMs <= 15) {
      mitigations.push('Reduce altitude to minimize wind exposure');
    }
    if (threats.threats.length > 0) {
      mitigations.push('Route waypoints to maximize distance from threat positions');
    }
    if (unhealthyDrones.length > 0) {
      mitigations.push(`Remove unhealthy drones from mission roster: ${unhealthyDrones.map((d) => d.callsign).join(', ')}`);
    }
    if (airspace.adsbContacts.length > 3) {
      mitigations.push('Dense air traffic — maintain enhanced see-and-avoid protocols');
    }

    let recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
    let confidence: number;

    if (riskScore > 0.75 || weather.thunderstorm || weather.windSpeedMs > 15 || weather.visibilityM < 1000 || unexemptTFRs.length > 0) {
      recommendation = 'REJECT';
      confidence = Math.min(0.95, 0.7 + riskScore * 0.25);
    } else if (riskScore > 0.5 || threats.overallThreatLevel === 'HIGH') {
      recommendation = 'HOLD';
      confidence = 0.6 + (1 - riskScore) * 0.2;
    } else {
      recommendation = 'APPROVE';
      confidence = Math.min(0.95, 0.75 + (1 - riskScore) * 0.2);
    }

    const reasoning = this.buildReasoning(recommendation, riskFactors, weather, threats, fleet);

    return {
      assessmentId: uuidv4(),
      missionId: context.mission.missionId,
      recommendation,
      confidence,
      riskScore,
      reasoning,
      riskFactors,
      mitigations,
      weatherData: weather,
      airspaceData: airspace,
      threatData: threats,
      fleetStatus: fleet,
      modelVersion: 'rule-engine-v1',
      assessedAt: zuluTimestamp(),
      hcsTransactionId: null,
    };
  }

  private buildReasoning(
    recommendation: string,
    factors: RiskFactor[],
    weather: WeatherData,
    threats: ThreatIntel,
    fleet: FleetDroneStatus[]
  ): string {
    const lines: string[] = [`AEGIS AI Assessment — ${recommendation}`];
    lines.push(`Assessment Time: ${zuluTimestamp()}`);
    lines.push(`Weather: ${weather.weatherCondition}, Wind ${weather.windSpeedMs.toFixed(1)}m/s, Vis ${weather.visibilityM}m`);
    lines.push(`Threats: ${threats.overallThreatLevel} (${threats.threats.length} active)`);
    lines.push(`Fleet: ${fleet.length} assigned, ${fleet.filter((d) => d.health >= 0.6).length} mission-ready`);

    if (factors.length > 0) {
      lines.push(`\nRisk factors identified (${factors.length}):`);
      factors.forEach((f, i) => {
        lines.push(`  ${i + 1}. [${f.severity}] ${f.category}: ${f.description}`);
      });
    }

    return lines.join('\n');
  }

  private async persistAssessment(assessment: AIAssessment): Promise<void> {
    await query(
      `INSERT INTO ai_assessments
       (assessment_id, mission_id, recommendation, confidence, risk_score, reasoning,
        risk_factors, mitigations, weather_data, airspace_data, threat_data,
        fleet_status, model_version, hcs_transaction_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
      [
        assessment.assessmentId,
        assessment.missionId,
        assessment.recommendation,
        assessment.confidence,
        assessment.riskScore,
        assessment.reasoning,
        JSON.stringify(assessment.riskFactors),
        JSON.stringify(assessment.mitigations),
        JSON.stringify(assessment.weatherData),
        JSON.stringify(assessment.airspaceData),
        JSON.stringify(assessment.threatData),
        JSON.stringify(assessment.fleetStatus),
        assessment.modelVersion,
        assessment.hcsTransactionId,
      ]
    );
  }

  private async updateMissionStatus(missionId: string, assessment: AIAssessment): Promise<void> {
    let newStatus: MissionStatus;
    switch (assessment.recommendation) {
      case 'APPROVE':
        newStatus = MissionStatus.AI_APPROVED;
        break;
      case 'REJECT':
        newStatus = MissionStatus.AI_REJECTED;
        break;
      case 'HOLD':
        newStatus = MissionStatus.PENDING_AI_REVIEW;
        break;
    }

    await query(
      'UPDATE missions SET status = $1, ai_assessment_id = $2 WHERE mission_id = $3',
      [newStatus, assessment.assessmentId, missionId]
    );
  }

  async initializeRI(): Promise<void> {
    await riSystem.initialize();
    logger.info('Recursive Improvement system initialized via AIMissionApprovalEngine');
  }

  async processCompletedMission(
    missionId: string,
    succeeded: boolean,
    assessment: { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number; assessmentId: string },
    actualMetrics: {
      routeEfficiency: number;
      etaAccuracyPercent: number;
      fuelUsedPercent: number;
      threatExposureSeconds: number;
      terrainMaskingPercent: number;
      weatherMatched: boolean;
      threatsMatched: boolean;
    },
  ): Promise<void> {
    const outcome: MissionOutcome = {
      missionId,
      succeeded,
      actualRisk: succeeded ? Math.min(assessment.riskScore, 0.4) : Math.max(assessment.riskScore, 0.6),
      weatherMatchedPrediction: actualMetrics.weatherMatched,
      threatsMatchedPrediction: actualMetrics.threatsMatched,
      routeEfficiency: actualMetrics.routeEfficiency,
      etaAccuracyPercent: actualMetrics.etaAccuracyPercent,
      fuelUsedPercent: actualMetrics.fuelUsedPercent,
      threatExposureSeconds: actualMetrics.threatExposureSeconds,
      terrainMaskingPercent: actualMetrics.terrainMaskingPercent,
      completedAt: zuluTimestamp(),
      telemetrySnapshots: [],
    };

    const analysis = await riSystem.processPostMission(
      missionId, assessment, outcome,
      actualMetrics.weatherMatched,
      actualMetrics.threatsMatched,
    );

    if (analysis) {
      logger.info({
        missionId,
        refined: analysis.refinementTriggered,
        predictionError: analysis.predictionError,
      }, 'Post-mission RI analysis complete');
    }
  }

  getRIStatus() {
    return riSystem.getSystemStatus();
  }
}

export const aiEngine = new AIMissionApprovalEngine();
