import {
  DroneClass,
  DroneStatus,
  SensorType,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export interface ReconDroneConfig extends DroneConfig {
  sensors?: SensorType[];
  groundResolutionCm?: number;
  recordingHours?: number;
}

export class ReconDrone extends DroneBase {
  sensors: SensorType[];
  stealthMode: boolean;
  groundResolutionCm: number;
  recordingHours: number;

  private recordingStartTime: number | null = null;
  private activeSensors: Set<SensorType> = new Set();

  constructor(cfg: ReconDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.RECON });
    this.sensors = cfg.sensors ?? [SensorType.EO, SensorType.IR];
    this.stealthMode = false;
    this.groundResolutionCm = cfg.groundResolutionCm ?? 15;
    this.recordingHours = cfg.recordingHours ?? 0;
  }

  activateSensor(sensor: SensorType): boolean {
    if (!this.sensors.includes(sensor)) {
      return false;
    }
    this.activeSensors.add(sensor);
    return true;
  }

  deactivateSensor(sensor: SensorType): void {
    this.activeSensors.delete(sensor);
  }

  getActiveSensors(): SensorType[] {
    return Array.from(this.activeSensors);
  }

  enableStealthMode(): void {
    this.stealthMode = true;
    this.activeSensors.delete(SensorType.SAR);
    this.activeSensors.delete(SensorType.SIGINT);
  }

  disableStealthMode(): void {
    this.stealthMode = false;
  }

  startRecording(): void {
    if (this.recordingStartTime === null) {
      this.recordingStartTime = Date.now();
    }
  }

  stopRecording(): number {
    if (this.recordingStartTime === null) {
      return this.recordingHours;
    }
    const elapsed = (Date.now() - this.recordingStartTime) / 3_600_000;
    this.recordingHours += elapsed;
    this.recordingStartTime = null;
    return this.recordingHours;
  }

  private getCurrentRecordingHours(): number {
    if (this.recordingStartTime === null) {
      return this.recordingHours;
    }
    return this.recordingHours + (Date.now() - this.recordingStartTime) / 3_600_000;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      sensors: [...this.sensors],
      activeSensors: this.getActiveSensors(),
      stealthMode: this.stealthMode,
      groundResolutionCm: this.groundResolutionCm,
      recordingHours: this.getCurrentRecordingHours(),
      sensorCount: this.sensors.length,
      activeSensorCount: this.activeSensors.size,
    };
  }

  getAIContextDescriptor(): string {
    const sensorList = this.sensors.join(', ');
    const activeList = this.getActiveSensors().join(', ') || 'NONE';
    return [
      `RECON drone ${this.callsign} (${this.model})`,
      `Sensors: [${sensorList}] | Active: [${activeList}]`,
      `Ground resolution: ${this.groundResolutionCm}cm`,
      `Stealth: ${this.stealthMode ? 'ENGAGED' : 'OFF'}`,
      `Recording: ${this.getCurrentRecordingHours().toFixed(2)}h`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'EO_IR_IMAGING',
        available: true,
        degradedMode: 'Reduced frame rate, cached waypoints for autonomous ISR pattern',
      },
      {
        capability: 'SAR_IMAGING',
        available: !this.stealthMode,
        degradedMode: 'SAR disabled in stealth; otherwise autonomous strip-map on cached route',
      },
      {
        capability: 'SIGINT_COLLECTION',
        available: !this.stealthMode,
        degradedMode: 'Passive-only SIGINT on pre-loaded frequency tables',
      },
      {
        capability: 'LIDAR_MAPPING',
        available: true,
        degradedMode: 'Autonomous terrain scan on pre-planned grid; stored onboard',
      },
      {
        capability: 'LIVE_DOWNLINK',
        available: false,
        degradedMode: 'No live stream; data recorded onboard for post-flight extraction',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS dead-reckoning with cached waypoints; silent return protocol',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.stealthMode = true;

    this.activeSensors.delete(SensorType.SAR);
    this.activeSensors.delete(SensorType.SIGINT);

    this.startRecording();
  }
}

export default ReconDrone;
