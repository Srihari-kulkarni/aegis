import { create } from 'zustand';
import { OperatorRole, ClearanceLevel } from '@aegis/shared';
import { apiPost, apiGet, setTokens, clearTokens, getAccessToken } from '@/lib/api';
import { connectAll, disconnectAll } from '@/lib/socket';

interface OperatorInfo {
  operatorId: string;
  username: string;
  callsign: string;
  role: OperatorRole;
  clearanceLevel: ClearanceLevel;
  email: string;
  mfaEnabled: boolean;
}

interface AuthState {
  operator: OperatorInfo | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  mfaRequired: boolean;
  error: string | null;
  login: (username: string, password: string, totpCode?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
  hasRole: (role: OperatorRole) => boolean;
}

const ROLE_HIERARCHY: Record<OperatorRole, number> = {
  [OperatorRole.SUPER_ADMIN]: 100,
  [OperatorRole.MISSION_COMMANDER]: 80,
  [OperatorRole.OPERATOR]: 60,
  [OperatorRole.ANALYST]: 40,
  [OperatorRole.AI_SYSTEM]: 50,
  [OperatorRole.AUDITOR]: 30,
  [OperatorRole.GUEST]: 10,
};

export const useAuthStore = create<AuthState>((set, get) => ({
  operator: null,
  isAuthenticated: false,
  isLoading: true,
  mfaRequired: false,
  error: null,

  login: async (username, password, totpCode) => {
    set({ isLoading: true, error: null });
    try {
      const res = await apiPost<{
        accessToken: string;
        refreshToken: string;
        operator: OperatorInfo;
        mfaRequired: boolean;
      }>('/auth/login', { username, password, totpCode });

      if (!res.success) {
        set({ error: res.error ?? 'Login failed', isLoading: false });
        return false;
      }

      if (res.data?.mfaRequired && !totpCode) {
        set({ mfaRequired: true, isLoading: false });
        return false;
      }

      if (res.data?.accessToken) {
        setTokens(res.data.accessToken, res.data.refreshToken);
        set({
          operator: res.data.operator,
          isAuthenticated: true,
          isLoading: false,
          mfaRequired: false,
          error: null,
        });
        connectAll();
        return true;
      }

      set({ error: 'Unexpected response', isLoading: false });
      return false;
    } catch {
      set({ error: 'Network error', isLoading: false });
      return false;
    }
  },

  logout: async () => {
    try {
      await apiPost('/auth/logout');
    } catch {
      // Best-effort logout
    }
    clearTokens();
    disconnectAll();
    set({ operator: null, isAuthenticated: false, mfaRequired: false, error: null });
  },

  checkAuth: async () => {
    const token = getAccessToken();
    if (!token) {
      set({ isLoading: false, isAuthenticated: false });
      return;
    }

    try {
      const res = await apiGet<OperatorInfo>('/auth/me');
      if (res.success && res.data) {
        set({
          operator: res.data,
          isAuthenticated: true,
          isLoading: false,
        });
        connectAll();
      } else {
        clearTokens();
        set({ isLoading: false, isAuthenticated: false });
      }
    } catch {
      set({ isLoading: false, isAuthenticated: false });
    }
  },

  hasPermission: (permission) => {
    const op = get().operator;
    if (!op) return false;
    const permissions: Record<OperatorRole, string[]> = {
      [OperatorRole.SUPER_ADMIN]: ['mission:create', 'mission:approve', 'mission:abort', 'mission:override', 'drone:command', 'drone:register', 'drone:decommission', 'operator:manage', 'log:read', 'intel:read', 'fleet:manage'],
      [OperatorRole.MISSION_COMMANDER]: ['mission:create', 'mission:approve', 'mission:abort', 'mission:override', 'drone:command', 'log:read', 'intel:read'],
      [OperatorRole.OPERATOR]: ['mission:create', 'drone:command', 'log:read', 'intel:read'],
      [OperatorRole.ANALYST]: ['log:read', 'intel:read'],
      [OperatorRole.AI_SYSTEM]: ['mission:assess', 'log:read', 'intel:read', 'drone:query'],
      [OperatorRole.AUDITOR]: ['log:read'],
      [OperatorRole.GUEST]: [],
    };
    return permissions[op.role]?.includes(permission) ?? false;
  },

  hasRole: (role) => {
    const op = get().operator;
    if (!op) return false;
    return ROLE_HIERARCHY[op.role] >= ROLE_HIERARCHY[role];
  },
}));
