import OpenAI from 'openai';
import { config } from '../config';
import { redis, redisPub } from '../redis';
import { logger } from '../logger';
import { zuluTimestamp, type MissionContext, type AIAssessment, type RiskFactor } from '@aegis/shared';
import { airllmService, type AirLLMInferenceResult } from './airllm-service';
import { v4 as uuidv4 } from 'uuid';

export type ModelTier = 'CLOUD_GPT4O' | 'LOCAL_70B' | 'LOCAL_7B' | 'RULE_ENGINE';

export interface RoutingDecision {
  tier: ModelTier;
  reason: string;
  timestamp: string;
  latencyMs: number;
}

export interface InferenceMetrics {
  tier: ModelTier;
  inferenceLatencyMs: number;
  confidence: number;
  confidenceDelta: number;
  modelVersion: string;
  timestamp: string;
}

const CLOUD_PROBE_TIMEOUT_MS = 2000;
const CLOUD_MODEL = 'gpt-4o';

export class ModelRouter {
  private openai: OpenAI | null;
  private currentTier: ModelTier = 'RULE_ENGINE';
  private lastCloudCheck = 0;
  private cloudAvailable = false;
  private cloudBaselineConfidence = 0.85;

  constructor() {
    if (config.openai.apiKey) {
      this.openai = new OpenAI({ apiKey: config.openai.apiKey });
      logger.info('ModelRouter: Cloud GPT-4o tier available');
    } else {
      this.openai = null;
      logger.info('ModelRouter: No OpenAI key — cloud tier disabled');
    }
  }

  async routeInference(
    context: MissionContext,
    promptContext: Record<string, unknown>,
    systemPrompt: string,
  ): Promise<AIAssessment> {
    const decision = await this.selectTier();

    await redis.set('ai:routing:current', JSON.stringify(decision), 'EX', 60);
    await redisPub.publish('ai:tier_change', JSON.stringify(decision));

    let assessment: AIAssessment;

    switch (decision.tier) {
      case 'CLOUD_GPT4O':
        assessment = await this.runCloudInference(context, systemPrompt);
        break;

      case 'LOCAL_70B':
      case 'LOCAL_7B':
        assessment = await this.runLocalInference(context, promptContext, systemPrompt, decision.tier);
        break;

      default:
        assessment = this.runRuleEngine(context, promptContext);
        break;
    }

    const metrics: InferenceMetrics = {
      tier: decision.tier,
      inferenceLatencyMs: decision.latencyMs,
      confidence: assessment.confidence,
      confidenceDelta: assessment.confidence - this.cloudBaselineConfidence,
      modelVersion: assessment.modelVersion,
      timestamp: zuluTimestamp(),
    };
    await redis.set(`ai:metrics:${context.mission.missionId}`, JSON.stringify(metrics), 'EX', 3600);

    logger.info({
      missionId: context.mission.missionId,
      tier: decision.tier,
      recommendation: assessment.recommendation,
      confidence: assessment.confidence,
    }, 'ModelRouter inference complete');

    return assessment;
  }

  async selectTier(): Promise<RoutingDecision> {
    const startMs = Date.now();

    if (this.openai) {
      const connectivity = await this.checkCloudConnectivity();
      if (connectivity.available && connectivity.latencyMs < 3000) {
        this.currentTier = 'CLOUD_GPT4O';
        return {
          tier: 'CLOUD_GPT4O',
          reason: `Cloud available (${connectivity.latencyMs}ms latency)`,
          timestamp: zuluTimestamp(),
          latencyMs: Date.now() - startMs,
        };
      }
    }

    if (airllmService.isLoaded && airllmService.isHealthy) {
      const tier: ModelTier = airllmService.modelSize === '7B' ? 'LOCAL_7B' : 'LOCAL_70B';
      this.currentTier = tier;
      return {
        tier,
        reason: `AirLLM ${airllmService.modelSize} loaded on ${airllmService.currentNodeType} node`,
        timestamp: zuluTimestamp(),
        latencyMs: Date.now() - startMs,
      };
    }

    this.currentTier = 'RULE_ENGINE';
    return {
      tier: 'RULE_ENGINE',
      reason: 'No cloud or local model available — falling back to rule engine',
      timestamp: zuluTimestamp(),
      latencyMs: Date.now() - startMs,
    };
  }

  private async checkCloudConnectivity(): Promise<{ available: boolean; latencyMs: number }> {
    const now = Date.now();
    if (now - this.lastCloudCheck < 30000) {
      return { available: this.cloudAvailable, latencyMs: 0 };
    }

    try {
      const start = Date.now();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), CLOUD_PROBE_TIMEOUT_MS);

      await fetch('https://api.openai.com/v1/models', {
        method: 'HEAD',
        headers: { Authorization: `Bearer ${config.openai.apiKey}` },
        signal: controller.signal,
      });

      clearTimeout(timeout);
      const latency = Date.now() - start;

      this.lastCloudCheck = now;
      this.cloudAvailable = true;
      return { available: true, latencyMs: latency };
    } catch {
      this.lastCloudCheck = now;
      this.cloudAvailable = false;
      logger.warn('Cloud connectivity probe failed');
      return { available: false, latencyMs: CLOUD_PROBE_TIMEOUT_MS };
    }
  }

  private async runCloudInference(context: MissionContext, systemPrompt: string): Promise<AIAssessment> {
    const fleet = context.assignedDrones;
    const weather = context.weatherData;
    const airspace = context.airspaceData;
    const threats = context.threatData;

    const userPrompt = this.buildPrompt(context, weather, airspace, threats, fleet);

    try {
      const completion = await this.openai!.chat.completions.create({
        model: CLOUD_MODEL,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.2,
        max_tokens: 2000,
        response_format: { type: 'json_object' },
      });

      const content = completion.choices[0]?.message?.content ?? '{}';
      const parsed = JSON.parse(content) as {
        recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
        confidence: number;
        riskScore: number;
        reasoning: string;
        riskFactors: RiskFactor[];
        mitigations: string[];
      };

      this.cloudBaselineConfidence = parsed.confidence;

      return {
        assessmentId: uuidv4(),
        missionId: context.mission.missionId,
        recommendation: parsed.recommendation,
        confidence: Math.max(0, Math.min(1, parsed.confidence)),
        riskScore: Math.max(0, Math.min(1, parsed.riskScore)),
        reasoning: parsed.reasoning,
        riskFactors: parsed.riskFactors ?? [],
        mitigations: parsed.mitigations ?? [],
        weatherData: weather,
        airspaceData: airspace,
        threatData: threats,
        fleetStatus: fleet,
        modelVersion: `${CLOUD_MODEL} (cloud)`,
        assessedAt: zuluTimestamp(),
        hcsTransactionId: null,
      };
    } catch (err) {
      logger.error({ err }, 'Cloud GPT-4o inference failed — falling back to local');
      return this.runLocalInference(context, {}, systemPrompt, 'LOCAL_70B');
    }
  }

  private async runLocalInference(
    context: MissionContext,
    promptContext: Record<string, unknown>,
    systemPrompt: string,
    _tier: ModelTier,
  ): Promise<AIAssessment> {
    const result: AirLLMInferenceResult = await airllmService.assessMission(promptContext, systemPrompt);

    return {
      assessmentId: uuidv4(),
      missionId: context.mission.missionId,
      recommendation: result.recommendation,
      confidence: result.confidence,
      riskScore: result.riskScore,
      reasoning: result.reasoning,
      riskFactors: result.riskFactors as RiskFactor[],
      mitigations: result.mitigations,
      weatherData: context.weatherData,
      airspaceData: context.airspaceData,
      threatData: context.threatData,
      fleetStatus: context.assignedDrones,
      modelVersion: `AirLLM:${result.modelUsed} (${result.nodeType})`,
      assessedAt: zuluTimestamp(),
      hcsTransactionId: null,
    };
  }

  private runRuleEngine(context: MissionContext, promptContext: Record<string, unknown>): AIAssessment {
    const riskFactors: RiskFactor[] = [];
    let riskScore = (promptContext.computed_risk_score as number) ?? 0;

    const factors = promptContext.computed_risk_factors as string[] | undefined;
    if (factors) {
      for (const f of factors) {
        riskFactors.push({ category: 'FLEET', severity: 'MEDIUM', description: f, score: 0.2 });
      }
    }

    let recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
    let confidence: number;

    if (riskScore > 0.75) { recommendation = 'REJECT'; confidence = 0.80; }
    else if (riskScore > 0.5) { recommendation = 'HOLD'; confidence = 0.65; }
    else { recommendation = 'APPROVE'; confidence = 0.70; }

    return {
      assessmentId: uuidv4(),
      missionId: context.mission.missionId,
      recommendation,
      confidence,
      riskScore,
      reasoning: `[Rule Engine Fallback] ${recommendation} — Risk: ${(riskScore * 100).toFixed(0)}%`,
      riskFactors,
      mitigations: [],
      weatherData: context.weatherData,
      airspaceData: context.airspaceData,
      threatData: context.threatData,
      fleetStatus: context.assignedDrones,
      modelVersion: 'rule-engine-v2',
      assessedAt: zuluTimestamp(),
      hcsTransactionId: null,
    };
  }

  private buildPrompt(
    context: MissionContext,
    weather: import('@aegis/shared').WeatherData | null,
    airspace: import('@aegis/shared').AirspaceData | null,
    threats: import('@aegis/shared').ThreatIntel | null,
    fleet: import('@aegis/shared').FleetDroneStatus[],
  ): string {
    const lines: string[] = [
      'MISSION ASSESSMENT REQUEST',
      '========================',
      `Mission: ${context.mission.name}`,
      `Type: ${context.mission.type}`,
      `Commander: ${context.commanderCallsign}`,
      `Clearance: ${context.operatorClearance}`,
      `Planned: ${context.mission.plannedStartTime} → ${context.mission.plannedEndTime}`,
      `Description: ${context.mission.description}`,
      '',
      `ASSIGNED FLEET (${fleet.length} assets):`,
      ...fleet.map((d) => `  - ${d.callsign} (${d.droneClass}) — Status: ${d.status}, Health: ${(d.health * 100).toFixed(0)}%, Battery: ${d.batteryPercent.toFixed(0)}%, Link: ${(d.linkQuality * 100).toFixed(0)}%`),
    ];

    if (weather) {
      lines.push('', 'WEATHER:', `  Wind: ${weather.windSpeedMs.toFixed(1)} m/s @ ${weather.windDirection.toFixed(0)}°`, `  Vis: ${weather.visibilityM}m`, `  Thunderstorm: ${weather.thunderstorm ? 'YES' : 'No'}`);
    }
    if (airspace) {
      lines.push('', `AIRSPACE: TFRs=${airspace.activeTFRs.length}, ADS-B=${airspace.adsbContacts.length}`);
    }
    if (threats) {
      lines.push('', `THREATS: ${threats.overallThreatLevel} (${threats.threats.length} active)`);
    }
    lines.push('', `WAYPOINTS: ${context.mission.waypoints.length}`);

    return lines.join('\n');
  }

  get activeTier(): ModelTier { return this.currentTier; }
}

export const modelRouter = new ModelRouter();
