import { redis } from '../../redis';
import { config } from '../../config';
import { logger } from '../../logger';
import { zuluTimestamp, type WeatherData } from '@aegis/shared';
import type { IntelFeedResult } from '../types';

const CACHE_KEY = 'intel:owm';
const TTL = 120;

export async function fetchOpenWeatherMap(lat: number, lon: number): Promise<IntelFeedResult<WeatherData>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(2)}_${lon.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'openweathermap', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  if (!config.openWeather.apiKey) {
    return { success: true, data: simulateOWM(lat, lon), source: 'owm-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${config.openWeather.apiKey}&units=metric`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`OWM HTTP ${res.status}`);

    const d = await res.json() as {
      main: { temp: number; humidity: number };
      wind: { speed: number; deg: number };
      visibility: number;
      clouds: { all: number };
      weather: Array<{ main: string }>;
      rain?: { '1h': number };
    };

    const result: WeatherData = {
      lat, lon,
      tempC: d.main.temp,
      humidity: d.main.humidity,
      windSpeedMs: d.wind.speed,
      windDirection: d.wind.deg,
      visibilityM: d.visibility,
      cloudCoverPercent: d.clouds.all,
      weatherCondition: d.weather[0]?.main ?? 'Clear',
      thunderstorm: d.weather.some((w) => w.main === 'Thunderstorm'),
      precipitationMm: d.rain?.['1h'] ?? 0,
      fetchedAt: zuluTimestamp(),
    };

    await redis.set(cacheKey, JSON.stringify(result), 'EX', TTL);
    return { success: true, data: result, source: 'openweathermap', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'OWM fetch failed — using simulated data');
    return { success: true, data: simulateOWM(lat, lon), source: 'owm-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateOWM(lat: number, lon: number): WeatherData {
  return {
    lat, lon,
    tempC: 18 + Math.random() * 15,
    humidity: 40 + Math.random() * 40,
    windSpeedMs: 2 + Math.random() * 12,
    windDirection: Math.random() * 360,
    visibilityM: 5000 + Math.random() * 10000,
    cloudCoverPercent: Math.random() * 80,
    weatherCondition: Math.random() > 0.85 ? 'Rain' : 'Clear',
    thunderstorm: Math.random() > 0.92,
    precipitationMm: Math.random() > 0.7 ? Math.random() * 5 : 0,
    fetchedAt: zuluTimestamp(),
  };
}
