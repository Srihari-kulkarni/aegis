'use client';

import { useState, useEffect } from 'react';
import { useFeedStore, type RISystemStatus, type RIRefinementEvent, type RISafetyEvent } from '@/stores/feedStore';
import { apiGet, apiPost } from '@/lib/api';

const LAYER_LABELS: Record<string, string> = {
  prompt: 'L1: PROMPT OPTIMIZER',
  capability: 'L2: CAPABILITY ASSESSOR',
  routing: 'L3: GP ROUTE OPTIMIZER',
};

const SEVERITY_COLORS: Record<string, string> = {
  WARNING: 'text-aegis-amber',
  CRITICAL: 'text-aegis-red',
  EMERGENCY: 'text-aegis-red animate-pulse',
};

interface CapabilityDesc {
  droneClass: string;
  version: number;
  maxWindToleranceMs: number;
  operationalCeilingFt: number;
  minHealthThreshold: number;
  effectiveRangeKm: number;
  sensorAccuracy: number;
  updatedBy: string;
  updatedAt: string;
}

function RIOverviewPanel(props: { riStatus: RISystemStatus }): JSX.Element {
  const { riStatus } = props;
  return (
    <div className="space-y-3">
      <div className="border border-aegis-border p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="data-label">RECURSIVE IMPROVEMENT ENGINE</span>
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 ${riStatus.enabled ? 'bg-aegis-green/20 text-aegis-green' : 'bg-aegis-red/20 text-aegis-red'}`}>
            {riStatus.enabled ? 'ACTIVE' : 'DISABLED'}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-[9px] font-mono text-aegis-muted">TOTAL ITERATIONS</div>
            <div className="text-sm font-mono text-aegis-cyan font-bold">{riStatus.totalIterations}</div>
          </div>
          <div>
            <div className="text-[9px] font-mono text-aegis-muted">SUCCESS RATE</div>
            <div className={`text-sm font-mono font-bold ${riStatus.successRate > 0.7 ? 'text-aegis-green' : riStatus.successRate > 0.4 ? 'text-aegis-amber' : 'text-aegis-red'}`}>
              {(riStatus.successRate * 100).toFixed(0)}%
            </div>
          </div>
        </div>
        {riStatus.lastRefinement && (
          <div className="text-[9px] font-mono text-aegis-muted mt-2">
            LAST: {riStatus.lastRefinement}
          </div>
        )}
      </div>

      {Object.entries(riStatus.layers).map(([key, layer]) => (
        <div key={key} className="border border-aegis-border p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-mono text-aegis-text font-bold">{LAYER_LABELS[key] || key}</span>
            <div className="flex items-center gap-1.5">
              <div className={`w-1.5 h-1.5 ${layer.active ? 'bg-aegis-green animate-pulse' : 'bg-aegis-muted'}`} />
              <span className="text-[9px] font-mono text-aegis-muted">v{layer.currentVersion}</span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-1">
            <div>
              <div className="text-[8px] font-mono text-aegis-muted">ITERS</div>
              <div className="text-[10px] font-mono text-aegis-text">{layer.totalIterations}</div>
            </div>
            <div>
              <div className="text-[8px] font-mono text-aegis-muted">ACCURACY</div>
              <div className={`text-[10px] font-mono ${layer.accuracy > 0.7 ? 'text-aegis-green' : 'text-aegis-amber'}`}>
                {(layer.accuracy * 100).toFixed(0)}%
              </div>
            </div>
            <div>
              <div className="text-[8px] font-mono text-aegis-muted">APPROVAL</div>
              <div className={`text-[10px] font-mono ${layer.pendingApproval ? 'text-aegis-amber' : 'text-aegis-green'}`}>
                {layer.pendingApproval ? 'PENDING' : 'OK'}
              </div>
            </div>
          </div>
          {layer.lastImprovement && (
            <div className="text-[8px] font-mono text-aegis-muted mt-1">
              LAST: {layer.lastImprovement}
            </div>
          )}
        </div>
      ))}

      <div className="border border-aegis-border p-3">
        <div className="data-label mb-2">SAFETY CONSTRAINTS</div>
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-[10px] font-mono text-aegis-muted">CONTAINMENT</span>
            <span className={`text-[10px] font-mono font-bold ${riStatus.safety.containmentIntact ? 'text-aegis-green' : 'text-aegis-red'}`}>
              {riStatus.safety.containmentIntact ? 'INTACT' : 'BREACHED'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[10px] font-mono text-aegis-muted">GOAL INVARIANCE</span>
            <span className={`text-[10px] font-mono font-bold ${riStatus.safety.goalInvariant ? 'text-aegis-green' : 'text-aegis-red'}`}>
              {riStatus.safety.goalInvariant ? 'VERIFIED' : 'DRIFT DETECTED'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[10px] font-mono text-aegis-muted">HUMAN GATES</span>
            <span className={`text-[10px] font-mono ${riStatus.safety.pendingHumanGates > 0 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
              {riStatus.safety.pendingHumanGates} PENDING
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[10px] font-mono text-aegis-muted">ROLLBACKS</span>
            <span className={`text-[10px] font-mono ${riStatus.safety.rollbacksTriggered > 0 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
              {riStatus.safety.rollbacksTriggered}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function RIHistoryPanel(props: { refinements: RIRefinementEvent[] }): JSX.Element {
  const { refinements } = props;
  return (
    <div className="space-y-2">
      <div className="data-label">REFINEMENT HISTORY</div>
      {refinements.length === 0 ? (
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-muted">No refinements recorded yet</div>
          <div className="text-[9px] font-mono text-aegis-muted mt-1">
            Refinements trigger after mission completions
          </div>
        </div>
      ) : (
        <div className="space-y-1.5">
          {refinements.map((r, i) => (
            <div key={`ri-${i}`} className={`border p-2 ${r.accepted ? 'border-aegis-border' : 'border-aegis-amber/50 bg-aegis-amber/5'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 ${
                    r.layer === 'PROMPT' ? 'bg-aegis-cyan/20 text-aegis-cyan' :
                    r.layer === 'CAPABILITY' ? 'bg-aegis-green/20 text-aegis-green' :
                    'bg-aegis-amber/20 text-aegis-amber'
                  }`}>
                    {r.layer}
                  </span>
                  <span className="text-[9px] font-mono text-aegis-muted">#{r.iteration}</span>
                </div>
                <span className={`text-[9px] font-mono font-bold ${r.accepted ? 'text-aegis-green' : 'text-aegis-red'}`}>
                  {r.accepted ? 'DEPLOYED' : 'REJECTED'}
                </span>
              </div>
              {r.accuracy !== undefined && (
                <div className="text-[9px] font-mono text-aegis-muted mt-0.5">
                  ACCURACY: {(r.accuracy * 100).toFixed(1)}%
                </div>
              )}
              {r.improvement !== undefined && (
                <div className="text-[9px] font-mono text-aegis-muted">
                  IMPROVEMENT: {r.improvement > 0 ? '+' : ''}{(r.improvement * 100).toFixed(1)}%
                </div>
              )}
              <div className="text-[8px] font-mono text-aegis-muted mt-0.5">{r.timestamp}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RISafetyPanel(props: { events: RISafetyEvent[] }): JSX.Element {
  const { events } = props;
  return (
    <div className="space-y-2">
      <div className="data-label">SAFETY EVENT LOG</div>
      {events.length === 0 ? (
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-green">ALL CLEAR</div>
          <div className="text-[9px] font-mono text-aegis-muted mt-1">
            No safety events. Containment, goal invariance, and rate limits are enforced.
          </div>
        </div>
      ) : (
        <div className="space-y-1.5">
          {events.map((e, i) => (
            <div key={`se-${i}`} className={`border p-2 ${
              e.severity === 'EMERGENCY' ? 'border-aegis-red bg-aegis-red/10' :
              e.severity === 'CRITICAL' ? 'border-aegis-red/50 bg-aegis-red/5' :
              'border-aegis-amber/50'
            }`}>
              <div className="flex items-center justify-between">
                <span className={`text-[9px] font-mono font-bold ${SEVERITY_COLORS[e.severity] || 'text-aegis-muted'}`}>
                  {e.severity} | {e.type}
                </span>
                <span className={`text-[9px] font-mono ${e.resolved ? 'text-aegis-green' : 'text-aegis-red'}`}>
                  {e.resolved ? 'RESOLVED' : 'ACTIVE'}
                </span>
              </div>
              <div className="text-[9px] font-mono text-aegis-text mt-0.5">
                {e.description.slice(0, 150)}{e.description.length > 150 ? '...' : ''}
              </div>
              <div className="text-[8px] font-mono text-aegis-muted mt-0.5">
                {e.layer} | {e.timestamp}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RICapabilitiesPanel(): JSX.Element {
  const [capabilities, setCapabilities] = useState<CapabilityDesc[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchCaps = async () => {
    setLoading(true);
    try {
      const res = await apiGet<CapabilityDesc[]>('/api/v1/intel/ri/capabilities');
      if (res.success && res.data) {
        setCapabilities(res.data);
      }
    } catch { /* noop */ }
    setLoading(false);
  };

  useEffect(() => { fetchCaps(); }, []);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="data-label">DRONE CAPABILITY DESCRIPTORS</div>
        <button
          onClick={fetchCaps}
          disabled={loading}
          className="text-[9px] font-mono text-aegis-cyan border border-aegis-border px-2 py-0.5 hover:border-aegis-cyan disabled:opacity-40"
        >
          {loading ? 'LOADING...' : 'REFRESH'}
        </button>
      </div>
      {capabilities.length === 0 ? (
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-muted">Loading capabilities...</div>
        </div>
      ) : (
        <div className="space-y-1.5">
          {capabilities.map((cap) => (
            <div key={cap.droneClass} className="border border-aegis-border p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono text-aegis-cyan font-bold">{cap.droneClass}</span>
                <span className="text-[8px] font-mono text-aegis-muted">v{cap.version} | {cap.updatedBy}</span>
              </div>
              <div className="grid grid-cols-2 gap-x-3 gap-y-0.5">
                <div className="flex justify-between">
                  <span className="text-[8px] font-mono text-aegis-muted">WIND</span>
                  <span className="text-[8px] font-mono text-aegis-text">{cap.maxWindToleranceMs}m/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[8px] font-mono text-aegis-muted">CEIL</span>
                  <span className="text-[8px] font-mono text-aegis-text">{cap.operationalCeilingFt}ft</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[8px] font-mono text-aegis-muted">HEALTH</span>
                  <span className="text-[8px] font-mono text-aegis-text">{(cap.minHealthThreshold * 100).toFixed(0)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[8px] font-mono text-aegis-muted">RANGE</span>
                  <span className="text-[8px] font-mono text-aegis-text">{cap.effectiveRangeKm}km</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[8px] font-mono text-aegis-muted">SENSOR</span>
                  <span className="text-[8px] font-mono text-aegis-text">{(cap.sensorAccuracy * 100).toFixed(0)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const RI_TABS = ['OVERVIEW', 'HISTORY', 'CAPS', 'SAFETY'] as const;

export function RIConsole(): JSX.Element {
  const { riStatus, riRefinements, riSafetyEvents, fetchRIStatus } = useFeedStore();
  const [activeTab, setActiveTab] = useState<string>('OVERVIEW');

  useEffect(() => {
    fetchRIStatus();
    const interval = setInterval(fetchRIStatus, 15000);
    return () => clearInterval(interval);
  }, [fetchRIStatus]);

  if (!riStatus) {
    return (
      <div className="space-y-3">
        <div className="data-label">RECURSIVE IMPROVEMENT</div>
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-muted">Initializing RI system...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex border-b border-aegis-border">
        {RI_TABS.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`flex-1 px-1 py-1 text-[8px] font-tactical font-semibold tracking-wider uppercase transition-colors ${
              activeTab === tab
                ? 'text-aegis-cyan border-b border-aegis-cyan'
                : 'text-aegis-muted hover:text-aegis-text'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>
      {activeTab === 'OVERVIEW' && <RIOverviewPanel riStatus={riStatus} />}
      {activeTab === 'HISTORY' && <RIHistoryPanel refinements={riRefinements} />}
      {activeTab === 'CAPS' && <RICapabilitiesPanel />}
      {activeTab === 'SAFETY' && <RISafetyPanel events={riSafetyEvents} />}
    </div>
  );
}
