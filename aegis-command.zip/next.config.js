/** @type {import('next').NextConfig} */
const nextConfig = {
  output: process.env.NETLIFY_BUILD ? 'export' : undefined,
  trailingSlash: true,
  transpilePackages: ['@aegis/shared'],
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
    NEXT_PUBLIC_WS_URL: process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:4000',
  },
};

module.exports = nextConfig;
