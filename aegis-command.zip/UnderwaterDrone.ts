import {
  DroneClass,
  DroneStatus,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export type SubsurfaceCommsMode = 'ELF' | 'VLF' | 'ACOUSTIC' | 'TETHERED';

export interface UnderwaterDroneConfig extends DroneConfig {
  maxDepthMeters?: number;
  subsurfaceComms?: SubsurfaceCommsMode;
  surfaceIntervalMin?: number;
}

export class UnderwaterDrone extends DroneBase {
  depthMeters: number;
  sonarActive: boolean;
  mineDetectionConfidence: number;
  subsurfaceComms: SubsurfaceCommsMode;
  surfaceIntervalMin: number;

  private maxDepthMeters: number;
  private surfacing: boolean = false;
  private minesDetected: number = 0;
  private lastSurfaceTime: number = Date.now();

  constructor(cfg: UnderwaterDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.UNDERWATER });
    this.depthMeters = 0;
    this.sonarActive = false;
    this.mineDetectionConfidence = 0;
    this.subsurfaceComms = cfg.subsurfaceComms ?? 'ACOUSTIC';
    this.surfaceIntervalMin = cfg.surfaceIntervalMin ?? 60;
    this.maxDepthMeters = cfg.maxDepthMeters ?? 200;
  }

  dive(targetDepthMeters: number): boolean {
    if (targetDepthMeters > this.maxDepthMeters || targetDepthMeters < 0) {
      return false;
    }
    this.depthMeters = targetDepthMeters;
    this.surfacing = false;
    return true;
  }

  surface(): void {
    this.surfacing = true;
    this.depthMeters = 0;
    this.lastSurfaceTime = Date.now();
  }

  isSurfaced(): boolean {
    return this.depthMeters === 0;
  }

  activateSonar(): void {
    this.sonarActive = true;
  }

  deactivateSonar(): void {
    this.sonarActive = false;
    this.mineDetectionConfidence = 0;
  }

  updateMineDetectionConfidence(confidence: number): void {
    this.mineDetectionConfidence = Math.max(0, Math.min(1, confidence));
  }

  recordMineDetection(): void {
    this.minesDetected++;
  }

  getMinesDetected(): number {
    return this.minesDetected;
  }

  getTimeSinceLastSurfaceMin(): number {
    return (Date.now() - this.lastSurfaceTime) / 60_000;
  }

  needsSurfacing(): boolean {
    return this.getTimeSinceLastSurfaceMin() >= this.surfaceIntervalMin;
  }

  getMaxDepthMeters(): number {
    return this.maxDepthMeters;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      depthMeters: this.depthMeters,
      maxDepthMeters: this.maxDepthMeters,
      sonarActive: this.sonarActive,
      mineDetectionConfidence: this.mineDetectionConfidence,
      minesDetected: this.minesDetected,
      subsurfaceComms: this.subsurfaceComms,
      surfaceIntervalMin: this.surfaceIntervalMin,
      timeSinceLastSurfaceMin: this.getTimeSinceLastSurfaceMin(),
      needsSurfacing: this.needsSurfacing(),
      surfacing: this.surfacing,
      isSurfaced: this.isSurfaced(),
    };
  }

  getAIContextDescriptor(): string {
    return [
      `UNDERWATER drone ${this.callsign} (${this.model})`,
      `Depth: ${this.depthMeters}m / ${this.maxDepthMeters}m max`,
      `Sonar: ${this.sonarActive ? 'ACTIVE' : 'OFF'} | Mine confidence: ${(this.mineDetectionConfidence * 100).toFixed(1)}%`,
      `Mines detected: ${this.minesDetected}`,
      `Comms: ${this.subsurfaceComms}`,
      `Surface interval: ${this.surfaceIntervalMin}min | Last surface: ${this.getTimeSinceLastSurfaceMin().toFixed(1)}min ago`,
      `Surfacing needed: ${this.needsSurfacing()}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ depth ${this.depthMeters}m`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'SONAR_SCANNING',
        available: true,
        degradedMode: 'Autonomous sonar sweep on pre-planned grid; detections stored onboard',
      },
      {
        capability: 'MINE_DETECTION',
        available: this.sonarActive,
        degradedMode: 'Passive mine classification using cached signatures; high-confidence only',
      },
      {
        capability: 'SUBSURFACE_COMMS',
        available: this.subsurfaceComms === 'TETHERED',
        degradedMode: 'Only tethered comms reliable during link loss; acoustic/ELF/VLF degraded',
      },
      {
        capability: 'DEPTH_CONTROL',
        available: true,
        degradedMode: 'Autonomous depth management; emergency surface if battery critical',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS dead-reckoning with DVL bottom-track; surface for GPS fix at intervals',
      },
      {
        capability: 'DATA_COLLECTION',
        available: true,
        degradedMode: 'Bathymetric and sensor data logged onboard for post-mission extraction',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.surface();
  }
}

export default UnderwaterDrone;
