import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { AirspaceLinkZone, IntelFeedResult } from '../types';

const CACHE_KEY = 'intel:airspacelink';
const TTL = 600;

export async function fetchAirspaceLink(lat: number, lon: number, _apiKey?: string): Promise<IntelFeedResult<AirspaceLinkZone[]>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(2)}_${lon.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'airspace-link', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  const zones = simulateAirspaceLink(lat, lon);
  await redis.set(cacheKey, JSON.stringify(zones), 'EX', TTL);
  logger.debug({ count: zones.length }, 'Airspace Link data generated (simulated)');
  return { success: true, data: zones, source: 'airspace-link-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
}

function simulateAirspaceLink(lat: number, lon: number): AirspaceLinkZone[] {
  const zones: AirspaceLinkZone[] = [
    {
      zoneId: `ASL-${lat.toFixed(0)}${lon.toFixed(0)}-A`,
      name: 'Class D Surface Area',
      type: 'CONTROLLED',
      maxAltFt: 2500,
      advisoryType: 'AUTHORIZATION_REQUIRED',
      laancStatus: 'AVAILABLE',
    },
  ];
  if (Math.random() > 0.5) {
    zones.push({
      zoneId: `ASL-${lat.toFixed(0)}${lon.toFixed(0)}-B`,
      name: 'National Security UAS Flight Restriction',
      type: 'RESTRICTED',
      maxAltFt: 400,
      advisoryType: 'PROHIBITED',
      laancStatus: 'NOT_AVAILABLE',
    });
  }
  return zones;
}
