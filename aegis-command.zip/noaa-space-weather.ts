import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, NOAASpaceWeather } from '../types';

const CACHE_KEY = 'intel:noaa_kp';
const TTL = 60;

export async function fetchNOAASpaceWeather(): Promise<IntelFeedResult<NOAASpaceWeather>> {
  const cached = await redis.get(CACHE_KEY);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'noaa-swpc', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = 'https://services.swpc.noaa.gov/json/planetary_k_index_1m.json';
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`NOAA Kp HTTP ${res.status}`);

    const json = await res.json() as Array<{ time_tag: string; kp_index: number }>;
    const latest = json[json.length - 1];
    const kp = latest?.kp_index ?? 2;

    const result = kpToAssessment(kp, latest?.time_tag ?? zuluTimestamp());
    await redis.set(CACHE_KEY, JSON.stringify(result), 'EX', TTL);
    logger.debug({ kpIndex: kp }, 'NOAA Space Weather fetched');
    return { success: true, data: result, source: 'noaa-swpc', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'NOAA Space Weather fetch failed — using simulated data');
    return { success: true, data: simulateSpaceWeather(), source: 'noaa-swpc-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function kpToAssessment(kp: number, timeTag: string): NOAASpaceWeather {
  let gpsConfidence: NOAASpaceWeather['gpsConfidence'];
  let riskDelta: number;

  if (kp <= 3) { gpsConfidence = 'HIGH'; riskDelta = 0; }
  else if (kp <= 5) { gpsConfidence = 'MEDIUM'; riskDelta = 0.10; }
  else if (kp <= 6) { gpsConfidence = 'LOW'; riskDelta = 0.25; }
  else if (kp <= 7) { gpsConfidence = 'DEGRADED'; riskDelta = 0.40; }
  else { gpsConfidence = 'UNUSABLE'; riskDelta = 0.90; }

  return { kpIndex: kp, timeTag, gpsConfidence, riskDelta };
}

function simulateSpaceWeather(): NOAASpaceWeather {
  const kp = Math.random() > 0.9 ? 5 + Math.random() * 3 : 1 + Math.random() * 3;
  return kpToAssessment(Math.round(kp * 10) / 10, zuluTimestamp());
}
