import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { query } from '../db/pool';
import { authMiddleware, rbacGuard } from '../auth/middleware';
import { hcsService } from '../hedera/HCSService';
import { logger } from '../logger';
import { ActionType } from '@aegis/shared';

const router = Router();

const logQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(50),
  missionId: z.string().uuid().optional(),
  droneId: z.string().uuid().optional(),
  actionType: z.nativeEnum(ActionType).optional(),
  startTime: z.string().datetime().optional(),
  endTime: z.string().datetime().optional(),
});

router.get('/', authMiddleware(), rbacGuard('log:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const parsed = logQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      res.status(400).json({ success: false, error: 'Invalid query parameters', details: parsed.error.flatten(), timestamp: new Date().toISOString() });
      return;
    }

    const { page, pageSize, missionId, droneId, actionType, startTime, endTime } = parsed.data;
    const offset = (page - 1) * pageSize;

    const conditions: string[] = [];
    const params: unknown[] = [];
    let paramIdx = 1;

    if (missionId) {
      conditions.push(`mission_id = $${paramIdx++}`);
      params.push(missionId);
    }
    if (droneId) {
      conditions.push(`drone_id = $${paramIdx++}`);
      params.push(droneId);
    }
    if (actionType) {
      conditions.push(`action_type = $${paramIdx++}`);
      params.push(actionType);
    }
    if (startTime) {
      conditions.push(`consensus_timestamp >= $${paramIdx++}`);
      params.push(startTime);
    }
    if (endTime) {
      conditions.push(`consensus_timestamp <= $${paramIdx++}`);
      params.push(endTime);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countResult = await query<{ count: string }>(
      `SELECT COUNT(*) as count FROM hcs_action_log ${whereClause}`,
      params
    );
    const total = parseInt(countResult.rows[0]?.count ?? '0', 10);

    const dataResult = await query(
      `SELECT id, sequence_number, consensus_timestamp, topic_id, transaction_id,
              drone_id, action_type, operator_id, mission_id, ai_confidence,
              payload, compliance_log, hashscan_url, created_at
       FROM hcs_action_log ${whereClause}
       ORDER BY consensus_timestamp DESC
       LIMIT $${paramIdx++} OFFSET $${paramIdx}`,
      [...params, pageSize, offset]
    );

    res.json({
      success: true,
      data: {
        data: dataResult.rows,
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch HCS log');
    res.status(500).json({ success: false, error: 'Failed to fetch action log', timestamp: new Date().toISOString() });
  }
});

router.get('/:missionId', authMiddleware(), rbacGuard('log:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const { missionId } = req.params;

    const pageSize = Math.min(parseInt(req.query.pageSize as string ?? '100', 10), 500);

    const result = await query(
      `SELECT id, sequence_number, consensus_timestamp, topic_id, transaction_id,
              drone_id, action_type, operator_id, mission_id, ai_confidence,
              payload, compliance_log, hashscan_url, created_at
       FROM hcs_action_log
       WHERE mission_id = $1
       ORDER BY sequence_number DESC
       LIMIT $2`,
      [missionId, pageSize]
    );

    const seqNumbers = result.rows.map((r: Record<string, unknown>) => parseInt((r.sequence_number as string) ?? '0', 10)).sort((a, b) => a - b);
    const gaps: number[] = [];
    for (let i = 1; i < seqNumbers.length; i++) {
      if (seqNumbers[i] - seqNumbers[i - 1] > 1) {
        for (let g = seqNumbers[i - 1] + 1; g < seqNumbers[i]; g++) {
          gaps.push(g);
        }
      }
    }

    res.json({
      success: true,
      data: {
        entries: result.rows,
        count: result.rowCount,
        sequenceGaps: gaps,
        integrity: gaps.length === 0 ? 'VERIFIED' : 'GAPS_DETECTED',
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch mission log');
    res.status(500).json({ success: false, error: 'Failed to fetch mission log', timestamp: new Date().toISOString() });
  }
});

router.get('/verify/:seqNumber', authMiddleware(), rbacGuard('log:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const seqNumber = parseInt(req.params.seqNumber, 10);
    if (isNaN(seqNumber)) {
      res.status(400).json({ success: false, error: 'Invalid sequence number', timestamp: new Date().toISOString() });
      return;
    }

    const result = await query(
      `SELECT id, sequence_number, consensus_timestamp, topic_id, transaction_id,
              drone_id, action_type, operator_id, mission_id, ai_confidence,
              compliance_log, hashscan_url
       FROM hcs_action_log
       WHERE sequence_number = $1`,
      [seqNumber]
    );

    if (result.rows.length === 0) {
      res.status(404).json({ success: false, error: `Sequence number ${seqNumber} not found`, timestamp: new Date().toISOString() });
      return;
    }

    const entry = result.rows[0] as Record<string, unknown>;

    const prevResult = await query(
      'SELECT sequence_number FROM hcs_action_log WHERE topic_id = $1 AND sequence_number = $2',
      [entry.topic_id, seqNumber - 1]
    );

    const nextResult = await query(
      'SELECT sequence_number FROM hcs_action_log WHERE topic_id = $1 AND sequence_number = $2',
      [entry.topic_id, seqNumber + 1]
    );

    res.json({
      success: true,
      data: {
        entry,
        sequenceIntegrity: {
          previousExists: prevResult.rowCount !== null && prevResult.rowCount > 0,
          nextExists: nextResult.rowCount !== null && nextResult.rowCount > 0,
          gapBefore: seqNumber > 1 && (prevResult.rowCount === null || prevResult.rowCount === 0),
          gapAfter: nextResult.rowCount === null || nextResult.rowCount === 0,
        },
        hashscanUrl: entry.hashscan_url,
        verificationNote: 'Verify on HashScan by visiting the hashscan_url. The transaction ID can be cross-referenced with the Hedera consensus timestamp.',
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to verify sequence');
    res.status(500).json({ success: false, error: 'Verification failed', timestamp: new Date().toISOString() });
  }
});

export { router as logRouter };
