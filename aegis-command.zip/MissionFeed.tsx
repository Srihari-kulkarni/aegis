'use client';

import { useRef, useEffect, useState, useCallback } from 'react';
import { useFeedStore } from '@/stores/feedStore';
import { ActionType } from '@aegis/shared';

interface MissionFeedProps {
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

const TRUNCATE_LEN = 8;

function truncateId(id: string): string {
  if (!id) return '—';
  if (id.length <= TRUNCATE_LEN + 4) return id;
  return `${id.slice(0, TRUNCATE_LEN)}…${id.slice(-4)}`;
}

function getActionBadgeClasses(actionType: ActionType): string {
  const base = 'inline-flex px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider border';
  const redBg = 'bg-aegis-red/20 border-aegis-red text-aegis-red';
  const purpleBg = 'bg-[#a855f7]/20 border-[#a855f7] text-[#a855f7]';
  const redBorder = 'border-aegis-red text-aegis-red bg-transparent';
  const amber = 'border-aegis-amber text-aegis-amber bg-aegis-amber/10';
  const green = 'border-aegis-green text-aegis-green bg-aegis-green/10';
  const cyan = 'border-aegis-cyan text-aegis-cyan bg-transparent';

  switch (actionType) {
    case ActionType.EMERGENCY_DECLARED:
    case ActionType.THREAT_DETECTED:
    case ActionType.LINK_LOST:
      return `${base} ${redBg}`;
    case ActionType.AI_ASSESSMENT:
    case ActionType.AI_OVERRIDE:
      return `${base} ${purpleBg}`;
    case ActionType.WEAPON_ARMED:
    case ActionType.WEAPON_RELEASED:
      return `${base} ${redBorder}`;
    case ActionType.LINK_DEGRADED:
      return `${base} ${amber}`;
    case ActionType.MISSION_COMPLETED:
    case ActionType.DRONE_LANDED:
      return `${base} ${green}`;
    default:
      return `${base} ${cyan}`;
  }
}

function isLinkDegraded(actionType: ActionType): boolean {
  return actionType === ActionType.LINK_DEGRADED;
}

const ACTION_TYPES: ActionType[] = Object.values(ActionType);

export function MissionFeed({ collapsed = false, onToggleCollapse }: MissionFeedProps) {
  const getFilteredLog = useFeedStore((s) => s.getFilteredLog);
  const autoScroll = useFeedStore((s) => s.autoScroll);
  const setAutoScroll = useFeedStore((s) => s.setAutoScroll);
  const actionTypeFilter = useFeedStore((s) => s.actionTypeFilter);
  const setActionTypeFilter = useFeedStore((s) => s.setActionTypeFilter);
  const missionFilter = useFeedStore((s) => s.missionFilter);
  const setMissionFilter = useFeedStore((s) => s.setMissionFilter);
  const detectSequenceGaps = useFeedStore((s) => s.detectSequenceGaps);

  const scrollRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [missionFilterInput, setMissionFilterInput] = useState('');

  const entries = getFilteredLog();
  const sortedEntries = [...entries].sort(
    (a, b) => new Date(b.consensusTimestamp).getTime() - new Date(a.consensusTimestamp).getTime()
  );
  const gaps = detectSequenceGaps();
  const hasGaps = gaps.length > 0;

  const shouldAutoScroll = autoScroll && !isHovering;

  useEffect(() => {
    if (shouldAutoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [sortedEntries, shouldAutoScroll]);

  const handleMissionFilterBlur = useCallback(() => {
    setMissionFilter(missionFilterInput.trim() || null);
  }, [missionFilterInput, setMissionFilter]);

  useEffect(() => {
    setMissionFilterInput(missionFilter ?? '');
  }, [missionFilter]);

  if (collapsed) {
    return (
      <div className="h-8 flex items-center bg-aegis-panel border-t border-aegis-border">
        <button
          type="button"
          onClick={onToggleCollapse}
          className="flex items-center gap-2 px-3 py-1 font-tactical font-semibold text-aegis-cyan uppercase tracking-wider text-[10px] hover:text-aegis-text"
        >
          ▲ MISSION FEED ({entries.length} entries)
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-aegis-panel border-t border-aegis-border">
      <div className="flex flex-col shrink-0 border-b border-aegis-border">
        <div className="flex items-center justify-between px-3 py-2">
          <div className="flex items-center gap-2">
            <h3 className="font-tactical font-semibold text-aegis-cyan uppercase tracking-wider text-xs">
              Mission Feed
            </h3>
            {onToggleCollapse && (
              <button
                type="button"
                onClick={onToggleCollapse}
                className="font-mono text-aegis-muted hover:text-aegis-text text-[10px]"
              >
                [Collapse]
              </button>
            )}
          </div>
          <label className="flex items-center gap-2 font-mono text-aegis-muted text-xs">
            <input
              type="checkbox"
              checked={autoScroll}
              onChange={(e) => setAutoScroll(e.target.checked)}
              className="border-aegis-border bg-aegis-bg"
            />
            Auto-scroll
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-2 px-3 pb-2">
          <select
            value={actionTypeFilter ?? ''}
            onChange={(e) => setActionTypeFilter((e.target.value as ActionType) || null)}
            className="tactical-input py-1.5 text-xs max-w-[180px]"
          >
            <option value="">All actions</option>
            {ACTION_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Mission ID filter"
            value={missionFilterInput}
            onChange={(e) => setMissionFilterInput(e.target.value)}
            onBlur={handleMissionFilterBlur}
            onKeyDown={(e) => e.key === 'Enter' && handleMissionFilterBlur()}
            className="tactical-input py-1.5 text-xs w-32"
          />
        </div>

        {hasGaps && (
          <div className="mx-3 mb-2 px-2 py-1.5 bg-aegis-amber/10 border border-aegis-amber font-mono text-[10px] text-aegis-amber">
            SEQUENCE GAP DETECTED — Missing: {gaps.slice(0, 10).join(', ')}
            {gaps.length > 10 && ` (+${gaps.length - 10} more)`}
          </div>
        )}
      </div>

      <div
        ref={scrollRef}
        className="flex-1 overflow-auto font-mono text-[10px] text-aegis-muted max-h-full"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        {sortedEntries.length === 0 ? (
          <p className="p-3 text-aegis-muted">No log entries</p>
        ) : (
          <div className="p-2 space-y-1">
            {sortedEntries.map((e, i) => (
              <div
                key={`${e.topicId}-${e.sequenceNumber}-${e.transactionId}-${i}`}
                className={`pl-2 py-1 border-l-2 ${
                  isLinkDegraded(e.actionType) ? 'border-aegis-red' : 'border-aegis-border'
                } hover:border-aegis-cyan/50`}
              >
                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                  <span className="text-aegis-muted font-mono">
                    {new Date(e.consensusTimestamp).toISOString().replace('T', ' ').slice(0, 19)}Z
                  </span>
                  <span className="text-aegis-cyan">{truncateId(e.droneId)}</span>
                  <span className={getActionBadgeClasses(e.actionType)}>{e.actionType}</span>
                  <span className="text-aegis-muted">SEQ:{e.sequenceNumber}</span>
                  <span className="text-aegis-muted">{truncateId(e.operatorId)}</span>
                  <span className="text-aegis-muted">{truncateId(e.missionId)}</span>
                  {e.transactionId && (
                    <a
                      href={`https://hashscan.io/testnet/transaction/${e.transactionId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-aegis-cyan hover:underline"
                    >
                      VERIFY ON HASHSCAN
                    </a>
                  )}
                </div>
                {e.actionType === ActionType.AI_ASSESSMENT && e.aiConfidence != null && (
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-aegis-muted">AI:</span>
                    <div className="flex-1 max-w-24 h-1 bg-aegis-bg">
                      <div
                        className={`h-full ${
                          e.aiConfidence >= 0.7
                            ? 'bg-aegis-green'
                            : e.aiConfidence >= 0.4
                              ? 'bg-aegis-amber'
                              : 'bg-aegis-red'
                        }`}
                        style={{ width: `${e.aiConfidence * 100}%` }}
                      />
                    </div>
                    <span className="text-aegis-muted">{(e.aiConfidence * 100).toFixed(0)}%</span>
                  </div>
                )}
                {e.complianceLog && (
                  <p className="mt-0.5 text-[9px] text-aegis-muted/80 break-all">{e.complianceLog}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
