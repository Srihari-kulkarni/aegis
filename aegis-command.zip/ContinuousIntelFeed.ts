import { aiEngine } from './AIMissionApprovalEngine';
import { query } from '../db/pool';
import { redis, redisPub } from '../redis';
import { logger } from '../logger';
import {
  MissionStatus,
  MissionType,
  ClearanceLevel,
  zuluTimestamp,
} from '@aegis/shared';

interface ActiveMissionRecord {
  mission_id: string;
  name: string;
  type: MissionType;
  status: MissionStatus;
  commander_id: string;
  commander_callsign: string;
  description: string;
  area_of_operations: Record<string, unknown> | null;
  waypoints: Array<{
    index: number;
    position: { lat: number; lon: number; alt: number };
    action: string;
    reached: boolean;
  }>;
  assigned_drone_ids: string[];
  hcs_topic_id: string | null;
  ai_assessment_id: string | null;
  planned_start_time: string;
  planned_end_time: string;
  actual_start_time: string | null;
  actual_end_time: string | null;
  clearance_level: ClearanceLevel;
}

interface RiskHistory {
  missionId: string;
  scores: number[];
  timestamps: string[];
}

export class ContinuousIntelFeed {
  private intervalHandle: ReturnType<typeof setInterval> | null = null;
  private riskHistory: Map<string, RiskHistory> = new Map();
  private lastRiskScores: Map<string, number> = new Map();
  private running = false;

  start(): void {
    if (this.running) return;
    this.running = true;

    this.intervalHandle = setInterval(() => {
      this.runCycle().catch((err) => {
        logger.error({ err }, 'Continuous intel feed cycle error');
      });
    }, 30000);

    logger.info('Continuous intel feed started (30s interval)');
  }

  stop(): void {
    if (this.intervalHandle) {
      clearInterval(this.intervalHandle);
      this.intervalHandle = null;
    }
    this.running = false;
    logger.info('Continuous intel feed stopped');
  }

  private async runCycle(): Promise<void> {
    const result = await query<Record<string, unknown> & ActiveMissionRecord>(
      "SELECT * FROM missions WHERE status IN ('ACTIVE', 'COMMANDER_APPROVED', 'AI_APPROVED')"
    );

    const activeMissions = result.rows;

    if (activeMissions.length === 0) return;

    logger.debug({ count: activeMissions.length }, 'Running continuous intel feed for active missions');

    for (const mission of activeMissions) {
      try {
        await this.reassessMission(mission);
      } catch (err) {
        logger.error({ err, missionId: mission.mission_id }, 'Failed to reassess mission');
      }
    }
  }

  private async reassessMission(mission: ActiveMissionRecord): Promise<void> {
    const firstWaypoint = mission.waypoints?.[0];
    const lat = firstWaypoint?.position.lat ?? 34.052;
    const lon = firstWaypoint?.position.lon ?? -118.244;

    const [weather, airspace, threats, fleet] = await Promise.all([
      aiEngine.fetchWeatherData(lat, lon),
      aiEngine.fetchAirspaceData(lat, lon),
      aiEngine.fetchThreatData(lat, lon),
      aiEngine.getFleetStatus(mission.assigned_drone_ids),
    ]);

    const context = {
      mission: {
        missionId: mission.mission_id,
        name: mission.name,
        type: mission.type,
        status: mission.status,
        commanderId: mission.commander_id,
        commanderCallsign: mission.commander_callsign,
        description: mission.description,
        areaOfOperations: mission.area_of_operations as import('@aegis/shared').GeoJSON.Polygon | null,
        waypoints: (mission.waypoints ?? []).map((w) => ({
          ...w,
          action: w.action as 'FLY_TO' | 'LOITER' | 'SURVEY' | 'DELIVER' | 'RETURN' | 'LAND',
        })),
        assignedDroneIds: mission.assigned_drone_ids,
        hcsTopicId: mission.hcs_topic_id,
        aiAssessmentId: mission.ai_assessment_id,
        plannedStartTime: mission.planned_start_time,
        plannedEndTime: mission.planned_end_time,
        actualStartTime: mission.actual_start_time,
        actualEndTime: mission.actual_end_time,
        clearanceLevel: mission.clearance_level,
        createdAt: '',
        updatedAt: '',
      },
      assignedDrones: fleet,
      weatherData: weather,
      airspaceData: airspace,
      threatData: threats,
      operatorClearance: mission.clearance_level,
      commanderCallsign: mission.commander_callsign,
    };

    const quickRiskScore = this.calculateQuickRisk(weather, threats, fleet);

    const previousScore = this.lastRiskScores.get(mission.mission_id) ?? 0;
    const delta = Math.abs(quickRiskScore - previousScore);

    this.lastRiskScores.set(mission.mission_id, quickRiskScore);

    const history = this.riskHistory.get(mission.mission_id) ?? {
      missionId: mission.mission_id,
      scores: [],
      timestamps: [],
    };
    history.scores.push(quickRiskScore);
    history.timestamps.push(zuluTimestamp());
    if (history.scores.length > 10) {
      history.scores.shift();
      history.timestamps.shift();
    }
    this.riskHistory.set(mission.mission_id, history);

    if (delta > 0.1) {
      logger.info({
        missionId: mission.mission_id,
        previousScore,
        newScore: quickRiskScore,
        delta,
      }, 'Significant risk delta detected — pushing intel update');

      await redisPub.publish('mission:ai_decision', JSON.stringify({
        type: 'CONTINUOUS_INTEL_UPDATE',
        missionId: mission.mission_id,
        missionName: mission.name,
        riskScore: quickRiskScore,
        riskDelta: delta,
        previousScore,
        weather: {
          condition: weather.weatherCondition,
          windSpeedMs: weather.windSpeedMs,
          visibilityM: weather.visibilityM,
          thunderstorm: weather.thunderstorm,
        },
        threatLevel: threats.overallThreatLevel,
        activeThreatCount: threats.threats.length,
        fleetReadyCount: fleet.filter((d) => d.health >= 0.6).length,
        riskHistory: history.scores.slice(-10),
        timestamp: zuluTimestamp(),
      }));
    }
  }

  private calculateQuickRisk(
    weather: import('@aegis/shared').WeatherData,
    threats: import('@aegis/shared').ThreatIntel,
    fleet: import('@aegis/shared').FleetDroneStatus[]
  ): number {
    let risk = 0;

    if (weather.thunderstorm) risk = Math.max(risk, 1.0);
    if (weather.windSpeedMs > 15) risk = Math.max(risk, 0.9);
    else if (weather.windSpeedMs > 10) risk = Math.max(risk, 0.5);

    if (weather.visibilityM < 1000) risk = Math.max(risk, 0.85);
    else if (weather.visibilityM < 3000) risk = Math.max(risk, 0.4);

    switch (threats.overallThreatLevel) {
      case 'CRITICAL': risk = Math.max(risk, 0.95); break;
      case 'HIGH': risk = Math.max(risk, 0.7); break;
      case 'MEDIUM': risk = Math.max(risk, 0.4); break;
      default: break;
    }

    const unhealthy = fleet.filter((d) => d.health < 0.6).length;
    if (unhealthy > 0) {
      risk = Math.max(risk, 0.3 + unhealthy * 0.15);
    }

    return Math.min(1.0, risk);
  }

  getRiskHistory(missionId: string): RiskHistory | null {
    return this.riskHistory.get(missionId) ?? null;
  }
}

export const continuousIntelFeed = new ContinuousIntelFeed();
