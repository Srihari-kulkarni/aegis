'use client';

import { useState, useEffect } from 'react';
import { useFeedStore } from '@/stores/feedStore';
import { useMissionStore } from '@/stores/missionStore';
import { apiGet, apiPost } from '@/lib/api';
import { RIConsole } from './RIConsole';

interface WeatherData {
  tempC: number;
  humidity: number;
  windSpeedMs: number;
  windDirection: number;
  visibilityM: number;
  cloudCoverPercent: number;
  weatherCondition: string;
  thunderstorm: boolean;
  precipitationMm: number;
  fetchedAt: string;
}

const TIER_LABELS: Record<string, string> = {
  CLOUD_GPT4O: 'GPT-4o CLOUD',
  LOCAL_70B: 'AirLLM 70B',
  LOCAL_7B: 'AirLLM 7B',
  RULE_ENGINE: 'RULE ENGINE',
};

const TIER_COLORS: Record<string, string> = {
  CLOUD_GPT4O: 'text-aegis-cyan',
  LOCAL_70B: 'text-aegis-green',
  LOCAL_7B: 'text-aegis-amber',
  RULE_ENGINE: 'text-aegis-muted',
};

const GPS_COLORS: Record<string, string> = {
  HIGH: 'text-aegis-green',
  MEDIUM: 'text-aegis-amber',
  LOW: 'text-aegis-red',
  DEGRADED: 'text-aegis-red',
  UNUSABLE: 'text-aegis-red',
};

const ALL_TIERS = ['CLOUD_GPT4O', 'LOCAL_70B', 'LOCAL_7B', 'RULE_ENGINE'];
const SECTIONS = ['STATUS', 'FEEDS', 'WEATHER', 'CMDS', 'INTEL', 'RI'] as const;

function windDir(deg: number): string {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return dirs[Math.round(deg / 22.5) % 16];
}

function StatusSection(props: {
  tier: string;
  modelStatus: ReturnType<typeof useFeedStore.getState>['modelStatus'];
  spaceWeather: ReturnType<typeof useFeedStore.getState>['spaceWeather'];
  selectedAssessment: ReturnType<typeof useMissionStore.getState>['selectedAssessment'];
  activeMissions: Array<{ missionId: string; name: string; status: string }>;
  isReassessing: boolean;
  onReassess: (id: string) => void;
}): JSX.Element {
  const { tier, modelStatus, spaceWeather, selectedAssessment, activeMissions, isReassessing, onReassess } = props;
  return (
    <>
      <div className="border border-aegis-border p-3">
        <div className="data-label mb-2">MODEL ROUTER</div>
        <div className="space-y-1.5">
          {ALL_TIERS.map((t) => {
            const isActive = tier === t;
            const st = modelStatus?.tiers?.[t]?.status || (isActive ? 'ACTIVE' : 'STANDBY');
            return (
              <div key={t} className={`flex items-center justify-between py-1 px-2 ${isActive ? 'bg-aegis-bg border border-aegis-cyan/30' : ''}`}>
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 ${isActive ? 'bg-aegis-green animate-pulse' : 'bg-aegis-muted'}`} />
                  <span className={`text-[10px] font-mono ${isActive ? (TIER_COLORS[t] || '') : 'text-aegis-muted'}`}>
                    {TIER_LABELS[t] || t}
                  </span>
                </div>
                <span className={`text-[9px] font-mono ${isActive ? 'text-aegis-green' : 'text-aegis-muted'}`}>{st}</span>
              </div>
            );
          })}
        </div>
        {modelStatus?.lastRouting && (
          <div className="mt-2 pt-2 border-t border-aegis-border/50">
            <div className="text-[9px] font-mono text-aegis-muted">
              ROUTING: {modelStatus.lastRouting.reason}
            </div>
            <div className="text-[9px] font-mono text-aegis-muted">
              LATENCY: {modelStatus.lastRouting.latencyMs}ms
            </div>
          </div>
        )}
      </div>

      <div className="border border-aegis-border p-3">
        <div className="data-label mb-2">SPACE WEATHER</div>
        {spaceWeather ? (
          <div className="space-y-1.5">
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">Kp INDEX</span>
              <span className={`text-xs font-mono font-bold ${spaceWeather.kpIndex > 7 ? 'text-aegis-red' : spaceWeather.kpIndex > 5 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
                {spaceWeather.kpIndex}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">GPS</span>
              <span className={`text-xs font-mono font-bold ${GPS_COLORS[spaceWeather.gpsConfidence] || 'text-aegis-text'}`}>
                {spaceWeather.gpsConfidence}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">RISK DELTA</span>
              <span className={`text-xs font-mono ${spaceWeather.riskDelta > 0 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
                {spaceWeather.riskDelta > 0 ? '+' : ''}{(spaceWeather.riskDelta * 100).toFixed(0)}%
              </span>
            </div>
            <div className="gauge-bar mt-1">
              <div
                className={`gauge-fill ${spaceWeather.kpIndex > 7 ? 'bg-aegis-red' : spaceWeather.kpIndex > 5 ? 'bg-aegis-amber' : 'bg-aegis-green'}`}
                style={{ width: `${Math.min(100, (spaceWeather.kpIndex / 9) * 100)}%` }}
              />
            </div>
            <div className="text-[9px] font-mono text-aegis-muted">
              NOAA SWPC | {spaceWeather.timeTag}
            </div>
          </div>
        ) : (
          <div className="text-xs font-mono text-aegis-muted">Loading...</div>
        )}
      </div>

      {selectedAssessment && (
        <div className="border border-aegis-border p-3">
          <div className="data-label mb-2">LAST ASSESSMENT</div>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-aegis-muted font-mono">REC</span>
              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 ${
                selectedAssessment.recommendation === 'APPROVE' ? 'bg-aegis-green/20 text-aegis-green' :
                selectedAssessment.recommendation === 'REJECT' ? 'bg-aegis-red/20 text-aegis-red' :
                'bg-aegis-amber/20 text-aegis-amber'
              }`}>
                {selectedAssessment.recommendation}
              </span>
            </div>
            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-[10px] text-aegis-muted font-mono">CONFIDENCE</span>
                <span className="text-[10px] font-mono text-aegis-text">
                  {(selectedAssessment.confidence * 100).toFixed(0)}%
                </span>
              </div>
              <div className="gauge-bar">
                <div
                  className={`gauge-fill ${selectedAssessment.confidence >= 0.7 ? 'bg-aegis-green' : 'bg-aegis-amber'}`}
                  style={{ width: `${selectedAssessment.confidence * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-0.5">
                <span className="text-[10px] text-aegis-muted font-mono">RISK</span>
                <span className="text-[10px] font-mono text-aegis-text">
                  {(selectedAssessment.riskScore * 100).toFixed(0)}%
                </span>
              </div>
              <div className="gauge-bar">
                <div
                  className={`gauge-fill ${
                    selectedAssessment.riskScore > 0.75 ? 'bg-aegis-red' :
                    selectedAssessment.riskScore > 0.4 ? 'bg-aegis-amber' : 'bg-aegis-green'
                  }`}
                  style={{ width: `${selectedAssessment.riskScore * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="border border-aegis-border p-3">
        <div className="data-label mb-2">ACTIVE MISSIONS ({activeMissions.length})</div>
        {activeMissions.length === 0 ? (
          <div className="text-xs font-mono text-aegis-muted">No active missions</div>
        ) : (
          <div className="space-y-1.5">
            {activeMissions.map((m) => (
              <div key={m.missionId} className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-mono text-aegis-text">{m.name}</div>
                  <div className="text-[9px] font-mono text-aegis-muted">{m.status}</div>
                </div>
                <button
                  onClick={() => onReassess(m.missionId)}
                  disabled={isReassessing}
                  className="text-[9px] font-mono text-aegis-cyan border border-aegis-border px-2 py-0.5 hover:border-aegis-cyan disabled:opacity-40"
                >
                  REASSESS
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

function FeedsSection(props: {
  intelFeedSummary: ReturnType<typeof useFeedStore.getState>['intelFeedSummary'];
  isLoadingFeeds: boolean;
  onRefresh: () => void;
}): JSX.Element {
  const { intelFeedSummary, isLoadingFeeds, onRefresh } = props;
  return (
    <>
      <div className="flex items-center justify-between mb-1">
        <div className="data-label">13 INTEL FEED STATUS</div>
        <button
          onClick={onRefresh}
          disabled={isLoadingFeeds}
          className="text-[9px] font-mono text-aegis-cyan border border-aegis-border px-2 py-0.5 hover:border-aegis-cyan disabled:opacity-40"
        >
          {isLoadingFeeds ? 'FETCHING...' : 'REFRESH ALL'}
        </button>
      </div>
      {intelFeedSummary ? (
        <div className="space-y-0.5">
          {Object.entries(intelFeedSummary).map(([key, val]) => {
            const v = val as Record<string, unknown>;
            const isLive = typeof v.source === 'string' && !v.source.includes('simulated');
            const extra = (v.count ?? v.alerts ?? v.tfrs ?? v.frequencies ?? v.flights ?? v.kpIndex) as number | undefined;
            return (
              <div key={key} className="flex items-center justify-between py-1 px-2 border border-aegis-border/30">
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 ${v.available ? (isLive ? 'bg-aegis-green' : 'bg-aegis-amber') : 'bg-aegis-red'}`} />
                  <span className="text-[10px] font-mono text-aegis-text uppercase">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {extra !== undefined && (
                    <span className="text-[9px] font-mono text-aegis-cyan">{extra}</span>
                  )}
                  <span className={`text-[9px] font-mono ${isLive ? 'text-aegis-green' : 'text-aegis-amber'}`}>
                    {isLive ? 'LIVE' : 'SIM'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-muted mb-2">No feed data loaded</div>
          <button
            onClick={onRefresh}
            className="text-[10px] font-mono text-aegis-cyan border border-aegis-cyan px-3 py-1 hover:bg-aegis-cyan/10"
          >
            FETCH ALL 13 FEEDS
          </button>
        </div>
      )}
    </>
  );
}

function WeatherSection(props: {
  weather: WeatherData | null;
  isLoadingWeather: boolean;
  spaceWeather: ReturnType<typeof useFeedStore.getState>['spaceWeather'];
  onRefresh: () => void;
}): JSX.Element {
  const { weather, isLoadingWeather, spaceWeather, onRefresh } = props;
  return (
    <>
      <div className="border border-aegis-border p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="data-label">SURFACE WEATHER</div>
          <button
            onClick={onRefresh}
            disabled={isLoadingWeather}
            className="text-[9px] font-mono text-aegis-cyan hover:underline"
          >
            {isLoadingWeather ? 'LOADING...' : 'REFRESH'}
          </button>
        </div>
        {weather ? (
          <div className="space-y-1.5">
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">CONDITION</span>
              <span className={`text-xs font-mono ${weather.thunderstorm ? 'text-aegis-red font-bold' : 'text-aegis-text'}`}>
                {weather.weatherCondition}
                {weather.thunderstorm && ' TSTORM'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">WIND</span>
              <span className={`text-xs font-mono ${weather.windSpeedMs > 15 ? 'text-aegis-red' : weather.windSpeedMs > 10 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
                {weather.windSpeedMs.toFixed(1)} m/s {windDir(weather.windDirection)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">VISIBILITY</span>
              <span className={`text-xs font-mono ${weather.visibilityM < 1000 ? 'text-aegis-red' : weather.visibilityM < 3000 ? 'text-aegis-amber' : 'text-aegis-green'}`}>
                {weather.visibilityM}m
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">CLOUD</span>
              <span className="text-xs font-mono text-aegis-text">{weather.cloudCoverPercent}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">TEMP / RH</span>
              <span className="text-xs font-mono text-aegis-text">
                {weather.tempC.toFixed(1)}C / {weather.humidity}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[10px] font-mono text-aegis-muted">PRECIP</span>
              <span className="text-xs font-mono text-aegis-text">
                {weather.precipitationMm.toFixed(1)} mm/h
              </span>
            </div>
            <div className="text-[9px] font-mono text-aegis-muted mt-1">
              FETCHED: {weather.fetchedAt}
            </div>
          </div>
        ) : (
          <div className="text-xs font-mono text-aegis-muted">Click REFRESH to load</div>
        )}
      </div>

      <div className="border border-aegis-border p-3">
        <div className="data-label mb-2">GEOMAGNETIC / GPS</div>
        {spaceWeather ? (
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-aegis-muted">
                Kp: <span className={`font-bold ${spaceWeather.kpIndex > 5 ? 'text-aegis-red' : 'text-aegis-green'}`}>
                  {spaceWeather.kpIndex}
                </span>
              </span>
            </div>
            <div className={`text-xs font-mono font-bold px-2 py-0.5 ${
              spaceWeather.gpsConfidence === 'HIGH' ? 'bg-aegis-green/20 text-aegis-green' :
              spaceWeather.gpsConfidence === 'MEDIUM' ? 'bg-aegis-amber/20 text-aegis-amber' :
              'bg-aegis-red/20 text-aegis-red'
            }`}>
              GPS: {spaceWeather.gpsConfidence}
            </div>
          </div>
        ) : (
          <div className="text-xs font-mono text-aegis-muted">Loading...</div>
        )}
      </div>
    </>
  );
}

function CmdsSection(props: {
  commandValidations: ReturnType<typeof useFeedStore.getState>['commandValidations'];
}): JSX.Element {
  const { commandValidations } = props;
  return (
    <>
      <div className="data-label mb-2">COMMAND VALIDATION LOG</div>
      {commandValidations.length === 0 ? (
        <div className="border border-aegis-border p-4 text-center">
          <div className="text-xs font-mono text-aegis-muted">No command validations yet</div>
          <div className="text-[9px] font-mono text-aegis-muted mt-1">
            Commands to OFFENSE, EW, and SWARM drones are validated by AirLLM
          </div>
        </div>
      ) : (
        <div className="space-y-1.5">
          {commandValidations.map((v, i) => (
            <div
              key={`cv-${i}`}
              className={`border p-2 ${v.approved ? 'border-aegis-border' : 'border-aegis-red/50 bg-aegis-red/5'}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-aegis-text">{v.command}</span>
                <span className={`text-[9px] font-mono font-bold px-1.5 ${
                  v.approved ? 'bg-aegis-green/20 text-aegis-green' : 'bg-aegis-red/20 text-aegis-red'
                }`}>
                  {v.approved ? 'APPROVED' : 'REJECTED'}
                </span>
              </div>
              <div className="text-[9px] font-mono text-aegis-muted mt-0.5">
                DRONE: {v.droneId.slice(0, 12)}... | {v.timestamp}
              </div>
              <div className="text-[9px] font-mono text-aegis-muted mt-0.5">
                {v.reasoning.slice(0, 120)}
                {v.reasoning.length > 120 ? '...' : ''}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function IntelSection(props: {
  aiIntelFeed: ReturnType<typeof useFeedStore.getState>['aiIntelFeed'];
}): JSX.Element {
  const { aiIntelFeed } = props;
  return (
    <>
      <div className="data-label mb-2">CONTINUOUS INTEL FEED</div>
      <div className="space-y-1.5">
        {aiIntelFeed.length === 0 ? (
          <div className="text-xs font-mono text-aegis-muted">Awaiting intel updates...</div>
        ) : (
          aiIntelFeed.slice(0, 20).map((update, i) => (
            <div key={`intel-${i}`} className="border-b border-aegis-border/50 pb-1.5 last:border-0">
              <div className="flex justify-between">
                <span className="text-[10px] font-mono text-aegis-muted">{update.timestamp}</span>
                <span className={`text-[10px] font-mono ${
                  update.threatLevel === 'CRITICAL' || update.threatLevel === 'HIGH' ? 'text-aegis-red' :
                  update.threatLevel === 'MEDIUM' ? 'text-aegis-amber' : 'text-aegis-green'
                }`}>
                  THREAT: {update.threatLevel || 'N/A'}
                </span>
              </div>
              <div className="text-[10px] font-mono text-aegis-text">
                {update.missionName || update.missionId.slice(0, 8)} - Risk: {(update.riskScore * 100).toFixed(0)}%
                {update.riskDelta !== undefined && update.riskDelta > 0.1 && (
                  <span className="text-aegis-red ml-1">+{(update.riskDelta * 100).toFixed(0)}%</span>
                )}
              </div>
              {update.weather && (
                <div className="text-[9px] font-mono text-aegis-muted">
                  {update.weather.condition} | Wind: {update.weather.windSpeedMs.toFixed(1)}m/s | Vis: {update.weather.visibilityM}m
                  {update.weather.thunderstorm && <span className="text-aegis-red ml-1">TSTORM</span>}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </>
  );
}

export function AIIntelConsole(): JSX.Element {
  const {
    aiIntelFeed, modelStatus, intelFeedSummary, spaceWeather,
    commandValidations, isLoadingFeeds,
    fetchModelStatus, fetchIntelFeeds, fetchSpaceWeather,
  } = useFeedStore();
  const { missions, selectedAssessment } = useMissionStore();
  const [weather, setWeather] = useState(null as WeatherData | null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [isReassessing, setIsReassessing] = useState(false);
  const [activeSection, setActiveSection] = useState('STATUS');

  const activeMissions = missions.filter(
    (m: { status: string }) => m.status === 'ACTIVE' || m.status === 'COMMANDER_APPROVED' || m.status === 'AI_APPROVED'
  );

  useEffect(() => {
    fetchModelStatus();
    fetchSpaceWeather();
    const interval = setInterval(() => {
      fetchModelStatus();
      fetchSpaceWeather();
    }, 30000);
    return () => clearInterval(interval);
  }, [fetchModelStatus, fetchSpaceWeather]);

  const doFetchWeather = async () => {
    setIsLoadingWeather(true);
    try {
      const res = await apiGet('/api/v1/intel/weather?lat=34.052&lon=-118.244');
      if (res.success && res.data) setWeather(res.data as WeatherData);
    } catch (err) {
      void err;
    }
    setIsLoadingWeather(false);
  };

  const doRefreshFeeds = async () => {
    await fetchIntelFeeds(34.052, -118.244);
  };

  const doReassess = async (missionId: string) => {
    setIsReassessing(true);
    try {
      await apiPost('/api/v1/missions/' + missionId + '/reassess');
    } catch (err) {
      void err;
    }
    setIsReassessing(false);
  };

  const tier = modelStatus?.activeTier || 'RULE_ENGINE';
  const tierDotClass = tier === 'RULE_ENGINE' ? 'bg-aegis-amber' : 'bg-aegis-green';
  const tierColorClass = TIER_COLORS[tier] || 'text-aegis-muted';
  const tierLabelText = TIER_LABELS[tier] || tier;

  return (
    <div className="h-full flex flex-col overflow-hidden -m-4">
      <div className="px-4 py-2 border-b border-aegis-border flex items-center justify-between shrink-0">
        <div className="font-tactical text-aegis-cyan text-sm tracking-wider uppercase">
          AI INTEL CONSOLE
        </div>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 ${tierDotClass} animate-pulse`} />
          <span className={`text-[10px] font-mono ${tierColorClass}`}>{tierLabelText}</span>
        </div>
      </div>

      <div className="flex border-b border-aegis-border shrink-0">
        {SECTIONS.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveSection(tab)}
            className={`flex-1 px-1 py-1.5 text-[9px] font-tactical font-semibold tracking-wider uppercase transition-colors ${
              activeSection === tab
                ? 'text-aegis-cyan border-b border-aegis-cyan bg-aegis-bg'
                : 'text-aegis-muted hover:text-aegis-text'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {activeSection === 'STATUS' && (
          <StatusSection
            tier={tier}
            modelStatus={modelStatus}
            spaceWeather={spaceWeather}
            selectedAssessment={selectedAssessment}
            activeMissions={activeMissions}
            isReassessing={isReassessing}
            onReassess={doReassess}
          />
        )}
        {activeSection === 'FEEDS' && (
          <FeedsSection
            intelFeedSummary={intelFeedSummary}
            isLoadingFeeds={isLoadingFeeds}
            onRefresh={doRefreshFeeds}
          />
        )}
        {activeSection === 'WEATHER' && (
          <WeatherSection
            weather={weather}
            isLoadingWeather={isLoadingWeather}
            spaceWeather={spaceWeather}
            onRefresh={doFetchWeather}
          />
        )}
        {activeSection === 'CMDS' && (
          <CmdsSection commandValidations={commandValidations} />
        )}
        {activeSection === 'INTEL' && (
          <IntelSection aiIntelFeed={aiIntelFeed} />
        )}
        {activeSection === 'RI' && (
          <RIConsole />
        )}
      </div>
    </div>
  );
}
