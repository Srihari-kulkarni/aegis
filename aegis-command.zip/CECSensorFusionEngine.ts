import { EventEmitter } from 'events';
import {
  J3_2_AirTrack,
  FusedTrack,
  PkAssessment,
  TrackSource,
  IFFIdentity,
  ROELevel,
  WeaponLoadout,
  GuidanceMode,
  WeaponType,
  STRIKE_PACKAGE,
  AircraftClass,
} from '@aegis/shared';

interface CECNode {
  callsign: string;
  platform: 'AEGIS_SHIP' | 'E3G_SENTRY' | 'F35' | 'MQ9' | 'OTHER';
  sensorQuality: number;
  active: boolean;
}

const HOSTILE_ARCHETYPES: Array<{
  platformType: string;
  classification: string;
  speedRange: [number, number];
  altRange: [number, number];
  maneuverability: number;
  cmEffectiveness: number;
  ecmDegradation: number;
}> = [
  { platformType: 'SU-57', classification: 'FIGHTER', speedRange: [450, 900], altRange: [15000, 45000], maneuverability: 0.85, cmEffectiveness: 0.6, ecmDegradation: 0.3 },
  { platformType: 'J-20', classification: 'FIGHTER', speedRange: [500, 950], altRange: [20000, 50000], maneuverability: 0.8, cmEffectiveness: 0.65, ecmDegradation: 0.35 },
  { platformType: 'TU-160', classification: 'BOMBER', speedRange: [400, 600], altRange: [25000, 40000], maneuverability: 0.3, cmEffectiveness: 0.4, ecmDegradation: 0.2 },
  { platformType: 'KH-47M2', classification: 'MISSILE', speedRange: [2800, 3600], altRange: [80000, 120000], maneuverability: 0.7, cmEffectiveness: 0.1, ecmDegradation: 0.05 },
  { platformType: 'P-800', classification: 'ASCM', speedRange: [700, 850], altRange: [30, 500], maneuverability: 0.6, cmEffectiveness: 0.15, ecmDegradation: 0.1 },
  { platformType: 'SHAHED-136', classification: 'UAS', speedRange: [90, 120], altRange: [500, 8000], maneuverability: 0.2, cmEffectiveness: 0.05, ecmDegradation: 0.0 },
  { platformType: 'SU-35', classification: 'FIGHTER', speedRange: [450, 850], altRange: [10000, 45000], maneuverability: 0.82, cmEffectiveness: 0.55, ecmDegradation: 0.25 },
];

const GUIDANCE_EFFICIENCY: Record<GuidanceMode, number> = {
  [GuidanceMode.GPS]: 0.88,
  [GuidanceMode.INS]: 0.75,
  [GuidanceMode.GPS_INS]: 0.93,
  [GuidanceMode.LASER]: 0.96,
  [GuidanceMode.RADAR]: 0.90,
  [GuidanceMode.IR]: 0.85,
};

const FUZE_RELIABILITY: Record<GuidanceMode, number> = {
  [GuidanceMode.GPS]: 0.92,
  [GuidanceMode.INS]: 0.88,
  [GuidanceMode.GPS_INS]: 0.94,
  [GuidanceMode.LASER]: 0.95,
  [GuidanceMode.RADAR]: 0.91,
  [GuidanceMode.IR]: 0.89,
};

export class CECSensorFusionEngine extends EventEmitter {
  private trackDatabase: Map<string, FusedTrack> = new Map();
  private rawTracks: Map<string, J3_2_AirTrack[]> = new Map();
  private cecNodes: Map<string, CECNode> = new Map();
  private hostileTracks: Map<string, FusedTrack> = new Map();
  private simulationInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    super();

    this.cecNodes.set('AEGIS-01', {
      callsign: 'AEGIS-01',
      platform: 'AEGIS_SHIP',
      sensorQuality: 7,
      active: true,
    });

    for (const asset of STRIKE_PACKAGE) {
      let platform: CECNode['platform'] = 'OTHER';
      let sensorQuality = 3;

      if (asset.platform === AircraftClass.E3_SENTRY) {
        platform = 'E3G_SENTRY';
        sensorQuality = 6;
      } else if (asset.platform === AircraftClass.F35A || asset.platform === AircraftClass.F35B) {
        platform = 'F35';
        sensorQuality = 5;
      } else if (asset.platform === AircraftClass.MQ9_REAPER) {
        platform = 'MQ9';
        sensorQuality = 4;
      }

      this.cecNodes.set(asset.callsign, {
        callsign: asset.callsign,
        platform,
        sensorQuality,
        active: true,
      });
    }
  }

  ingestTrack(rawTrack: J3_2_AirTrack, sourceCallsign: string): FusedTrack {
    const node = this.cecNodes.get(sourceCallsign);
    if (!node || !node.active) {
      throw new Error(`CEC node ${sourceCallsign} not registered or inactive`);
    }

    const existing = this.rawTracks.get(rawTrack.trackId) ?? [];
    const idx = existing.findIndex(
      (t) => t.trackSource === rawTrack.trackSource && t.originatorDid === rawTrack.originatorDid
    );
    if (idx >= 0) {
      existing[idx] = rawTrack;
    } else {
      existing.push(rawTrack);
    }
    this.rawTracks.set(rawTrack.trackId, existing);

    const isNew = !this.trackDatabase.has(rawTrack.trackId);
    const fused = this.fuseTrack(rawTrack.trackId);

    if (isNew) {
      this.emit('track:new', fused);
    } else {
      this.emit('track:updated', fused);
    }

    if (fused.iffIdentity === IFFIdentity.HOSTILE) {
      this.hostileTracks.set(fused.trackId, fused);
      this.emit('track:hostile', fused);
    }

    if (fused.contributors.length >= 2) {
      this.emit('track:fused', fused);
    }

    return fused;
  }

  private categorizeSource(sourceCallsign: string): TrackSource {
    const node = this.cecNodes.get(sourceCallsign);
    if (!node) return TrackSource.PPLI;

    switch (node.platform) {
      case 'AEGIS_SHIP':
        return TrackSource.AEGIS_CEC;
      case 'E3G_SENTRY':
        return TrackSource.AWACS_ORGANIC;
      case 'F35':
        return TrackSource.PPLI;
      case 'MQ9':
        return TrackSource.DRONE_ORGANIC;
      default:
        return TrackSource.PPLI;
    }
  }

  fuseTrack(trackId: string): FusedTrack {
    const contributors = this.rawTracks.get(trackId);
    if (!contributors || contributors.length === 0) {
      throw new Error(`No raw tracks for trackId ${trackId}`);
    }

    const weighted = contributors.map((track) => {
      const sourceNode = this.findNodeForTrack(track);
      const baseWeight = sourceNode ? sourceNode.sensorQuality : 3;
      const qualityBoost = track.trackQuality / 7;
      const cecBoost = track.cecSourceFlag ? 1.5 : 1.0;
      const weight = baseWeight * qualityBoost * cecBoost;
      return { track, weight };
    });

    const pos = this.weightedAveragePosition(weighted);
    const fusionQuality = this.computeFusionQuality(weighted);

    const totalWeight = weighted.reduce((s, c) => s + c.weight, 0);
    const fusedSpeed = weighted.reduce((s, c) => s + c.track.speedKts * c.weight, 0) / totalWeight;
    const fusedHeading = this.weightedCircularMean(
      weighted.map((c) => ({ angle: c.track.headingDeg, weight: c.weight }))
    );

    const uniqueSources = [...new Set(contributors.map((c) => c.trackSource))];
    const isFused = contributors.length >= 2;

    const bestTrack = weighted.reduce((best, c) => (c.weight > best.weight ? c : best), weighted[0]).track;

    const fused: FusedTrack = {
      trackId,
      jtidsTrackNum: bestTrack.jtidsTrackNum,
      lat: pos.lat,
      lon: pos.lon,
      altFt: pos.altFt,
      speedKts: Math.round(fusedSpeed * 10) / 10,
      headingDeg: Math.round(fusedHeading * 10) / 10,
      iffIdentity: this.resolveIdentity(contributors),
      trackQuality: Math.min(7, Math.round(fusionQuality * 7)),
      trackSource: isFused ? TrackSource.FUSED : bestTrack.trackSource,
      cecSourceFlag: contributors.some((c) => c.cecSourceFlag),
      classification: bestTrack.classification,
      platformType: bestTrack.platformType,
      fusionQuality,
      contributors: isFused ? [...uniqueSources, TrackSource.FUSED] : uniqueSources,
      threatPriority: 0,
      ecmDegradation: bestTrack.cecSourceFlag ? 0.1 : 0.0,
      maneuverability: 0.5,
      cmEffectiveness: 0.3,
      lastFusedAt: new Date().toISOString(),
    };

    if (fused.iffIdentity === IFFIdentity.HOSTILE) {
      fused.threatPriority = this.evaluateThreat(fused);
    }

    this.trackDatabase.set(trackId, fused);

    if (fused.iffIdentity === IFFIdentity.HOSTILE) {
      this.hostileTracks.set(trackId, fused);
    } else {
      this.hostileTracks.delete(trackId);
    }

    return fused;
  }

  private weightedAveragePosition(
    contributors: { track: J3_2_AirTrack; weight: number }[]
  ): { lat: number; lon: number; altFt: number } {
    const totalWeight = contributors.reduce((s, c) => s + c.weight, 0);
    if (totalWeight === 0) {
      const first = contributors[0].track;
      return { lat: first.lat, lon: first.lon, altFt: first.altFt };
    }

    const DEG2RAD = Math.PI / 180;
    const RAD2DEG = 180 / Math.PI;

    let xSum = 0, ySum = 0, zSum = 0, altSum = 0;

    for (const { track, weight } of contributors) {
      const latR = track.lat * DEG2RAD;
      const lonR = track.lon * DEG2RAD;
      const norm = weight / totalWeight;

      xSum += Math.cos(latR) * Math.cos(lonR) * norm;
      ySum += Math.cos(latR) * Math.sin(lonR) * norm;
      zSum += Math.sin(latR) * norm;
      altSum += track.altFt * norm;
    }

    const lonFused = Math.atan2(ySum, xSum) * RAD2DEG;
    const hyp = Math.sqrt(xSum * xSum + ySum * ySum);
    const latFused = Math.atan2(zSum, hyp) * RAD2DEG;

    return {
      lat: Math.round(latFused * 1e6) / 1e6,
      lon: Math.round(lonFused * 1e6) / 1e6,
      altFt: Math.round(altSum),
    };
  }

  private computeFusionQuality(
    contributors: { track: J3_2_AirTrack; weight: number }[]
  ): number {
    if (contributors.length === 0) return 0;

    const n = contributors.length;
    const maxWeight = Math.max(...contributors.map((c) => c.weight));
    const avgWeight = contributors.reduce((s, c) => s + c.weight, 0) / n;

    const diversityBonus = Math.min(n / 4, 1.0);
    const qualityFactor = avgWeight / 10.5;
    const peakFactor = maxWeight / 10.5;

    const raw = 0.4 * diversityBonus + 0.35 * qualityFactor + 0.25 * peakFactor;
    return Math.min(1.0, Math.max(0, Math.round(raw * 1000) / 1000));
  }

  evaluateThreat(track: FusedTrack): number {
    let priority = 0;

    if (track.iffIdentity === IFFIdentity.HOSTILE) priority += 3;
    else if (track.iffIdentity === IFFIdentity.UNKNOWN) priority += 1;

    if (track.speedKts > 2000) priority += 3;
    else if (track.speedKts > 800) priority += 2;
    else if (track.speedKts > 400) priority += 1;

    if (track.altFt < 1000) priority += 2;
    else if (track.altFt < 5000) priority += 1;

    if (track.classification === 'MISSILE' || track.classification === 'ASCM') priority += 2;
    else if (track.classification === 'FIGHTER') priority += 1;

    if (track.maneuverability > 0.7) priority += 1;
    if (track.ecmDegradation > 0.2) priority -= 1;

    return Math.min(10, Math.max(0, priority));
  }

  computePk(
    track: FusedTrack,
    weapon: WeaponLoadout,
    aegisSensorQuality: number
  ): PkAssessment {
    const sensorNorm = Math.min(aegisSensorQuality, 7) / 7;

    const rangeFactor = this.engagementGeometryFactor(track);
    const guidanceEff = GUIDANCE_EFFICIENCY[weapon.guidance] ?? 0.8;
    const ecmDeg = track.ecmDegradation;

    const pHit = rangeFactor * guidanceEff * (1 - ecmDeg) * (0.7 + 0.3 * sensorNorm);
    const pHitClamped = Math.min(1, Math.max(0, pHit));

    const baseFuze = FUZE_RELIABILITY[weapon.guidance] ?? 0.9;
    const cepPenalty = weapon.cepMeters > 0 ? Math.max(0.5, 1 - weapon.cepMeters / 50) : 1.0;
    const pFuse = baseFuze * weapon.reliability * cepPenalty;
    const pFuseClamped = Math.min(1, Math.max(0, pFuse));

    const pCCM = 1 - track.cmEffectiveness * track.maneuverability;
    const pCCMClamped = Math.min(1, Math.max(0, pCCM));

    const pkFinal = pHitClamped * pFuseClamped * pCCMClamped;

    const assessment: PkAssessment = {
      trackId: track.trackId,
      targetType: track.platformType ?? track.classification ?? 'UNKNOWN',
      aegisSensorQuality,
      engagementGeometry: Math.round(rangeFactor * 1000) / 1000,
      environmentalDeg: Math.round(ecmDeg * 1000) / 1000,
      weaponCep: weapon.cepMeters,
      weaponReliability: weapon.reliability,
      guidance: weapon.guidance,
      pkSingleShot: Math.round(pHitClamped * 10000) / 10000,
      pkFusing: Math.round(pFuseClamped * 10000) / 10000,
      pkCCM: Math.round(pCCMClamped * 10000) / 10000,
      pkFinal: Math.round(pkFinal * 10000) / 10000,
      authChainComplete: false,
      roeClearance: ROELevel.WEAPONS_HOLD,
      pkComputedAt: new Date().toISOString(),
    };

    this.emit('pk:computed', assessment);
    return assessment;
  }

  getAllTracks(): FusedTrack[] {
    return Array.from(this.trackDatabase.values());
  }

  getHostileTracks(): FusedTrack[] {
    return Array.from(this.hostileTracks.values());
  }

  getTrack(trackId: string): FusedTrack | undefined {
    return this.trackDatabase.get(trackId);
  }

  getPkAssessments(trackId: string, availableWeapons: WeaponLoadout[]): PkAssessment[] {
    const track = this.trackDatabase.get(trackId);
    if (!track) return [];

    const aegisNode = this.cecNodes.get('AEGIS-01');
    const sensorQ = aegisNode?.sensorQuality ?? 7;

    return availableWeapons.map((w) => this.computePk(track, w, sensorQ));
  }

  getStats(): {
    totalTracks: number;
    bySource: Record<string, number>;
    hostileCount: number;
    fusedCount: number;
  } {
    const bySource: Record<string, number> = {};
    let fusedCount = 0;

    for (const track of this.trackDatabase.values()) {
      const key = track.trackSource;
      bySource[key] = (bySource[key] ?? 0) + 1;
      if (track.trackSource === TrackSource.FUSED) fusedCount++;
    }

    return {
      totalTracks: this.trackDatabase.size,
      bySource,
      hostileCount: this.hostileTracks.size,
      fusedCount,
    };
  }

  generateSimulatedThreatPicture(): void {
    if (this.simulationInterval) {
      clearInterval(this.simulationInterval);
    }

    const threatCount = 5 + Math.floor(Math.random() * 6);
    const baseLatCenter = 34.0 + (Math.random() - 0.5) * 4;
    const baseLonCenter = 132.0 + (Math.random() - 0.5) * 6;

    const activeTracks: Array<{
      trackId: string;
      archetype: typeof HOSTILE_ARCHETYPES[number];
      lat: number;
      lon: number;
      altFt: number;
      speedKts: number;
      headingDeg: number;
      jtidsTrackNum: number;
    }> = [];

    for (let i = 0; i < threatCount; i++) {
      const archetype = HOSTILE_ARCHETYPES[Math.floor(Math.random() * HOSTILE_ARCHETYPES.length)];
      const trackId = `TN-${(7000 + i).toString()}`;
      const jtidsTrackNum = 7000 + i;

      const angle = (Math.PI * 2 * i) / threatCount + (Math.random() - 0.5) * 0.5;
      const range = 0.5 + Math.random() * 2.5;
      const lat = baseLatCenter + Math.cos(angle) * range;
      const lon = baseLonCenter + Math.sin(angle) * range;

      const [minSpd, maxSpd] = archetype.speedRange;
      const [minAlt, maxAlt] = archetype.altRange;
      const speedKts = minSpd + Math.random() * (maxSpd - minSpd);
      const altFt = minAlt + Math.random() * (maxAlt - minAlt);
      const headingDeg = Math.random() * 360;

      activeTracks.push({ trackId, archetype, lat, lon, altFt, speedKts, headingDeg, jtidsTrackNum });

      const sourceNodes = this.pickRandomSources(2, 4);
      for (const sourceCallsign of sourceNodes) {
        const node = this.cecNodes.get(sourceCallsign);
        if (!node || !node.active) continue;

        const jitter = this.sensorJitter(node.sensorQuality);
        const raw: J3_2_AirTrack = {
          trackId,
          jtidsTrackNum,
          lat: lat + jitter.lat,
          lon: lon + jitter.lon,
          altFt: Math.round(altFt + jitter.alt),
          speedKts: Math.round((speedKts + jitter.speed) * 10) / 10,
          headingDeg: Math.round(((headingDeg + jitter.heading + 360) % 360) * 10) / 10,
          iffIdentity: IFFIdentity.HOSTILE,
          trackQuality: Math.min(7, Math.max(1, node.sensorQuality + Math.floor(Math.random() * 2 - 1))),
          trackSource: this.categorizeSource(sourceCallsign),
          cecSourceFlag: node.platform === 'AEGIS_SHIP' || node.platform === 'E3G_SENTRY',
          classification: archetype.classification,
          platformType: archetype.platformType,
        };

        this.ingestTrack(raw, sourceCallsign);
      }

      const fused = this.trackDatabase.get(trackId);
      if (fused) {
        fused.maneuverability = archetype.maneuverability;
        fused.cmEffectiveness = archetype.cmEffectiveness;
        fused.ecmDegradation = archetype.ecmDegradation;
        fused.threatPriority = this.evaluateThreat(fused);
        this.trackDatabase.set(trackId, fused);
        this.hostileTracks.set(trackId, fused);
      }
    }

    this.simulationInterval = setInterval(() => {
      for (const entry of activeTracks) {
        const dtHours = 2 / 3600;
        const NM_PER_DEG_LAT = 60;
        const NM_PER_DEG_LON = 60 * Math.cos((entry.lat * Math.PI) / 180);

        const distNm = entry.speedKts * dtHours;
        const headRad = (entry.headingDeg * Math.PI) / 180;

        entry.lat += (distNm * Math.cos(headRad)) / NM_PER_DEG_LAT;
        entry.lon += (distNm * Math.sin(headRad)) / NM_PER_DEG_LON;

        entry.headingDeg = (entry.headingDeg + (Math.random() - 0.5) * 3 + 360) % 360;
        entry.altFt += (Math.random() - 0.5) * 200;

        const sourceNodes = this.pickRandomSources(1, 3);
        for (const sourceCallsign of sourceNodes) {
          const node = this.cecNodes.get(sourceCallsign);
          if (!node || !node.active) continue;

          const jitter = this.sensorJitter(node.sensorQuality);
          const raw: J3_2_AirTrack = {
            trackId: entry.trackId,
            jtidsTrackNum: entry.jtidsTrackNum,
            lat: entry.lat + jitter.lat,
            lon: entry.lon + jitter.lon,
            altFt: Math.round(entry.altFt + jitter.alt),
            speedKts: Math.round((entry.speedKts + jitter.speed) * 10) / 10,
            headingDeg: Math.round(((entry.headingDeg + jitter.heading + 360) % 360) * 10) / 10,
            iffIdentity: IFFIdentity.HOSTILE,
            trackQuality: Math.min(7, Math.max(1, node.sensorQuality + Math.floor(Math.random() * 2 - 1))),
            trackSource: this.categorizeSource(sourceCallsign),
            cecSourceFlag: node.platform === 'AEGIS_SHIP' || node.platform === 'E3G_SENTRY',
            classification: entry.archetype.classification,
            platformType: entry.archetype.platformType,
          };

          this.ingestTrack(raw, sourceCallsign);
        }
      }
    }, 2000);
  }

  pruneStale(maxAgeSeconds: number): number {
    const now = Date.now();
    let pruned = 0;

    for (const [trackId, track] of this.trackDatabase) {
      const age = (now - new Date(track.lastFusedAt).getTime()) / 1000;
      if (age > maxAgeSeconds) {
        this.trackDatabase.delete(trackId);
        this.rawTracks.delete(trackId);
        this.hostileTracks.delete(trackId);
        pruned++;
      }
    }

    return pruned;
  }

  // --- Private helpers ---

  private findNodeForTrack(track: J3_2_AirTrack): CECNode | undefined {
    for (const node of this.cecNodes.values()) {
      if (this.categorizeSource(node.callsign) === track.trackSource) {
        return node;
      }
    }
    return undefined;
  }

  private resolveIdentity(contributors: J3_2_AirTrack[]): IFFIdentity {
    const identities = contributors.map((c) => c.iffIdentity);

    if (identities.includes(IFFIdentity.HOSTILE)) return IFFIdentity.HOSTILE;
    if (identities.includes(IFFIdentity.FRIEND)) return IFFIdentity.FRIEND;
    if (identities.includes(IFFIdentity.ASSUMED_FRIEND)) return IFFIdentity.ASSUMED_FRIEND;
    if (identities.includes(IFFIdentity.NEUTRAL)) return IFFIdentity.NEUTRAL;
    if (identities.includes(IFFIdentity.UNKNOWN)) return IFFIdentity.UNKNOWN;
    return IFFIdentity.PENDING;
  }

  private weightedCircularMean(entries: { angle: number; weight: number }[]): number {
    const DEG2RAD = Math.PI / 180;
    const RAD2DEG = 180 / Math.PI;
    const totalWeight = entries.reduce((s, e) => s + e.weight, 0);
    if (totalWeight === 0) return entries[0]?.angle ?? 0;

    let sinSum = 0, cosSum = 0;
    for (const { angle, weight } of entries) {
      const norm = weight / totalWeight;
      sinSum += Math.sin(angle * DEG2RAD) * norm;
      cosSum += Math.cos(angle * DEG2RAD) * norm;
    }

    const mean = Math.atan2(sinSum, cosSum) * RAD2DEG;
    return (mean + 360) % 360;
  }

  private engagementGeometryFactor(track: FusedTrack): number {
    const altNorm = Math.min(track.altFt / 60000, 1);
    const altFactor = 1 - 0.15 * altNorm;

    const spdNorm = Math.min(track.speedKts / 3600, 1);
    const spdFactor = 1 - 0.4 * spdNorm;

    const aspectPenalty = track.maneuverability > 0.7 ? 0.85 : 1.0;

    return Math.max(0.2, altFactor * spdFactor * aspectPenalty);
  }

  private pickRandomSources(min: number, max: number): string[] {
    const cecCapable = Array.from(this.cecNodes.entries())
      .filter(([, n]) => n.active && (n.platform === 'AEGIS_SHIP' || n.platform === 'E3G_SENTRY' || n.platform === 'F35' || n.platform === 'MQ9'))
      .map(([k]) => k);

    const count = min + Math.floor(Math.random() * (max - min + 1));
    const selected: string[] = [];
    const pool = [...cecCapable];

    for (let i = 0; i < Math.min(count, pool.length); i++) {
      const idx = Math.floor(Math.random() * pool.length);
      selected.push(pool[idx]);
      pool.splice(idx, 1);
    }

    return selected;
  }

  private sensorJitter(sensorQuality: number): {
    lat: number;
    lon: number;
    alt: number;
    speed: number;
    heading: number;
  } {
    const errorScale = Math.max(0.01, (8 - sensorQuality) / 7);
    return {
      lat: (Math.random() - 0.5) * 0.005 * errorScale,
      lon: (Math.random() - 0.5) * 0.005 * errorScale,
      alt: (Math.random() - 0.5) * 500 * errorScale,
      speed: (Math.random() - 0.5) * 20 * errorScale,
      heading: (Math.random() - 0.5) * 5 * errorScale,
    };
  }
}

export const cecEngine = new CECSensorFusionEngine();
