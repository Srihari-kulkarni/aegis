export enum AircraftClass {
  B2_SPIRIT = 'B-2A',
  E3_SENTRY = 'E-3G',
  F35A = 'F-35A',
  F35B = 'F-35B',
  MQ9_REAPER = 'MQ-9B',
  C17_GLOBEMASTER = 'C-17A',
  KC46_PEGASUS = 'KC-46A',
}

export enum MissionRole {
  STRIKE = 'STRIKE',
  ISR = 'ISR',
  TANKER = 'TANKER',
  LOGISTICS = 'LOGISTICS',
  C2_BRIDGE = 'C2_BRIDGE',
  SILENT_NODE = 'SILENT_NODE',
  STRIKE_ISR = 'STRIKE_ISR',
  STRIKE_CAS = 'STRIKE_CAS',
  ISR_STRIKE_SUPPORT = 'ISR_STRIKE_SUPPORT',
  ISR_PERSISTENT = 'ISR_PERSISTENT',
  LOGISTICS_CASEVAC = 'LOGISTICS_CASEVAC',
  AAR_TANKER = 'AAR_TANKER',
  AEGIS_HEDERA_BRIDGE = 'AEGIS_HEDERA_BRIDGE',
}

export enum Link16Role {
  NET_TIME_REFERENCE = 'NTR_PRIMARY',
  JTIDS_UNIT_PRIMARY = 'JU_PRIMARY',
  JTIDS_UNIT_SECONDARY = 'JU_SECONDARY',
  RELAY = 'JU_RELAY',
  PASSIVE = 'JU_PASSIVE',
}

export enum CECProfile {
  USG_2B = 'USG-2B',
  USG_3B = 'USG-3B',
  NONE = 'NONE',
}

export enum TxAuthLevel {
  FULL = 'FULL_TX',
  RESTRICTED = 'RESTRICTED_TX',
  SILENT = 'RECEIVE_ONLY',
}

export enum AegisLinkStatus {
  AUTHENTICATED = 'AUTHENTICATED',
  PENDING = 'PENDING',
  REVOKED = 'REVOKED',
}

export enum IFFIdentity {
  FRIEND = 'FRIEND',
  HOSTILE = 'HOSTILE',
  NEUTRAL = 'NEUTRAL',
  UNKNOWN = 'UNKNOWN',
  ASSUMED_FRIEND = 'ASSUMED_FRIEND',
  PENDING = 'PENDING',
}

export enum TrackSource {
  AEGIS_CEC = 'AEGIS_CEC',
  AWACS_ORGANIC = 'AWACS_ORGANIC',
  DRONE_ORGANIC = 'DRONE_ORGANIC',
  FUSED = 'FUSED',
  PPLI = 'PPLI',
  SILENT_NODE = 'SILENT_NODE',
}

export enum ROELevel {
  WEAPONS_FREE = 'WEAPONS_FREE',
  WEAPONS_TIGHT = 'WEAPONS_TIGHT',
  WEAPONS_HOLD = 'WEAPONS_HOLD',
}

export enum WeaponType {
  GBU_31_JDAM = 'GBU-31 JDAM',
  GBU_39_SDB = 'GBU-39 SDB',
  AIM_120_AMRAAM = 'AIM-120 AMRAAM',
  AGM_114_HELLFIRE = 'AGM-114 Hellfire',
  GBU_12_PAVEWAY = 'GBU-12 Paveway',
  AGM_158_JASSM = 'AGM-158 JASSM',
}

export enum GuidanceMode {
  GPS = 'GPS',
  INS = 'INS',
  GPS_INS = 'GPS/INS',
  LASER = 'LASER',
  RADAR = 'RADAR',
  IR = 'IR',
}

export enum FireAuthStatus {
  DESIGNATION_PENDING = 'DESIGNATION_PENDING',
  OPERATOR_PENDING = 'OPERATOR_PENDING',
  AUTHORIZED = 'AUTHORIZED',
  EXECUTED = 'EXECUTED',
  ABORTED = 'ABORTED',
}

export enum JMessageType {
  J0_0_INITIAL_ENTRY = 'J0.0',
  J2_2_PPLI = 'J2.2',
  J2_5_IFF = 'J2.5',
  J3_2_AIR_TRACK = 'J3.2',
  J3_3_SURFACE_TRACK = 'J3.3',
  J3_7_EW_PRODUCT = 'J3.7',
  J6_0_INTEL = 'J6.0',
  J7_0_WEAPON_COORD_A = 'J7.0',
  J7_1_WEAPON_COORD_B = 'J7.1',
  J12_0_MISSION_ASSIGN = 'J12.0',
  J12_3_TARGET_HANDOFF = 'J12.3',
  J12_5_STRIKE_COORD = 'J12.5',
  J12_6_ENGAGEMENT_COORD = 'J12.6',
  J13_2_PLATFORM_STATUS = 'J13.2',
}

export interface AircraftNFTMetadata {
  assetId: string;
  callsign: string;
  platformType: AircraftClass;
  missionRole: MissionRole;
  did: string;
  link16Role: Link16Role;
  cecProfile: CECProfile;
  txAuthority: TxAuthLevel;
  arsenalTopicId: string;
  telemetryTopicId: string;
  missionTopicId: string;
  htsTokenId: string;
  serialNumber: number;
  commanderId: string;
  aegisLinkStatus: AegisLinkStatus;
}

export interface WeaponLoadout {
  weapon: WeaponType;
  quantity: number;
  guidance: GuidanceMode;
  cepMeters: number;
  reliability: number;
}

export interface AircraftArsenal {
  callsign: string;
  weapons: WeaponLoadout[];
  totalOrdnance: number;
  lastUpdated: string;
  hcsMessageId?: string;
}

export interface J3_2_AirTrack {
  trackId: string;
  jtidsTrackNum: number;
  lat: number;
  lon: number;
  altFt: number;
  speedKts: number;
  headingDeg: number;
  iffIdentity: IFFIdentity;
  trackQuality: number;
  trackSource: TrackSource;
  originatorDid?: string;
  cecSourceFlag: boolean;
  hcsMessageId?: string;
  consensusTimestamp?: string;
  classification?: string;
  platformType?: string;
}

export interface FusedTrack extends J3_2_AirTrack {
  fusionQuality: number;
  contributors: TrackSource[];
  threatPriority: number;
  ecmDegradation: number;
  maneuverability: number;
  cmEffectiveness: number;
  lastFusedAt: string;
}

export interface PkAssessment {
  trackId: string;
  targetType: string;
  aegisSensorQuality: number;
  engagementGeometry: number;
  environmentalDeg: number;
  weaponCep: number;
  weaponReliability: number;
  guidance: GuidanceMode;
  pkSingleShot: number;
  pkFusing: number;
  pkCCM: number;
  pkFinal: number;
  designationId?: string;
  authChainComplete: boolean;
  roeClearance: ROELevel;
  pkComputedAt: string;
  computedByDid?: string;
  hcsAuditRef?: string;
}

export interface TargetDesignation {
  type: 'TARGET_DESIGNATION';
  trackId: string;
  targetData: J3_2_AirTrack;
  pkAssessment: PkAssessment;
  designatedBy: string;
  assignedTo: string;
  assignedCallsign: string;
  roeClearance: ROELevel;
  expiresAt: string;
  signature: string;
  hcsMessageId?: string;
  consensusTimestamp?: string;
}

export interface OperatorConfirmation {
  type: 'OPERATOR_CONFIRMATION';
  designationId: string;
  operatorDid: string;
  confirmedAt: string;
  arsenalCheck: WeaponLoadout;
  selectedWeapon: WeaponType;
  signature: string;
  hcsMessageId?: string;
  consensusTimestamp?: string;
}

export interface FireAuthorization {
  type: 'FIRE_AUTHORIZATION';
  designationId: string;
  confirmId: string;
  authorizedBy: string[];
  tofSeconds: number;
  impactTime: string;
  targetCoords: { lat: number; lon: number; altFt: number };
  roeFinal: ROELevel;
  weapon: WeaponType;
  assignedCallsign: string;
  status: FireAuthStatus;
  combinedSignature: string;
  hcsMessageId?: string;
  consensusTimestamp?: string;
}

export interface FireControlState {
  activeDesignations: TargetDesignation[];
  pendingConfirmations: OperatorConfirmation[];
  authorizations: FireAuthorization[];
  currentROE: ROELevel;
}

export interface JMessage {
  type: JMessageType;
  npg: number;
  direction: 'TX' | 'RX' | 'BOTH';
  rawBits?: Uint8Array;
  decoded: Record<string, unknown>;
  originatorCallsign: string;
  originatorDid?: string;
  timestamp: string;
  hcsMessageId?: string;
}

export const STRIKE_PACKAGE: Array<{
  callsign: string;
  platform: AircraftClass;
  role: MissionRole;
  link16Role: Link16Role;
  cecProfile: CECProfile;
  txAuthority: TxAuthLevel;
  weapons: WeaponLoadout[];
}> = [
  {
    callsign: 'GHOST-01',
    platform: AircraftClass.B2_SPIRIT,
    role: MissionRole.SILENT_NODE,
    link16Role: Link16Role.PASSIVE,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.SILENT,
    weapons: [
      { weapon: WeaponType.AGM_158_JASSM, quantity: 16, guidance: GuidanceMode.GPS_INS, cepMeters: 3, reliability: 0.92 },
      { weapon: WeaponType.GBU_31_JDAM, quantity: 16, guidance: GuidanceMode.GPS_INS, cepMeters: 3, reliability: 0.95 },
    ],
  },
  {
    callsign: 'SENTRY-01',
    platform: AircraftClass.E3_SENTRY,
    role: MissionRole.AEGIS_HEDERA_BRIDGE,
    link16Role: Link16Role.NET_TIME_REFERENCE,
    cecProfile: CECProfile.USG_2B,
    txAuthority: TxAuthLevel.FULL,
    weapons: [],
  },
  {
    callsign: 'VIPER-01',
    platform: AircraftClass.F35A,
    role: MissionRole.STRIKE_ISR,
    link16Role: Link16Role.JTIDS_UNIT_PRIMARY,
    cecProfile: CECProfile.USG_3B,
    txAuthority: TxAuthLevel.FULL,
    weapons: [
      { weapon: WeaponType.GBU_31_JDAM, quantity: 2, guidance: GuidanceMode.GPS_INS, cepMeters: 3, reliability: 0.95 },
      { weapon: WeaponType.GBU_39_SDB, quantity: 4, guidance: GuidanceMode.GPS, cepMeters: 5, reliability: 0.93 },
      { weapon: WeaponType.AIM_120_AMRAAM, quantity: 2, guidance: GuidanceMode.RADAR, cepMeters: 0, reliability: 0.85 },
    ],
  },
  {
    callsign: 'VIPER-02',
    platform: AircraftClass.F35A,
    role: MissionRole.STRIKE_ISR,
    link16Role: Link16Role.JTIDS_UNIT_SECONDARY,
    cecProfile: CECProfile.USG_3B,
    txAuthority: TxAuthLevel.FULL,
    weapons: [
      { weapon: WeaponType.GBU_31_JDAM, quantity: 2, guidance: GuidanceMode.GPS_INS, cepMeters: 3, reliability: 0.95 },
      { weapon: WeaponType.GBU_39_SDB, quantity: 4, guidance: GuidanceMode.GPS, cepMeters: 5, reliability: 0.93 },
      { weapon: WeaponType.AIM_120_AMRAAM, quantity: 2, guidance: GuidanceMode.RADAR, cepMeters: 0, reliability: 0.85 },
    ],
  },
  {
    callsign: 'VIPER-03',
    platform: AircraftClass.F35B,
    role: MissionRole.STRIKE_CAS,
    link16Role: Link16Role.JTIDS_UNIT_SECONDARY,
    cecProfile: CECProfile.USG_3B,
    txAuthority: TxAuthLevel.FULL,
    weapons: [
      { weapon: WeaponType.GBU_31_JDAM, quantity: 2, guidance: GuidanceMode.GPS_INS, cepMeters: 3, reliability: 0.95 },
      { weapon: WeaponType.GBU_12_PAVEWAY, quantity: 2, guidance: GuidanceMode.LASER, cepMeters: 3, reliability: 0.90 },
      { weapon: WeaponType.AIM_120_AMRAAM, quantity: 2, guidance: GuidanceMode.RADAR, cepMeters: 0, reliability: 0.85 },
    ],
  },
  {
    callsign: 'REAPER-01',
    platform: AircraftClass.MQ9_REAPER,
    role: MissionRole.ISR_STRIKE_SUPPORT,
    link16Role: Link16Role.RELAY,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.FULL,
    weapons: [
      { weapon: WeaponType.AGM_114_HELLFIRE, quantity: 4, guidance: GuidanceMode.LASER, cepMeters: 0.5, reliability: 0.92 },
      { weapon: WeaponType.GBU_12_PAVEWAY, quantity: 2, guidance: GuidanceMode.LASER, cepMeters: 3, reliability: 0.90 },
    ],
  },
  {
    callsign: 'REAPER-02',
    platform: AircraftClass.MQ9_REAPER,
    role: MissionRole.ISR_PERSISTENT,
    link16Role: Link16Role.RELAY,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.FULL,
    weapons: [
      { weapon: WeaponType.AGM_114_HELLFIRE, quantity: 4, guidance: GuidanceMode.LASER, cepMeters: 0.5, reliability: 0.92 },
    ],
  },
  {
    callsign: 'ATLAS-01',
    platform: AircraftClass.C17_GLOBEMASTER,
    role: MissionRole.LOGISTICS_CASEVAC,
    link16Role: Link16Role.PASSIVE,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.RESTRICTED,
    weapons: [],
  },
  {
    callsign: 'PEGASUS-01',
    platform: AircraftClass.KC46_PEGASUS,
    role: MissionRole.AAR_TANKER,
    link16Role: Link16Role.PASSIVE,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.RESTRICTED,
    weapons: [],
  },
  {
    callsign: 'PEGASUS-02',
    platform: AircraftClass.KC46_PEGASUS,
    role: MissionRole.AAR_TANKER,
    link16Role: Link16Role.PASSIVE,
    cecProfile: CECProfile.NONE,
    txAuthority: TxAuthLevel.RESTRICTED,
    weapons: [],
  },
];

export const TRACK_SYMBOLOGY: Record<TrackSource, { symbol: string; color: string; label: string }> = {
  [TrackSource.AEGIS_CEC]: { symbol: '\u25C7', color: '#ff1a3c', label: 'AEGIS CEC' },
  [TrackSource.AWACS_ORGANIC]: { symbol: '\u25CB', color: '#00d4ff', label: 'AWACS' },
  [TrackSource.DRONE_ORGANIC]: { symbol: '\u00D7', color: '#00ff88', label: 'ORGANIC' },
  [TrackSource.FUSED]: { symbol: '\u2295', color: '#ffffff', label: 'FUSED' },
  [TrackSource.PPLI]: { symbol: '\u25B7', color: '#00b4ff', label: 'FRIENDLY' },
  [TrackSource.SILENT_NODE]: { symbol: '--', color: '#6688aa', label: 'SILENT' },
};

export const IFF_COLORS: Record<IFFIdentity, string> = {
  [IFFIdentity.FRIEND]: '#00b4ff',
  [IFFIdentity.HOSTILE]: '#ff1a3c',
  [IFFIdentity.UNKNOWN]: '#ffc800',
  [IFFIdentity.NEUTRAL]: '#00ff88',
  [IFFIdentity.ASSUMED_FRIEND]: '#4488cc',
  [IFFIdentity.PENDING]: '#888888',
};
