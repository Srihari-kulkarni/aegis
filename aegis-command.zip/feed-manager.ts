import { logger } from '../logger';
import { config } from '../config';
import { zuluTimestamp } from '@aegis/shared';
import type { AggregatedIntel, BoundingBox } from './types';

import { fetchOpenSky } from './feeds/opensky';
import { fetchADSBExchange } from './feeds/adsb-exchange';
import { fetchOpenMeteo } from './feeds/open-meteo';
import { fetchOpenWeatherMap } from './feeds/openweathermap';
import { fetchNOAAWeatherAlerts } from './feeds/noaa-weather';
import { fetchFAATFR } from './feeds/faa-tfr';
import { fetchNOAASpaceWeather } from './feeds/noaa-space-weather';
import { fetchOpenTopoData } from './feeds/open-topo';
import { fetchUSGS3DEP } from './feeds/usgs-3dep';
import { fetchRadioReference } from './feeds/radio-reference';
import { fetchAirLabs } from './feeds/airlabs';
import { fetchAirspaceLink } from './feeds/airspace-link';
import { fetchAloftLAANC } from './feeds/aloft-laanc';

export class FeedManager {
  private rapidApiKey: string;
  private airLabsKey: string;

  constructor() {
    this.rapidApiKey = config.rapidApiKey ?? '';
    this.airLabsKey = config.airLabsKey ?? '';
  }

  async fetchAllFeeds(
    lat: number,
    lon: number,
    waypoints?: Array<{ lat: number; lon: number }>,
  ): Promise<AggregatedIntel> {
    const bbox = this.buildBoundingBox(lat, lon, 0.5);
    const topoLocations = waypoints ?? [{ lat, lon }];

    const startMs = Date.now();

    const [
      openSky, adsbExchange, openMeteo, openWeatherMap,
      noaaWeather, faaTFR, noaaSpaceWeather,
      openTopo, usgs3dep, radioRef,
      airLabs, airspaceLink, aloftLAANC,
    ] = await Promise.allSettled([
      fetchOpenSky(bbox),
      fetchADSBExchange(bbox, this.rapidApiKey || undefined),
      fetchOpenMeteo(lat, lon),
      fetchOpenWeatherMap(lat, lon),
      fetchNOAAWeatherAlerts(lat, lon),
      fetchFAATFR(),
      fetchNOAASpaceWeather(),
      fetchOpenTopoData(topoLocations),
      fetchUSGS3DEP(topoLocations),
      fetchRadioReference(lat, lon),
      fetchAirLabs(bbox, this.airLabsKey || undefined),
      fetchAirspaceLink(lat, lon),
      fetchAloftLAANC(lat, lon),
    ]);

    const elapsed = Date.now() - startMs;
    const fulfilled = [openSky, adsbExchange, openMeteo, openWeatherMap, noaaWeather, faaTFR, noaaSpaceWeather, openTopo, usgs3dep, radioRef, airLabs, airspaceLink, aloftLAANC]
      .filter((r) => r.status === 'fulfilled').length;

    logger.info({ elapsedMs: elapsed, fulfilledFeeds: fulfilled, totalFeeds: 13 }, 'All intel feeds fetched');

    return {
      openSky: openSky.status === 'fulfilled' ? openSky.value : null,
      adsbExchange: adsbExchange.status === 'fulfilled' ? adsbExchange.value : null,
      openMeteo: openMeteo.status === 'fulfilled' ? openMeteo.value : null,
      openWeatherMap: openWeatherMap.status === 'fulfilled' ? openWeatherMap.value : null,
      noaaWeather: noaaWeather.status === 'fulfilled' ? noaaWeather.value : null,
      faaTFR: faaTFR.status === 'fulfilled' ? faaTFR.value : null,
      noaaSpaceWeather: noaaSpaceWeather.status === 'fulfilled' ? noaaSpaceWeather.value : null,
      openTopo: openTopo.status === 'fulfilled' ? openTopo.value : null,
      usgs3dep: usgs3dep.status === 'fulfilled' ? usgs3dep.value : null,
      radioRef: radioRef.status === 'fulfilled' ? radioRef.value : null,
      airLabs: airLabs.status === 'fulfilled' ? airLabs.value : null,
      airspaceLink: airspaceLink.status === 'fulfilled' ? airspaceLink.value : null,
      aloftLAANC: aloftLAANC.status === 'fulfilled' ? aloftLAANC.value : null,
    };
  }

  async fetchCriticalFeeds(lat: number, lon: number): Promise<Pick<AggregatedIntel, 'openMeteo' | 'openWeatherMap' | 'noaaSpaceWeather' | 'faaTFR' | 'openSky'>> {
    const bbox = this.buildBoundingBox(lat, lon, 0.3);
    const [openMeteo, openWeatherMap, noaaSpaceWeather, faaTFR, openSky] = await Promise.allSettled([
      fetchOpenMeteo(lat, lon),
      fetchOpenWeatherMap(lat, lon),
      fetchNOAASpaceWeather(),
      fetchFAATFR(),
      fetchOpenSky(bbox),
    ]);

    return {
      openMeteo: openMeteo.status === 'fulfilled' ? openMeteo.value : null,
      openWeatherMap: openWeatherMap.status === 'fulfilled' ? openWeatherMap.value : null,
      noaaSpaceWeather: noaaSpaceWeather.status === 'fulfilled' ? noaaSpaceWeather.value : null,
      faaTFR: faaTFR.status === 'fulfilled' ? faaTFR.value : null,
      openSky: openSky.status === 'fulfilled' ? openSky.value : null,
    };
  }

  async fetchEWFeeds(lat: number, lon: number): Promise<Pick<AggregatedIntel, 'radioRef' | 'openSky' | 'adsbExchange'>> {
    const bbox = this.buildBoundingBox(lat, lon, 0.3);
    const [radioRef, openSky, adsbExchange] = await Promise.allSettled([
      fetchRadioReference(lat, lon),
      fetchOpenSky(bbox),
      fetchADSBExchange(bbox, this.rapidApiKey || undefined),
    ]);

    return {
      radioRef: radioRef.status === 'fulfilled' ? radioRef.value : null,
      openSky: openSky.status === 'fulfilled' ? openSky.value : null,
      adsbExchange: adsbExchange.status === 'fulfilled' ? adsbExchange.value : null,
    };
  }

  private buildBoundingBox(lat: number, lon: number, halfDegree: number): BoundingBox {
    return {
      lamin: lat - halfDegree,
      lomin: lon - halfDegree,
      lamax: lat + halfDegree,
      lomax: lon + halfDegree,
    };
  }
}

export const feedManager = new FeedManager();
