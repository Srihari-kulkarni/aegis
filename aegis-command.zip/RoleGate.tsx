'use client';

import type { ReactNode } from 'react';
import { OperatorRole } from '@aegis/shared';
import { useAuthStore } from '@/stores/authStore';

export interface RoleGateProps {
  role: OperatorRole;
  children: ReactNode;
  fallback?: ReactNode;
  showBadge?: boolean;
}

export function RoleGate({ role, children, fallback, showBadge }: RoleGateProps): ReactNode | null {
  const hasRole = useAuthStore((s) => s.hasRole(role));
  const operator = useAuthStore((s) => s.operator);

  if (!hasRole) {
    return <>{fallback ?? null}</>;
  }

  const badge =
    showBadge && operator?.role === OperatorRole.ANALYST ? (
      <div className="absolute top-2 right-2 px-2 py-0.5 border border-aegis-amber bg-aegis-bg font-mono text-[10px] text-aegis-amber uppercase tracking-wider rounded-none">
        READ ONLY
      </div>
    ) : showBadge && operator?.role === OperatorRole.AUDITOR ? (
      <div className="absolute top-2 right-2 px-2 py-0.5 border border-aegis-muted bg-aegis-bg font-mono text-[10px] text-aegis-muted uppercase tracking-wider rounded-none">
        AUDIT ACCESS ONLY
      </div>
    ) : null;

  return (
    <div className="relative rounded-none">
      {badge}
      {children}
    </div>
  );
}
