import {
  Client,
  TopicCreateTransaction,
  TopicMessageSubmitTransaction,
  TopicMessageQuery,
  TopicId,
  PrivateKey,
  AccountId,
  Hbar,
} from '@hashgraph/sdk';
import { v4 as uuidv4 } from 'uuid';
import { config } from '../config';
import { query } from '../db/pool';
import { redis, redisPub } from '../redis';
import { logger } from '../logger';
import {
  ActionType,
  HCSMessage,
  formatComplianceLog,
  zuluTimestamp,
} from '@aegis/shared';

export interface SubmitActionParams {
  topicId: string;
  droneId: string;
  actionType: ActionType;
  operatorId: string;
  missionId: string;
  aiConfidence?: number;
  payload?: Record<string, unknown>;
}

interface TopicMessageCallback {
  (message: HCSMessage): void;
}

export class HCSService {
  private client: Client | null = null;
  private demoMode: boolean;
  private sequenceCounters: Map<string, number> = new Map();

  constructor() {
    this.demoMode = config.demoMode;

    if (!this.demoMode && config.hedera.accountId !== '0.0.0000' && config.hedera.privateKey) {
      try {
        this.client = Client.forTestnet();
        this.client.setOperator(
          AccountId.fromString(config.hedera.accountId),
          PrivateKey.fromStringDer(config.hedera.privateKey)
        );
        this.client.setDefaultMaxTransactionFee(new Hbar(2));
        logger.info('Hedera HCS client initialized for testnet');
      } catch (err) {
        logger.warn({ err }, 'Hedera client init failed — falling back to demo mode');
        this.demoMode = true;
      }
    } else {
      logger.info('HCS running in demo mode (no Hedera credentials)');
    }
  }

  async createMissionTopic(missionId: string, operatorId: string): Promise<string> {
    if (this.demoMode || !this.client) {
      const demoTopicId = `0.0.${Math.floor(1000000 + Math.random() * 9000000)}`;
      await redis.set(`hcs:topic:${missionId}`, demoTopicId);
      logger.info({ missionId, topicId: demoTopicId }, 'Demo HCS topic created');
      return demoTopicId;
    }

    const transaction = new TopicCreateTransaction()
      .setTopicMemo(`AEGIS-CMD Mission ${missionId}`)
      .setSubmitKey(PrivateKey.fromStringDer(config.hedera.privateKey));

    const txResponse = await transaction.execute(this.client);
    const receipt = await txResponse.getReceipt(this.client);
    const topicId = receipt.topicId?.toString() ?? '';

    await redis.set(`hcs:topic:${missionId}`, topicId);

    await this.submitAction({
      topicId,
      droneId: 'SYSTEM',
      actionType: ActionType.MISSION_CREATED,
      operatorId,
      missionId,
      payload: { event: 'TOPIC_CREATED', topicId },
    });

    logger.info({ missionId, topicId }, 'HCS mission topic created on Hedera testnet');
    return topicId;
  }

  async submitAction(params: SubmitActionParams): Promise<HCSMessage> {
    const { topicId, droneId, actionType, operatorId, missionId, aiConfidence, payload } = params;

    const currentSeq = (this.sequenceCounters.get(topicId) ?? 0) + 1;
    this.sequenceCounters.set(topicId, currentSeq);

    const timestamp = zuluTimestamp();
    let transactionId = `demo-${uuidv4().slice(0, 8)}`;

    const messageContent = JSON.stringify({
      seq: currentSeq,
      ts: timestamp,
      droneId,
      action: actionType,
      operator: operatorId,
      mission: missionId,
      aiConf: aiConfidence ?? null,
      payload: payload ?? {},
    });

    if (!this.demoMode && this.client) {
      try {
        const tx = new TopicMessageSubmitTransaction()
          .setTopicId(TopicId.fromString(topicId))
          .setMessage(messageContent);
        const txResponse = await tx.execute(this.client);
        const receipt = await txResponse.getReceipt(this.client);
        transactionId = txResponse.transactionId.toString();
        logger.debug({ topicId, seq: currentSeq, txId: transactionId }, 'HCS message submitted');
      } catch (err) {
        logger.error({ err, topicId }, 'HCS submit failed — recording locally');
        transactionId = `failed-${uuidv4().slice(0, 8)}`;
      }
    }

    const hcsMessage: Omit<HCSMessage, 'complianceLog'> = {
      sequenceNumber: currentSeq,
      consensusTimestamp: timestamp,
      topicId,
      transactionId,
      droneId,
      actionType,
      operatorId,
      missionId,
      aiConfidence: aiConfidence ?? null,
      payload: payload ?? {},
    };

    const complianceLog = formatComplianceLog(hcsMessage);
    const fullMessage: HCSMessage = { ...hcsMessage, complianceLog };

    await this.persistActionLog(fullMessage, transactionId);

    await redisPub.publish('mission:actions', JSON.stringify(fullMessage));

    return fullMessage;
  }

  subscribeToTopic(topicId: string, onMessage: TopicMessageCallback): void {
    if (this.demoMode || !this.client) {
      logger.info({ topicId }, 'Demo mode — subscription simulated via Redis pub/sub');
      return;
    }

    new TopicMessageQuery()
      .setTopicId(TopicId.fromString(topicId))
      .subscribe(this.client, null, (msg) => {
        try {
          const contents = Buffer.from(msg.contents).toString('utf-8');
          const parsed = JSON.parse(contents) as {
            seq: number; ts: string; droneId: string; action: ActionType;
            operator: string; mission: string; aiConf: number | null;
            payload: Record<string, unknown>;
          };

          const hcsMsg: HCSMessage = {
            sequenceNumber: parsed.seq,
            consensusTimestamp: msg.consensusTimestamp.toDate().toISOString(),
            topicId,
            transactionId: `sub-${uuidv4().slice(0, 8)}`,
            droneId: parsed.droneId,
            actionType: parsed.action,
            operatorId: parsed.operator,
            missionId: parsed.mission,
            aiConfidence: parsed.aiConf,
            payload: parsed.payload,
            complianceLog: '',
          };
          hcsMsg.complianceLog = formatComplianceLog(hcsMsg);

          onMessage(hcsMsg);
        } catch (err) {
          logger.error({ err }, 'Error processing HCS subscription message');
        }
      });

    logger.info({ topicId }, 'Subscribed to HCS topic');
  }

  async validateMessageSequence(topicId: string, expectedSeq: number): Promise<boolean> {
    const result = await query<{ max_seq: string }>(
      'SELECT MAX(sequence_number) as max_seq FROM hcs_action_log WHERE topic_id = $1',
      [topicId]
    );

    const maxSeq = parseInt(result.rows[0]?.max_seq ?? '0', 10);
    const valid = maxSeq + 1 === expectedSeq;

    if (!valid) {
      logger.warn({ topicId, expectedSeq, actualMax: maxSeq }, 'Sequence gap detected');
    }

    return valid;
  }

  async getTopicMessages(topicId: string, limit: number = 100): Promise<HCSMessage[]> {
    const result = await query<{
      sequence_number: string; consensus_timestamp: string; topic_id: string;
      transaction_id: string; drone_id: string; action_type: ActionType;
      operator_id: string; mission_id: string; ai_confidence: string | null;
      payload: Record<string, unknown>; compliance_log: string;
    }>(
      `SELECT sequence_number, consensus_timestamp, topic_id, transaction_id,
              drone_id, action_type, operator_id, mission_id, ai_confidence,
              payload, compliance_log
       FROM hcs_action_log
       WHERE topic_id = $1
       ORDER BY sequence_number DESC
       LIMIT $2`,
      [topicId, limit]
    );

    return result.rows.map((row) => ({
      sequenceNumber: parseInt(row.sequence_number, 10),
      consensusTimestamp: row.consensus_timestamp,
      topicId: row.topic_id,
      transactionId: row.transaction_id,
      droneId: row.drone_id,
      actionType: row.action_type,
      operatorId: row.operator_id,
      missionId: row.mission_id,
      aiConfidence: row.ai_confidence ? parseFloat(row.ai_confidence) : null,
      payload: row.payload,
      complianceLog: row.compliance_log,
    }));
  }

  private async persistActionLog(msg: HCSMessage, txId: string): Promise<void> {
    try {
      await query(
        `INSERT INTO hcs_action_log
         (sequence_number, consensus_timestamp, topic_id, transaction_id,
          drone_id, action_type, operator_id, mission_id, ai_confidence,
          payload, compliance_log)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [
          msg.sequenceNumber,
          msg.consensusTimestamp,
          msg.topicId,
          txId,
          msg.droneId === 'SYSTEM' ? null : msg.droneId,
          msg.actionType,
          msg.operatorId,
          msg.missionId,
          msg.aiConfidence,
          JSON.stringify(msg.payload),
          msg.complianceLog,
        ]
      );
    } catch (err) {
      logger.error({ err, msg }, 'Failed to persist HCS action log');
    }
  }
}

export const hcsService = new HCSService();
