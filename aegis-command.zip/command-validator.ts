import { logger } from '../logger';
import { redis, redisPub } from '../redis';
import { hcsService } from '../hedera/HCSService';
import { feedManager } from '../intel/feed-manager';
import { airllmService } from './airllm-service';
import { ActionType, DroneClass, zuluTimestamp } from '@aegis/shared';

export interface CommandValidationResult {
  approved: boolean;
  reasoning: string;
  validatedBy: 'AIRLLM_7B' | 'AIRLLM_70B' | 'RULE_ENGINE' | 'PASS_THROUGH';
  latencyMs: number;
  riskLevel: number;
}

const BLOCKING_COMMANDS: Record<string, Set<string>> = {
  OFFENSE: new Set(['ARM', 'DISARM', 'PAYLOAD_DROP', 'EMERGENCY_STOP']),
  EW: new Set(['JAM_START', 'JAM_STOP']),
  SWARM: new Set(['SWARM_JOIN', 'SWARM_LEAVE']),
};

const LOG_ONLY_COMMANDS = new Set([
  'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
  'ACTIVATE_SENSOR', 'DEACTIVATE_SENSOR',
]);

export class CommandValidator {

  async validate(
    command: string,
    droneId: string,
    droneClass: DroneClass,
    operatorId: string,
    missionId: string | null,
    parameters?: Record<string, unknown>,
  ): Promise<CommandValidationResult> {
    const startMs = Date.now();

    const blockingSet = BLOCKING_COMMANDS[droneClass];
    const isBlocking = blockingSet?.has(command) ?? false;

    if (!isBlocking) {
      if (LOG_ONLY_COMMANDS.has(command)) {
        await this.logValidation(droneId, command, operatorId, missionId, true, 'Pass-through — non-critical command');
      }
      return {
        approved: true,
        reasoning: `${command} — pass-through (non-blocking for ${droneClass})`,
        validatedBy: 'PASS_THROUGH',
        latencyMs: Date.now() - startMs,
        riskLevel: 0,
      };
    }

    let result: CommandValidationResult;

    switch (droneClass) {
      case DroneClass.OFFENSE:
        result = await this.validateOffenseCommand(command, droneId, parameters ?? {}, startMs);
        break;
      case DroneClass.EW:
        result = await this.validateEWCommand(command, droneId, parameters ?? {}, startMs);
        break;
      case DroneClass.SWARM:
        result = await this.validateSwarmCommand(command, droneId, parameters ?? {}, startMs);
        break;
      default:
        result = await this.validateGenericCritical(command, droneId, droneClass, startMs);
        break;
    }

    await this.logValidation(droneId, command, operatorId, missionId, result.approved, result.reasoning);

    if (!result.approved) {
      await this.logRejectionToHCS(droneId, command, operatorId, missionId, result.reasoning);
    }

    return result;
  }

  private async validateOffenseCommand(
    command: string,
    droneId: string,
    parameters: Record<string, unknown>,
    startMs: number,
  ): Promise<CommandValidationResult> {
    const liveData = await redis.hgetall(`drone:live:${droneId}`);
    const armingState = liveData.armingState ?? 'SAFE';

    if (command === 'ARM') {
      if (armingState !== 'SAFE') {
        return {
          approved: false,
          reasoning: `ARM rejected: Current arming state is ${armingState}, must be SAFE`,
          validatedBy: 'RULE_ENGINE',
          latencyMs: Date.now() - startMs,
          riskLevel: 0.8,
        };
      }

      const result = await airllmService.validateCommand(command, 'OFFENSE', { armingState, parameters });
      return {
        approved: result.approved,
        reasoning: result.reasoning,
        validatedBy: 'AIRLLM_7B',
        latencyMs: Date.now() - startMs,
        riskLevel: result.approved ? 0.3 : 0.9,
      };
    }

    if (command === 'PAYLOAD_DROP') {
      if (armingState !== 'LOCKED' && armingState !== 'MASTER_ARM_ON') {
        return {
          approved: false,
          reasoning: `PAYLOAD_DROP rejected: Arming state ${armingState} — must be LOCKED or MASTER_ARM_ON`,
          validatedBy: 'RULE_ENGINE',
          latencyMs: Date.now() - startMs,
          riskLevel: 0.95,
        };
      }

      const result = await airllmService.validateCommand(command, 'OFFENSE', { armingState, parameters });
      return {
        approved: result.approved,
        reasoning: result.reasoning,
        validatedBy: 'AIRLLM_7B',
        latencyMs: Date.now() - startMs,
        riskLevel: 0.7,
      };
    }

    return this.validateGenericCritical(command, droneId, DroneClass.OFFENSE, startMs);
  }

  private async validateEWCommand(
    command: string,
    droneId: string,
    parameters: Record<string, unknown>,
    startMs: number,
  ): Promise<CommandValidationResult> {
    if (command === 'JAM_START') {
      const liveData = await redis.hgetall(`drone:live:${droneId}`);
      const lat = parseFloat(liveData.lat ?? '34.052');
      const lon = parseFloat(liveData.lon ?? '-118.244');

      const ewFeeds = await feedManager.fetchEWFeeds(lat, lon);

      const openSkyAircraft = ewFeeds.openSky?.data ?? [];
      const adsbxAircraft = ewFeeds.adsbExchange?.data ?? [];
      const civilAircraft = [
        ...openSkyAircraft.filter((a) => !a.onGround),
        ...adsbxAircraft.filter((a) => !a.mil),
      ];

      if (civilAircraft.length > 0) {
        const first = civilAircraft[0];
        const nearestId = ('callsign' in first && first.callsign) ? String(first.callsign) : ('hex' in first ? String(first.hex) : 'Unknown');
        return {
          approved: false,
          reasoning: `JAM_START BLOCKED: ${civilAircraft.length} civil ADS-B aircraft detected within jam radius. Federal regulation prohibits jamming with civil traffic present. Nearest: ${nearestId}`,
          validatedBy: 'AIRLLM_7B',
          latencyMs: Date.now() - startMs,
          riskLevel: 1.0,
        };
      }

      const radioFreqs = ewFeeds.radioRef?.data ?? [];
      const protectedFreqs = radioFreqs.filter((f) => f.protected);
      const jamBand = parameters.jamBand as string | undefined;

      const result = await airllmService.validateCommand('JAM_START', 'EW', {
        civil_aircraft_in_range: civilAircraft.length,
        protected_frequencies: protectedFreqs.map((f) => f.frequency),
        jam_band: jamBand,
        lat, lon,
      });

      return {
        approved: result.approved,
        reasoning: result.reasoning + ` | Protected freqs guarded: ${protectedFreqs.map((f) => `${f.frequency}MHz`).join(', ')}`,
        validatedBy: 'AIRLLM_7B',
        latencyMs: Date.now() - startMs,
        riskLevel: result.approved ? 0.4 : 1.0,
      };
    }

    return {
      approved: true,
      reasoning: `${command} validated for EW drone`,
      validatedBy: 'RULE_ENGINE',
      latencyMs: Date.now() - startMs,
      riskLevel: 0.1,
    };
  }

  private async validateSwarmCommand(
    command: string,
    droneId: string,
    _parameters: Record<string, unknown>,
    startMs: number,
  ): Promise<CommandValidationResult> {
    const liveData = await redis.hgetall(`drone:live:${droneId}`);
    const swarmId = liveData.swarmId ?? null;

    if (command === 'SWARM_JOIN' && swarmId) {
      return {
        approved: false,
        reasoning: `SWARM_JOIN rejected: Drone already in swarm ${swarmId}`,
        validatedBy: 'RULE_ENGINE',
        latencyMs: Date.now() - startMs,
        riskLevel: 0.3,
      };
    }

    if (command === 'SWARM_LEAVE' && !swarmId) {
      return {
        approved: false,
        reasoning: 'SWARM_LEAVE rejected: Drone not in any swarm',
        validatedBy: 'RULE_ENGINE',
        latencyMs: Date.now() - startMs,
        riskLevel: 0.1,
      };
    }

    const result = await airllmService.validateCommand(command, 'SWARM', { swarmId, droneId });
    return {
      approved: result.approved,
      reasoning: result.reasoning,
      validatedBy: 'AIRLLM_7B',
      latencyMs: Date.now() - startMs,
      riskLevel: result.approved ? 0.2 : 0.6,
    };
  }

  private async validateGenericCritical(
    command: string,
    _droneId: string,
    droneClass: DroneClass,
    startMs: number,
  ): Promise<CommandValidationResult> {
    const result = await airllmService.validateCommand(command, droneClass, {});
    return {
      approved: result.approved,
      reasoning: result.reasoning,
      validatedBy: 'AIRLLM_7B',
      latencyMs: Date.now() - startMs,
      riskLevel: result.approved ? 0.2 : 0.7,
    };
  }

  private async logValidation(
    droneId: string,
    command: string,
    operatorId: string,
    missionId: string | null,
    approved: boolean,
    reasoning: string,
  ): Promise<void> {
    const entry = {
      droneId, command, operatorId, missionId,
      approved, reasoning,
      timestamp: zuluTimestamp(),
    };

    await redis.set(
      `cmd:validation:${droneId}:${Date.now()}`,
      JSON.stringify(entry),
      'EX', 3600,
    );

    await redisPub.publish('command:validation', JSON.stringify(entry));
  }

  private async logRejectionToHCS(
    droneId: string,
    command: string,
    operatorId: string,
    missionId: string | null,
    reasoning: string,
  ): Promise<void> {
    if (!missionId) return;

    try {
      const missionData = await redis.get(`mission:active:${missionId}`);
      const topicId = missionData ? (JSON.parse(missionData) as { hcsTopicId?: string }).hcsTopicId : null;
      if (topicId) {
        await hcsService.submitAction({
          topicId,
          droneId,
          actionType: ActionType.DRONE_COMMAND,
          operatorId,
          missionId,
          payload: { command, status: 'REJECTED', reasoning, validatedBy: 'AIRLLM' },
        });
      }
    } catch (err) {
      logger.error({ err }, 'Failed to log command rejection to HCS');
    }
  }
}

export const commandValidator = new CommandValidator();
