import { redis } from '../../redis';
import { config } from '../../config';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, RadioRefFrequency } from '../types';

const CACHE_KEY = 'intel:radioref';
const TTL = 3600;

const PROTECTED_FREQUENCIES = [
  { frequency: 121.5, description: 'International Aeronautical Emergency', mode: 'AM', tag: 'EMERGENCY', protected: true },
  { frequency: 156.8, description: 'VHF Marine Channel 16 — Distress', mode: 'FM', tag: 'MARITIME', protected: true },
  { frequency: 243.0, description: 'Military Emergency Guard', mode: 'AM', tag: 'MIL-EMERGENCY', protected: true },
  { frequency: 406.0, description: 'COSPAS-SARSAT Emergency Beacon', mode: 'DIGITAL', tag: 'SAR', protected: true },
  { frequency: 462.5625, description: 'FRS Channel 1', mode: 'FM', tag: 'FRS', protected: true },
  { frequency: 462.7125, description: 'GMRS Emergency', mode: 'FM', tag: 'GMRS', protected: true },
];

export async function fetchRadioReference(lat: number, lon: number): Promise<IntelFeedResult<RadioRefFrequency[]>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(1)}_${lon.toFixed(1)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'radio-reference', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  const freqs = simulateRadioRef(lat, lon);
  await redis.set(cacheKey, JSON.stringify(freqs), 'EX', TTL);
  logger.debug({ count: freqs.length }, 'RadioReference data generated (simulated + protected)');
  return { success: true, data: freqs, source: config.demoMode ? 'radioref-simulated' : 'radio-reference', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
}

function simulateRadioRef(_lat: number, _lon: number): RadioRefFrequency[] {
  const activeFreqs: RadioRefFrequency[] = [
    ...PROTECTED_FREQUENCIES,
    { frequency: 155.475, description: 'Local Police Dispatch', mode: 'FM', tag: 'LAW', protected: false },
    { frequency: 154.280, description: 'Fire Primary', mode: 'FM', tag: 'FIRE', protected: false },
    { frequency: 155.940, description: 'EMS Dispatch', mode: 'FM', tag: 'EMS', protected: false },
    { frequency: 460.025, description: 'Civil Air Patrol', mode: 'FM', tag: 'CAP', protected: false },
    { frequency: 138.750, description: 'Military Air-Ground', mode: 'AM', tag: 'MIL', protected: false },
    { frequency: 225.000, description: 'UHF Military', mode: 'AM', tag: 'MIL', protected: false },
    { frequency: 311.000, description: 'Air Refueling', mode: 'AM', tag: 'MIL', protected: false },
  ];
  return activeFreqs;
}
