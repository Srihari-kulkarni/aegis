'use client';

export function ClassificationBanner() {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 w-full bg-aegis-amber/10 border-b border-aegis-amber/30 rounded-none">
      <p className="font-mono text-[10px] tracking-[0.3em] text-aegis-amber uppercase text-center py-2 whitespace-nowrap overflow-hidden">
        {'// UNCLASSIFIED // FOR OFFICIAL USE ONLY // '.repeat(20)}
      </p>
    </div>
  );
}
