import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { ADSBExchangeAircraft, BoundingBox, IntelFeedResult } from '../types';

const CACHE_KEY = 'intel:adsbx';
const TTL = 10;

export async function fetchADSBExchange(bbox: BoundingBox, rapidApiKey?: string): Promise<IntelFeedResult<ADSBExchangeAircraft[]>> {
  const cacheKey = `${CACHE_KEY}:${bbox.lamin.toFixed(2)}_${bbox.lomin.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'adsb-exchange', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  if (!rapidApiKey) {
    const sim = simulateADSBX(bbox);
    return { success: true, data: sim, source: 'adsbx-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const lat = (bbox.lamin + bbox.lamax) / 2;
    const lon = (bbox.lomin + bbox.lomax) / 2;
    const dist = Math.max(Math.abs(bbox.lamax - bbox.lamin), Math.abs(bbox.lomax - bbox.lomin)) * 55;
    const url = `https://adsbexchange-com1.p.rapidapi.com/v2/lat/${lat}/lon/${lon}/dist/${Math.ceil(dist)}/`;
    const res = await fetch(url, {
      signal: AbortSignal.timeout(5000),
      headers: { 'x-rapidapi-host': 'adsbexchange-com1.p.rapidapi.com', 'x-rapidapi-key': rapidApiKey },
    });
    if (!res.ok) throw new Error(`ADSBX HTTP ${res.status}`);

    const json = await res.json() as { ac: Array<{ hex: string; flight: string; alt_baro: number; gs: number; track: number; lat: number; lon: number; baro_rate: number; squawk: string; category: string; dbFlags: number }> };
    const aircraft: ADSBExchangeAircraft[] = (json.ac ?? []).map((a) => ({
      hex: a.hex,
      flight: (a.flight ?? '').trim(),
      alt: a.alt_baro ?? 0,
      speed: a.gs ?? 0,
      track: a.track ?? 0,
      lat: a.lat,
      lon: a.lon,
      vertRate: a.baro_rate ?? 0,
      squawk: a.squawk ?? '',
      category: a.category ?? '',
      mil: (a.dbFlags & 1) === 1,
    }));

    await redis.set(cacheKey, JSON.stringify(aircraft), 'EX', TTL);
    return { success: true, data: aircraft, source: 'adsb-exchange', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'ADS-B Exchange fetch failed');
    return { success: true, data: simulateADSBX(bbox), source: 'adsbx-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateADSBX(bbox: BoundingBox): ADSBExchangeAircraft[] {
  const count = 1 + Math.floor(Math.random() * 4);
  return Array.from({ length: count }, (_, i) => ({
    hex: `AE${(1000 + i).toString(16).toUpperCase()}`,
    flight: Math.random() > 0.3 ? `MIL${1000 + Math.floor(Math.random() * 9000)}` : `SWA${100 + i}`,
    alt: 5000 + Math.random() * 35000,
    speed: 150 + Math.random() * 400,
    track: Math.random() * 360,
    lat: bbox.lamin + Math.random() * (bbox.lamax - bbox.lamin),
    lon: bbox.lomin + Math.random() * (bbox.lomax - bbox.lomin),
    vertRate: (Math.random() - 0.5) * 2000,
    squawk: `${1200 + Math.floor(Math.random() * 6600)}`,
    category: 'A3',
    mil: Math.random() > 0.6,
  }));
}
