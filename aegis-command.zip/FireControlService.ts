import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import {
  TargetDesignation,
  OperatorConfirmation,
  FireAuthorization,
  FireAuthStatus,
  ROELevel,
  J3_2_AirTrack,
  PkAssessment,
  WeaponType,
  FireControlState,
  STRIKE_PACKAGE,
  WeaponLoadout,
} from '@aegis/shared';
import { cecEngine } from './CECSensorFusionEngine';
import { logger } from '../logger';
import { config } from '../config';

const DEFAULT_DESIGNATION_TTL_MINUTES = 15;

export class FireControlService extends EventEmitter {
  private designations: Map<string, TargetDesignation> = new Map();
  private confirmations: Map<string, OperatorConfirmation> = new Map();
  private authorizations: Map<string, FireAuthorization> = new Map();
  private currentROE: ROELevel = ROELevel.WEAPONS_TIGHT;

  async designateTarget(params: {
    trackId: string;
    targetData: J3_2_AirTrack;
    pkAssessment: PkAssessment;
    designatedBy: string;
    assignedTo: string;
    assignedCallsign: string;
    roeClearance: ROELevel;
    expiresInMinutes?: number;
  }): Promise<TargetDesignation> {
    if (this.currentROE === ROELevel.WEAPONS_HOLD) {
      throw new Error('Cannot designate targets under WEAPONS_HOLD ROE');
    }

    const ttl = params.expiresInMinutes ?? DEFAULT_DESIGNATION_TTL_MINUTES;
    const expiresAt = new Date(Date.now() + ttl * 60_000).toISOString();
    const designationId = `FCD-${uuidv4().slice(0, 8).toUpperCase()}`;

    const designation: TargetDesignation = {
      type: 'TARGET_DESIGNATION',
      trackId: params.trackId,
      targetData: params.targetData,
      pkAssessment: {
        ...params.pkAssessment,
        designationId,
        authChainComplete: false,
        roeClearance: params.roeClearance,
      },
      designatedBy: params.designatedBy,
      assignedTo: params.assignedTo,
      assignedCallsign: params.assignedCallsign,
      roeClearance: params.roeClearance,
      expiresAt,
      signature: this.generateSignature(params.designatedBy, designationId),
    };

    if (config.demoMode) {
      this.designations.set(designationId, designation);
      logger.info(
        { designationId, trackId: params.trackId, assignedTo: params.assignedCallsign },
        'Target designated (demo)',
      );
    } else {
      // Production: submit to HCS fire control topic, then store with HCS message ID
      this.designations.set(designationId, designation);
      logger.info(
        { designationId, trackId: params.trackId, assignedTo: params.assignedCallsign },
        'Target designated',
      );
    }

    this.emit('designation:new', { designationId, designation });
    return designation;
  }

  async confirmDesignation(params: {
    designationId: string;
    operatorDid: string;
    selectedWeapon: WeaponType;
  }): Promise<OperatorConfirmation> {
    const designation = this.designations.get(params.designationId);
    if (!designation) {
      throw new Error(`Designation ${params.designationId} not found`);
    }

    if (new Date(designation.expiresAt).getTime() < Date.now()) {
      throw new Error(`Designation ${params.designationId} has expired`);
    }

    const arsenalCheck = this.findWeaponInArsenal(
      designation.assignedCallsign,
      params.selectedWeapon,
    );
    if (!arsenalCheck) {
      throw new Error(
        `Weapon ${params.selectedWeapon} not available on ${designation.assignedCallsign}`,
      );
    }

    const confirmation: OperatorConfirmation = {
      type: 'OPERATOR_CONFIRMATION',
      designationId: params.designationId,
      operatorDid: params.operatorDid,
      confirmedAt: new Date().toISOString(),
      arsenalCheck,
      selectedWeapon: params.selectedWeapon,
      signature: this.generateSignature(params.operatorDid, params.designationId),
    };

    if (config.demoMode) {
      this.confirmations.set(params.designationId, confirmation);
      logger.info(
        { designationId: params.designationId, operatorDid: params.operatorDid, weapon: params.selectedWeapon },
        'Designation confirmed by operator (demo)',
      );
    } else {
      this.confirmations.set(params.designationId, confirmation);
      logger.info(
        { designationId: params.designationId, operatorDid: params.operatorDid, weapon: params.selectedWeapon },
        'Designation confirmed by operator',
      );
    }

    this.emit('confirmation:new', { designationId: params.designationId, confirmation });
    return confirmation;
  }

  async authorizeStrike(params: {
    designationId: string;
  }): Promise<FireAuthorization> {
    const designation = this.designations.get(params.designationId);
    if (!designation) {
      throw new Error(`Designation ${params.designationId} not found`);
    }

    const confirmation = this.confirmations.get(params.designationId);
    if (!confirmation) {
      throw new Error(`No operator confirmation for designation ${params.designationId}`);
    }

    if (new Date(designation.expiresAt).getTime() < Date.now()) {
      throw new Error(`Designation ${params.designationId} has expired`);
    }

    const tofSeconds = this.computeTimeOfFlight(designation, confirmation.selectedWeapon);
    const impactTime = new Date(Date.now() + tofSeconds * 1000).toISOString();
    const confirmId = `FCC-${uuidv4().slice(0, 8).toUpperCase()}`;

    const authorization: FireAuthorization = {
      type: 'FIRE_AUTHORIZATION',
      designationId: params.designationId,
      confirmId,
      authorizedBy: [designation.designatedBy, confirmation.operatorDid],
      tofSeconds,
      impactTime,
      targetCoords: {
        lat: designation.targetData.lat,
        lon: designation.targetData.lon,
        altFt: designation.targetData.altFt,
      },
      roeFinal: designation.roeClearance,
      weapon: confirmation.selectedWeapon,
      assignedCallsign: designation.assignedCallsign,
      status: FireAuthStatus.AUTHORIZED,
      combinedSignature: this.combineSignatures(designation.signature, confirmation.signature),
    };

    designation.pkAssessment.authChainComplete = true;

    if (config.demoMode) {
      this.authorizations.set(params.designationId, authorization);
      logger.info(
        { designationId: params.designationId, weapon: confirmation.selectedWeapon, tofSeconds },
        'Strike authorized (demo)',
      );
    } else {
      this.authorizations.set(params.designationId, authorization);
      logger.info(
        { designationId: params.designationId, weapon: confirmation.selectedWeapon, tofSeconds },
        'Strike authorized',
      );
    }

    this.emit('authorization:granted', { designationId: params.designationId, authorization });
    return authorization;
  }

  async abortAuthorization(designationId: string, reason: string): Promise<void> {
    const authorization = this.authorizations.get(designationId);
    if (!authorization) {
      throw new Error(`No authorization found for designation ${designationId}`);
    }

    if (authorization.status === FireAuthStatus.ABORTED) {
      throw new Error(`Authorization for ${designationId} already aborted`);
    }

    authorization.status = FireAuthStatus.ABORTED;
    this.authorizations.set(designationId, authorization);

    const designation = this.designations.get(designationId);
    if (designation) {
      designation.pkAssessment.authChainComplete = false;
    }

    logger.warn({ designationId, reason }, 'Fire authorization aborted');
    this.emit('authorization:aborted', { designationId, reason, authorization });
  }

  setROE(level: ROELevel): void {
    const previous = this.currentROE;
    this.currentROE = level;
    logger.info({ previous, current: level }, 'ROE level changed');
    this.emit('roe:changed', { previous, current: level });
  }

  getROE(): ROELevel {
    return this.currentROE;
  }

  getState(): FireControlState {
    return {
      activeDesignations: this.getActiveDesignations(),
      pendingConfirmations: Array.from(this.confirmations.values()),
      authorizations: Array.from(this.authorizations.values()),
      currentROE: this.currentROE,
    };
  }

  getDesignationChain(designationId: string): {
    designation: TargetDesignation | undefined;
    confirmation: OperatorConfirmation | undefined;
    authorization: FireAuthorization | undefined;
    status: FireAuthStatus;
  } {
    const designation = this.designations.get(designationId);
    const confirmation = this.confirmations.get(designationId);
    const authorization = this.authorizations.get(designationId);

    let status: FireAuthStatus;
    if (authorization) {
      status = authorization.status;
    } else if (confirmation) {
      status = FireAuthStatus.OPERATOR_PENDING;
    } else if (designation) {
      status = FireAuthStatus.DESIGNATION_PENDING;
    } else {
      status = FireAuthStatus.DESIGNATION_PENDING;
    }

    return { designation, confirmation, authorization, status };
  }

  getActiveDesignations(): TargetDesignation[] {
    const now = Date.now();
    return Array.from(this.designations.values()).filter(
      (d) => new Date(d.expiresAt).getTime() > now,
    );
  }

  getAuthorizationHistory(limit?: number): FireAuthorization[] {
    const all = Array.from(this.authorizations.values());
    return limit ? all.slice(-limit) : all;
  }

  getHostileTracksWithPk(): Array<{
    track: ReturnType<typeof cecEngine.getTrack>;
    pkAssessments: PkAssessment[];
  }> {
    const hostiles = cecEngine.getHostileTracks();
    return hostiles.map((track) => {
      const allWeapons = this.getAllAvailableWeapons();
      const pkAssessments = cecEngine.getPkAssessments(track.trackId, allWeapons);
      return { track, pkAssessments };
    });
  }

  private findWeaponInArsenal(
    callsign: string,
    weaponType: WeaponType,
  ): WeaponLoadout | null {
    const asset = STRIKE_PACKAGE.find((a) => a.callsign === callsign);
    if (!asset) return null;
    return asset.weapons.find((w) => w.weapon === weaponType) ?? null;
  }

  private getAllAvailableWeapons(): WeaponLoadout[] {
    const weaponMap = new Map<string, WeaponLoadout>();
    for (const asset of STRIKE_PACKAGE) {
      for (const w of asset.weapons) {
        if (!weaponMap.has(w.weapon)) {
          weaponMap.set(w.weapon, w);
        }
      }
    }
    return Array.from(weaponMap.values());
  }

  private computeTimeOfFlight(
    designation: TargetDesignation,
    weapon: WeaponType,
  ): number {
    const alt = designation.targetData.altFt;
    const speed = designation.targetData.speedKts;

    const baseToF: Record<string, number> = {
      [WeaponType.GBU_31_JDAM]: 45,
      [WeaponType.GBU_39_SDB]: 60,
      [WeaponType.AIM_120_AMRAAM]: 25,
      [WeaponType.AGM_114_HELLFIRE]: 15,
      [WeaponType.GBU_12_PAVEWAY]: 35,
      [WeaponType.AGM_158_JASSM]: 120,
    };

    const base = baseToF[weapon] ?? 40;
    const altModifier = 1 + (alt / 60000) * 0.3;
    const speedModifier = 1 + (speed / 2000) * 0.2;

    return Math.round(base * altModifier * speedModifier);
  }

  private generateSignature(did: string, designationId: string): string {
    const payload = `${did}:${designationId}:${Date.now()}`;
    const hash = Buffer.from(payload).toString('base64url');
    return `SIG-${hash.slice(0, 32)}`;
  }

  private combineSignatures(sig1: string, sig2: string): string {
    const combined = `${sig1}+${sig2}`;
    const hash = Buffer.from(combined).toString('base64url');
    return `MSIG-${hash.slice(0, 48)}`;
  }
}

export const fireControlService = new FireControlService();
