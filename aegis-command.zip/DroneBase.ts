import { v4 as uuidv4 } from 'uuid';
import {
  DroneClass,
  DroneStatus,
  GeoPosition,
  Telemetry,
  zuluTimestamp,
} from '@aegis/shared';

export interface DroneConfig {
  droneId?: string;
  callsign: string;
  droneClass: DroneClass;
  model: string;
  manufacturer: string;
  serialNumber: string;
  position?: GeoPosition;
}

export interface TypeMetrics {
  [key: string]: unknown;
}

export interface DegradedCapability {
  capability: string;
  available: boolean;
  degradedMode: string;
}

export abstract class DroneBase {
  readonly droneId: string;
  readonly callsign: string;
  readonly droneClass: DroneClass;
  readonly model: string;
  readonly manufacturer: string;
  readonly serialNumber: string;

  status: DroneStatus;
  health: number;
  batteryPercent: number;
  fuelPercent: number;
  position: GeoPosition;
  heading: number;
  speedKnots: number;
  altitude: number;
  linkQuality: number;
  currentMissionId: string | null;
  htsTokenId: string | null;
  htsSerialNumber: number | null;

  protected lastTelemetryTime: number;

  constructor(cfg: DroneConfig) {
    this.droneId = cfg.droneId ?? uuidv4();
    this.callsign = cfg.callsign;
    this.droneClass = cfg.droneClass;
    this.model = cfg.model;
    this.manufacturer = cfg.manufacturer;
    this.serialNumber = cfg.serialNumber;
    this.status = DroneStatus.STANDBY;
    this.health = 1.0;
    this.batteryPercent = 100;
    this.fuelPercent = 100;
    this.position = cfg.position ?? { lat: 0, lon: 0, alt: 0 };
    this.heading = 0;
    this.speedKnots = 0;
    this.altitude = cfg.position?.alt ?? 0;
    this.linkQuality = 1.0;
    this.currentMissionId = null;
    this.htsTokenId = null;
    this.htsSerialNumber = null;
    this.lastTelemetryTime = Date.now();
  }

  abstract getTypeMetrics(): TypeMetrics;
  abstract getAIContextDescriptor(): string;
  abstract getDegradedModeCapabilities(): DegradedCapability[];
  abstract handleLinkLoss(): void;

  updateTelemetry(telemetry: Partial<Telemetry>): void {
    if (telemetry.position) {
      this.position = telemetry.position;
    }
    if (telemetry.heading !== undefined) this.heading = telemetry.heading;
    if (telemetry.speedKnots !== undefined) this.speedKnots = telemetry.speedKnots;
    if (telemetry.altitude !== undefined) this.altitude = telemetry.altitude;
    if (telemetry.batteryPercent !== undefined) this.batteryPercent = telemetry.batteryPercent;
    if (telemetry.fuelPercent !== undefined) this.fuelPercent = telemetry.fuelPercent;
    if (telemetry.health !== undefined) this.health = telemetry.health;
    if (telemetry.linkQuality !== undefined) this.linkQuality = telemetry.linkQuality;
    this.lastTelemetryTime = Date.now();
  }

  validateCommand(command: string, operatorRole: string): { valid: boolean; reason: string } {
    if (this.status === DroneStatus.DESTROYED || this.status === DroneStatus.DECOMMISSIONED) {
      return { valid: false, reason: `Drone ${this.callsign} is ${this.status} — cannot accept commands` };
    }

    if (this.status === DroneStatus.LOST_LINK && command !== 'EMERGENCY_STOP') {
      return { valid: false, reason: `Drone ${this.callsign} has LOST_LINK — only EMERGENCY_STOP accepted` };
    }

    if (command === 'LAUNCH' && this.status !== DroneStatus.STANDBY && this.status !== DroneStatus.PREFLIGHT) {
      return { valid: false, reason: `Cannot launch: drone is ${this.status}` };
    }

    if (command === 'LAND' && this.status !== DroneStatus.AIRBORNE && this.status !== DroneStatus.ON_MISSION && this.status !== DroneStatus.RETURNING) {
      return { valid: false, reason: `Cannot land: drone is ${this.status}` };
    }

    if (this.health < 0.3 && command === 'LAUNCH') {
      return { valid: false, reason: 'Health too low for launch' };
    }

    if (this.batteryPercent < 10 && command === 'LAUNCH') {
      return { valid: false, reason: 'Battery too low for launch' };
    }

    return { valid: true, reason: 'OK' };
  }

  toRedisHash(): Record<string, string> {
    return {
      droneId: this.droneId,
      callsign: this.callsign,
      droneClass: this.droneClass,
      model: this.model,
      status: this.status,
      health: this.health.toString(),
      batteryPercent: this.batteryPercent.toString(),
      fuelPercent: this.fuelPercent.toString(),
      lat: this.position.lat.toString(),
      lon: this.position.lon.toString(),
      alt: this.position.alt.toString(),
      heading: this.heading.toString(),
      speedKnots: this.speedKnots.toString(),
      altitude: this.altitude.toString(),
      linkQuality: this.linkQuality.toString(),
      currentMissionId: this.currentMissionId ?? '',
      htsTokenId: this.htsTokenId ?? '',
      typeMetrics: JSON.stringify(this.getTypeMetrics()),
      updatedAt: zuluTimestamp(),
    };
  }

  toComplianceLog(): string {
    return `[${zuluTimestamp()}] DRONE_STATE droneId=${this.droneId} callsign=${this.callsign} class=${this.droneClass} status=${this.status} health=${this.health} battery=${this.batteryPercent}% pos=${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} alt=${this.altitude}ft link=${this.linkQuality}`;
  }

  toJSON(): Record<string, unknown> {
    return {
      droneId: this.droneId,
      callsign: this.callsign,
      droneClass: this.droneClass,
      model: this.model,
      manufacturer: this.manufacturer,
      serialNumber: this.serialNumber,
      status: this.status,
      health: this.health,
      batteryPercent: this.batteryPercent,
      fuelPercent: this.fuelPercent,
      position: this.position,
      heading: this.heading,
      speedKnots: this.speedKnots,
      altitude: this.altitude,
      linkQuality: this.linkQuality,
      currentMissionId: this.currentMissionId,
      htsTokenId: this.htsTokenId,
      htsSerialNumber: this.htsSerialNumber,
      typeMetrics: this.getTypeMetrics(),
    };
  }
}
