import { logger } from '../../logger';
import { redis } from '../../redis';
import { zuluTimestamp } from '@aegis/shared';
import type { ValidationResult, BacktestResult, MissionOutcome, PredictionError } from './types';
import { v4 as uuidv4 } from 'uuid';

const BACKTEST_KEY = 'ri:backtest:history';
const MAX_HISTORY = 200;

interface HistoricalMission {
  missionId: string;
  context: Record<string, unknown>;
  assessment: {
    recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
    confidence: number;
    riskScore: number;
  };
  outcome: MissionOutcome;
  timestamp: string;
}

export class RegressionGuard {
  private baselineAccuracy = 0.7;
  private historicalMissions: HistoricalMission[] = [];
  private passingBaseline = new Set<string>();

  async initialize(): Promise<void> {
    try {
      const data = await redis.get(BACKTEST_KEY);
      if (data) {
        this.historicalMissions = JSON.parse(data) as HistoricalMission[];
        this.baselineAccuracy = this.computeAccuracy(this.historicalMissions);
        for (const m of this.historicalMissions) {
          if (m.outcome.succeeded === (m.assessment.recommendation === 'APPROVE')) {
            this.passingBaseline.add(m.missionId);
          }
        }
        logger.info({ count: this.historicalMissions.length, accuracy: this.baselineAccuracy },
          'RegressionGuard initialized from Redis');
      }
    } catch {
      logger.warn('RegressionGuard: No historical data found, starting fresh');
    }
  }

  async recordMissionOutcome(
    missionId: string,
    context: Record<string, unknown>,
    assessment: { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number },
    outcome: MissionOutcome,
  ): Promise<void> {
    const record: HistoricalMission = {
      missionId,
      context,
      assessment,
      outcome,
      timestamp: zuluTimestamp(),
    };

    this.historicalMissions.push(record);
    if (this.historicalMissions.length > MAX_HISTORY) {
      this.historicalMissions = this.historicalMissions.slice(-MAX_HISTORY);
    }

    if (outcome.succeeded === (assessment.recommendation === 'APPROVE')) {
      this.passingBaseline.add(missionId);
    }

    await redis.set(BACKTEST_KEY, JSON.stringify(this.historicalMissions));
    this.baselineAccuracy = this.computeAccuracy(this.historicalMissions);
  }

  async backtestPrompt(
    candidatePromptFn: (context: Record<string, unknown>) => { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number },
    lookbackMissions = 50,
  ): Promise<BacktestResult> {
    const testSet = this.historicalMissions.slice(-lookbackMissions);
    let correct = 0;
    let falseApprovals = 0;
    let falseRejections = 0;
    let totalConfDelta = 0;

    for (const mission of testSet) {
      const candidateResult = candidatePromptFn(mission.context);
      const actualSuccess = mission.outcome.succeeded;
      const candidateApproved = candidateResult.recommendation === 'APPROVE';

      if (actualSuccess === candidateApproved) {
        correct++;
      } else if (candidateApproved && !actualSuccess) {
        falseApprovals++;
      } else {
        falseRejections++;
      }
      totalConfDelta += Math.abs(candidateResult.confidence - mission.assessment.confidence);
    }

    const accuracy = testSet.length > 0 ? correct / testSet.length : 0;

    return {
      promptVersion: uuidv4(),
      missionsEvaluated: testSet.length,
      correctDecisions: correct,
      accuracy,
      falseApprovals,
      falseRejections,
      avgConfidenceDelta: testSet.length > 0 ? totalConfDelta / testSet.length : 0,
    };
  }

  validateCandidate(
    candidateResults: Map<string, { recommendation: 'APPROVE' | 'REJECT' | 'HOLD' }>,
  ): ValidationResult {
    const regressions: string[] = [];

    for (const missionId of this.passingBaseline) {
      const candidate = candidateResults.get(missionId);
      if (!candidate) continue;

      const historical = this.historicalMissions.find((m) => m.missionId === missionId);
      if (!historical) continue;

      const wasCorrect = historical.outcome.succeeded === (historical.assessment.recommendation === 'APPROVE');
      const nowCorrect = historical.outcome.succeeded === (candidate.recommendation === 'APPROVE');

      if (wasCorrect && !nowCorrect) {
        regressions.push(missionId);
      }
    }

    if (regressions.length > 0) {
      return {
        accepted: false,
        reason: `REGRESSION: ${regressions.length} previously correct decisions now incorrect`,
        regressions,
      };
    }

    const newlyFixed: string[] = [];
    for (const [missionId, candidate] of candidateResults) {
      if (this.passingBaseline.has(missionId)) continue;
      const historical = this.historicalMissions.find((m) => m.missionId === missionId);
      if (!historical) continue;
      const nowCorrect = historical.outcome.succeeded === (candidate.recommendation === 'APPROVE');
      if (nowCorrect) newlyFixed.push(missionId);
    }

    return {
      accepted: true,
      reason: `Passed regression check. ${newlyFixed.length} newly fixed decisions.`,
      newlyFixed,
      netImprovement: newlyFixed.length,
    };
  }

  computePredictionError(
    assessment: { riskScore: number; recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number },
    outcome: MissionOutcome,
    weatherMatched: boolean,
    threatsMatched: boolean,
  ): PredictionError {
    return {
      riskScoreDelta: Math.abs(assessment.riskScore - outcome.actualRisk),
      weatherAccuracy: weatherMatched,
      threatAccuracy: threatsMatched,
      decisionQuality: outcome.succeeded === (assessment.recommendation === 'APPROVE'),
      confidenceDelta: assessment.confidence - (outcome.succeeded ? 1.0 : 0.0),
    };
  }

  private computeAccuracy(missions: HistoricalMission[]): number {
    if (missions.length === 0) return 0.7;
    let correct = 0;
    for (const m of missions) {
      if (m.outcome.succeeded === (m.assessment.recommendation === 'APPROVE')) {
        correct++;
      }
    }
    return correct / missions.length;
  }

  get currentBaselineAccuracy(): number { return this.baselineAccuracy; }
  get historySize(): number { return this.historicalMissions.length; }
}

export const regressionGuard = new RegressionGuard();
