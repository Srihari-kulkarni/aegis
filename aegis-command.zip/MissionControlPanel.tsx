'use client';

import { useState, useCallback, useEffect } from 'react';
import { useMissionStore } from '@/stores/missionStore';
import { useDroneStore } from '@/stores/droneStore';
import { useAuthStore } from '@/stores/authStore';
import { useFeedStore } from '@/stores/feedStore';
import { RoleGate } from '@/components/RoleGate';
import { MissionStatus, MissionType, OperatorRole } from '@aegis/shared';

const TRUNCATE_LEN = 8;

function truncateId(id: string): string {
  if (!id) return '—';
  if (id.length <= TRUNCATE_LEN + 4) return id;
  return `${id.slice(0, TRUNCATE_LEN)}…${id.slice(-4)}`;
}

function getStatusBadgeClasses(status: MissionStatus): string {
  const base = 'inline-flex px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider border';
  switch (status) {
    case MissionStatus.DRAFT:
      return `${base} border-aegis-muted text-aegis-muted`;
    case MissionStatus.PENDING_AI_REVIEW:
      return `${base} border-aegis-amber text-aegis-amber bg-aegis-amber/10`;
    case MissionStatus.AI_APPROVED:
      return `${base} border-aegis-green text-aegis-green bg-aegis-green/10`;
    case MissionStatus.AI_REJECTED:
      return `${base} border-aegis-red text-aegis-red bg-aegis-red/10`;
    case MissionStatus.COMMANDER_APPROVED:
      return `${base} border-aegis-cyan text-aegis-cyan bg-transparent`;
    case MissionStatus.ACTIVE:
      return `${base} border-aegis-green text-aegis-green bg-aegis-green/10 animate-pulse`;
    case MissionStatus.PAUSED:
      return `${base} border-aegis-amber text-aegis-amber bg-aegis-amber/10`;
    case MissionStatus.COMPLETED:
      return `${base} border-aegis-muted text-aegis-muted`;
    case MissionStatus.ABORTED:
    case MissionStatus.FAILED:
      return `${base} border-aegis-red text-aegis-red bg-aegis-red/10`;
    default:
      return `${base} border-aegis-muted text-aegis-muted`;
  }
}

function GaugeBar({ value, colorClass }: { value: number; colorClass: string }) {
  const pct = Math.min(100, Math.max(0, value * 100));
  return (
    <div className="h-1.5 w-full bg-aegis-bg">
      <div className={`h-full transition-all duration-300 ${colorClass}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function getRiskGaugeColor(score: number): string {
  if (score < 0.4) return 'bg-aegis-green';
  if (score <= 0.75) return 'bg-aegis-amber';
  return 'bg-aegis-red';
}

function getConfidenceGaugeColor(score: number): string {
  if (score >= 0.7) return 'bg-aegis-green';
  if (score >= 0.4) return 'bg-aegis-amber';
  return 'bg-aegis-red';
}

interface MissionControlPanelProps {
  clickedLocation?: { lat: number; lon: number } | null;
  onClearLocation?: () => void;
}

// ─── Mission Creator Form ──────────────────────────────────────────────────────

interface MissionFormState {
  name: string;
  type: MissionType;
  description: string;
  lat: string;
  lon: string;
  alt: string;
  searchQuery: string;
}

function MissionCreator({ clickedLocation, onClearLocation, onClose }: {
  clickedLocation?: { lat: number; lon: number } | null;
  onClearLocation?: () => void;
  onClose: () => void;
}) {
  const createMission = useMissionStore((s) => s.createMission);
  const drones = useDroneStore((s) => s.drones);
  const [form, setForm] = useState<MissionFormState>({
    name: '',
    type: MissionType.ISR,
    description: '',
    lat: '',
    lon: '',
    alt: '300',
    searchQuery: '',
  });
  const [selectedDroneIds, setSelectedDroneIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [geocoding, setGeocoding] = useState(false);

  useEffect(() => {
    if (clickedLocation) {
      setForm((f) => ({
        ...f,
        lat: clickedLocation.lat.toFixed(6),
        lon: clickedLocation.lon.toFixed(6),
      }));
    }
  }, [clickedLocation]);

  const handleGeocode = useCallback(async () => {
    if (!form.searchQuery.trim()) return;
    setGeocoding(true);
    try {
      const q = encodeURIComponent(form.searchQuery.trim());
      const resp = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${q}&limit=1`);
      const data = await resp.json() as Array<{ lat: string; lon: string; display_name: string }>;
      if (data.length > 0) {
        setForm((f) => ({
          ...f,
          lat: parseFloat(data[0].lat).toFixed(6),
          lon: parseFloat(data[0].lon).toFixed(6),
        }));
      } else {
        setError('Location not found. Try a different search.');
      }
    } catch {
      setError('Geocoding failed. Enter coordinates manually.');
    } finally {
      setGeocoding(false);
    }
  }, [form.searchQuery]);

  const toggleDrone = useCallback((droneId: string) => {
    setSelectedDroneIds((ids) =>
      ids.includes(droneId) ? ids.filter((id) => id !== droneId) : [...ids, droneId]
    );
  }, []);

  const handleSubmit = useCallback(async () => {
    setError(null);
    if (!form.name.trim()) { setError('Mission name is required'); return; }
    if (!form.lat || !form.lon) { setError('Location coordinates are required'); return; }
    if (selectedDroneIds.length === 0) { setError('Select at least one drone'); return; }

    const lat = parseFloat(form.lat);
    const lon = parseFloat(form.lon);
    const alt = parseFloat(form.alt) || 300;

    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      setError('Invalid coordinates. Lat: -90 to 90, Lon: -180 to 180');
      return;
    }

    setSubmitting(true);
    const now = new Date();
    const later = new Date(now.getTime() + 3600000);

    const payload = {
      name: form.name.trim().toUpperCase(),
      type: form.type,
      description: form.description.trim() || `Mission ${form.name.trim()} at coordinates ${lat}, ${lon}`,
      areaOfOperations: null,
      waypoints: [
        { index: 0, position: { lat, lon, alt }, action: 'FLY_TO' },
        { index: 1, position: { lat, lon, alt }, action: 'LOITER', loiterDurationSec: 600 },
      ],
      assignedDroneIds: selectedDroneIds,
      plannedStartTime: now.toISOString(),
      plannedEndTime: later.toISOString(),
      clearanceLevel: 'SECRET',
    };

    const ok = await createMission(payload);
    setSubmitting(false);

    if (ok) {
      setSuccess(true);
      if (onClearLocation) onClearLocation();
      setTimeout(() => { onClose(); setSuccess(false); }, 1500);
    } else {
      setError('Failed to create mission. Check console.');
    }
  }, [form, selectedDroneIds, createMission, onClearLocation, onClose]);

  const droneList = Array.from(drones.values());

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-tactical font-semibold text-aegis-cyan uppercase tracking-wider text-sm">
          New Mission
        </h3>
        <button type="button" onClick={onClose} className="text-aegis-muted hover:text-aegis-red text-xs">
          ✕ CANCEL
        </button>
      </div>

      {success && (
        <div className="p-3 border border-aegis-green bg-aegis-green/10 font-mono text-xs text-aegis-green">
          Mission created successfully.
        </div>
      )}

      {error && (
        <div className="p-3 border border-aegis-red bg-aegis-red/10 font-mono text-xs text-aegis-red">
          {error}
        </div>
      )}

      {/* Mission name */}
      <div>
        <label className="data-label block mb-1">Mission Name</label>
        <input
          type="text"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="e.g. OVERWATCH BRAVO"
          className="tactical-input w-full"
        />
      </div>

      {/* Mission type */}
      <div>
        <label className="data-label block mb-1">Type</label>
        <select
          value={form.type}
          onChange={(e) => setForm({ ...form, type: e.target.value as MissionType })}
          className="tactical-input w-full"
        >
          {Object.values(MissionType).map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {/* Description */}
      <div>
        <label className="data-label block mb-1">Description</label>
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Brief mission description..."
          rows={2}
          className="tactical-input w-full resize-none"
        />
      </div>

      {/* Location section */}
      <div className="border border-aegis-border p-3 space-y-3">
        <h4 className="data-label">Location</h4>

        {/* Search by address/pincode */}
        <div>
          <label className="text-aegis-muted text-[10px] block mb-1">Search by address or pincode</label>
          <div className="flex gap-1">
            <input
              type="text"
              value={form.searchQuery}
              onChange={(e) => setForm({ ...form, searchQuery: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleGeocode()}
              placeholder="e.g. 90210 or Downtown LA"
              className="tactical-input flex-1"
            />
            <button
              type="button"
              onClick={handleGeocode}
              disabled={geocoding}
              className="tactical-btn-primary text-[10px] px-3"
            >
              {geocoding ? '...' : 'FIND'}
            </button>
          </div>
        </div>

        {/* Manual lat/lon */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-aegis-muted text-[10px] block mb-1">Latitude</label>
            <input
              type="text"
              value={form.lat}
              onChange={(e) => setForm({ ...form, lat: e.target.value })}
              placeholder="34.052235"
              className="tactical-input w-full"
            />
          </div>
          <div>
            <label className="text-aegis-muted text-[10px] block mb-1">Longitude</label>
            <input
              type="text"
              value={form.lon}
              onChange={(e) => setForm({ ...form, lon: e.target.value })}
              placeholder="-118.243683"
              className="tactical-input w-full"
            />
          </div>
        </div>

        <div>
          <label className="text-aegis-muted text-[10px] block mb-1">Altitude (m)</label>
          <input
            type="text"
            value={form.alt}
            onChange={(e) => setForm({ ...form, alt: e.target.value })}
            placeholder="300"
            className="tactical-input w-24"
          />
        </div>

        {clickedLocation && (
          <div className="flex items-center gap-2 text-[10px]">
            <span className="text-aegis-green">MAP PIN SET</span>
            <button
              type="button"
              onClick={() => {
                if (onClearLocation) onClearLocation();
                setForm((f) => ({ ...f, lat: '', lon: '' }));
              }}
              className="text-aegis-muted hover:text-aegis-red"
            >
              [clear]
            </button>
          </div>
        )}

        <p className="text-aegis-muted text-[9px]">
          Click on the map to set coordinates, search by address/pincode, or enter lat/lon manually.
        </p>
      </div>

      {/* Drone assignment */}
      <div>
        <label className="data-label block mb-1">Assign Drones ({selectedDroneIds.length} selected)</label>
        <div className="max-h-32 overflow-y-auto border border-aegis-border">
          {droneList.length === 0 ? (
            <p className="p-2 text-aegis-muted text-xs">No drones available</p>
          ) : (
            droneList.map((drone) => (
              <button
                key={drone.droneId}
                type="button"
                onClick={() => toggleDrone(drone.droneId)}
                className={`w-full text-left px-3 py-1.5 flex items-center justify-between text-[11px] font-mono border-b border-aegis-border last:border-b-0 transition-colors ${
                  selectedDroneIds.includes(drone.droneId)
                    ? 'bg-aegis-cyan/10 text-aegis-cyan'
                    : 'text-aegis-text hover:bg-aegis-bg'
                }`}
              >
                <span>{drone.callsign}</span>
                <span className="text-aegis-muted text-[10px]">{drone.status}</span>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Submit */}
      <button
        type="button"
        onClick={handleSubmit}
        disabled={submitting}
        className="tactical-btn-primary w-full py-3"
      >
        {submitting ? 'CREATING MISSION...' : 'CREATE MISSION'}
      </button>
    </div>
  );
}

// ─── Main Panel ────────────────────────────────────────────────────────────────

export function MissionControlPanel({ clickedLocation, onClearLocation }: MissionControlPanelProps) {
  const missions = useMissionStore((s) => s.getFilteredMissions());
  const selectedMission = useMissionStore((s) => s.getSelectedMission());
  const selectedAssessment = useMissionStore((s) => s.selectedAssessment);
  const selectMission = useMissionStore((s) => s.selectMission);
  const approveMission = useMissionStore((s) => s.approveMission);
  const abortMission = useMissionStore((s) => s.abortMission);
  const overrideMission = useMissionStore((s) => s.overrideMission);

  const drones = useDroneStore((s) => s.drones);
  const hasRole = useAuthStore((s) => s.hasRole);
  const modelStatus = useFeedStore((s) => s.modelStatus);

  const [showCreator, setShowCreator] = useState(false);
  const [abortConfirmId, setAbortConfirmId] = useState<string | null>(null);
  const [overrideModalId, setOverrideModalId] = useState<string | null>(null);
  const [overrideMfaCode, setOverrideMfaCode] = useState('');
  const [overrideReason, setOverrideReason] = useState('');

  const handleApprove = useCallback(async () => {
    if (!selectedMission) return;
    await approveMission(selectedMission.missionId);
  }, [selectedMission, approveMission]);

  const handleAbortConfirm = useCallback(async () => {
    if (!abortConfirmId) return;
    await abortMission(abortConfirmId);
    setAbortConfirmId(null);
    selectMission(null);
  }, [abortConfirmId, abortMission, selectMission]);

  const handleOverrideConfirm = useCallback(async () => {
    if (!overrideModalId || !overrideMfaCode.trim() || !overrideReason.trim()) return;
    await overrideMission(overrideModalId, overrideReason.trim(), overrideMfaCode.trim());
    setOverrideModalId(null);
    setOverrideMfaCode('');
    setOverrideReason('');
  }, [overrideModalId, overrideMfaCode, overrideReason, overrideMission]);

  const getDroneById = (droneId: string) => drones.get(droneId);

  if (showCreator) {
    return (
      <MissionCreator
        clickedLocation={clickedLocation}
        onClearLocation={onClearLocation}
        onClose={() => setShowCreator(false)}
      />
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Create mission button */}
      <div className="p-3 border-b border-aegis-border shrink-0">
        <button
          type="button"
          onClick={() => setShowCreator(true)}
          className="tactical-btn-primary w-full py-2.5 flex items-center justify-center gap-2"
        >
          <span className="text-lg leading-none">+</span>
          <span>NEW MISSION</span>
        </button>
      </div>

      {/* Mission list */}
      <div className="flex-1 overflow-y-auto min-h-0">
        <div className="p-3">
          <h2 className="font-tactical font-semibold text-aegis-cyan uppercase tracking-wider text-xs mb-3">
            Missions ({missions.length})
          </h2>

          {missions.length === 0 ? (
            <p className="font-mono text-aegis-muted text-xs">No missions found</p>
          ) : (
            <div className="space-y-2">
              {missions.map((m) => (
                <button
                  key={m.missionId}
                  type="button"
                  onClick={() => selectMission(m.missionId)}
                  className={`w-full text-left p-3 border transition-colors ${
                    selectedMission?.missionId === m.missionId
                      ? 'border-aegis-cyan bg-aegis-cyan/5'
                      : 'border-aegis-border hover:border-aegis-muted'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-tactical text-sm text-aegis-text">{m.name}</span>
                    <span className={getStatusBadgeClasses(m.status)}>{m.status}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="font-mono text-[10px] text-aegis-muted">{m.type}</span>
                    <span className="font-mono text-[10px] text-aegis-muted">•</span>
                    <span className="font-mono text-[10px] text-aegis-muted">{m.assignedDroneIds.length} drone{m.assignedDroneIds.length !== 1 ? 's' : ''}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Selected mission detail */}
        {selectedMission && (
          <div className="p-3 border-t border-aegis-border">
            <h3 className="font-tactical font-semibold text-aegis-cyan uppercase tracking-wider text-sm mb-3">
              {selectedMission.name}
            </h3>

            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className={getStatusBadgeClasses(selectedMission.status)}>{selectedMission.status}</span>
              <span className="font-mono text-[10px] text-aegis-muted border border-aegis-border px-1.5 py-0.5">
                {selectedMission.type}
              </span>
            </div>

            {/* AI Assessment */}
            {selectedAssessment && (
              <div className="mb-4 p-3 border border-aegis-border bg-aegis-bg/50">
                <h4 className="data-label mb-2">AI Assessment</h4>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className={`inline-flex px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider border ${
                    selectedAssessment.recommendation === 'APPROVE' ? 'border-aegis-green text-aegis-green bg-aegis-green/10' :
                    selectedAssessment.recommendation === 'REJECT' ? 'border-aegis-red text-aegis-red bg-aegis-red/10' :
                    'border-aegis-amber text-aegis-amber bg-aegis-amber/10'
                  }`}>
                    {selectedAssessment.recommendation}
                  </span>
                  <span className="font-mono text-[9px] text-aegis-muted border border-aegis-border px-1 py-0.5">
                    {modelStatus?.activeTier === 'CLOUD_GPT4O' ? 'GPT-4o' :
                     modelStatus?.activeTier === 'LOCAL_70B' ? 'AirLLM 70B' :
                     modelStatus?.activeTier === 'LOCAL_7B' ? 'AirLLM 7B' : 'RULE'}
                  </span>
                </div>
                <div className="space-y-2 mb-2">
                  <div>
                    <div className="flex justify-between text-[10px]">
                      <span className="text-aegis-muted">Confidence</span>
                      <span className="text-aegis-text">{((selectedAssessment.confidence ?? 0) * 100).toFixed(0)}%</span>
                    </div>
                    <GaugeBar value={selectedAssessment.confidence ?? 0} colorClass={getConfidenceGaugeColor(selectedAssessment.confidence ?? 0)} />
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px]">
                      <span className="text-aegis-muted">Risk</span>
                      <span className="text-aegis-text">{(selectedAssessment.riskScore ?? 0).toFixed(2)}</span>
                    </div>
                    <GaugeBar value={selectedAssessment.riskScore ?? 0} colorClass={getRiskGaugeColor(selectedAssessment.riskScore ?? 0)} />
                  </div>
                </div>
                {selectedAssessment.reasoning && (
                  <p className="font-mono text-[10px] text-aegis-muted leading-relaxed">{selectedAssessment.reasoning}</p>
                )}
              </div>
            )}

            {/* Action buttons */}
            <div className="flex flex-wrap gap-2 mb-4">
              <RoleGate role={OperatorRole.MISSION_COMMANDER}>
                <button
                  type="button"
                  onClick={handleApprove}
                  className="tactical-btn-primary text-[11px]"
                >
                  APPROVE
                </button>
              </RoleGate>
              {hasRole(OperatorRole.MISSION_COMMANDER) && (
                <button
                  type="button"
                  onClick={() => setOverrideModalId(selectedMission.missionId)}
                  className="tactical-btn border-aegis-amber text-aegis-amber hover:bg-aegis-amber hover:text-aegis-bg text-[11px]"
                >
                  OVERRIDE AI
                </button>
              )}
              {(hasRole(OperatorRole.MISSION_COMMANDER) || hasRole(OperatorRole.SUPER_ADMIN)) && (
                <button
                  type="button"
                  onClick={() => setAbortConfirmId(selectedMission.missionId)}
                  className="tactical-btn-danger text-[11px]"
                >
                  ABORT
                </button>
              )}
            </div>

            {/* Assigned drones */}
            <div>
              <h4 className="data-label mb-2">Assigned Drones</h4>
              {selectedMission.assignedDroneIds.length === 0 ? (
                <p className="font-mono text-aegis-muted text-xs">None assigned</p>
              ) : (
                <ul className="space-y-1">
                  {selectedMission.assignedDroneIds.map((droneId) => {
                    const drone = getDroneById(droneId);
                    return (
                      <li
                        key={droneId}
                        className="flex items-center justify-between font-mono text-[10px] py-1.5 px-2 border border-aegis-border"
                      >
                        <span className="text-aegis-cyan">{truncateId(droneId)}</span>
                        <span className="text-aegis-muted">
                          {drone ? `${drone.callsign} — ${drone.status}` : '—'}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Abort confirmation modal */}
      {abortConfirmId && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70">
          <div className="bg-aegis-panel border-2 border-aegis-red p-6 w-full max-w-sm mx-4 shadow-2xl">
            <h3 className="font-tactical font-bold text-aegis-red uppercase tracking-wider text-sm mb-3">
              ⚠ CONFIRM ABORT
            </h3>
            <p className="font-mono text-aegis-muted text-xs mb-2">
              Mission: <span className="text-aegis-text">{truncateId(abortConfirmId)}</span>
            </p>
            <p className="font-mono text-aegis-red/80 text-[10px] mb-6">
              This will immediately terminate the mission and recall all assigned drones. This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={handleAbortConfirm}
                className="tactical-btn-danger flex-1 py-2.5"
              >
                CONFIRM ABORT
              </button>
              <button
                type="button"
                onClick={() => setAbortConfirmId(null)}
                className="tactical-btn flex-1 py-2.5"
              >
                CANCEL
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Override modal */}
      {overrideModalId && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70">
          <div className="bg-aegis-panel border-2 border-aegis-amber p-6 w-full max-w-md mx-4 shadow-2xl">
            <h3 className="font-tactical font-bold text-aegis-amber uppercase tracking-wider text-sm mb-3">
              Override AI Decision
            </h3>
            <p className="font-mono text-aegis-muted text-xs mb-4">
              Mission: <span className="text-aegis-text">{truncateId(overrideModalId)}</span>
            </p>
            <div className="space-y-3 mb-4">
              <div>
                <label className="data-label block mb-1">TOTP Code</label>
                <input
                  type="text"
                  value={overrideMfaCode}
                  onChange={(e) => setOverrideMfaCode(e.target.value)}
                  placeholder="6-digit code"
                  maxLength={6}
                  className="tactical-input w-full"
                  autoComplete="one-time-code"
                />
              </div>
              <div>
                <label className="data-label block mb-1">Override Reason</label>
                <textarea
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="Justification for overriding AI decision..."
                  rows={3}
                  className="tactical-input w-full resize-none"
                />
              </div>
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={handleOverrideConfirm}
                className="tactical-btn border-aegis-amber text-aegis-amber hover:bg-aegis-amber hover:text-aegis-bg flex-1 py-2.5"
              >
                CONFIRM OVERRIDE
              </button>
              <button
                type="button"
                onClick={() => { setOverrideModalId(null); setOverrideMfaCode(''); setOverrideReason(''); }}
                className="tactical-btn flex-1 py-2.5"
              >
                CANCEL
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
