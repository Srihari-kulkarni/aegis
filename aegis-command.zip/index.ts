import { DroneClass } from '@aegis/shared';
import { DroneBase, DroneConfig } from './DroneBase';
import { ReconDrone } from './ReconDrone';
import { OffenseDrone } from './OffenseDrone';
import { DeliveryDrone } from './DeliveryDrone';
import { EWDrone } from './EWDrone';
import { RelayDrone } from './RelayDrone';
import { SwarmDrone } from './SwarmDrone';
import { CBRNDrone } from './CBRNDrone';
import { UnderwaterDrone } from './UnderwaterDrone';
import { LargeAltitudeDrone } from './LargeAltitudeDrone';
import { MicroDrone } from './MicroDrone';

export {
  DroneBase,
  ReconDrone,
  OffenseDrone,
  DeliveryDrone,
  EWDrone,
  RelayDrone,
  SwarmDrone,
  CBRNDrone,
  UnderwaterDrone,
  LargeAltitudeDrone,
  MicroDrone,
};

export type { DroneConfig, TypeMetrics, DegradedCapability } from './DroneBase';

const DRONE_CLASS_MAP: Record<DroneClass, new (cfg: DroneConfig) => DroneBase> = {
  [DroneClass.RECON]: ReconDrone,
  [DroneClass.OFFENSE]: OffenseDrone,
  [DroneClass.DELIVERY]: DeliveryDrone,
  [DroneClass.EW]: EWDrone,
  [DroneClass.RELAY]: RelayDrone,
  [DroneClass.SWARM]: SwarmDrone,
  [DroneClass.CBRN]: CBRNDrone,
  [DroneClass.UNDERWATER]: UnderwaterDrone,
  [DroneClass.LARGE_ALTITUDE]: LargeAltitudeDrone,
  [DroneClass.MICRO]: MicroDrone,
};

export function createDrone(droneClass: DroneClass, cfg: DroneConfig): DroneBase {
  const Constructor = DRONE_CLASS_MAP[droneClass];
  return new Constructor(cfg);
}
