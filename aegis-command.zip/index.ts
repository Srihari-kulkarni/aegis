import express from 'express';
import { createServer } from 'http';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import { config } from './config';
import { logger } from './logger';
import { testConnection } from './db/pool';
import { connectRedis } from './redis';
import { initWebSocketServer } from './websocket/server';
import { authRouter } from './auth/routes';
import { missionRouter } from './routes/missions';
import { droneRouter } from './routes/drones';
import { logRouter } from './routes/log';
import { intelRouter } from './routes/intel';
import { fireControlRouter } from './routes/fireControl';
import { telemetrySimulator } from './simulator/TelemetrySimulator';
import { continuousIntelFeed } from './ai/ContinuousIntelFeed';
import { htsDroneRegistry } from './hedera/HTSDroneRegistry';
import { aiEngine } from './ai/AIMissionApprovalEngine';
import { cecEngine } from './services/CECSensorFusionEngine';
import { fireControlService } from './services/FireControlService';

async function bootstrap(): Promise<void> {
  logger.info({ env: config.env, port: config.port, demoMode: config.demoMode }, 'AEGIS COMMAND backend starting');

  const app = express();
  const httpServer = createServer(app);

  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
  }));
  app.use(cors({
    origin: config.cors.origin,
    credentials: true,
  }));
  app.use(compression());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));

  const globalLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: 'Rate limit exceeded', timestamp: new Date().toISOString() },
  });
  app.use(globalLimiter);

  app.get('/health', (_req, res) => {
    res.json({
      status: 'operational',
      service: 'aegis-command-backend',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  });

  app.use('/auth', authRouter);
  app.use('/api/v1/missions', missionRouter);
  app.use('/api/v1/drones', droneRouter);
  app.use('/api/v1/log', logRouter);
  app.use('/api/v1/intel', intelRouter);
  app.use('/api/v1/fire-control', fireControlRouter);

  app.use((_req, res) => {
    res.status(404).json({ success: false, error: 'Not found', timestamp: new Date().toISOString() });
  });

  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    logger.error({ err }, 'Unhandled error');
    res.status(500).json({ success: false, error: 'Internal server error', timestamp: new Date().toISOString() });
  });

  try {
    await testConnection();
    logger.info('PostgreSQL connected');
  } catch (err) {
    logger.warn({ err }, 'PostgreSQL connection failed — running in limited mode');
  }

  try {
    await connectRedis();
    logger.info('Redis connected');
  } catch (err) {
    logger.warn({ err }, 'Redis connection failed — running in limited mode');
  }

  const io = initWebSocketServer(httpServer);

  try {
    await htsDroneRegistry.initializeCollection();
    logger.info('HTS drone registry initialized');
  } catch (err) {
    logger.warn({ err }, 'HTS registry init failed');
  }

  try {
    await telemetrySimulator.initialize();
    telemetrySimulator.start();
    logger.info('Telemetry simulator running');
  } catch (err) {
    logger.warn({ err }, 'Telemetry simulator init failed');
  }

  continuousIntelFeed.start();

  if (config.demoMode) {
    try {
      cecEngine.generateSimulatedThreatPicture();
      logger.info('CEC sensor fusion engine — simulated threat picture active');
    } catch (err) {
      logger.warn({ err }, 'CEC threat picture generation failed');
    }
  }

  const fireControlNs = io.of('/fire-control');
  fireControlNs.use((socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined
      ?? socket.handshake.headers?.authorization?.replace('Bearer ', '');
    if (!token) { next(new Error('Authentication required')); return; }
    try {
      jwt.verify(token, config.jwt.publicKey, { algorithms: ['RS256'] });
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  fireControlNs.on('connection', (socket) => {
    logger.debug('Fire control WS client connected');
    socket.join('fire-control-global');
    socket.on('disconnect', () => {
      logger.debug('Fire control WS client disconnected');
    });
  });

  fireControlService.on('designation:new', (data) => {
    fireControlNs.to('fire-control-global').emit('designation:new', data);
  });
  fireControlService.on('confirmation:new', (data) => {
    fireControlNs.to('fire-control-global').emit('confirmation:new', data);
  });
  fireControlService.on('authorization:granted', (data) => {
    fireControlNs.to('fire-control-global').emit('authorization:granted', data);
  });
  fireControlService.on('authorization:aborted', (data) => {
    fireControlNs.to('fire-control-global').emit('authorization:aborted', data);
  });
  fireControlService.on('roe:changed', (data) => {
    fireControlNs.to('fire-control-global').emit('roe:changed', data);
  });

  logger.info('Fire control WebSocket namespace /fire-control initialized');

  try {
    await aiEngine.initializeRI();
    logger.info('Recursive Improvement system initialized');
  } catch (err) {
    logger.warn({ err }, 'Recursive Improvement system init failed — running without RI');
  }

  httpServer.listen(config.port, () => {
    logger.info(`
╔══════════════════════════════════════════╗
║         AEGIS COMMAND — ONLINE           ║
║                                          ║
║  API:       http://localhost:${config.port}       ║
║  WebSocket: ws://localhost:${config.port}         ║
║  Mode:      ${config.demoMode ? 'DEMO' : 'LIVE'}                         ║
║  Env:       ${config.env.toUpperCase().padEnd(27)}║
╚══════════════════════════════════════════╝
    `);
  });

  const shutdown = async (): Promise<void> => {
    logger.info('AEGIS COMMAND shutting down...');
    telemetrySimulator.stop();
    continuousIntelFeed.stop();
    httpServer.close();
    process.exit(0);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

bootstrap().catch((err) => {
  logger.fatal({ err }, 'AEGIS COMMAND bootstrap failed');
  process.exit(1);
});
