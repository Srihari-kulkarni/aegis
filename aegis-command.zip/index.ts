import { logger } from '../../logger';
import { redis, redisPub } from '../../redis';
import { zuluTimestamp, DroneClass } from '@aegis/shared';
import { promptOptimizer } from './prompt-optimizer';
import { capabilityAssessor } from './capability-assessor';
import { waypointOptimizer } from './waypoint-optimizer';
import { regressionGuard } from './regression-guard';
import { safetyMonitor } from './safety-monitor';
import type {
  RISystemStatus,
  MissionOutcome,
  RefinementRecord,
  DronePerformanceLog,
  PostMissionAnalysis,
} from './types';

const RI_STATUS_KEY = 'ri:system:status';
const RI_ENABLED_KEY = 'ri:system:enabled';

export class RecursiveImprovementSystem {
  private enabled = true;
  private totalIterations = 0;
  private lastRefinement: string | null = null;
  private initialized = false;

  async initialize(): Promise<void> {
    if (this.initialized) return;

    const enabledData = await redis.get(RI_ENABLED_KEY);
    if (enabledData === 'false') {
      this.enabled = false;
      logger.info('Recursive Improvement system is disabled');
    }

    await regressionGuard.initialize();
    await promptOptimizer.initialize();
    await capabilityAssessor.initialize();
    await waypointOptimizer.initialize();
    await safetyMonitor.initialize();

    this.initialized = true;
    logger.info('Recursive Improvement system fully initialized (3 layers + safety)');

    await this.publishStatus();
  }

  async processPostMission(
    missionId: string,
    assessment: { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number; assessmentId: string },
    outcome: MissionOutcome,
    weatherMatched: boolean,
    threatsMatched: boolean,
  ): Promise<PostMissionAnalysis | null> {
    if (!this.enabled) return null;

    if (!safetyMonitor.checkRateLimit()) {
      logger.warn('RI rate limit exceeded — skipping post-mission refinement');
      return null;
    }

    if (!safetyMonitor.isContainmentIntact) {
      logger.error('RI containment compromised — refusing all refinements');
      return null;
    }

    await regressionGuard.recordMissionOutcome(
      missionId,
      { recommendation: assessment.recommendation, riskScore: assessment.riskScore },
      assessment,
      outcome,
    );

    const analysis = await promptOptimizer.postMissionRefine(
      missionId, assessment, outcome, weatherMatched, threatsMatched,
    );

    if (analysis.refinementResult) {
      safetyMonitor.recordRefinementOutcome(analysis.refinementResult);
      this.totalIterations++;
      this.lastRefinement = zuluTimestamp();
    }

    await this.publishStatus();
    return analysis;
  }

  async logDronePerformance(log: DronePerformanceLog): Promise<RefinementRecord | null> {
    if (!this.enabled) return null;

    await capabilityAssessor.logPerformance(log);
    const result = await capabilityAssessor.assessAndUpdate(log.droneClass);

    if (result) {
      safetyMonitor.recordRefinementOutcome(result);
      this.totalIterations++;
      this.lastRefinement = zuluTimestamp();
      await this.publishStatus();
    }

    return result;
  }

  async optimizeMissionRoute(
    missionId: string,
    origin: { lat: number; lon: number; alt: number },
    destination: { lat: number; lon: number; alt: number },
    currentWaypoints: Array<{ lat: number; lon: number; alt: number }>,
    threats: Array<{ threatId: string; type: string; position: { lat: number; lon: number; alt: number }; radiusKm: number; confidence: number; hostileUnitId: string; description: string; firstDetected: string; lastUpdated: string; active: boolean }>,
    terrainData: Array<{ position: { lat: number; lon: number; alt: number }; elevationM: number; canMask: boolean }>,
    maxFlightTimeMin: number,
    cruiseSpeedKnots: number,
    fuelCapacityPercent: number,
  ) {
    if (!this.enabled) return null;

    if (!safetyMonitor.checkRateLimit()) {
      logger.warn('RI rate limit exceeded — skipping route optimization');
      return null;
    }

    const result = await waypointOptimizer.optimizeRoute({
      missionId,
      origin,
      destination,
      currentWaypoints,
      threats: threats as import('@aegis/shared').Threat[],
      terrainData,
      maxFlightTimeMin,
      cruiseSpeedKnots,
      fuelCapacityPercent,
    });

    if (result.accepted) {
      this.totalIterations++;
      this.lastRefinement = zuluTimestamp();
    }

    await this.publishStatus();
    return result;
  }

  getSystemStatus(): RISystemStatus {
    const promptStatus = promptOptimizer.getStatus();
    const capabilityStatus = capabilityAssessor.getStatus();
    const routingStatus = waypointOptimizer.getStatus();

    const allHistories = [
      ...promptOptimizer.refinementHistory,
      ...capabilityAssessor.history,
      ...waypointOptimizer.history,
    ];
    const accepted = allHistories.filter((r) => r.accepted).length;
    const successRate = allHistories.length > 0 ? accepted / allHistories.length : 0;

    return {
      enabled: this.enabled,
      layers: {
        prompt: promptStatus,
        capability: capabilityStatus,
        routing: routingStatus,
      },
      safety: {
        containmentIntact: safetyMonitor.isContainmentIntact,
        goalInvariant: safetyMonitor.isGoalInvariant,
        pendingHumanGates: safetyMonitor.pendingHumanGates,
        rollbacksTriggered: safetyMonitor.totalRollbacks,
      },
      totalIterations: this.totalIterations,
      lastRefinement: this.lastRefinement,
      successRate,
    };
  }

  getRefinementHistory(): RefinementRecord[] {
    return [
      ...promptOptimizer.refinementHistory,
      ...capabilityAssessor.history,
      ...waypointOptimizer.history,
    ].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }

  getCapabilityDescriptors() {
    return capabilityAssessor.getAllDescriptors();
  }

  getCapabilityDescriptor(droneClass: DroneClass) {
    return capabilityAssessor.getDescriptor(droneClass);
  }

  getSafetyEvents() {
    return safetyMonitor.safetyEvents;
  }

  getPromptVersions() {
    return promptOptimizer.versionHistory;
  }

  getGPConfig() {
    return waypointOptimizer.gpConfig;
  }

  async setEnabled(enabled: boolean): Promise<void> {
    this.enabled = enabled;
    await redis.set(RI_ENABLED_KEY, enabled.toString());
    logger.info({ enabled }, 'RI system enabled state changed');
    await this.publishStatus();
  }

  async approveSafetyEvent(eventId: string, approvedBy: string): Promise<boolean> {
    return safetyMonitor.approveRefinement(eventId, approvedBy);
  }

  private async publishStatus(): Promise<void> {
    const status = this.getSystemStatus();
    await redis.set(RI_STATUS_KEY, JSON.stringify(status), 'EX', 60);
    await redisPub.publish('ri:status', JSON.stringify(status));
  }
}

export const riSystem = new RecursiveImprovementSystem();

export { promptOptimizer } from './prompt-optimizer';
export { capabilityAssessor } from './capability-assessor';
export { waypointOptimizer } from './waypoint-optimizer';
export { regressionGuard } from './regression-guard';
export { safetyMonitor } from './safety-monitor';
export { GeneticEngine } from './genetic-engine';

export type {
  RISystemStatus,
  RefinementRecord,
  MissionOutcome,
  PostMissionAnalysis,
  DronePerformanceLog,
  SafetyEvent,
  CapabilityDescriptor,
  PromptVersion,
  GPConfig,
  GPGenerationReport,
  RouteFitness,
  ValidationResult,
  BacktestResult,
  PredictionError,
  LayerStatus,
} from './types';
