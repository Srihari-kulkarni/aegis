import { DroneClass } from '@aegis/shared';

export type FeedSuitability = 'PRIMARY' | 'HIGH' | 'MEDIUM' | 'LOW' | 'N/A';

export interface BoundingBox {
  lamin: number;
  lomin: number;
  lamax: number;
  lomax: number;
}

export interface OpenSkyState {
  icao24: string;
  callsign: string | null;
  originCountry: string;
  longitude: number | null;
  latitude: number | null;
  baroAltitude: number | null;
  velocity: number | null;
  trueTrack: number | null;
  verticalRate: number | null;
  onGround: boolean;
  squawk: string | null;
}

export interface OpenMeteoWind {
  lat: number;
  lon: number;
  wind10m: number;
  wind80m: number;
  wind120m: number;
  gusts10m: number;
  visibility: number;
  precipitation: number;
  weatherCode: number;
  fetchedAt: string;
}

export interface FAA_TFR {
  tfrId: string;
  type: 'SECURITY' | 'HAZARD' | 'VIP' | 'MILITARY' | 'SPACE' | 'OTHER';
  description: string;
  center: { lat: number; lon: number };
  radiusNm: number;
  floorFt: number;
  ceilingFt: number;
  startTime: string;
  endTime: string;
}

export interface NOAASpaceWeather {
  kpIndex: number;
  timeTag: string;
  gpsConfidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'DEGRADED' | 'UNUSABLE';
  riskDelta: number;
}

export interface TopoElevation {
  lat: number;
  lon: number;
  elevationM: number;
  dataset: string;
}

export interface NOAAAlert {
  id: string;
  event: string;
  severity: 'Extreme' | 'Severe' | 'Moderate' | 'Minor' | 'Unknown';
  headline: string;
  description: string;
  areaDesc: string;
  onset: string;
  expires: string;
}

export interface RadioRefFrequency {
  frequency: number;
  description: string;
  mode: string;
  tag: string;
  protected: boolean;
}

export interface AirLabsFlight {
  flightIata: string;
  airlineIcao: string;
  aircraftIcao: string;
  lat: number;
  lng: number;
  alt: number;
  speed: number;
  dir: number;
  status: string;
}

export interface AirspaceLinkZone {
  zoneId: string;
  name: string;
  type: string;
  maxAltFt: number;
  advisoryType: string;
  laancStatus: string;
}

export interface AloftLAANC {
  facilityId: string;
  gridId: string;
  maxAltFt: number;
  laancAvailable: boolean;
  autoApproveBelow: number;
  furtherCoordinationRequired: boolean;
}

export interface USGS3DEP {
  lat: number;
  lon: number;
  elevationM: number;
  resolution: string;
  dataset: string;
}

export interface ADSBExchangeAircraft {
  hex: string;
  flight: string;
  alt: number;
  speed: number;
  track: number;
  lat: number;
  lon: number;
  vertRate: number;
  squawk: string;
  category: string;
  mil: boolean;
}

export interface IntelFeedResult<T> {
  success: boolean;
  data: T;
  source: string;
  cached: boolean;
  fetchedAt: string;
  ttlSeconds: number;
}

export interface AggregatedIntel {
  openSky: IntelFeedResult<OpenSkyState[]> | null;
  adsbExchange: IntelFeedResult<ADSBExchangeAircraft[]> | null;
  openMeteo: IntelFeedResult<OpenMeteoWind> | null;
  openWeatherMap: IntelFeedResult<import('@aegis/shared').WeatherData> | null;
  noaaWeather: IntelFeedResult<NOAAAlert[]> | null;
  faaTFR: IntelFeedResult<FAA_TFR[]> | null;
  noaaSpaceWeather: IntelFeedResult<NOAASpaceWeather> | null;
  openTopo: IntelFeedResult<TopoElevation[]> | null;
  usgs3dep: IntelFeedResult<USGS3DEP[]> | null;
  radioRef: IntelFeedResult<RadioRefFrequency[]> | null;
  airLabs: IntelFeedResult<AirLabsFlight[]> | null;
  airspaceLink: IntelFeedResult<AirspaceLinkZone[]> | null;
  aloftLAANC: IntelFeedResult<AloftLAANC> | null;
}

export const WIND_ABORT_THRESHOLDS: Record<DroneClass, { altitudeBand: string; thresholdMs: number }> = {
  [DroneClass.MICRO]: { altitudeBand: '10m', thresholdMs: 10 },
  [DroneClass.CBRN]: { altitudeBand: '10m', thresholdMs: 12 },
  [DroneClass.SWARM]: { altitudeBand: '10m', thresholdMs: 12 },
  [DroneClass.DELIVERY]: { altitudeBand: '10-80m', thresholdMs: 13 },
  [DroneClass.EW]: { altitudeBand: '10-80m', thresholdMs: 15 },
  [DroneClass.RECON]: { altitudeBand: '10-80m', thresholdMs: 15 },
  [DroneClass.RELAY]: { altitudeBand: '80-180m', thresholdMs: 18 },
  [DroneClass.OFFENSE]: { altitudeBand: '80-180m', thresholdMs: 20 },
  [DroneClass.LARGE_ALTITUDE]: { altitudeBand: '120m+', thresholdMs: 25 },
  [DroneClass.UNDERWATER]: { altitudeBand: 'N/A', thresholdMs: 999 },
};

export const TERRAIN_CLEARANCE_M: Record<DroneClass, number> = {
  [DroneClass.MICRO]: 30,
  [DroneClass.CBRN]: 60,
  [DroneClass.SWARM]: 50,
  [DroneClass.DELIVERY]: 80,
  [DroneClass.EW]: 100,
  [DroneClass.RECON]: 150,
  [DroneClass.RELAY]: 120,
  [DroneClass.OFFENSE]: 200,
  [DroneClass.LARGE_ALTITUDE]: 300,
  [DroneClass.UNDERWATER]: 0,
};
