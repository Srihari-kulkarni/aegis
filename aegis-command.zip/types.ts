import type { DroneClass, GeoPosition, AIAssessment, MissionContext } from '@aegis/shared';

export interface RefinementRecord {
  iterationId: string;
  iteration: number;
  timestamp: string;
  layer: 'PROMPT' | 'CAPABILITY' | 'ROUTING';
  previousVersion: string;
  candidateVersion: string;
  accepted: boolean;
  reason: string;
  metrics: RefinementMetrics;
}

export interface RefinementMetrics {
  successRate: number;
  avgIterationsToFix: number;
  riskScoreDelta: number;
  predictionAccuracy: number;
  latencyMs: number;
}

export interface MissionOutcome {
  missionId: string;
  succeeded: boolean;
  actualRisk: number;
  weatherMatchedPrediction: boolean;
  threatsMatchedPrediction: boolean;
  routeEfficiency: number;
  etaAccuracyPercent: number;
  fuelUsedPercent: number;
  threatExposureSeconds: number;
  terrainMaskingPercent: number;
  completedAt: string;
  telemetrySnapshots: TelemetrySnapshot[];
}

export interface TelemetrySnapshot {
  timestamp: string;
  droneId: string;
  position: GeoPosition;
  batteryPercent: number;
  fuelPercent: number;
  health: number;
}

export interface PredictionError {
  riskScoreDelta: number;
  weatherAccuracy: boolean;
  threatAccuracy: boolean;
  decisionQuality: boolean;
  confidenceDelta: number;
}

export interface PromptVersion {
  versionId: string;
  prompt: string;
  iteration: number;
  accuracy: number;
  backtestScore: number;
  deployedAt: string;
  retired: boolean;
}

export interface CapabilityDescriptor {
  droneClass: DroneClass;
  version: number;
  maxWindToleranceMs: number;
  operationalCeilingFt: number;
  minHealthThreshold: number;
  effectiveRangeKm: number;
  sensorAccuracy: number;
  plumeModelAccuracy?: number;
  jamEffectiveness?: number;
  swarmCoherenceScore?: number;
  updatedAt: string;
  updatedBy: 'SYSTEM' | 'AIRLLM' | 'OPERATOR';
  evidence: CapabilityEvidence[];
}

export interface CapabilityEvidence {
  missionId: string;
  metric: string;
  predicted: number;
  actual: number;
  delta: number;
  timestamp: string;
}

export interface RouteGene {
  waypoints: GeoPosition[];
  fitness: number;
  generation: number;
  parentIds: [string, string] | null;
}

export interface GPConfig {
  populationSize: number;
  maxGenerations: number;
  maxDepth: number;
  crossoverRate: number;
  mutationRate: number;
  elitismPercent: number;
  parsimonyCoefficient: number;
  tournamentSize: number;
}

export interface RouteFitness {
  total: number;
  fuelEfficiency: number;
  threatExposure: number;
  terrainMasking: number;
  etaAccuracy: number;
  distancePenalty: number;
}

export interface GPGenerationReport {
  generation: number;
  bestFitness: number;
  avgFitness: number;
  worstFitness: number;
  diversity: number;
  eliteCount: number;
  mutationCount: number;
  crossoverCount: number;
  timestamp: string;
}

export interface ValidationResult {
  accepted: boolean;
  reason: string;
  newlyFixed?: string[];
  netImprovement?: number;
  regressions?: string[];
}

export interface SafetyEvent {
  eventId: string;
  type: 'CONTAINMENT_BREACH' | 'GOAL_DRIFT' | 'ROLLBACK_TRIGGERED' | 'HUMAN_GATE_REQUIRED' | 'TREACHEROUS_TURN_DETECTED';
  layer: 'PROMPT' | 'CAPABILITY' | 'ROUTING' | 'SAFETY';
  severity: 'WARNING' | 'CRITICAL' | 'EMERGENCY';
  description: string;
  timestamp: string;
  resolved: boolean;
  resolvedBy?: string;
}

export interface RISystemStatus {
  enabled: boolean;
  layers: {
    prompt: LayerStatus;
    capability: LayerStatus;
    routing: LayerStatus;
  };
  safety: {
    containmentIntact: boolean;
    goalInvariant: boolean;
    pendingHumanGates: number;
    rollbacksTriggered: number;
  };
  totalIterations: number;
  lastRefinement: string | null;
  successRate: number;
}

export interface LayerStatus {
  active: boolean;
  currentVersion: number;
  totalIterations: number;
  lastImprovement: string | null;
  accuracy: number;
  pendingApproval: boolean;
}

export interface BacktestResult {
  promptVersion: string;
  missionsEvaluated: number;
  correctDecisions: number;
  accuracy: number;
  falseApprovals: number;
  falseRejections: number;
  avgConfidenceDelta: number;
}

export interface PostMissionAnalysis {
  missionId: string;
  assessmentId: string;
  predictionError: PredictionError;
  refinementTriggered: boolean;
  refinementResult: RefinementRecord | null;
  analysisTimestamp: string;
}

export interface DronePerformanceLog {
  droneId: string;
  droneClass: DroneClass;
  missionId: string;
  metric: string;
  predicted: number;
  actual: number;
  delta: number;
  timestamp: string;
}
