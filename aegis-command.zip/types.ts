export enum DroneClass {
  RECON = 'RECON',
  OFFENSE = 'OFFENSE',
  DELIVERY = 'DELIVERY',
  EW = 'EW',
  RELAY = 'RELAY',
  SWARM = 'SWARM',
  CBRN = 'CBRN',
  UNDERWATER = 'UNDERWATER',
  LARGE_ALTITUDE = 'LARGE_ALTITUDE',
  MICRO = 'MICRO',
}

export enum DroneStatus {
  STANDBY = 'STANDBY',
  PREFLIGHT = 'PREFLIGHT',
  AIRBORNE = 'AIRBORNE',
  ON_MISSION = 'ON_MISSION',
  RETURNING = 'RETURNING',
  LANDED = 'LANDED',
  MAINTENANCE = 'MAINTENANCE',
  LOST_LINK = 'LOST_LINK',
  EMERGENCY = 'EMERGENCY',
  DESTROYED = 'DESTROYED',
  DECOMMISSIONED = 'DECOMMISSIONED',
}

export enum MissionStatus {
  DRAFT = 'DRAFT',
  PENDING_AI_REVIEW = 'PENDING_AI_REVIEW',
  AI_APPROVED = 'AI_APPROVED',
  AI_REJECTED = 'AI_REJECTED',
  COMMANDER_APPROVED = 'COMMANDER_APPROVED',
  ACTIVE = 'ACTIVE',
  PAUSED = 'PAUSED',
  COMPLETED = 'COMPLETED',
  ABORTED = 'ABORTED',
  FAILED = 'FAILED',
}

export enum ActionType {
  MISSION_CREATED = 'MISSION_CREATED',
  MISSION_APPROVED = 'MISSION_APPROVED',
  MISSION_REJECTED = 'MISSION_REJECTED',
  MISSION_ACTIVATED = 'MISSION_ACTIVATED',
  MISSION_PAUSED = 'MISSION_PAUSED',
  MISSION_RESUMED = 'MISSION_RESUMED',
  MISSION_COMPLETED = 'MISSION_COMPLETED',
  MISSION_ABORTED = 'MISSION_ABORTED',
  MISSION_FAILED = 'MISSION_FAILED',
  AI_ASSESSMENT = 'AI_ASSESSMENT',
  AI_OVERRIDE = 'AI_OVERRIDE',
  DRONE_ASSIGNED = 'DRONE_ASSIGNED',
  DRONE_LAUNCHED = 'DRONE_LAUNCHED',
  DRONE_RECALLED = 'DRONE_RECALLED',
  DRONE_LANDED = 'DRONE_LANDED',
  DRONE_COMMAND = 'DRONE_COMMAND',
  TELEMETRY_UPDATE = 'TELEMETRY_UPDATE',
  WAYPOINT_REACHED = 'WAYPOINT_REACHED',
  THREAT_DETECTED = 'THREAT_DETECTED',
  THREAT_CLEARED = 'THREAT_CLEARED',
  LINK_DEGRADED = 'LINK_DEGRADED',
  LINK_LOST = 'LINK_LOST',
  LINK_RESTORED = 'LINK_RESTORED',
  EMERGENCY_DECLARED = 'EMERGENCY_DECLARED',
  EMERGENCY_RESOLVED = 'EMERGENCY_RESOLVED',
  WEAPON_ARMED = 'WEAPON_ARMED',
  WEAPON_RELEASED = 'WEAPON_RELEASED',
  PAYLOAD_DELIVERED = 'PAYLOAD_DELIVERED',
  EW_ACTIVATED = 'EW_ACTIVATED',
  EW_DEACTIVATED = 'EW_DEACTIVATED',
  SWARM_FORMED = 'SWARM_FORMED',
  SWARM_DISSOLVED = 'SWARM_DISSOLVED',
  CBRN_ALERT = 'CBRN_ALERT',
  OPERATOR_LOGIN = 'OPERATOR_LOGIN',
  OPERATOR_LOGOUT = 'OPERATOR_LOGOUT',
  COMMANDER_OVERRIDE = 'COMMANDER_OVERRIDE',
}

export enum OperatorRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  MISSION_COMMANDER = 'MISSION_COMMANDER',
  OPERATOR = 'OPERATOR',
  ANALYST = 'ANALYST',
  AI_SYSTEM = 'AI_SYSTEM',
  AUDITOR = 'AUDITOR',
  GUEST = 'GUEST',
}

export enum ClearanceLevel {
  UNCLASSIFIED = 'UNCLASSIFIED',
  CONFIDENTIAL = 'CONFIDENTIAL',
  SECRET = 'SECRET',
  TOP_SECRET = 'TOP_SECRET',
  SCI = 'SCI',
}

export enum MissionType {
  ISR = 'ISR',
  STRIKE = 'STRIKE',
  LOGISTICS = 'LOGISTICS',
  ELECTRONIC_WARFARE = 'ELECTRONIC_WARFARE',
  RELAY_COMMS = 'RELAY_COMMS',
  SWARM_OPS = 'SWARM_OPS',
  CBRN_SURVEY = 'CBRN_SURVEY',
  MINE_COUNTERMEASURES = 'MINE_COUNTERMEASURES',
  PERSISTENT_SURVEILLANCE = 'PERSISTENT_SURVEILLANCE',
  SEARCH_AND_RESCUE = 'SEARCH_AND_RESCUE',
  CASEVAC = 'CASEVAC',
}

export enum ThreatType {
  SAM = 'SAM',
  AAA = 'AAA',
  MANPADS = 'MANPADS',
  EW_JAMMER = 'EW_JAMMER',
  COUNTER_UAS = 'COUNTER_UAS',
  HOSTILE_DRONE = 'HOSTILE_DRONE',
  SMALL_ARMS = 'SMALL_ARMS',
  CYBER = 'CYBER',
  GPS_SPOOFING = 'GPS_SPOOFING',
  UNKNOWN = 'UNKNOWN',
}

export enum ArmingState {
  SAFE = 'SAFE',
  MASTER_ARM_ON = 'MASTER_ARM_ON',
  SEEKER_ACTIVE = 'SEEKER_ACTIVE',
  LOCKED = 'LOCKED',
  RELEASED = 'RELEASED',
}

export enum AutonomyLevel {
  FULL = 'FULL',
  SUPERVISED = 'SUPERVISED',
  MANUAL = 'MANUAL',
}

export enum SensorType {
  EO = 'EO',
  IR = 'IR',
  SAR = 'SAR',
  LIDAR = 'LIDAR',
  SIGINT = 'SIGINT',
  AIS = 'AIS',
}

export enum JamBand {
  GPS_L1 = 'GPS_L1',
  GPS_L2 = 'GPS_L2',
  VHF = 'VHF',
  UHF = 'UHF',
  X_BAND = 'X_BAND',
  KU_BAND = 'KU_BAND',
}

export interface GeoPosition {
  lat: number;
  lon: number;
  alt: number;
  mgrs?: string;
}

export interface Waypoint {
  index: number;
  position: GeoPosition;
  action: 'FLY_TO' | 'LOITER' | 'SURVEY' | 'DELIVER' | 'RETURN' | 'LAND';
  loiterDurationSec?: number;
  speedKnots?: number;
  altitudeOverride?: number;
  reached: boolean;
  reachedAt?: string;
}

export interface Drone {
  droneId: string;
  callsign: string;
  droneClass: DroneClass;
  model: string;
  manufacturer: string;
  serialNumber: string;
  status: DroneStatus;
  health: number;
  batteryPercent: number;
  fuelPercent: number;
  position: GeoPosition;
  heading: number;
  speedKnots: number;
  altitude: number;
  linkQuality: number;
  currentMissionId: string | null;
  htsTokenId: string | null;
  htsSerialNumber: number | null;
  createdAt: string;
  updatedAt: string;
  typeMetrics: Record<string, unknown>;
}

export interface Mission {
  missionId: string;
  name: string;
  type: MissionType;
  status: MissionStatus;
  commanderId: string;
  commanderCallsign: string;
  description: string;
  areaOfOperations: GeoJSON.Polygon | null;
  waypoints: Waypoint[];
  assignedDroneIds: string[];
  hcsTopicId: string | null;
  aiAssessmentId: string | null;
  plannedStartTime: string;
  plannedEndTime: string;
  actualStartTime: string | null;
  actualEndTime: string | null;
  clearanceLevel: ClearanceLevel;
  createdAt: string;
  updatedAt: string;
}

export interface HCSMessage {
  sequenceNumber: number;
  consensusTimestamp: string;
  topicId: string;
  transactionId: string;
  droneId: string;
  actionType: ActionType;
  operatorId: string;
  missionId: string;
  aiConfidence: number | null;
  payload: Record<string, unknown>;
  complianceLog: string;
}

export interface Telemetry {
  time: string;
  droneId: string;
  position: GeoPosition;
  heading: number;
  speedKnots: number;
  altitude: number;
  batteryPercent: number;
  fuelPercent: number;
  health: number;
  linkQuality: number;
  satelliteCount: number;
  ambientTempC: number;
  windSpeedMs: number;
  windDirection: number;
  vibrationLevel: number;
  cpuTempC: number;
  memoryUsagePercent: number;
  classSpecific: Record<string, unknown>;
  status?: string;
  currentMissionId?: string | null;
}

export interface AIAssessment {
  assessmentId: string;
  missionId: string;
  recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
  confidence: number;
  riskScore: number;
  reasoning: string;
  riskFactors: RiskFactor[];
  mitigations: string[];
  weatherData: WeatherData | null;
  airspaceData: AirspaceData | null;
  threatData: ThreatIntel | null;
  fleetStatus: FleetDroneStatus[];
  modelVersion: string;
  assessedAt: string;
  hcsTransactionId: string | null;
}

export interface RiskFactor {
  category: 'WEATHER' | 'AIRSPACE' | 'THREAT' | 'FLEET' | 'TERRAIN' | 'POLITICAL' | 'COMMS';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
  score: number;
}

export interface WeatherData {
  lat: number;
  lon: number;
  tempC: number;
  humidity: number;
  windSpeedMs: number;
  windDirection: number;
  visibilityM: number;
  cloudCoverPercent: number;
  weatherCondition: string;
  thunderstorm: boolean;
  precipitationMm: number;
  fetchedAt: string;
}

export interface AirspaceData {
  lat: number;
  lon: number;
  activeTFRs: TemporaryFlightRestriction[];
  activeNOTAMs: NOTAM[];
  adsbContacts: ADSBContact[];
  fetchedAt: string;
}

export interface TemporaryFlightRestriction {
  tfrId: string;
  type: 'SECURITY' | 'HAZARD' | 'VIP' | 'MILITARY';
  center: GeoPosition;
  radiusKm: number;
  floorFt: number;
  ceilingFt: number;
  startTime: string;
  endTime: string;
  exemptionHeld: boolean;
}

export interface NOTAM {
  notamId: string;
  type: string;
  description: string;
  affectedArea: string;
  effectiveFrom: string;
  effectiveTo: string;
}

export interface ADSBContact {
  icao24: string;
  callsign: string;
  altitudeFt: number;
  speedKnots: number;
  heading: number;
  position: GeoPosition;
  verticalRate: number;
  squawk: string;
  onGround: boolean;
}

export interface ThreatIntel {
  threats: Threat[];
  overallThreatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  fetchedAt: string;
}

export interface Threat {
  threatId: string;
  type: ThreatType;
  position: GeoPosition;
  radiusKm: number;
  confidence: number;
  hostileUnitId: string;
  description: string;
  firstDetected: string;
  lastUpdated: string;
  active: boolean;
}

export interface FleetDroneStatus {
  droneId: string;
  callsign: string;
  droneClass: DroneClass;
  status: DroneStatus;
  health: number;
  batteryPercent: number;
  fuelPercent: number;
  position: GeoPosition;
  linkQuality: number;
  available: boolean;
}

export interface Operator {
  operatorId: string;
  username: string;
  callsign: string;
  role: OperatorRole;
  clearanceLevel: ClearanceLevel;
  email: string;
  mfaEnabled: boolean;
  mfaSecret: string | null;
  passwordHash: string;
  active: boolean;
  lastLogin: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface OperatorSession {
  sessionId: string;
  operatorId: string;
  tokenHash: string;
  ipAddress: string;
  userAgent: string;
  issuedAt: string;
  expiresAt: string;
  mfaVerifiedAt: string | null;
  revoked: boolean;
}

export interface MissionContext {
  mission: Mission;
  assignedDrones: FleetDroneStatus[];
  weatherData: WeatherData | null;
  airspaceData: AirspaceData | null;
  threatData: ThreatIntel | null;
  operatorClearance: ClearanceLevel;
  commanderCallsign: string;
}

export interface NoFlyZone {
  zoneId: string;
  name: string;
  polygon: GeoJSON.Polygon;
  floorFt: number;
  ceilingFt: number;
  permanent: boolean;
  activeFrom: string | null;
  activeTo: string | null;
  reason: string;
}

export interface AuditLogEntry {
  auditId: string;
  tableName: string;
  recordId: string;
  action: 'INSERT' | 'UPDATE' | 'DELETE';
  oldData: Record<string, unknown> | null;
  newData: Record<string, unknown> | null;
  operatorId: string | null;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
}

export interface LoginRequest {
  username: string;
  password: string;
  totpCode?: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  operator: Omit<Operator, 'passwordHash' | 'mfaSecret'>;
  mfaRequired: boolean;
}

export interface DroneCommandRequest {
  command: 'LAUNCH' | 'LAND' | 'RTB' | 'HOLD_POSITION' | 'GOTO_WAYPOINT' | 'EMERGENCY_STOP' | 'ARM' | 'DISARM' | 'ACTIVATE_SENSOR' | 'DEACTIVATE_SENSOR' | 'JAM_START' | 'JAM_STOP' | 'PAYLOAD_DROP' | 'SWARM_JOIN' | 'SWARM_LEAVE';
  parameters?: Record<string, unknown>;
  mfaCode?: string;
}

export interface CreateMissionRequest {
  name: string;
  type: MissionType;
  description: string;
  areaOfOperations: GeoJSON.Polygon | null;
  waypoints: Omit<Waypoint, 'reached' | 'reachedAt'>[];
  assignedDroneIds: string[];
  plannedStartTime: string;
  plannedEndTime: string;
  clearanceLevel: ClearanceLevel;
}

export namespace GeoJSON {
  export interface Polygon {
    type: 'Polygon';
    coordinates: number[][][];
  }
  export interface Point {
    type: 'Point';
    coordinates: [number, number];
  }
}

export const ROLE_HIERARCHY: Record<OperatorRole, number> = {
  [OperatorRole.SUPER_ADMIN]: 100,
  [OperatorRole.MISSION_COMMANDER]: 80,
  [OperatorRole.OPERATOR]: 60,
  [OperatorRole.ANALYST]: 40,
  [OperatorRole.AI_SYSTEM]: 50,
  [OperatorRole.AUDITOR]: 30,
  [OperatorRole.GUEST]: 10,
};

export const ROLE_PERMISSIONS: Record<OperatorRole, string[]> = {
  [OperatorRole.SUPER_ADMIN]: [
    'mission:create', 'mission:approve', 'mission:abort', 'mission:override',
    'drone:command', 'drone:register', 'drone:decommission',
    'operator:manage', 'log:read', 'intel:read', 'fleet:manage',
  ],
  [OperatorRole.MISSION_COMMANDER]: [
    'mission:create', 'mission:approve', 'mission:abort', 'mission:override',
    'drone:command', 'log:read', 'intel:read',
  ],
  [OperatorRole.OPERATOR]: [
    'mission:create', 'drone:command', 'log:read', 'intel:read',
  ],
  [OperatorRole.ANALYST]: [
    'log:read', 'intel:read',
  ],
  [OperatorRole.AI_SYSTEM]: [
    'mission:assess', 'log:read', 'intel:read', 'drone:query',
  ],
  [OperatorRole.AUDITOR]: [
    'log:read',
  ],
  [OperatorRole.GUEST]: [],
};

export const CRITICAL_COMMANDS = new Set<string>([
  'ARM', 'WEAPON_RELEASED', 'EMERGENCY_STOP', 'MISSION_ABORT', 'AI_OVERRIDE',
]);

export function zuluTimestamp(): string {
  return new Date().toISOString().replace('T', ' ').replace(/\.\d{3}Z$/, 'Z');
}

export function formatComplianceLog(msg: Omit<HCSMessage, 'complianceLog'>): string {
  return `[${msg.consensusTimestamp}] [${msg.droneId}] [${msg.actionType}] [SEQ:${msg.sequenceNumber}] [${msg.operatorId}] [${msg.missionId}] [AI_CONF:${msg.aiConfidence ?? 'N/A'}] [${msg.topicId}]`;
}
