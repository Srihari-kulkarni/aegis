import { logger } from '../../logger';
import { redis, redisPub } from '../../redis';
import { zuluTimestamp, type GeoPosition, type Threat } from '@aegis/shared';
import { GeneticEngine } from './genetic-engine';
import type { RefinementRecord, RouteFitness, GPGenerationReport, GPConfig } from './types';
import { v4 as uuidv4 } from 'uuid';

const ROUTING_LOG_KEY = 'ri:routing:refinement_log';
const ROUTING_CONFIG_KEY = 'ri:routing:gp_config';
const ROUTING_BEST_KEY = 'ri:routing:best_routes';

interface RouteOptimizationRequest {
  missionId: string;
  origin: GeoPosition;
  destination: GeoPosition;
  currentWaypoints: GeoPosition[];
  threats: Threat[];
  terrainData: Array<{ position: GeoPosition; elevationM: number; canMask: boolean }>;
  maxFlightTimeMin: number;
  cruiseSpeedKnots: number;
  fuelCapacityPercent: number;
}

export interface OptimizationResult {
  missionId: string;
  originalFitness: RouteFitness;
  optimizedFitness: RouteFitness;
  optimizedRoute: GeoPosition[];
  improvement: number;
  generations: number;
  accepted: boolean;
  reason: string;
  reports: GPGenerationReport[];
}

export class WaypointOptimizer {
  private engine: GeneticEngine;
  private refinementLog: RefinementRecord[] = [];
  private currentIteration = 0;
  private bestRoutes = new Map<string, { route: GeoPosition[]; fitness: number }>();

  constructor() {
    this.engine = new GeneticEngine();
  }

  async initialize(): Promise<void> {
    try {
      const configData = await redis.get(ROUTING_CONFIG_KEY);
      if (configData) {
        const config = JSON.parse(configData) as Partial<GPConfig>;
        this.engine.setConfig(config);
      }

      const logData = await redis.get(ROUTING_LOG_KEY);
      if (logData) {
        this.refinementLog = JSON.parse(logData) as RefinementRecord[];
        this.currentIteration = this.refinementLog.length;
      }

      const bestData = await redis.get(ROUTING_BEST_KEY);
      if (bestData) {
        const parsed = JSON.parse(bestData) as Array<{ id: string; route: GeoPosition[]; fitness: number }>;
        for (const entry of parsed) {
          this.bestRoutes.set(entry.id, { route: entry.route, fitness: entry.fitness });
        }
      }

      logger.info({
        iteration: this.currentIteration,
        cachedRoutes: this.bestRoutes.size,
      }, 'WaypointOptimizer initialized');
    } catch (err) {
      logger.warn({ err }, 'WaypointOptimizer initialization failed');
    }
  }

  async optimizeRoute(request: RouteOptimizationRequest): Promise<OptimizationResult> {
    const startMs = Date.now();
    this.currentIteration++;

    const context = {
      origin: request.origin,
      destination: request.destination,
      threats: request.threats,
      terrain: request.terrainData,
      maxFlightTimeMin: request.maxFlightTimeMin,
      cruiseSpeedKnots: request.cruiseSpeedKnots,
      fuelCapacityPercent: request.fuelCapacityPercent,
    };

    const originalFitness = this.engine.computeFitness(request.currentWaypoints, context);

    logger.info({
      missionId: request.missionId,
      originalFitness: originalFitness.total.toFixed(4),
      waypoints: request.currentWaypoints.length,
      threats: request.threats.length,
    }, 'Starting GP route optimization');

    const bestGene = this.engine.evolve(context, request.currentWaypoints);
    const optimizedFitness = this.engine.computeFitness(bestGene.waypoints, context);
    const improvement = optimizedFitness.total - originalFitness.total;

    const accepted = improvement > 0.02;

    const result: OptimizationResult = {
      missionId: request.missionId,
      originalFitness,
      optimizedFitness,
      optimizedRoute: bestGene.waypoints,
      improvement,
      generations: bestGene.generation,
      accepted,
      reason: accepted
        ? `Route improved by ${(improvement * 100).toFixed(1)}%: fuel ${(optimizedFitness.fuelEfficiency * 100).toFixed(0)}%, threat avoidance ${(optimizedFitness.threatExposure * 100).toFixed(0)}%, terrain masking ${(optimizedFitness.terrainMasking * 100).toFixed(0)}%`
        : `Improvement ${(improvement * 100).toFixed(1)}% below 2% threshold — keeping original route`,
      reports: this.engine.reports,
    };

    if (accepted) {
      this.bestRoutes.set(request.missionId, {
        route: bestGene.waypoints,
        fitness: optimizedFitness.total,
      });
      await this.persistBestRoutes();
    }

    const record: RefinementRecord = {
      iterationId: uuidv4(),
      iteration: this.currentIteration,
      timestamp: zuluTimestamp(),
      layer: 'ROUTING',
      previousVersion: `Route: ${request.currentWaypoints.length} WPs, fitness=${originalFitness.total.toFixed(4)}`,
      candidateVersion: `Route: ${bestGene.waypoints.length} WPs, fitness=${optimizedFitness.total.toFixed(4)}`,
      accepted,
      reason: result.reason,
      metrics: {
        successRate: accepted ? 1 : 0,
        avgIterationsToFix: bestGene.generation,
        riskScoreDelta: improvement,
        predictionAccuracy: optimizedFitness.total,
        latencyMs: Date.now() - startMs,
      },
    };

    this.refinementLog.push(record);
    if (this.refinementLog.length > 100) {
      this.refinementLog = this.refinementLog.slice(-100);
    }
    await redis.set(ROUTING_LOG_KEY, JSON.stringify(this.refinementLog));

    await redisPub.publish('ri:refinement', JSON.stringify({
      layer: 'ROUTING',
      missionId: request.missionId,
      iteration: this.currentIteration,
      accepted,
      improvement: improvement,
      originalFitness: originalFitness.total,
      optimizedFitness: optimizedFitness.total,
      generations: bestGene.generation,
      timestamp: zuluTimestamp(),
    }));

    logger.info({
      missionId: request.missionId,
      improvement: (improvement * 100).toFixed(1) + '%',
      accepted,
      generations: bestGene.generation,
      latencyMs: Date.now() - startMs,
    }, 'GP route optimization complete');

    return result;
  }

  getBestRoute(missionId: string): { route: GeoPosition[]; fitness: number } | undefined {
    return this.bestRoutes.get(missionId);
  }

  async updateGPConfig(config: Partial<GPConfig>): Promise<void> {
    this.engine.setConfig(config);
    await redis.set(ROUTING_CONFIG_KEY, JSON.stringify(this.engine.currentConfig));
    logger.info({ config }, 'GP configuration updated');
  }

  private async persistBestRoutes(): Promise<void> {
    const entries = Array.from(this.bestRoutes.entries()).map(([id, data]) => ({ id, ...data }));
    const recent = entries.slice(-50);
    await redis.set(ROUTING_BEST_KEY, JSON.stringify(recent));
  }

  getStatus(): { active: boolean; currentVersion: number; totalIterations: number; lastImprovement: string | null; accuracy: number; pendingApproval: boolean } {
    const lastAccepted = this.refinementLog.filter((r) => r.accepted).pop();
    return {
      active: true,
      currentVersion: this.currentIteration,
      totalIterations: this.currentIteration,
      lastImprovement: lastAccepted?.timestamp ?? null,
      accuracy: lastAccepted?.metrics.predictionAccuracy ?? 0.5,
      pendingApproval: this.refinementLog.some((r) => r.accepted && r.layer === 'ROUTING'),
    };
  }

  get history(): RefinementRecord[] { return [...this.refinementLog]; }
  get gpConfig(): GPConfig { return this.engine.currentConfig; }
}

export const waypointOptimizer = new WaypointOptimizer();
