import { redis, redisPub } from '../redis';
import { query } from '../db/pool';
import { hcsService } from '../hedera/HCSService';
import { logger } from '../logger';
import { link16Gateway } from '../services/Link16GatewayService';
import {
  DroneStatus,
  ActionType,
  Telemetry,
  GeoPosition,
  zuluTimestamp,
  STRIKE_PACKAGE,
  AircraftClass,
  MissionRole,
  Link16Role,
  CECProfile,
  TxAuthLevel,
  WeaponLoadout,
  JMessageType,
  IFFIdentity,
} from '@aegis/shared';

// ─── Internal Types ──────────────────────────────────────────────────────────

interface SimulatedAircraft {
  aircraftId: string;
  callsign: string;
  platform: AircraftClass;
  missionRole: MissionRole;
  status: DroneStatus;
  position: GeoPosition;
  heading: number;
  speedKnots: number;
  altitude: number;
  fuelPercent: number;
  fuelCapacityLbs: number;
  health: number;
  linkQuality: number;
  link16Role: Link16Role;
  cecProfile: CECProfile;
  txAuthority: TxAuthLevel;
  weapons: WeaponLoadout[];
  currentMissionId: string | null;
  hcsTopicId: string | null;
  waypointIndex: number;
  waypoints: GeoPosition[];
}

interface FaultScenario {
  type: 'LINK_DEGRADATION' | 'FUEL_LEAK' | 'HEALTH_DROP' | 'GPS_DRIFT';
  probability: number;
  severity: number;
}

// ─── Flight Profile & Fuel Constants ─────────────────────────────────────────

interface FlightProfile {
  cruiseSpeedKts: number;
  ceilingFt: number;
  cruiseAltFt: number;
  speedVariance: number;
  patternType: 'oval' | 'racetrack' | 'patrol' | 'figure8' | 'linear' | 'tanker_orbit';
  patternSpreadDeg: number;
}

const FLIGHT_PROFILES: Record<AircraftClass, FlightProfile> = {
  [AircraftClass.B2_SPIRIT]:       { cruiseSpeedKts: 475, ceilingFt: 50000, cruiseAltFt: 45000, speedVariance: 15, patternType: 'oval',         patternSpreadDeg: 0.5  },
  [AircraftClass.E3_SENTRY]:       { cruiseSpeedKts: 320, ceilingFt: 35000, cruiseAltFt: 32000, speedVariance: 10, patternType: 'racetrack',    patternSpreadDeg: 0.3  },
  [AircraftClass.F35A]:            { cruiseSpeedKts: 550, ceilingFt: 50000, cruiseAltFt: 35000, speedVariance: 25, patternType: 'patrol',       patternSpreadDeg: 0.15 },
  [AircraftClass.F35B]:            { cruiseSpeedKts: 550, ceilingFt: 50000, cruiseAltFt: 33000, speedVariance: 25, patternType: 'patrol',       patternSpreadDeg: 0.15 },
  [AircraftClass.MQ9_REAPER]:      { cruiseSpeedKts: 180, ceilingFt: 40000, cruiseAltFt: 25000, speedVariance: 8,  patternType: 'figure8',      patternSpreadDeg: 0.08 },
  [AircraftClass.C17_GLOBEMASTER]: { cruiseSpeedKts: 450, ceilingFt: 28000, cruiseAltFt: 24000, speedVariance: 12, patternType: 'linear',       patternSpreadDeg: 0.6  },
  [AircraftClass.KC46_PEGASUS]:    { cruiseSpeedKts: 460, ceilingFt: 43000, cruiseAltFt: 30000, speedVariance: 10, patternType: 'tanker_orbit', patternSpreadDeg: 0.25 },
};

const FUEL_CAPACITY_LBS: Record<AircraftClass, number> = {
  [AircraftClass.B2_SPIRIT]:       167000,
  [AircraftClass.E3_SENTRY]:       152000,
  [AircraftClass.F35A]:            18480,
  [AircraftClass.F35B]:            13326,
  [AircraftClass.MQ9_REAPER]:      3900,
  [AircraftClass.C17_GLOBEMASTER]: 181054,
  [AircraftClass.KC46_PEGASUS]:    212300,
};

const FUEL_BURN_PER_TICK: Record<AircraftClass, number> = {
  [AircraftClass.B2_SPIRIT]:       0.0030,
  [AircraftClass.E3_SENTRY]:       0.0027,
  [AircraftClass.F35A]:            0.0150,
  [AircraftClass.F35B]:            0.0230,
  [AircraftClass.MQ9_REAPER]:      0.0028,
  [AircraftClass.C17_GLOBEMASTER]: 0.0060,
  [AircraftClass.KC46_PEGASUS]:    0.0040,
};

// ─── Operational Area ────────────────────────────────────────────────────────

const OPS_CENTER = { lat: 34.0, lon: 132.0 };

const STARTING_OFFSETS: Record<string, { dLat: number; dLon: number; altFt: number }> = {
  'GHOST-01':   { dLat: -0.30, dLon: -0.40, altFt: 45000 },
  'SENTRY-01':  { dLat:  0.20, dLon: -0.30, altFt: 32000 },
  'VIPER-01':   { dLat:  0.10, dLon:  0.10, altFt: 35000 },
  'VIPER-02':   { dLat:  0.05, dLon:  0.15, altFt: 36000 },
  'VIPER-03':   { dLat: -0.05, dLon:  0.12, altFt: 33000 },
  'REAPER-01':  { dLat:  0.15, dLon:  0.25, altFt: 25000 },
  'REAPER-02':  { dLat: -0.10, dLon:  0.30, altFt: 22000 },
  'ATLAS-01':   { dLat:  0.40, dLon: -0.50, altFt: 24000 },
  'PEGASUS-01': { dLat:  0.25, dLon: -0.20, altFt: 30000 },
  'PEGASUS-02': { dLat: -0.20, dLon: -0.25, altFt: 31000 },
};

// ─── Fault Injection ─────────────────────────────────────────────────────────

const FAULTS: FaultScenario[] = [
  { type: 'LINK_DEGRADATION', probability: 0.020, severity: 0.25 },
  { type: 'FUEL_LEAK',        probability: 0.008, severity: 0.10 },
  { type: 'HEALTH_DROP',      probability: 0.010, severity: 0.15 },
  { type: 'GPS_DRIFT',        probability: 0.015, severity: 0.08 },
];

// ─── Telemetry Simulator ────────────────────────────────────────────────────

export class TelemetrySimulator {
  private aircraft: Map<string, SimulatedAircraft> = new Map();
  private telemetryInterval: ReturnType<typeof setInterval> | null = null;
  private hcsInterval: ReturnType<typeof setInterval> | null = null;
  private ppliInterval: ReturnType<typeof setInterval> | null = null;
  private running = false;

  // ═══════════════════════════════════════════════════════════════════════════
  //  Initialization — DB persistence with STRIKE_PACKAGE in-memory fallback
  // ═══════════════════════════════════════════════════════════════════════════

  async initialize(): Promise<void> {
    let dbRows: Array<{
      drone_id: string; callsign: string; status: DroneStatus;
      position_lat: number; position_lon: number; position_alt: number;
      heading: number; speed_knots: number; altitude: number;
      fuel_percent: number; health: number; link_quality: number;
      current_mission: string | null;
    }> = [];

    try {
      const result = await query<(typeof dbRows)[0]>(
        'SELECT * FROM drones WHERE status != $1 AND status != $2',
        [DroneStatus.DESTROYED, DroneStatus.DECOMMISSIONED],
      );
      const strikeCallsigns = new Set(STRIKE_PACKAGE.map((s) => s.callsign));
      dbRows = result.rows.filter((r) => strikeCallsigns.has(r.callsign));
    } catch {
      // DB unavailable — pure in-memory demo mode
    }

    const rows = dbRows.length > 0
      ? dbRows
      : STRIKE_PACKAGE.map((spec) => {
          const off = STARTING_OFFSETS[spec.callsign] ?? { dLat: 0, dLon: 0, altFt: 30000 };
          const profile = FLIGHT_PROFILES[spec.platform];
          return {
            drone_id: spec.callsign,
            callsign: spec.callsign,
            status: DroneStatus.AIRBORNE as DroneStatus,
            position_lat: OPS_CENTER.lat + off.dLat,
            position_lon: OPS_CENTER.lon + off.dLon,
            position_alt: off.altFt,
            heading: Math.random() * 360,
            speed_knots: profile.cruiseSpeedKts,
            altitude: off.altFt,
            fuel_percent: 75 + Math.random() * 20,
            health: 0.90 + Math.random() * 0.10,
            link_quality: spec.txAuthority === TxAuthLevel.SILENT
              ? 0.60 + Math.random() * 0.15
              : 0.90 + Math.random() * 0.10,
            current_mission: null,
          };
        });

    for (const row of rows) {
      const spec = STRIKE_PACKAGE.find((s) => s.callsign === row.callsign);
      if (!spec) continue;

      const profile = FLIGHT_PROFILES[spec.platform];
      const origin: GeoPosition = { lat: row.position_lat, lon: row.position_lon, alt: row.position_alt };

      const ac: SimulatedAircraft = {
        aircraftId: row.drone_id,
        callsign: row.callsign,
        platform: spec.platform,
        missionRole: spec.role,
        status: row.status === DroneStatus.STANDBY ? DroneStatus.AIRBORNE : row.status,
        position: origin,
        heading: row.heading || Math.random() * 360,
        speedKnots: row.speed_knots || profile.cruiseSpeedKts,
        altitude: row.altitude || profile.cruiseAltFt,
        fuelPercent: parseFloat(row.fuel_percent.toString()),
        fuelCapacityLbs: FUEL_CAPACITY_LBS[spec.platform],
        health: parseFloat(row.health.toString()),
        linkQuality: parseFloat(row.link_quality.toString()),
        link16Role: spec.link16Role,
        cecProfile: spec.cecProfile,
        txAuthority: spec.txAuthority,
        weapons: spec.weapons.map((w) => ({ ...w })),
        currentMissionId: row.current_mission,
        hcsTopicId: null,
        waypointIndex: 0,
        waypoints: this.generatePatternWaypoints(origin, spec.platform),
      };

      this.aircraft.set(ac.aircraftId, ac);

      await redis.hset(`drone:live:${ac.aircraftId}`, {
        droneId: ac.aircraftId,
        callsign: ac.callsign,
        platform: ac.platform,
        missionRole: ac.missionRole,
        droneClass: ac.platform,
        status: ac.status,
        health: ac.health.toString(),
        batteryPercent: '100',
        fuelPercent: ac.fuelPercent.toString(),
        fuelCapacityLbs: ac.fuelCapacityLbs.toString(),
        lat: ac.position.lat.toString(),
        lon: ac.position.lon.toString(),
        alt: ac.position.alt.toString(),
        heading: ac.heading.toString(),
        speedKnots: ac.speedKnots.toString(),
        altitude: ac.altitude.toString(),
        linkQuality: ac.linkQuality.toString(),
        link16Role: ac.link16Role,
        cecProfile: ac.cecProfile,
        txAuthority: ac.txAuthority,
        currentMissionId: ac.currentMissionId ?? '',
        updatedAt: zuluTimestamp(),
      });
      await redis.expire(`drone:live:${ac.aircraftId}`, 300);
      await redis.set(`drone:status:${ac.aircraftId}`, ac.status, 'EX', 300);
    }

    logger.info({ aircraftCount: this.aircraft.size }, 'Telemetry simulator initialized with STRIKE_PACKAGE');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Start / Stop
  // ═══════════════════════════════════════════════════════════════════════════

  start(): void {
    if (this.running) return;
    this.running = true;

    this.telemetryInterval = setInterval(() => {
      this.updateAllAircraft().catch((err) => {
        logger.error({ err }, 'Telemetry simulator tick error');
      });
    }, 2000);

    this.ppliInterval = setInterval(() => {
      this.emitPPLI();
    }, 12000);

    this.hcsInterval = setInterval(() => {
      this.submitHCSUpdates().catch((err) => {
        logger.error({ err }, 'HCS telemetry submission error');
      });
    }, 60000);

    logger.info('Telemetry simulator started (2s telemetry, 12s PPLI, 60s HCS)');
  }

  stop(): void {
    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }
    if (this.ppliInterval) {
      clearInterval(this.ppliInterval);
      this.ppliInterval = null;
    }
    if (this.hcsInterval) {
      clearInterval(this.hcsInterval);
      this.hcsInterval = null;
    }
    this.running = false;
    logger.info('Telemetry simulator stopped');
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Core Tick — movement, fuel, faults, telemetry emit
  // ═══════════════════════════════════════════════════════════════════════════

  private async updateAllAircraft(): Promise<void> {
    for (const [id, ac] of this.aircraft) {
      if (
        ac.status === DroneStatus.DESTROYED ||
        ac.status === DroneStatus.DECOMMISSIONED ||
        ac.status === DroneStatus.MAINTENANCE
      ) {
        continue;
      }

      this.simulateMovement(ac);
      this.simulateFuelConsumption(ac);
      this.injectFaults(ac);

      const telemetry = this.buildTelemetry(ac);

      await redis.hset(`drone:live:${id}`, {
        status: ac.status,
        health: ac.health.toFixed(3),
        fuelPercent: ac.fuelPercent.toFixed(2),
        lat: ac.position.lat.toFixed(8),
        lon: ac.position.lon.toFixed(8),
        alt: ac.position.alt.toFixed(1),
        heading: ac.heading.toFixed(1),
        speedKnots: ac.speedKnots.toFixed(1),
        altitude: ac.altitude.toFixed(0),
        linkQuality: ac.linkQuality.toFixed(3),
        currentMissionId: ac.currentMissionId ?? '',
        updatedAt: zuluTimestamp(),
      });
      await redis.expire(`drone:live:${id}`, 300);

      await redisPub.publish(`telemetry:${id}`, JSON.stringify(telemetry));
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Movement — platform-specific flight models
  // ═══════════════════════════════════════════════════════════════════════════

  private simulateMovement(ac: SimulatedAircraft): void {
    const profile = FLIGHT_PROFILES[ac.platform];

    if (ac.waypoints.length === 0) {
      ac.heading = (ac.heading + (Math.random() - 0.5) * 5) % 360;
      if (ac.heading < 0) ac.heading += 360;
    } else {
      const target = ac.waypoints[ac.waypointIndex];
      const dLat = target.lat - ac.position.lat;
      const dLon = target.lon - ac.position.lon;
      const bearing = Math.atan2(dLon, dLat) * (180 / Math.PI);
      ac.heading = (bearing + 360) % 360;

      const dist = Math.sqrt(dLat * dLat + dLon * dLon);
      if (dist < 0.005) {
        ac.waypointIndex = (ac.waypointIndex + 1) % ac.waypoints.length;
      }
    }

    // Position update — 2-second tick
    const speedDeg = (ac.speedKnots / 3600) * (1 / 60) * 2.0;
    const headingRad = ac.heading * (Math.PI / 180);
    ac.position.lat += speedDeg * Math.cos(headingRad) + (Math.random() - 0.5) * 0.00002;
    ac.position.lon += speedDeg * Math.sin(headingRad) + (Math.random() - 0.5) * 0.00002;

    // Altitude hold toward cruise
    ac.altitude += (profile.cruiseAltFt - ac.altitude) * 0.02 + (Math.random() - 0.5) * 20;
    ac.position.alt = ac.altitude;

    // Speed variance around cruise
    ac.speedKnots += (Math.random() - 0.5) * profile.speedVariance * 0.1;
    ac.speedKnots = Math.max(
      profile.cruiseSpeedKts * 0.85,
      Math.min(profile.cruiseSpeedKts * 1.1, ac.speedKnots),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Fuel Consumption
  // ═══════════════════════════════════════════════════════════════════════════

  private simulateFuelConsumption(ac: SimulatedAircraft): void {
    const burnRate = FUEL_BURN_PER_TICK[ac.platform];
    ac.fuelPercent = Math.max(0, ac.fuelPercent - burnRate + (Math.random() - 0.5) * burnRate * 0.1);

    if (ac.fuelPercent < 5) {
      ac.status = DroneStatus.EMERGENCY;
    } else if (ac.fuelPercent < 15 && ac.status === DroneStatus.AIRBORNE) {
      ac.status = DroneStatus.RETURNING;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Fault Injection
  // ═══════════════════════════════════════════════════════════════════════════

  private injectFaults(ac: SimulatedAircraft): void {
    for (const fault of FAULTS) {
      if (Math.random() >= fault.probability) continue;

      switch (fault.type) {
        case 'LINK_DEGRADATION':
          if (ac.txAuthority === TxAuthLevel.SILENT) break;
          ac.linkQuality = Math.max(0.1, ac.linkQuality - fault.severity * Math.random());
          if (ac.linkQuality < 0.3) ac.status = DroneStatus.LOST_LINK;
          break;
        case 'FUEL_LEAK':
          ac.fuelPercent = Math.max(0, ac.fuelPercent - fault.severity * 100 * Math.random());
          break;
        case 'HEALTH_DROP':
          ac.health = Math.max(0.1, ac.health - fault.severity * Math.random());
          if (ac.health < 0.3) ac.status = DroneStatus.EMERGENCY;
          break;
        case 'GPS_DRIFT':
          ac.position.lat += (Math.random() - 0.5) * 0.001 * fault.severity;
          ac.position.lon += (Math.random() - 0.5) * 0.001 * fault.severity;
          break;
      }
    }

    // Link quality recovery tendency
    if (ac.linkQuality < 1.0 && ac.txAuthority !== TxAuthLevel.SILENT && Math.random() > 0.7) {
      ac.linkQuality = Math.min(1.0, ac.linkQuality + 0.05);
      if (ac.linkQuality >= 0.5 && ac.status === DroneStatus.LOST_LINK) {
        ac.status = DroneStatus.AIRBORNE;
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Telemetry Build — maps to shared Telemetry type with classSpecific
  // ═══════════════════════════════════════════════════════════════════════════

  private buildTelemetry(ac: SimulatedAircraft): Telemetry {
    const isEMCON = ac.txAuthority === TxAuthLevel.SILENT;

    const classSpecific: Record<string, unknown> = {
      callsign: ac.callsign,
      platform: ac.platform,
      missionRole: ac.missionRole,
      link16Role: ac.link16Role,
      cecProfile: ac.cecProfile,
      txAuthority: ac.txAuthority,
      fuelCapacityLbs: ac.fuelCapacityLbs,
      fuelRemainingLbs: Math.round((ac.fuelCapacityLbs * ac.fuelPercent) / 100),
      weapons: ac.weapons,
      totalOrdnance: ac.weapons.reduce((sum, w) => sum + w.quantity, 0),
    };

    if (isEMCON) {
      classSpecific.dataSource = 'MADL';
      classSpecific.positionConfidence = 0.55 + Math.random() * 0.25;
      classSpecific.emconActive = true;
    } else {
      classSpecific.dataSource = 'LINK16_PPLI';
      classSpecific.positionConfidence = 0.95 + Math.random() * 0.05;
      classSpecific.emconActive = false;
    }

    return {
      time: new Date().toISOString(),
      droneId: ac.aircraftId,
      position: { ...ac.position },
      heading: ac.heading,
      speedKnots: ac.speedKnots,
      altitude: ac.altitude,
      batteryPercent: 100,
      fuelPercent: ac.fuelPercent,
      health: ac.health,
      linkQuality: ac.linkQuality,
      satelliteCount: 10 + Math.floor(Math.random() * 6),
      ambientTempC: -40 + Math.random() * 20,
      windSpeedMs: 5 + Math.random() * 25,
      windDirection: Math.random() * 360,
      vibrationLevel: Math.random() * 0.15,
      cpuTempC: 40 + Math.random() * 20,
      memoryUsagePercent: 25 + Math.random() * 35,
      classSpecific,
      status: ac.status,
      currentMissionId: ac.currentMissionId,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  J2.2 PPLI Generation — every 12s for transmit-capable aircraft
  // ═══════════════════════════════════════════════════════════════════════════

  private emitPPLI(): void {
    for (const [, ac] of this.aircraft) {
      if (ac.status === DroneStatus.DESTROYED || ac.status === DroneStatus.DECOMMISSIONED) continue;

      if (ac.txAuthority === TxAuthLevel.SILENT) continue;

      const ppliData = {
        callsign: ac.callsign,
        lat: ac.position.lat,
        lon: ac.position.lon,
        altFt: ac.altitude,
        speedKts: ac.speedKnots,
        headingDeg: ac.heading,
        platformType: ac.platform as string,
        iff: IFFIdentity.FRIEND,
      };

      const rawBits = link16Gateway.encodeJ2_2(ppliData);
      link16Gateway.buildJMessage(
        JMessageType.J2_2_PPLI,
        'TX',
        ac.callsign,
        ppliData as unknown as Record<string, unknown>,
        rawBits,
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  EMCON Enforcement — rejects TX requests on SILENT nodes
  // ═══════════════════════════════════════════════════════════════════════════

  requestTransmit(aircraftId: string): boolean {
    const ac = this.aircraft.get(aircraftId);
    if (!ac) return false;

    if (ac.txAuthority === TxAuthLevel.SILENT) {
      logger.warn(
        { callsign: ac.callsign, aircraftId, platform: ac.platform },
        'EMCON_VIOLATION_ALERT: TX command rejected — aircraft is RECEIVE_ONLY',
      );
      return false;
    }
    return true;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  HCS Ledger Submission
  // ═══════════════════════════════════════════════════════════════════════════

  private async submitHCSUpdates(): Promise<void> {
    for (const [id, ac] of this.aircraft) {
      if (ac.status === DroneStatus.DESTROYED || ac.status === DroneStatus.DECOMMISSIONED) continue;

      const topicId = ac.hcsTopicId ?? (await redis.get(`hcs:topic:${ac.currentMissionId}`));
      if (!topicId) continue;

      try {
        await hcsService.submitAction({
          topicId,
          droneId: id,
          actionType: ActionType.TELEMETRY_UPDATE,
          operatorId: 'SYSTEM',
          missionId: ac.currentMissionId ?? 'UNASSIGNED',
          payload: {
            callsign: ac.callsign,
            platform: ac.platform,
            lat: ac.position.lat,
            lon: ac.position.lon,
            alt: ac.position.alt,
            heading: ac.heading,
            speed: ac.speedKnots,
            fuel: ac.fuelPercent,
            health: ac.health,
            link: ac.linkQuality,
          },
        });
      } catch (err) {
        logger.error({ err, aircraftId: id }, 'Failed to submit HCS telemetry update');
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Pattern Waypoint Generation — platform-specific flight patterns
  // ═══════════════════════════════════════════════════════════════════════════

  private generatePatternWaypoints(origin: GeoPosition, platform: AircraftClass): GeoPosition[] {
    const profile = FLIGHT_PROFILES[platform];
    const spread = profile.patternSpreadDeg;
    const alt = profile.cruiseAltFt;

    switch (profile.patternType) {
      case 'oval':         return this.generateOvalWaypoints(origin, spread, alt);
      case 'racetrack':    return this.generateRacetrackWaypoints(origin, spread, alt);
      case 'tanker_orbit': return this.generateRacetrackWaypoints(origin, spread, alt);
      case 'patrol':       return this.generatePatrolWaypoints(origin, spread, alt);
      case 'figure8':      return this.generateFigure8Waypoints(origin, spread, alt);
      case 'linear':       return this.generateLinearWaypoints(origin, spread, alt);
      default:             return this.generatePatrolWaypoints(origin, spread, alt);
    }
  }

  private generateOvalWaypoints(center: GeoPosition, spread: number, altFt: number): GeoPosition[] {
    const count = 12;
    return Array.from({ length: count }, (_, i) => {
      const angle = (2 * Math.PI * i) / count;
      return {
        lat: center.lat + spread * Math.sin(angle),
        lon: center.lon + spread * 1.5 * Math.cos(angle),
        alt: altFt + (Math.random() - 0.5) * 500,
      };
    });
  }

  private generateRacetrackWaypoints(center: GeoPosition, spread: number, altFt: number): GeoPosition[] {
    const halfLen = spread * 0.6;
    const halfWidth = spread * 0.15;
    return [
      { lat: center.lat + halfLen, lon: center.lon - halfWidth, alt: altFt },
      { lat: center.lat + halfLen, lon: center.lon + halfWidth, alt: altFt },
      { lat: center.lat - halfLen, lon: center.lon + halfWidth, alt: altFt },
      { lat: center.lat - halfLen, lon: center.lon - halfWidth, alt: altFt },
    ];
  }

  private generatePatrolWaypoints(center: GeoPosition, spread: number, altFt: number): GeoPosition[] {
    const count = 5 + Math.floor(Math.random() * 3);
    return Array.from({ length: count }, () => ({
      lat: center.lat + (Math.random() - 0.5) * spread * 2,
      lon: center.lon + (Math.random() - 0.5) * spread * 2,
      alt: altFt + (Math.random() - 0.5) * 3000,
    }));
  }

  private generateFigure8Waypoints(center: GeoPosition, spread: number, altFt: number): GeoPosition[] {
    const count = 16;
    return Array.from({ length: count }, (_, i) => {
      const t = (2 * Math.PI * i) / count;
      return {
        lat: center.lat + spread * Math.sin(t),
        lon: center.lon + spread * 0.5 * Math.sin(2 * t),
        alt: altFt + (Math.random() - 0.5) * 200,
      };
    });
  }

  private generateLinearWaypoints(center: GeoPosition, spread: number, altFt: number): GeoPosition[] {
    return [
      { lat: center.lat + spread, lon: center.lon + spread * 0.3, alt: altFt },
      { lat: center.lat - spread, lon: center.lon - spread * 0.3, alt: altFt },
    ];
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Mission Dispatch / Recall — backward-compatible public API
  // ═══════════════════════════════════════════════════════════════════════════

  dispatchDronesToMission(
    missionId: string,
    droneIds: string[],
    missionWaypoints: Array<{ lat: number; lon: number; alt: number }>,
  ): void {
    for (const id of droneIds) {
      const ac = this.aircraft.get(id);
      if (!ac) continue;

      ac.currentMissionId = missionId;
      ac.status = DroneStatus.ON_MISSION;
      ac.waypointIndex = 0;
      ac.waypoints = missionWaypoints.map((wp) => ({
        lat: wp.lat,
        lon: wp.lon,
        alt: wp.alt,
      }));

      logger.info(
        { aircraftId: id, callsign: ac.callsign, missionId, waypointCount: ac.waypoints.length },
        'Aircraft dispatched to mission waypoints',
      );
    }
  }

  recallDronesFromMission(missionId: string): void {
    for (const [, ac] of this.aircraft) {
      if (ac.currentMissionId !== missionId) continue;

      const profile = FLIGHT_PROFILES[ac.platform];
      ac.currentMissionId = null;
      ac.status = DroneStatus.RETURNING;
      ac.waypointIndex = 0;
      ac.waypoints = [{ lat: OPS_CENTER.lat, lon: OPS_CENTER.lon, alt: profile.cruiseAltFt }];

      logger.info(
        { aircraftId: ac.aircraftId, callsign: ac.callsign, missionId },
        'Aircraft recalled from mission — returning to station',
      );
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Accessors — backward-compatible method names
  // ═══════════════════════════════════════════════════════════════════════════

  getDroneState(droneId: string): SimulatedAircraft | undefined {
    return this.aircraft.get(droneId);
  }

  getAllDroneStates(): SimulatedAircraft[] {
    return Array.from(this.aircraft.values());
  }

  getDroneCount(): number {
    return this.aircraft.size;
  }
}

export const telemetrySimulator = new TelemetrySimulator();
