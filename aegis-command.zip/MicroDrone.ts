import {
  DroneClass,
  DroneStatus,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export interface MicroDroneConfig extends DroneConfig {
  covertOps?: boolean;
  singleUse?: boolean;
  acousticSignatureDb?: number;
}

export class MicroDrone extends DroneBase {
  urbanMode: boolean;
  covertOps: boolean;
  singleUse: boolean;
  indoorNavigation: boolean;
  acousticSignatureDb: number;

  private silentLandingActive: boolean = false;
  private rtbInitiated: boolean = false;
  private expendableDeployed: boolean = false;

  constructor(cfg: MicroDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.MICRO });
    this.urbanMode = false;
    this.covertOps = cfg.covertOps ?? false;
    this.singleUse = cfg.singleUse ?? false;
    this.indoorNavigation = false;
    this.acousticSignatureDb = cfg.acousticSignatureDb ?? 35;
  }

  enableUrbanMode(): void {
    this.urbanMode = true;
  }

  disableUrbanMode(): void {
    this.urbanMode = false;
  }

  enableIndoorNavigation(): void {
    this.indoorNavigation = true;
  }

  disableIndoorNavigation(): void {
    this.indoorNavigation = false;
  }

  enableCovertOps(): void {
    this.covertOps = true;
  }

  disableCovertOps(): void {
    this.covertOps = false;
  }

  deployExpendable(): boolean {
    if (this.singleUse && !this.expendableDeployed) {
      this.expendableDeployed = true;
      return true;
    }
    return false;
  }

  isExpended(): boolean {
    return this.singleUse && this.expendableDeployed;
  }

  isSilentLanding(): boolean {
    return this.silentLandingActive;
  }

  isRTBInitiated(): boolean {
    return this.rtbInitiated;
  }

  initiateRTB(): void {
    this.rtbInitiated = true;
    this.status = DroneStatus.RETURNING;
  }

  initiateSilentLanding(): void {
    this.silentLandingActive = true;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      urbanMode: this.urbanMode,
      covertOps: this.covertOps,
      singleUse: this.singleUse,
      indoorNavigation: this.indoorNavigation,
      acousticSignatureDb: this.acousticSignatureDb,
      silentLandingActive: this.silentLandingActive,
      rtbInitiated: this.rtbInitiated,
      expendableDeployed: this.expendableDeployed,
      isExpended: this.isExpended(),
    };
  }

  getAIContextDescriptor(): string {
    return [
      `MICRO drone ${this.callsign} (${this.model})`,
      `Urban: ${this.urbanMode ? 'ON' : 'OFF'} | Indoor nav: ${this.indoorNavigation ? 'ON' : 'OFF'}`,
      `Covert: ${this.covertOps ? 'YES' : 'NO'} | Acoustic: ${this.acousticSignatureDb}dB`,
      `Single-use: ${this.singleUse ? 'YES' : 'NO'} | Expended: ${this.isExpended()}`,
      `Silent landing: ${this.silentLandingActive ? 'ACTIVE' : 'OFF'} | RTB: ${this.rtbInitiated ? 'INITIATED' : 'NO'}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'COVERT_OPERATION',
        available: this.covertOps,
        degradedMode: 'Silent landing at current position; minimal electromagnetic emissions',
      },
      {
        capability: 'INDOOR_NAVIGATION',
        available: this.indoorNavigation,
        degradedMode: 'SLAM-based navigation continues without external positioning; drift increases over time',
      },
      {
        capability: 'URBAN_FLIGHT',
        available: this.urbanMode,
        degradedMode: 'Obstacle avoidance maintained via onboard sensors; altitude hold in urban canyon',
      },
      {
        capability: 'RTB',
        available: !this.covertOps,
        degradedMode: 'Autonomous return to base using cached route; covert mode overrides with silent landing',
      },
      {
        capability: 'SENSOR_FEED',
        available: true,
        degradedMode: 'Video and sensor data recorded locally; no live stream',
      },
      {
        capability: 'SELF_DESTRUCT',
        available: this.singleUse && !this.expendableDeployed,
        degradedMode: 'Expendable deployment remains available on onboard timer or proximity trigger',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;

    if (this.covertOps) {
      this.initiateSilentLanding();
    } else {
      this.initiateRTB();
    }
  }
}

export default MicroDrone;
