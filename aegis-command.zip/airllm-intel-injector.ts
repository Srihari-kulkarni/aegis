import { logger } from '../logger';
import { feedManager } from '../intel/feed-manager';
import { zuluTimestamp, type MissionContext, type FleetDroneStatus, DroneClass } from '@aegis/shared';
import type { AggregatedIntel } from '../intel/types';
import { WIND_ABORT_THRESHOLDS, TERRAIN_CLEARANCE_M } from '../intel/types';

export interface AirLLMPromptContext {
  mission: Record<string, unknown>;
  weather: Record<string, unknown> | null;
  altitude_wind: Record<string, unknown> | null;
  airspace_traffic_count: number;
  nearest_aircraft_km: number;
  adsb_military_count: number;
  tfr_conflict: Record<string, unknown> | null;
  terrain_profile: Array<Record<string, unknown>>;
  gps_confidence: string;
  kp_index: number;
  noaa_alerts: Array<Record<string, unknown>>;
  active_threats: Array<Record<string, unknown>>;
  radio_environment: Array<Record<string, unknown>>;
  airspace_zones: Array<Record<string, unknown>>;
  laanc_status: Record<string, unknown> | null;
  computed_risk_score: number;
  computed_risk_factors: string[];
  feed_sources: string[];
}

export class AirLLMIntelInjector {

  async fetchAndCacheAllFeeds(mission: MissionContext): Promise<AggregatedIntel> {
    const lat = mission.mission.waypoints[0]?.position.lat ?? 34.052;
    const lon = mission.mission.waypoints[0]?.position.lon ?? -118.244;
    const wpLocations = mission.mission.waypoints.map((w) => ({ lat: w.position.lat, lon: w.position.lon }));

    logger.info({ missionId: mission.mission.missionId, lat, lon }, 'Fetching all intel feeds for AirLLM context');
    return feedManager.fetchAllFeeds(lat, lon, wpLocations);
  }

  buildAirLLMContext(feeds: AggregatedIntel, mission: MissionContext): AirLLMPromptContext {
    const feedSources: string[] = [];
    Object.entries(feeds).forEach(([key, val]) => {
      if (val) feedSources.push(`${key}:${val.source}`);
    });

    const openMeteo = feeds.openMeteo?.data ?? null;
    const owm = feeds.openWeatherMap?.data ?? null;
    const spaceWx = feeds.noaaSpaceWeather?.data ?? null;

    const weather = owm ? {
      windSpeedMs: owm.windSpeedMs,
      windDirection: owm.windDirection,
      visibilityM: owm.visibilityM,
      thunderstorm: owm.thunderstorm,
      weatherCondition: owm.weatherCondition,
      tempC: owm.tempC,
      humidity: owm.humidity,
      precipitationMm: owm.precipitationMm,
    } : null;

    const altitudeWind = openMeteo ? {
      wind10m: openMeteo.wind10m,
      wind80m: openMeteo.wind80m,
      wind120m: openMeteo.wind120m,
      gusts10m: openMeteo.gusts10m,
      visibility: openMeteo.visibility,
      precipitation: openMeteo.precipitation,
    } : null;

    const openSkyStates = feeds.openSky?.data ?? [];
    const adsbxAircraft = feeds.adsbExchange?.data ?? [];
    const totalAircraft = openSkyStates.length + adsbxAircraft.length;
    const milCount = adsbxAircraft.filter((a) => a.mil).length;

    let nearestKm = 999;
    const missionLat = mission.mission.waypoints[0]?.position.lat ?? 34.052;
    const missionLon = mission.mission.waypoints[0]?.position.lon ?? -118.244;
    for (const ac of openSkyStates) {
      if (ac.latitude != null && ac.longitude != null) {
        const d = haversineKm(missionLat, missionLon, ac.latitude, ac.longitude);
        if (d < nearestKm) nearestKm = d;
      }
    }

    const tfrs = feeds.faaTFR?.data ?? [];
    let tfrConflict: Record<string, unknown> | null = null;
    for (const tfr of tfrs) {
      const dist = haversineKm(missionLat, missionLon, tfr.center.lat, tfr.center.lon);
      if (dist < tfr.radiusNm * 1.852) {
        tfrConflict = { tfrId: tfr.tfrId, type: tfr.type, description: tfr.description, distanceKm: dist };
        break;
      }
    }

    const terrain = (feeds.openTopo?.data ?? []).map((t) => ({
      lat: t.lat,
      lon: t.lon,
      elevationM: t.elevationM,
      dataset: t.dataset,
    }));

    const noaaAlerts = (feeds.noaaWeather?.data ?? []).map((a) => ({
      event: a.event,
      severity: a.severity,
      headline: a.headline,
    }));

    const radioEnv = (feeds.radioRef?.data ?? []).map((f) => ({
      frequency: f.frequency,
      description: f.description,
      protected: f.protected,
      tag: f.tag,
    }));

    const airspaceZones = (feeds.airspaceLink?.data ?? []).map((z) => ({
      name: z.name,
      type: z.type,
      maxAltFt: z.maxAltFt,
      advisoryType: z.advisoryType,
    }));

    const laanc = feeds.aloftLAANC?.data ? {
      maxAltFt: feeds.aloftLAANC.data.maxAltFt,
      laancAvailable: feeds.aloftLAANC.data.laancAvailable,
      autoApproveBelow: feeds.aloftLAANC.data.autoApproveBelow,
      furtherCoordination: feeds.aloftLAANC.data.furtherCoordinationRequired,
    } : null;

    const threats = (mission.threatData?.threats ?? []).map((t) => ({
      type: t.type,
      position: t.position,
      radiusKm: t.radiusKm,
      confidence: t.confidence,
      distance_km: haversineKm(missionLat, missionLon, t.position.lat, t.position.lon),
    }));

    const { riskScore, riskFactors } = this.computePreRiskScore(feeds, mission.assignedDrones, mission);

    return {
      mission: {
        missionId: mission.mission.missionId,
        name: mission.mission.name,
        type: mission.mission.type,
        clearanceLevel: mission.mission.clearanceLevel,
        waypointCount: mission.mission.waypoints.length,
        droneCount: mission.assignedDrones.length,
        droneClasses: [...new Set(mission.assignedDrones.map((d) => d.droneClass))],
      },
      weather,
      altitude_wind: altitudeWind,
      airspace_traffic_count: totalAircraft,
      nearest_aircraft_km: nearestKm,
      adsb_military_count: milCount,
      tfr_conflict: tfrConflict,
      terrain_profile: terrain,
      gps_confidence: spaceWx?.gpsConfidence ?? 'HIGH',
      kp_index: spaceWx?.kpIndex ?? 2,
      noaa_alerts: noaaAlerts,
      active_threats: threats,
      radio_environment: radioEnv,
      airspace_zones: airspaceZones,
      laanc_status: laanc,
      computed_risk_score: riskScore,
      computed_risk_factors: riskFactors,
      feed_sources: feedSources,
    };
  }

  computePreRiskScore(
    feeds: AggregatedIntel,
    drones: FleetDroneStatus[],
    mission: MissionContext,
  ): { riskScore: number; riskFactors: string[] } {
    const riskFactors: string[] = [];
    let riskScore = 0;

    const openMeteo = feeds.openMeteo?.data;
    if (openMeteo) {
      for (const drone of drones) {
        const threshold = WIND_ABORT_THRESHOLDS[drone.droneClass];
        let effectiveWind: number;

        if (drone.droneClass === DroneClass.MICRO || drone.droneClass === DroneClass.CBRN || drone.droneClass === DroneClass.SWARM) {
          effectiveWind = openMeteo.wind10m;
        } else if (drone.droneClass === DroneClass.LARGE_ALTITUDE) {
          effectiveWind = openMeteo.wind120m;
        } else if (drone.droneClass === DroneClass.RELAY || drone.droneClass === DroneClass.OFFENSE) {
          effectiveWind = openMeteo.wind80m;
        } else {
          effectiveWind = Math.max(openMeteo.wind10m, openMeteo.wind80m);
        }

        if (effectiveWind > threshold.thresholdMs) {
          riskFactors.push(`${drone.callsign}: Wind ${effectiveWind.toFixed(1)}m/s exceeds ${drone.droneClass} threshold ${threshold.thresholdMs}m/s at ${threshold.altitudeBand}`);
          riskScore = Math.max(riskScore, 0.90);
        } else if (effectiveWind > threshold.thresholdMs * 0.75) {
          riskFactors.push(`${drone.callsign}: Wind ${effectiveWind.toFixed(1)}m/s approaching ${drone.droneClass} threshold (75%+)`);
          riskScore = Math.max(riskScore, 0.40);
        }
      }
    }

    const tfrs = feeds.faaTFR?.data ?? [];
    const missionLat = mission.mission.waypoints[0]?.position.lat ?? 34.052;
    const missionLon = mission.mission.waypoints[0]?.position.lon ?? -118.244;
    for (const tfr of tfrs) {
      const dist = haversineKm(missionLat, missionLon, tfr.center.lat, tfr.center.lon);
      if (dist < tfr.radiusNm * 1.852) {
        const tfrRisk = (tfr.type === 'SECURITY' || tfr.type === 'VIP') ? 0.90 : 0.40;
        riskFactors.push(`TFR CONFLICT: ${tfr.type} — ${tfr.tfrId}`);
        riskScore = Math.max(riskScore, tfrRisk);
      }
    }

    const spaceWx = feeds.noaaSpaceWeather?.data;
    if (spaceWx) {
      riskScore = Math.max(riskScore, riskScore + spaceWx.riskDelta);
      if (spaceWx.riskDelta > 0) {
        riskFactors.push(`GPS: Kp=${spaceWx.kpIndex} confidence=${spaceWx.gpsConfidence}`);
      }
    }

    const terrain = feeds.openTopo?.data ?? [];
    for (const wp of mission.mission.waypoints) {
      const nearestTerrain = terrain.find((t) =>
        Math.abs(t.lat - wp.position.lat) < 0.001 && Math.abs(t.lon - wp.position.lon) < 0.001
      );
      if (nearestTerrain) {
        for (const drone of drones) {
          const required = TERRAIN_CLEARANCE_M[drone.droneClass];
          const clearance = wp.position.alt * 0.3048 - nearestTerrain.elevationM;
          if (clearance < required) {
            riskFactors.push(`TERRAIN: WP${wp.index} clearance ${clearance.toFixed(0)}m < required ${required}m for ${drone.droneClass}`);
            riskScore = Math.max(riskScore, 0.30);
          }
        }
      }
    }

    const noaaAlerts = feeds.noaaWeather?.data ?? [];
    for (const alert of noaaAlerts) {
      if (alert.event.includes('Tornado') || alert.severity === 'Extreme') {
        riskFactors.push(`NOAA: ${alert.event} — ${alert.severity}`);
        riskScore = Math.max(riskScore, 1.0);
      } else if (alert.severity === 'Severe') {
        riskFactors.push(`NOAA: ${alert.event} — ${alert.severity}`);
        riskScore = Math.max(riskScore, 0.7);
      }
    }

    for (const drone of drones) {
      if (drone.health < 0.6) {
        riskFactors.push(`FLEET: ${drone.callsign} health ${(drone.health * 100).toFixed(0)}% below threshold`);
        riskScore = Math.max(riskScore, 0.65);
      }
    }

    return { riskScore: Math.min(1.0, riskScore), riskFactors };
  }

  validateAndTruncate(context: AirLLMPromptContext, maxTokens: number): AirLLMPromptContext {
    const json = JSON.stringify(context);
    const estimatedTokens = Math.ceil(json.length / 4);

    if (estimatedTokens <= maxTokens) return context;

    logger.warn({ estimatedTokens, maxTokens }, 'Context exceeds max tokens — truncating');

    const truncated = { ...context };
    if (truncated.terrain_profile.length > 5) {
      truncated.terrain_profile = truncated.terrain_profile.slice(0, 5);
    }
    if (truncated.radio_environment.length > 6) {
      truncated.radio_environment = truncated.radio_environment.filter((r) => (r as { protected?: boolean }).protected);
    }
    if (truncated.noaa_alerts.length > 3) {
      truncated.noaa_alerts = truncated.noaa_alerts.slice(0, 3);
    }

    return truncated;
  }
}

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export const intelInjector = new AirLLMIntelInjector();
