'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const NAV_LINKS = [
  { href: '/dashboard', label: 'TACTICAL' },
  { href: '/fire-control', label: 'FIRE CTRL' },
  { href: '/assets', label: 'ASSETS' },
  { href: '/tracks', label: 'TRACKS' },
  { href: '/link16', label: 'LINK-16' },
  { href: '/intel', label: 'INTEL' },
  { href: '/identity', label: 'IDENTITY' },
  { href: '/hcs-log', label: 'HCS LOG' },
] as const;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#030508]">
      <nav className="shrink-0 h-8 flex items-center gap-0 bg-[#030508] border-b border-[#0a1828] px-2 z-50">
        {NAV_LINKS.map((link) => {
          const active = pathname === link.href || pathname.startsWith(link.href + '/');
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 py-1 font-mono text-[10px] uppercase tracking-[0.15em] transition-colors ${
                active
                  ? 'text-[#00d4ff] border-b border-[#00d4ff] bg-[#00d4ff]/5'
                  : 'text-[#556677] hover:text-[#e8eaf0]'
              }`}
            >
              {link.label}
            </Link>
          );
        })}
        <div className="ml-auto font-mono text-[9px] text-[#556677] tracking-widest">
          AEGIS BASELINE 9.C1 // CEC USG-2B // AN/SPY-1D
        </div>
      </nav>
      <div className="flex-1 min-h-0">{children}</div>
    </div>
  );
}
