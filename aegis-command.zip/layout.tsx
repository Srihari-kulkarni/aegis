'use client';

import './globals.css';
import { useEffect } from 'react';
import { useAuthStore } from '@/stores/authStore';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const checkAuth = useAuthStore((s) => s.checkAuth);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  return (
    <html lang="en">
      <head>
        <title>AEGIS COMMAND</title>
        <meta name="description" content="Defense-Grade Drone Mission Control" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className="min-h-screen bg-aegis-bg">
        {children}
      </body>
    </html>
  );
}
