# AEGIS COMMAND

**Defense-Grade Drone Mission Control Platform**

A complete, production-grade internal mission control platform for defensive drone operations. Every action is logged to the Hedera Consensus Service (HCS) for tamper-proof compliance. AI-powered mission approval via GPT-4o with continuous environmental monitoring.

```
// UNCLASSIFIED // FOR OFFICIAL USE ONLY //
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        NGINX (Port 80/443)                      │
│                    Reverse Proxy + SSL Termination               │
└───────────┬──────────────────────┬──────────────────────────────┘
            │                      │
    ┌───────▼───────┐      ┌───────▼───────┐
    │   Frontend    │      │   Backend     │
    │  Next.js 14   │      │  Express +    │
    │  React 18     │◄────►│  Socket.io    │
    │  Tailwind CSS │  WS  │  TypeScript   │
    │  Zustand      │      │  Port 4000    │
    │  Leaflet.js   │      │               │
    │  Port 3000    │      └───┬───┬───┬───┘
    └───────────────┘          │   │   │
                               │   │   │
          ┌────────────────────┘   │   └────────────────────┐
          │                        │                        │
  ┌───────▼───────┐       ┌───────▼───────┐       ┌───────▼───────┐
  │  PostgreSQL   │       │    Redis      │       │    Hedera     │
  │  16 +         │       │    7          │       │    Testnet    │
  │  TimescaleDB  │       │  Cache/PubSub │       │  HCS + HTS   │
  │  Port 5432    │       │  Port 6379    │       │               │
  └───────────────┘       └───────────────┘       └───────┬───────┘
                                                          │
                                                  ┌───────▼───────┐
                                                  │  HashScan.io  │
                                                  │  Verification │
                                                  └───────────────┘

  External APIs:
  ├── OpenAI GPT-4o (AI Mission Approval)
  ├── OpenWeatherMap (Real-time Weather)
  └── Simulated ADS-B/SIGINT/Threat Feeds
```

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Next.js 14, TypeScript, Tailwind CSS, Zustand, Leaflet.js, Socket.io Client |
| Backend | Node.js 20, Express, TypeScript (strict), Socket.io, Pino |
| Blockchain | Hedera Testnet — HCS (Consensus Service) + HTS (Token Service) |
| AI Engine | OpenAI GPT-4o |
| Database | PostgreSQL 16 + TimescaleDB |
| Cache | Redis 7 (ioredis) |
| Auth | JWT (RS256) + bcrypt + TOTP MFA (speakeasy) |
| Container | Docker Compose |

---

## Quick Start

### Prerequisites

- Docker & Docker Compose
- Node.js 20+ (for local development)
- Git

### 1. Clone & Configure

```bash
git clone <repository-url> aegis-command
cd aegis-command
cp .env.example .env
```

### 2. Start Services

```bash
docker compose up -d
```

This starts PostgreSQL + TimescaleDB, Redis, Backend, Frontend, and Nginx.

### 3. Seed Database

```bash
docker compose exec backend npm run seed --workspace=packages/backend
```

### 4. Access the Platform

| URL | Service |
|-----|---------|
| http://localhost | Platform (via Nginx) |
| http://localhost:3000 | Frontend (direct) |
| http://localhost:4000 | Backend API (direct) |
| http://localhost:4000/health | Health check |

### 5. Login

Use the default credentials below for the testnet demo.

---

## Default Credentials

| Role | Username | Password | Callsign | Clearance |
|------|----------|----------|----------|-----------|
| SUPER_ADMIN | admin | AegisAdmin!2025 | OVERLORD | SCI |
| MISSION_COMMANDER | cmdr_hawk | HawkCmdr!2025 | HAWK-6 | TOP_SECRET |
| OPERATOR | op_viper | ViperOp!2025 | VIPER-1 | SECRET |
| ANALYST | analyst_raven | RavenAnalyst!2025 | RAVEN-3 | SECRET |
| AI_SYSTEM | ai_system | AegisAI!System | AEGIS-AI | TOP_SECRET |
| AUDITOR | auditor_eagle | EagleAudit!2025 | EAGLE-9 | CONFIDENTIAL |

> MFA is disabled by default for demo accounts. Enable via `/auth/mfa/setup`.

---

## Drone Fleet (Seed Data)

| Callsign | Class | Model | Manufacturer |
|----------|-------|-------|-------------|
| SHADOW-1 | RECON | RQ-180 | Northrop Grumman |
| STRIKER-1 | OFFENSE | MQ-9B | General Atomics |
| MULE-1 | DELIVERY | K-MAX | Kaman |
| PHANTOM-1 | EW | EA-18G | Boeing |
| NEXUS-1 | RELAY | RQ-7B | AAI Corp |
| HIVE-1 | SWARM | OFFSET-S | DARPA |
| HAZMAT-1 | CBRN | DR-X1 | Chemring |
| DEPTH-1 | UNDERWATER | Orca XLUUV | Boeing |
| SENTINEL-1 | LARGE_ALTITUDE | RQ-4B | Northrop Grumman |
| BUG-1 | MICRO | Black Hornet 4 | FLIR |

---

## Hedera Testnet Setup

1. **Create Account**: Visit [Hedera Portal](https://portal.hedera.com/)
2. **Get Testnet Credentials**: Copy your Account ID and Private Key
3. **Fund Account**: Use the [testnet faucet](https://portal.hedera.com/) to get test HBAR
4. **Configure**: Add to `.env`:
   ```
   HEDERA_ACCOUNT_ID=0.0.XXXXXXX
   HEDERA_PRIVATE_KEY=302e020100...
   ```
5. **Disable Demo Mode**: Set `DEMO_MODE=false` in `.env`

> In demo mode (default), HCS/HTS operations are simulated locally. All compliance logging still works — transactions get demo IDs instead of real Hedera transaction IDs.

---

## API Reference

### Authentication

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | /auth/login | Login with username + password + MFA | No |
| POST | /auth/refresh | Refresh JWT tokens | Refresh Token |
| POST | /auth/logout | Revoke session | JWT |
| POST | /auth/mfa/setup | Generate TOTP secret + QR | JWT |
| POST | /auth/mfa/verify | Verify TOTP code | JWT |
| GET | /auth/me | Current operator profile | JWT |

### Missions

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | /api/v1/missions | Create mission + trigger AI assessment | JWT + mission:create |
| GET | /api/v1/missions | List missions (filterable) | JWT |
| GET | /api/v1/missions/:id | Full mission detail + AI assessment | JWT |
| POST | /api/v1/missions/:id/approve | Commander approval | JWT + MISSION_COMMANDER |
| POST | /api/v1/missions/:id/abort | Abort active mission | JWT + mission:abort |
| POST | /api/v1/missions/:id/override | Override AI rejection | JWT + MFA + MISSION_COMMANDER |

### Drones

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | /api/v1/drones | Fleet list with live status | JWT |
| GET | /api/v1/drones/:id | Full drone detail + telemetry | JWT |
| POST | /api/v1/drones/:id/command | Issue command | JWT + drone:command |
| POST | /api/v1/drones | Register drone + mint NFT | JWT + SUPER_ADMIN |

### HCS Log

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | /api/v1/log | Paginated action log | JWT + log:read |
| GET | /api/v1/log/:missionId | Mission-specific log | JWT + log:read |
| GET | /api/v1/log/verify/:seqNumber | Verify sequence integrity | JWT + log:read |

### Intel

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | /api/v1/intel/weather | Weather for AO | JWT + intel:read |
| GET | /api/v1/intel/threats | Active threat feed | JWT + intel:read |
| GET | /api/v1/intel/airspace | Airspace restrictions | JWT + intel:read |

---

## WebSocket Events

### Namespace: `/telemetry`

| Event | Direction | Data |
|-------|-----------|------|
| subscribe:drone | Client → Server | droneId: string |
| subscribe:all | Client → Server | — |
| unsubscribe:drone | Client → Server | droneId: string |
| telemetry:update | Server → Client | Telemetry object |

### Namespace: `/mission-feed`

| Event | Direction | Data |
|-------|-----------|------|
| subscribe:mission | Client → Server | missionId: string |
| subscribe:all | Client → Server | — |
| action:new | Server → Client | HCSMessage object |

### Namespace: `/ai-intel`

| Event | Direction | Data |
|-------|-----------|------|
| subscribe:mission | Client → Server | missionId: string |
| ai:update | Server → Client | AI assessment/intel update |

### Namespace: `/threats`

| Event | Direction | Data |
|-------|-----------|------|
| threat:update | Server → Client | Threat object |

**Auth**: JWT token required in `socket.handshake.auth.token` on connection.

---

## Compliance Log Format

Every action logged to HCS follows this format:

```
[CONSENSUS_TS] [DRONE_ID] [ACTION_TYPE] [SEQ:NUMBER] [OPERATOR_ID] [MISSION_ID] [AI_CONF:VALUE] [TOPIC_ID]
```

**Example:**
```
[2026-03-02 14:35:22Z] [SHADOW-1] [DRONE_LAUNCHED] [SEQ:42] [HAWK-6] [MSN-001] [AI_CONF:0.87] [0.0.1234567]
```

---

## HCS Verification Guide

Every action in AEGIS COMMAND is recorded on the Hedera Consensus Service. To verify:

1. **Find the transaction**: In the Mission Feed, click "VERIFY ON HASHSCAN" on any log entry
2. **HashScan URL**: `https://hashscan.io/testnet/transaction/{transactionId}`
3. **Verify fields**:
   - Consensus timestamp matches the log entry
   - Topic ID matches the mission's HCS topic
   - Message content contains the compliance log string
4. **Sequence integrity**: Use the `/api/v1/log/verify/:seqNumber` endpoint to check for gaps

> In demo mode, transaction IDs are prefixed with `demo-` and won't resolve on HashScan.

---

## Development

### Local Development (without Docker)

```bash
# Install dependencies
npm install

# Build shared types
npm run build:shared

# Start PostgreSQL and Redis (required)
docker compose up postgres redis -d

# Seed database
npm run seed --workspace=packages/backend

# Start backend (dev mode)
npm run dev:backend

# Start frontend (dev mode, in another terminal)
npm run dev:frontend
```

### Project Structure

```
aegis-command/
├── packages/
│   ├── backend/
│   │   └── src/
│   │       ├── ai/           # AI Mission Approval Engine
│   │       ├── auth/         # JWT + MFA auth system
│   │       ├── db/           # PostgreSQL pool + schema + seed
│   │       ├── drones/       # Drone class hierarchy (10 classes)
│   │       ├── hedera/       # HCS + HTS integration
│   │       ├── routes/       # REST API routes
│   │       ├── simulator/    # Telemetry simulator
│   │       ├── websocket/    # Socket.io server
│   │       ├── config.ts     # Environment config
│   │       ├── logger.ts     # Pino structured logger
│   │       ├── redis.ts      # Redis connections
│   │       └── index.ts      # Entry point
│   ├── frontend/
│   │   └── src/
│   │       ├── app/          # Next.js app router
│   │       ├── components/   # React components
│   │       ├── stores/       # Zustand stores
│   │       └── lib/          # API client + socket
│   └── shared/
│       └── src/
│           └── types.ts      # Shared enums + interfaces
├── docker-compose.yml
├── nginx.conf
├── .env.example
└── README.md
```

---

## Security

- **JWT RS256**: Asymmetric key signing — keys auto-generated on first run
- **MFA**: TOTP-based MFA via speakeasy — required for critical actions
- **RBAC**: Role-based access control with 7 operator roles
- **Session Management**: Redis-backed sessions with 8h TTL
- **Rate Limiting**: express-rate-limit on all API routes
- **Security Headers**: Helmet.js
- **Input Validation**: Zod schemas on every endpoint
- **Immutable Logs**: HCS action log table is INSERT-only (no UPDATE/DELETE)
- **Blockchain Audit Trail**: Every action logged to Hedera for tamper-proof compliance

---

## License

Proprietary — AEGIS COMMAND. For authorized use only.
