import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  transport: process.env.NODE_ENV !== 'production'
    ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'UTC:yyyy-mm-dd HH:MM:ss.lZ' } }
    : undefined,
  base: { service: 'aegis-command' },
  timestamp: () => `,"time":"${new Date().toISOString()}"`,
  formatters: {
    level(label: string) {
      return { level: label.toUpperCase() };
    },
  },
});
