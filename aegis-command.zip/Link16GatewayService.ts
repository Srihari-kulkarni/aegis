import { EventEmitter } from 'events';
import {
  JMessageType,
  J3_2_AirTrack,
  IFFIdentity,
  TrackSource,
  WeaponType,
  JMessage,
  ROELevel,
} from '@aegis/shared';

// ─── Codec Constants ─────────────────────────────────────────────────────────

const LINK16_CHARSET = ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-./';

const LAT_LSB_DEG = 0.00549;
const LON_LSB_DEG = 0.00549;
const ALT_INCREMENT_FT = 100;
const HEADING_LSB_DEG = 0.7;

const IFF_TABLE: IFFIdentity[] = [
  IFFIdentity.FRIEND,
  IFFIdentity.HOSTILE,
  IFFIdentity.NEUTRAL,
  IFFIdentity.UNKNOWN,
  IFFIdentity.ASSUMED_FRIEND,
  IFFIdentity.PENDING,
];

const WEAPON_TABLE: WeaponType[] = [
  WeaponType.GBU_31_JDAM,
  WeaponType.GBU_39_SDB,
  WeaponType.AIM_120_AMRAAM,
  WeaponType.AGM_114_HELLFIRE,
  WeaponType.GBU_12_PAVEWAY,
  WeaponType.AGM_158_JASSM,
];

const ROE_TABLE: ROELevel[] = [
  ROELevel.WEAPONS_FREE,
  ROELevel.WEAPONS_TIGHT,
  ROELevel.WEAPONS_HOLD,
];

const TRACK_SOURCE_TABLE: TrackSource[] = [
  TrackSource.AEGIS_CEC,
  TrackSource.AWACS_ORGANIC,
  TrackSource.DRONE_ORGANIC,
  TrackSource.FUSED,
  TrackSource.PPLI,
  TrackSource.SILENT_NODE,
];

const PLATFORM_TABLE = [
  'F-35A', 'F-35B', 'B-2A', 'E-3G', 'MQ-9B',
  'C-17A', 'KC-46A', 'F-22A', 'F-15E', 'F-16C',
  'EA-18G', 'P-8A', 'E-2D', 'UNKNOWN', 'SAM', 'FIGHTER',
];

const MISSION_TYPE_TABLE = [
  'STRIKE', 'ISR', 'CAS', 'ESCORT', 'CAP', 'SEAD',
  'TANKER', 'AIRLIFT', 'SAR', 'RECON', 'EW', 'PATROL',
  'INTERCEPT', 'BDA', 'OTHER',
];

const NPG_PPLI = 1;
const NPG_SURVEILLANCE = 2;
const NPG_MISSION_MGMT = 7;
const NPG_WEAPONS = 9;

// ─── Coordinate Helpers ──────────────────────────────────────────────────────

function encodeLat(lat: number): number {
  const clamped = Math.max(-90, Math.min(90, lat));
  return Math.round((clamped + 90) / LAT_LSB_DEG);
}

function decodeLat(raw: number): number {
  return raw * LAT_LSB_DEG - 90;
}

function encodeLon(lon: number): number {
  const clamped = Math.max(-180, Math.min(180, lon));
  return Math.round((clamped + 180) / LON_LSB_DEG);
}

function decodeLon(raw: number): number {
  return raw * LON_LSB_DEG - 180;
}

function encodeAlt(altFt: number): number {
  return Math.min(2047, Math.max(0, Math.round(altFt / ALT_INCREMENT_FT)));
}

function decodeAlt(raw: number): number {
  return raw * ALT_INCREMENT_FT;
}

function encodeHeading(deg: number): number {
  const normalized = ((deg % 360) + 360) % 360;
  return Math.round(normalized / HEADING_LSB_DEG) & 0x1ff;
}

function decodeHeading(raw: number): number {
  return raw * HEADING_LSB_DEG;
}

function encodeSpeed(kts: number): number {
  return Math.min(1023, Math.max(0, Math.round(kts)));
}

function indexOf<T>(table: T[], value: T, fallback = 0): number {
  const i = table.indexOf(value);
  return i >= 0 ? i : fallback;
}

// ─── BitWriter ───────────────────────────────────────────────────────────────
// Packs arbitrary-width unsigned integers MSB-first into a growable byte buffer.

class BitWriter {
  private bytes: number[] = [];
  private accumulator = 0;
  private bitsInAccumulator = 0;

  write(value: number, width: number): void {
    for (let i = width - 1; i >= 0; i--) {
      this.accumulator = (this.accumulator << 1) | ((value >>> i) & 1);
      this.bitsInAccumulator++;
      if (this.bitsInAccumulator === 8) {
        this.bytes.push(this.accumulator);
        this.accumulator = 0;
        this.bitsInAccumulator = 0;
      }
    }
  }

  writeString(str: string, maxChars: number, bitsPerChar = 6): void {
    const padded = str.toUpperCase().padEnd(maxChars).substring(0, maxChars);
    for (let i = 0; i < maxChars; i++) {
      const code = LINK16_CHARSET.indexOf(padded[i]);
      this.write(code >= 0 ? code : 0, bitsPerChar);
    }
  }

  toUint8Array(): Uint8Array {
    const trailing = this.bitsInAccumulator > 0 ? 1 : 0;
    const out = new Uint8Array(this.bytes.length + trailing);
    for (let i = 0; i < this.bytes.length; i++) out[i] = this.bytes[i];
    if (trailing) {
      out[this.bytes.length] = this.accumulator << (8 - this.bitsInAccumulator);
    }
    return out;
  }

  get totalBits(): number {
    return this.bytes.length * 8 + this.bitsInAccumulator;
  }
}

// ─── BitReader ───────────────────────────────────────────────────────────────
// Reads arbitrary-width unsigned integers MSB-first from a Uint8Array.

class BitReader {
  private data: Uint8Array;
  private bytePos = 0;
  private bitOffset = 0;

  constructor(data: Uint8Array) {
    this.data = data;
  }

  read(width: number): number {
    let value = 0;
    for (let i = 0; i < width; i++) {
      const bit = (this.data[this.bytePos] >>> (7 - this.bitOffset)) & 1;
      value = (value << 1) | bit;
      this.bitOffset++;
      if (this.bitOffset === 8) {
        this.bitOffset = 0;
        this.bytePos++;
      }
    }
    return value;
  }

  readString(maxChars: number, bitsPerChar = 6): string {
    let result = '';
    for (let i = 0; i < maxChars; i++) {
      const code = this.read(bitsPerChar);
      result += code < LINK16_CHARSET.length ? LINK16_CHARSET[code] : ' ';
    }
    return result.trimEnd();
  }

  get remainingBits(): number {
    return (this.data.length - this.bytePos) * 8 - this.bitOffset;
  }
}

// ─── Link16GatewayService ────────────────────────────────────────────────────

export class Link16GatewayService extends EventEmitter {
  private messageLog: JMessage[] = [];
  private jtidsTrackCounter = 1000;

  // ═══════════════════════════════════════════════════════════════════════════
  //  J3.2 — Air Track
  //  Word 1  label(5) subLabel(2) trackNumber(7) exerciseIndicator(1)   = 15b
  //  Word 2  latitude(17) longitude(18) altitude(11)                     = 46b
  //  Word 3  speed(10) heading(9) identity(4) trackQuality(3)            = 26b
  //  Total payload: 87 bits → 11 bytes
  // ═══════════════════════════════════════════════════════════════════════════

  encodeJ3_2(track: J3_2_AirTrack): Uint8Array {
    const w = new BitWriter();

    // Word 1
    w.write(0b00011, 5);                                         // label  → J3
    w.write(0b10, 2);                                            // sub    → .2
    w.write(track.jtidsTrackNum & 0x7f, 7);
    w.write(0, 1);                                               // exerciseIndicator (live)

    // Word 2
    w.write(encodeLat(track.lat), 17);
    w.write(encodeLon(track.lon), 18);
    w.write(encodeAlt(track.altFt), 11);

    // Word 3
    w.write(encodeSpeed(track.speedKts), 10);
    w.write(encodeHeading(track.headingDeg), 9);
    w.write(indexOf(IFF_TABLE, track.iffIdentity, 3), 4);
    w.write(Math.min(7, Math.max(0, track.trackQuality)), 3);

    return w.toUint8Array();
  }

  decodeJ3_2(bits: Uint8Array): J3_2_AirTrack {
    const r = new BitReader(bits);

    // Word 1
    const label = r.read(5);
    const sub = r.read(2);
    if (label !== 0b00011 || sub !== 0b10) {
      throw new Error(
        `Invalid J3.2 header: label=0b${label.toString(2)} sub=0b${sub.toString(2)}`,
      );
    }
    const jtidsTrackNum = r.read(7);
    r.read(1); // exerciseIndicator — discard

    // Word 2
    const lat = decodeLat(r.read(17));
    const lon = decodeLon(r.read(18));
    const altFt = decodeAlt(r.read(11));

    // Word 3
    const speedKts = r.read(10);
    const headingDeg = decodeHeading(r.read(9));
    const iffIdx = r.read(4);
    const trackQuality = r.read(3);

    return {
      trackId: `TN-${jtidsTrackNum.toString().padStart(4, '0')}`,
      jtidsTrackNum,
      lat,
      lon,
      altFt,
      speedKts,
      headingDeg,
      iffIdentity: IFF_TABLE[iffIdx] ?? IFFIdentity.UNKNOWN,
      trackQuality,
      trackSource: TrackSource.AEGIS_CEC,
      cecSourceFlag: true,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  J2.2 — Precise Participant Location & Identification (PPLI)
  //  Header  label(5) subLabel(2)                                        =  7b
  //  Body    callsign(8×6=48) lat(17) lon(18) alt(11) speed(10)
  //          heading(9) platformType(4) iff(4)                           = 121b
  //  Total: 128 bits → 16 bytes
  // ═══════════════════════════════════════════════════════════════════════════

  encodeJ2_2(ppli: {
    callsign: string;
    lat: number;
    lon: number;
    altFt: number;
    speedKts: number;
    headingDeg: number;
    platformType: string;
    iff: IFFIdentity;
  }): Uint8Array {
    const w = new BitWriter();

    w.write(0b00010, 5); // label → J2
    w.write(0b10, 2);    // sub   → .2

    w.writeString(ppli.callsign, 8);
    w.write(encodeLat(ppli.lat), 17);
    w.write(encodeLon(ppli.lon), 18);
    w.write(encodeAlt(ppli.altFt), 11);
    w.write(encodeSpeed(ppli.speedKts), 10);
    w.write(encodeHeading(ppli.headingDeg), 9);
    w.write(indexOf(PLATFORM_TABLE, ppli.platformType, 13), 4);
    w.write(indexOf(IFF_TABLE, ppli.iff, 3), 4);

    return w.toUint8Array();
  }

  decodeJ2_2(bits: Uint8Array): {
    callsign: string;
    lat: number;
    lon: number;
    altFt: number;
    speedKts: number;
    headingDeg: number;
    platformType: string;
    iff: IFFIdentity;
  } {
    const r = new BitReader(bits);

    const label = r.read(5);
    const sub = r.read(2);
    if (label !== 0b00010 || sub !== 0b10) {
      throw new Error(
        `Invalid J2.2 header: label=0b${label.toString(2)} sub=0b${sub.toString(2)}`,
      );
    }

    const callsign = r.readString(8);
    const lat = decodeLat(r.read(17));
    const lon = decodeLon(r.read(18));
    const altFt = decodeAlt(r.read(11));
    const speedKts = r.read(10);
    const headingDeg = decodeHeading(r.read(9));
    const platformIdx = r.read(4);
    const iffIdx = r.read(4);

    return {
      callsign,
      lat,
      lon,
      altFt,
      speedKts,
      headingDeg,
      platformType: PLATFORM_TABLE[platformIdx] ?? 'UNKNOWN',
      iff: IFF_TABLE[iffIdx] ?? IFFIdentity.UNKNOWN,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  J12.0 — Mission Assignment
  //  Header  label(5) subLabel(2)                                        =  7b
  //  Body    targetTrackNum(7) assignedForceTrackNum(7) missionType(4)
  //          callsign(8×6=48) roeClearance(2)                            = 68b
  //  Total: 75 bits → 10 bytes
  // ═══════════════════════════════════════════════════════════════════════════

  encodeJ12_0(assignment: {
    targetTrackNum: number;
    assignedForceTrackNum: number;
    missionType: string;
    assignedCallsign: string;
    roeClearance: ROELevel;
  }): Uint8Array {
    const w = new BitWriter();

    w.write(0b01100, 5); // label → J12
    w.write(0b00, 2);    // sub   → .0

    w.write(assignment.targetTrackNum & 0x7f, 7);
    w.write(assignment.assignedForceTrackNum & 0x7f, 7);
    w.write(indexOf(MISSION_TYPE_TABLE, assignment.missionType.toUpperCase(), 14), 4);
    w.writeString(assignment.assignedCallsign, 8);
    w.write(indexOf(ROE_TABLE, assignment.roeClearance, 2), 2);

    return w.toUint8Array();
  }

  decodeJ12_0(bits: Uint8Array): {
    targetTrackNum: number;
    assignedForceTrackNum: number;
    missionType: string;
    assignedCallsign: string;
    roeClearance: ROELevel;
  } {
    const r = new BitReader(bits);

    const label = r.read(5);
    const sub = r.read(2);
    if (label !== 0b01100 || sub !== 0b00) {
      throw new Error(
        `Invalid J12.0 header: label=0b${label.toString(2)} sub=0b${sub.toString(2)}`,
      );
    }

    const targetTrackNum = r.read(7);
    const assignedForceTrackNum = r.read(7);
    const missionTypeIdx = r.read(4);
    const assignedCallsign = r.readString(8);
    const roeIdx = r.read(2);

    return {
      targetTrackNum,
      assignedForceTrackNum,
      missionType: MISSION_TYPE_TABLE[missionTypeIdx] ?? 'OTHER',
      assignedCallsign,
      roeClearance: ROE_TABLE[roeIdx] ?? ROELevel.WEAPONS_HOLD,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  J7.0 — Weapon Coordination
  //  Header  label(5) subLabel(2)                                        =  7b
  //  Body    weaponType(4) launchLat(17) launchLon(18)
  //          targetLat(17) targetLon(18) tofSeconds(10)                  = 84b
  //  Total: 91 bits → 12 bytes
  // ═══════════════════════════════════════════════════════════════════════════

  encodeJ7_0(weaponCoord: {
    weapon: WeaponType;
    launchLat: number;
    launchLon: number;
    targetLat: number;
    targetLon: number;
    tofSeconds: number;
  }): Uint8Array {
    const w = new BitWriter();

    w.write(0b00111, 5); // label → J7
    w.write(0b00, 2);    // sub   → .0

    w.write(indexOf(WEAPON_TABLE, weaponCoord.weapon), 4);
    w.write(encodeLat(weaponCoord.launchLat), 17);
    w.write(encodeLon(weaponCoord.launchLon), 18);
    w.write(encodeLat(weaponCoord.targetLat), 17);
    w.write(encodeLon(weaponCoord.targetLon), 18);
    w.write(Math.min(1023, Math.max(0, Math.round(weaponCoord.tofSeconds))), 10);

    return w.toUint8Array();
  }

  decodeJ7_0(bits: Uint8Array): {
    weapon: WeaponType;
    launchLat: number;
    launchLon: number;
    targetLat: number;
    targetLon: number;
    tofSeconds: number;
  } {
    const r = new BitReader(bits);

    const label = r.read(5);
    const sub = r.read(2);
    if (label !== 0b00111 || sub !== 0b00) {
      throw new Error(
        `Invalid J7.0 header: label=0b${label.toString(2)} sub=0b${sub.toString(2)}`,
      );
    }

    const weaponIdx = r.read(4);
    const launchLat = decodeLat(r.read(17));
    const launchLon = decodeLon(r.read(18));
    const targetLat = decodeLat(r.read(17));
    const targetLon = decodeLon(r.read(18));
    const tofSeconds = r.read(10);

    return {
      weapon: WEAPON_TABLE[weaponIdx] ?? WeaponType.GBU_31_JDAM,
      launchLat,
      launchLon,
      targetLat,
      targetLon,
      tofSeconds,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Message Log / Queue
  // ═══════════════════════════════════════════════════════════════════════════

  logMessage(msg: JMessage): void {
    this.messageLog.push(msg);
    this.emit('message', msg);
    this.emit(msg.direction === 'TX' ? 'tx' : 'rx', msg);
  }

  getMessageLog(limit?: number): JMessage[] {
    if (limit !== undefined && limit > 0) {
      return this.messageLog.slice(-limit);
    }
    return [...this.messageLog];
  }

  getMessagesByType(type: JMessageType): JMessage[] {
    return this.messageLog.filter((m) => m.type === type);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  Track-Number Management (JTIDS sequential assignment)
  // ═══════════════════════════════════════════════════════════════════════════

  assignTrackNumber(): number {
    return this.jtidsTrackCounter++;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  JMessage Factory — wraps encoded data into the shared JMessage envelope
  // ═══════════════════════════════════════════════════════════════════════════

  buildJMessage(
    type: JMessageType,
    direction: 'TX' | 'RX',
    callsign: string,
    decoded: Record<string, unknown>,
    rawBits?: Uint8Array,
  ): JMessage {
    const npgLookup: Partial<Record<JMessageType, number>> = {
      [JMessageType.J2_2_PPLI]: NPG_PPLI,
      [JMessageType.J3_2_AIR_TRACK]: NPG_SURVEILLANCE,
      [JMessageType.J12_0_MISSION_ASSIGN]: NPG_MISSION_MGMT,
      [JMessageType.J7_0_WEAPON_COORD_A]: NPG_WEAPONS,
    };

    const msg: JMessage = {
      type,
      npg: npgLookup[type] ?? 0,
      direction,
      rawBits,
      decoded,
      originatorCallsign: callsign,
      timestamp: new Date().toISOString(),
    };

    this.logMessage(msg);
    return msg;
  }
}

export const link16Gateway = new Link16GatewayService();
