import { config } from '../config';
import { logger } from '../logger';

type QueryResult<T = Record<string, unknown>> = {
  rows: T[];
  rowCount: number | null;
};

let pgAvailable = false;
let pool: { query: <T>(text: string, params?: unknown[]) => Promise<QueryResult<T>>; connect: () => Promise<{ query: (text: string, params?: unknown[]) => Promise<QueryResult>; release: () => void }> } | null = null;

try {
  if (!config.demoMode) {
    const pg = require('pg') as typeof import('pg');
    const pgPool = new pg.Pool({
      connectionString: config.databaseUrl,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    });
    pgPool.on('error', (err: Error) => {
      logger.error({ err }, 'PostgreSQL pool error');
    });
    pool = pgPool as unknown as typeof pool;
    pgAvailable = true;
  }
} catch {
  logger.info('PostgreSQL driver not available — using in-memory store');
}

const inMemoryStore: Map<string, Record<string, unknown>[]> = new Map();

export async function query<T extends Record<string, unknown> = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<QueryResult<T>> {
  if (pgAvailable && pool) {
    const start = Date.now();
    const result = await pool.query<T>(text, params);
    const duration = Date.now() - start;
    logger.debug({ query: text.slice(0, 80), duration, rows: result.rowCount }, 'SQL query');
    return result;
  }
  logger.debug({ query: text.slice(0, 60) }, 'In-memory query (demo mode — no-op)');
  return { rows: [] as T[], rowCount: 0 };
}

export async function withTransaction<T>(
  fn: (client: { query: (text: string, params?: unknown[]) => Promise<QueryResult> }) => Promise<T>
): Promise<T> {
  if (pgAvailable && pool) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(client);
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }
  return fn({ query: async () => ({ rows: [], rowCount: 0 }) });
}

export async function testConnection(): Promise<void> {
  if (pgAvailable && pool) {
    const client = await pool.connect();
    try {
      const res = await client.query('SELECT NOW() as now');
      logger.info({ serverTime: (res.rows[0] as Record<string, unknown>)?.now }, 'PostgreSQL connected');
    } finally {
      client.release();
    }
  } else {
    logger.info('Running without PostgreSQL (demo mode — in-memory)');
  }
}

export { inMemoryStore };
