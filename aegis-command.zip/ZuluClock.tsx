'use client';

import { useState, useEffect } from 'react';

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

function formatZulu(): string {
  const now = new Date();
  const day = String(now.getUTCDate()).padStart(2, '0');
  const month = MONTHS[now.getUTCMonth()];
  const year = now.getUTCFullYear();
  const h = String(now.getUTCHours()).padStart(2, '0');
  const m = String(now.getUTCMinutes()).padStart(2, '0');
  const s = String(now.getUTCSeconds()).padStart(2, '0');
  return `${day} ${month} ${year} ${h}:${m}:${s}Z`;
}

export function ZuluClock() {
  const [time, setTime] = useState(formatZulu);

  useEffect(() => {
    const id = setInterval(() => setTime(formatZulu()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <span className="font-mono text-xs text-aegis-muted rounded-none">
      {time}
      <span className="text-aegis-cyan ml-2">ZULU</span>
    </span>
  );
}
