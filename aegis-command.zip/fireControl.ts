import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { ROELevel, WeaponType, IFFIdentity } from '@aegis/shared';
import { authMiddleware } from '../auth/middleware';
import { fireControlService } from '../services/FireControlService';
import { cecEngine } from '../services/CECSensorFusionEngine';
import { logger } from '../logger';
import { config } from '../config';

const router = Router();

// ---------------------------------------------------------------------------
// Zod schemas
// ---------------------------------------------------------------------------

const airTrackSchema = z.object({
  trackId: z.string().min(1),
  jtidsTrackNum: z.number().int(),
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  altFt: z.number(),
  speedKts: z.number().min(0),
  headingDeg: z.number().min(0).max(360),
  iffIdentity: z.nativeEnum(IFFIdentity),
  trackQuality: z.number().int().min(0).max(7),
  trackSource: z.string(),
  cecSourceFlag: z.boolean(),
  classification: z.string().optional(),
  platformType: z.string().optional(),
});

const pkAssessmentSchema = z.object({
  trackId: z.string(),
  targetType: z.string(),
  aegisSensorQuality: z.number(),
  engagementGeometry: z.number(),
  environmentalDeg: z.number(),
  weaponCep: z.number(),
  weaponReliability: z.number(),
  guidance: z.string(),
  pkSingleShot: z.number(),
  pkFusing: z.number(),
  pkCCM: z.number(),
  pkFinal: z.number(),
  authChainComplete: z.boolean(),
  roeClearance: z.nativeEnum(ROELevel),
  pkComputedAt: z.string(),
});

const designateSchema = z.object({
  trackId: z.string().min(1),
  targetData: airTrackSchema,
  pkAssessment: pkAssessmentSchema,
  designatedBy: z.string().min(1),
  assignedTo: z.string().min(1),
  assignedCallsign: z.string().min(1),
  roeClearance: z.nativeEnum(ROELevel),
  expiresInMinutes: z.number().int().min(1).max(120).optional(),
});

const confirmSchema = z.object({
  designationId: z.string().min(1),
  operatorDid: z.string().min(1),
  selectedWeapon: z.nativeEnum(WeaponType),
});

const authorizeSchema = z.object({
  designationId: z.string().min(1),
});

const setRoeSchema = z.object({
  level: z.nativeEnum(ROELevel),
});

const historyQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(200).optional(),
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function apiResponse<T>(data: T, success = true) {
  return { success, data, timestamp: new Date().toISOString() };
}

function apiError(error: string, status: number, res: Response): void {
  res.status(status).json({ success: false, error, timestamp: new Date().toISOString() });
}

// ---------------------------------------------------------------------------
// GET /fire-control — full fire control state
// ---------------------------------------------------------------------------

router.get(
  '/',
  authMiddleware(),
  (_req: Request, res: Response): void => {
    try {
      const state = fireControlService.getState();
      res.json(apiResponse(state));
    } catch (err) {
      logger.error({ err }, 'Get fire control state error');
      apiError('Failed to retrieve fire control state', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /fire-control/roe — current ROE level
// ---------------------------------------------------------------------------

router.get(
  '/roe',
  authMiddleware(),
  (_req: Request, res: Response): void => {
    try {
      res.json(apiResponse({ roe: fireControlService.getROE() }));
    } catch (err) {
      logger.error({ err }, 'Get ROE error');
      apiError('Failed to retrieve ROE level', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// PUT /fire-control/roe — set ROE level (CO only in production)
// ---------------------------------------------------------------------------

router.put(
  '/roe',
  authMiddleware(),
  (req: Request, res: Response): void => {
    try {
      const parsed = setRoeSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      fireControlService.setROE(parsed.data.level);
      logger.info(
        { level: parsed.data.level, operatorId: req.operator?.sub },
        'ROE level updated',
      );
      res.json(apiResponse({ roe: parsed.data.level }));
    } catch (err) {
      logger.error({ err }, 'Set ROE error');
      apiError('Failed to set ROE level', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /fire-control/designate — Step 1: CO designates target
// ---------------------------------------------------------------------------

router.post(
  '/designate',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = designateSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const operator = req.operator;
      const body = parsed.data;

      if (!config.demoMode && body.designatedBy !== operator?.sub) {
        apiError('designatedBy must match the authenticated operator', 403, res);
        return;
      }

      const designation = await fireControlService.designateTarget({
        trackId: body.trackId,
        targetData: body.targetData as Parameters<typeof fireControlService.designateTarget>[0]['targetData'],
        pkAssessment: body.pkAssessment as Parameters<typeof fireControlService.designateTarget>[0]['pkAssessment'],
        designatedBy: body.designatedBy,
        assignedTo: body.assignedTo,
        assignedCallsign: body.assignedCallsign,
        roeClearance: body.roeClearance,
        expiresInMinutes: body.expiresInMinutes,
      });

      res.status(201).json(apiResponse(designation));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to designate target';
      logger.error({ err }, 'Designate target error');
      apiError(message, 400, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /fire-control/confirm — Step 2: Operator confirms designation
// ---------------------------------------------------------------------------

router.post(
  '/confirm',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = confirmSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const confirmation = await fireControlService.confirmDesignation(parsed.data);
      res.status(201).json(apiResponse(confirmation));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to confirm designation';
      logger.error({ err }, 'Confirm designation error');
      apiError(message, 400, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /fire-control/authorize — Step 3: Final fire authorization
// ---------------------------------------------------------------------------

router.post(
  '/authorize',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = authorizeSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const authorization = await fireControlService.authorizeStrike(parsed.data);
      res.status(201).json(apiResponse(authorization));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to authorize strike';
      logger.error({ err }, 'Authorize strike error');
      apiError(message, 400, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /fire-control/abort/:designationId — abort active authorization
// ---------------------------------------------------------------------------

router.post(
  '/abort/:designationId',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { designationId } = req.params;
      const reason = typeof req.body?.reason === 'string'
        ? req.body.reason
        : 'Abort requested by operator';

      await fireControlService.abortAuthorization(designationId, reason);
      logger.warn(
        { designationId, operatorId: req.operator?.sub, reason },
        'Fire authorization aborted via API',
      );
      res.json(apiResponse({ designationId, status: 'ABORTED', reason }));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to abort authorization';
      logger.error({ err }, 'Abort authorization error');
      apiError(message, 400, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /fire-control/chain/:designationId — full auth chain status
// ---------------------------------------------------------------------------

router.get(
  '/chain/:designationId',
  authMiddleware(),
  (req: Request, res: Response): void => {
    try {
      const { designationId } = req.params;
      const chain = fireControlService.getDesignationChain(designationId);
      res.json(apiResponse(chain));
    } catch (err) {
      logger.error({ err }, 'Get designation chain error');
      apiError('Failed to retrieve designation chain', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /fire-control/history — authorization history
// ---------------------------------------------------------------------------

router.get(
  '/history',
  authMiddleware(),
  (req: Request, res: Response): void => {
    try {
      const parsed = historyQuerySchema.safeParse(req.query);
      const limit = parsed.success ? parsed.data.limit : undefined;
      const history = fireControlService.getAuthorizationHistory(limit);
      res.json(apiResponse({ history, count: history.length }));
    } catch (err) {
      logger.error({ err }, 'Get authorization history error');
      apiError('Failed to retrieve authorization history', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /fire-control/tracks — hostile tracks with Pk assessments
// ---------------------------------------------------------------------------

router.get(
  '/tracks',
  authMiddleware(),
  (_req: Request, res: Response): void => {
    try {
      const tracksWithPk = fireControlService.getHostileTracksWithPk();
      const stats = cecEngine.getStats();
      res.json(apiResponse({
        tracks: tracksWithPk,
        hostileCount: stats.hostileCount,
        totalTracked: stats.totalTracks,
        roe: fireControlService.getROE(),
      }));
    } catch (err) {
      logger.error({ err }, 'Get hostile tracks error');
      apiError('Failed to retrieve hostile tracks', 500, res);
    }
  },
);

export { router as fireControlRouter };
