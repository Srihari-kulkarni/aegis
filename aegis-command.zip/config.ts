import { z } from 'zod';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().default('4000'),
  DATABASE_URL: z.string().default('postgresql://aegis:aegis_secret@localhost:5432/aegis_command'),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  HEDERA_ACCOUNT_ID: z.string().default('0.0.0000'),
  HEDERA_PRIVATE_KEY: z.string().default(''),
  HEDERA_NETWORK: z.enum(['testnet', 'mainnet', 'previewnet']).default('testnet'),
  OPENAI_API_KEY: z.string().default(''),
  OPENWEATHER_API_KEY: z.string().default(''),
  RAPIDAPI_KEY: z.string().default(''),
  AIRLABS_API_KEY: z.string().default(''),
  AEGIS_NODE_TYPE: z.enum(['COMMAND', 'FOB', 'MOBILE', 'EDGE']).default('FOB'),
  JWT_PRIVATE_KEY: z.string().optional(),
  JWT_PUBLIC_KEY: z.string().optional(),
  CORS_ORIGIN: z.string().default('http://localhost:3000'),
  DEMO_MODE: z.string().default('true'),
});

function getOrCreateKeyPair(): { privateKey: string; publicKey: string } {
  const keyDir = path.resolve(__dirname, '..', '.keys');
  const privPath = path.join(keyDir, 'jwt_private.pem');
  const pubPath = path.join(keyDir, 'jwt_public.pem');

  if (fs.existsSync(privPath) && fs.existsSync(pubPath)) {
    return {
      privateKey: fs.readFileSync(privPath, 'utf-8'),
      publicKey: fs.readFileSync(pubPath, 'utf-8'),
    };
  }

  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });

  if (!fs.existsSync(keyDir)) {
    fs.mkdirSync(keyDir, { recursive: true });
  }
  fs.writeFileSync(privPath, privateKey, { mode: 0o600 });
  fs.writeFileSync(pubPath, publicKey, { mode: 0o644 });
  return { privateKey, publicKey };
}

const parsed = envSchema.parse(process.env);

const keyPair = parsed.JWT_PRIVATE_KEY && parsed.JWT_PUBLIC_KEY
  ? { privateKey: parsed.JWT_PRIVATE_KEY, publicKey: parsed.JWT_PUBLIC_KEY }
  : getOrCreateKeyPair();

export const config = {
  env: parsed.NODE_ENV,
  port: parseInt(parsed.PORT, 10),
  databaseUrl: parsed.DATABASE_URL,
  redisUrl: parsed.REDIS_URL,
  hedera: {
    accountId: parsed.HEDERA_ACCOUNT_ID,
    privateKey: parsed.HEDERA_PRIVATE_KEY,
    network: parsed.HEDERA_NETWORK,
  },
  openai: {
    apiKey: parsed.OPENAI_API_KEY,
  },
  openWeather: {
    apiKey: parsed.OPENWEATHER_API_KEY,
  },
  rapidApiKey: parsed.RAPIDAPI_KEY,
  airLabsKey: parsed.AIRLABS_API_KEY,
  aegisNodeType: parsed.AEGIS_NODE_TYPE,
  jwt: {
    privateKey: keyPair.privateKey,
    publicKey: keyPair.publicKey,
    accessTokenExpiry: '15m',
    refreshTokenExpiry: '8h',
  },
  cors: {
    origin: parsed.CORS_ORIGIN,
  },
  demoMode: parsed.DEMO_MODE === 'true',
} as const;
