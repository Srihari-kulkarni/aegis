'use client';

const TOPIC_TIERS = [
  { tier: 0, name: 'Governance', topics: ['0.0.12345', '0.0.12346'] },
  { tier: 1, name: 'Mission', topics: ['0.0.23456', '0.0.23457', '0.0.23458'] },
  { tier: 2, name: 'Asset', topics: ['0.0.34567', '0.0.34568', '0.0.34569'] },
  { tier: 3, name: 'System', topics: ['0.0.45678', '0.0.45679', '0.0.45680'] },
];

const DEMO_MESSAGES = [
  { seq: 1001, ts: '2025-03-09T14:32:01.123Z', topic: '0.0.23456', type: 'TARGET_DESIGNATION', preview: '{"trackId":"TRK-001","designatedBy":"did:hedera:..."}', did: 'did:hedera:testnet:0.0.1234' },
  { seq: 1002, ts: '2025-03-09T14:32:05.456Z', topic: '0.0.23456', type: 'FIRE_AUTHORIZATION', preview: '{"designationId":"hcs-abc123","status":"AUTHORIZED"}', did: 'did:hedera:testnet:0.0.5678' },
  { seq: 1003, ts: '2025-03-09T14:32:08.789Z', topic: '0.0.34567', type: 'TRACK_UPDATE', preview: '{"trackId":"TRK-002","lat":32.45,"lon":44.38}', did: 'did:hedera:testnet:0.0.9012' },
  { seq: 1004, ts: '2025-03-09T14:32:12.012Z', topic: '0.0.34568', type: 'ARSENAL_CHANGE', preview: '{"callsign":"VIPER-01","weapon":"GBU-31","qty":-1}', did: 'did:hedera:testnet:0.0.3456' },
  { seq: 1005, ts: '2025-03-09T14:32:15.234Z', topic: '0.0.12345', type: 'DID_CREDENTIAL_EVENT', preview: '{"action":"VERIFY","subject":"did:hedera:..."}', did: 'did:hedera:testnet:0.0.1234' },
  { seq: 1006, ts: '2025-03-09T14:32:18.567Z', topic: '0.0.45678', type: 'PPLI_BROADCAST', preview: '{"callsign":"SENTRY-01","lat":32.40,"lon":44.32}', did: 'did:hedera:testnet:0.0.7890' },
  { seq: 1007, ts: '2025-03-09T14:32:22.890Z', topic: '0.0.23456', type: 'TARGET_DESIGNATION', preview: '{"trackId":"TRK-003","designatedBy":"did:hedera:..."}', did: 'did:hedera:testnet:0.0.1234' },
  { seq: 1008, ts: '2025-03-09T14:32:26.123Z', topic: '0.0.34567', type: 'TRACK_UPDATE', preview: '{"trackId":"TRK-001","fusionQuality":0.92}', did: 'did:hedera:testnet:0.0.9012' },
  { seq: 1009, ts: '2025-03-09T14:32:29.456Z', topic: '0.0.23457', type: 'FIRE_AUTHORIZATION', preview: '{"designationId":"hcs-def456","status":"EXECUTED"}', did: 'did:hedera:testnet:0.0.5678' },
  { seq: 1010, ts: '2025-03-09T14:32:32.789Z', topic: '0.0.45679', type: 'PPLI_BROADCAST', preview: '{"callsign":"VIPER-01","heading":185}', did: 'did:hedera:testnet:0.0.7890' },
  { seq: 1011, ts: '2025-03-09T14:32:36.012Z', topic: '0.0.34568', type: 'ARSENAL_CHANGE', preview: '{"callsign":"REAPER-01","weapon":"AGM-114","qty":-1}', did: 'did:hedera:testnet:0.0.3456' },
  { seq: 1012, ts: '2025-03-09T14:32:39.234Z', topic: '0.0.12346', type: 'DID_CREDENTIAL_EVENT', preview: '{"action":"REVOKE","subject":"did:hedera:..."}', did: 'did:hedera:testnet:0.0.1234' },
  { seq: 1013, ts: '2025-03-09T14:32:42.567Z', topic: '0.0.23458', type: 'TRACK_UPDATE', preview: '{"trackId":"TRK-004","iffIdentity":"FRIEND"}', did: 'did:hedera:testnet:0.0.9012' },
  { seq: 1014, ts: '2025-03-09T14:32:45.890Z', topic: '0.0.45680', type: 'PPLI_BROADCAST', preview: '{"callsign":"PEGASUS-01","altFt":25000}', did: 'did:hedera:testnet:0.0.7890' },
  { seq: 1015, ts: '2025-03-09T14:32:49.123Z', topic: '0.0.23456', type: 'TARGET_DESIGNATION', preview: '{"trackId":"TRK-005","assignedCallsign":"VIPER-02"}', did: 'did:hedera:testnet:0.0.1234' },
];

function formatTs(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toISOString().replace('T', ' ').replace(/\.\d{3}Z$/, 'Z');
  } catch {
    return iso;
  }
}


export default function HCSAuditExplorerPage() {
  const msgCount = DEMO_MESSAGES.length;
  const costPerMsg = 0.0001;
  const estimatedCost = (msgCount * costPerMsg).toFixed(4);
  const budgetRemaining = (100 - msgCount * costPerMsg).toFixed(2);

  return (
    <div className="h-full flex flex-col bg-[#030508] font-mono text-sm overflow-hidden">
      {/* Header */}
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
        <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-[#00d4ff] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
          HCS AUDIT EXPLORER // HEDERA CONSENSUS SERVICE
        </h1>
      </header>

      <div className="flex-1 flex min-h-0">
        {/* Left: Topic hierarchy */}
        <aside className="w-56 shrink-0 border-r border-[#0a1828] p-4 overflow-y-auto">
          <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-3">
            TOPIC HIERARCHY
          </div>
          {TOPIC_TIERS.map(({ tier, name, topics }) => (
            <div key={tier} className="mb-4">
              <div className="font-mono text-[10px] text-[#ffd60a] mb-1">
                Tier {tier}: {name}
              </div>
              <div className="space-y-1 pl-2 border-l border-[#0a1828]">
                {topics.map((t) => (
                  <a
                    key={t}
                    href={`https://hashscan.io/testnet/topic/${t}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block font-mono text-[9px] text-[#00d4ff] hover:text-[#00ff99] hover:underline"
                  >
                    {t}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </aside>

        {/* Center: Message log */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
            <span className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              MESSAGE LOG
            </span>
          </div>
          <div className="flex-1 overflow-auto">
            <table className="w-full border-collapse text-[11px]">
              <thead className="sticky top-0 bg-[#060b10] z-10">
                <tr className="border-b border-[#0a1828]">
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Sequence #</th>
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Consensus Timestamp</th>
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Topic</th>
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Message Type</th>
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Payload Preview</th>
                  <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Originator DID</th>
                </tr>
              </thead>
              <tbody>
                {DEMO_MESSAGES.map((m) => (
                  <tr key={m.seq} className="border-b border-[#0a1828]/50 hover:bg-[#060b10]">
                    <td className="px-3 py-2 text-[#e8eaf0]">{m.seq}</td>
                    <td className="px-3 py-2 text-[#6688aa]">{formatTs(m.ts)}</td>
                    <td className="px-3 py-2">
                      <a
                        href={`https://hashscan.io/testnet/topic/${m.topic}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#00d4ff] hover:text-[#00ff99] hover:underline"
                      >
                        {m.topic}
                      </a>
                    </td>
                    <td className="px-3 py-2">
                      <span className={
                        m.type === 'FIRE_AUTHORIZATION' ? 'text-[#ff2d55]' :
                        m.type === 'TARGET_DESIGNATION' ? 'text-[#ffd60a]' :
                        m.type === 'PPLI_BROADCAST' ? 'text-[#00ff99]' :
                        'text-[#e8eaf0]'
                      }>
                        {m.type}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-[#6688aa] max-w-xs truncate" title={m.preview}>
                      {m.preview}
                    </td>
                    <td className="px-3 py-2 text-[#6688aa] max-w-[180px] truncate" title={m.did}>
                      {m.did}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>

        {/* Right: Fee budget */}
        <aside className="w-52 shrink-0 border-l border-[#0a1828] p-4">
          <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-3">
            FEE BUDGET
          </div>
          <div className="space-y-3 border border-[#0a1828] bg-[#060b10] p-3">
            <div className="flex justify-between">
              <span className="font-mono text-[10px] text-[#6688aa]">Messages this mission</span>
              <span className="font-mono text-[10px] text-[#e8eaf0] font-semibold">{msgCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-mono text-[10px] text-[#6688aa]">Estimated cost ($0.0001/msg)</span>
              <span className="font-mono text-[10px] text-[#ffd60a]">${estimatedCost}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-[#0a1828]">
              <span className="font-mono text-[10px] text-[#6688aa]">Budget remaining</span>
              <span className="font-mono text-[10px] text-[#00ff99] font-semibold">${budgetRemaining}</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
