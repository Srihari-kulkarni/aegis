'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/stores/authStore';
import { apiGet, apiPost, apiPut } from '@/lib/api';
import {
  type FireControlState,
  type FusedTrack,
  type PkAssessment,
  type TargetDesignation,
  type OperatorConfirmation,
  type FireAuthorization,
  type WeaponLoadout,
  ROELevel,
  FireAuthStatus,
  IFFIdentity,
  IFF_COLORS,
  STRIKE_PACKAGE,
  TRACK_SYMBOLOGY,
} from '@aegis/shared';

const POLL_INTERVAL = 3000;

interface HostileTrack extends FusedTrack {
  pk?: PkAssessment;
}

interface TracksResponse {
  tracks: HostileTrack[];
}

interface ROEResponse {
  roe: ROELevel;
}

export default function FireControlPage() {
  const router = useRouter();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isLoading = useAuthStore((s) => s.isLoading);
  const operator = useAuthStore((s) => s.operator);

  const [fcState, setFcState] = useState<FireControlState | null>(null);
  const [tracks, setTracks] = useState<HostileTrack[]>([]);
  const [currentROE, setCurrentROE] = useState<ROELevel>(ROELevel.WEAPONS_HOLD);
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAllData = useCallback(async () => {
    try {
      const [stateRes, tracksRes, roeRes] = await Promise.all([
        apiGet<FireControlState>('/api/v1/fire-control'),
        apiGet<TracksResponse>('/api/v1/fire-control/tracks'),
        apiGet<ROEResponse>('/api/v1/fire-control/roe'),
      ]);

      if (stateRes.success && stateRes.data) setFcState(stateRes.data);
      if (tracksRes.success && tracksRes.data) setTracks(tracksRes.data.tracks ?? []);
      if (roeRes.success && roeRes.data) setCurrentROE(roeRes.data.roe ?? ROELevel.WEAPONS_HOLD);
    } catch {
      setError('LINK DEGRADED — RETRY');
    }
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetchAllData();
    pollRef.current = setInterval(fetchAllData, POLL_INTERVAL);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [isAuthenticated, fetchAllData]);

  const doAction = useCallback(async (label: string, fn: () => Promise<unknown>) => {
    setActionLoading(label);
    setError(null);
    try {
      await fn();
      await fetchAllData();
    } catch {
      setError(`${label} FAILED`);
    } finally {
      setActionLoading(null);
    }
  }, [fetchAllData]);

  const handleDesignate = useCallback((trackId: string) => {
    doAction('DESIGNATE', () => apiPost('/api/v1/fire-control/designate', { trackId }));
  }, [doAction]);

  const handleConfirm = useCallback((designationId: string) => {
    doAction('CONFIRM', () => apiPost('/api/v1/fire-control/confirm', { designationId }));
  }, [doAction]);

  const handleAuthorize = useCallback((designationId: string) => {
    doAction('AUTHORIZE', () => apiPost('/api/v1/fire-control/authorize', { designationId }));
  }, [doAction]);

  const handleAbort = useCallback((designationId: string) => {
    doAction('ABORT', () => apiPost(`/api/v1/fire-control/abort/${designationId}`));
  }, [doAction]);

  const handleROEChange = useCallback((roe: ROELevel) => {
    doAction('ROE', () => apiPut('/api/v1/fire-control/roe', { roe }));
  }, [doAction]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="h-full bg-[#030508] flex items-center justify-center">
        <div className="font-mono text-aegis-muted text-sm animate-pulse">
          INITIALIZING FIRE CONTROL SYSTEM...
        </div>
      </div>
    );
  }

  const selectedTrack = tracks.find((t) => t.trackId === selectedTrackId);
  const activeDesignation = fcState?.activeDesignations?.find(
    (d) => d.trackId === selectedTrackId
  );
  const pendingConfirmation = fcState?.pendingConfirmations?.find(
    (c) => c.designationId === activeDesignation?.hcsMessageId
  );
  const authorization = fcState?.authorizations?.find(
    (a) => a.designationId === activeDesignation?.hcsMessageId
  );

  const strikeAssets = STRIKE_PACKAGE.filter((a) => a.weapons.length > 0);

  return (
    <div className="h-full flex flex-col bg-[#030508] relative overflow-hidden">
      {/* CRT scanline overlay */}
      <div className="pointer-events-none absolute inset-0 z-50 crt-scanlines" />

      {/* Header bar */}
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-aegis-cyan drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
            FIRE CONTROL
          </h1>
          <span className="font-mono text-[10px] text-aegis-muted">//</span>
          <span className="font-mono text-xs text-aegis-text">
            TARGET: {selectedTrack ? (
              <span className="text-aegis-red">{selectedTrack.classification ?? selectedTrack.trackId}</span>
            ) : (
              <span className="text-aegis-muted">NO SELECTION</span>
            )}
          </span>
          <span className="font-mono text-[10px] text-aegis-muted">//</span>
          <span className="font-mono text-xs text-aegis-muted">
            J3.2 TRACK: {selectedTrack?.jtidsTrackNum ?? '----'}
          </span>
        </div>

        <div className="flex items-center gap-4">
          {/* ROE selector */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] text-aegis-muted tracking-wider">ROE:</span>
            <select
              value={currentROE}
              onChange={(e) => handleROEChange(e.target.value as ROELevel)}
              className="bg-[#030508] border border-[#0a1828] text-xs font-mono px-2 py-1 text-aegis-text focus:outline-none focus:border-aegis-cyan"
              disabled={actionLoading === 'ROE'}
            >
              <option value={ROELevel.WEAPONS_FREE}>WEAPONS FREE</option>
              <option value={ROELevel.WEAPONS_TIGHT}>WEAPONS TIGHT</option>
              <option value={ROELevel.WEAPONS_HOLD}>WEAPONS HOLD</option>
            </select>
          </div>

          <ROEBadge roe={currentROE} />

          <span className="font-mono text-[10px] text-aegis-cyan">
            {operator?.callsign ?? '—'}
          </span>
        </div>
      </header>

      {error && (
        <div className="shrink-0 px-4 py-1 bg-aegis-red/10 border-b border-aegis-red/30 font-mono text-[10px] text-aegis-red tracking-wider">
          ⚠ {error}
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex min-h-0">
        {/* Track list sidebar */}
        <aside className="w-56 shrink-0 border-r border-[#0a1828] flex flex-col overflow-hidden">
          <div className="px-3 py-2 border-b border-[#0a1828]">
            <div className="font-mono text-[10px] text-aegis-cyan tracking-[0.2em] drop-shadow-[0_0_6px_rgba(0,212,255,0.3)]">
              HOSTILE TRACKS
            </div>
            <div className="font-mono text-[9px] text-aegis-muted mt-0.5">
              {tracks.length} TRACK{tracks.length !== 1 ? 'S' : ''} //
              SPY-1D FEED
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {tracks.length === 0 && (
              <div className="p-3 font-mono text-[10px] text-aegis-muted text-center">
                NO HOSTILE TRACKS
              </div>
            )}
            {tracks.map((track) => (
              <button
                key={track.trackId}
                type="button"
                onClick={() => setSelectedTrackId(track.trackId)}
                className={`w-full text-left px-3 py-2 border-b border-[#0a1828]/50 transition-colors ${
                  selectedTrackId === track.trackId
                    ? 'bg-aegis-cyan/5 border-l-2 border-l-aegis-cyan'
                    : 'hover:bg-[#0a1828]/50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] font-semibold" style={{ color: IFF_COLORS[track.iffIdentity] }}>
                    {TRACK_SYMBOLOGY[track.trackSource]?.symbol ?? '?'}{' '}
                    {track.classification ?? track.trackId}
                  </span>
                  <span className="font-mono text-[9px] text-aegis-muted">
                    {track.jtidsTrackNum}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <span className="font-mono text-[9px] text-aegis-muted">
                    {track.platformType ?? 'UNK'} // {track.trackSource}
                  </span>
                  {track.pk && (
                    <PkMini value={track.pk.pkFinal} />
                  )}
                </div>
              </button>
            ))}
          </div>
        </aside>

        {/* Center panels */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="flex-1 flex min-h-0">
            {/* Left: Target Assessment */}
            <div className="flex-1 border-r border-[#0a1828] overflow-y-auto p-4">
              <PanelHeading>AEGIS TARGET ASSESSMENT</PanelHeading>

              {!selectedTrack ? (
                <div className="mt-8 text-center font-mono text-xs text-aegis-muted">
                  SELECT A HOSTILE TRACK TO VIEW ASSESSMENT
                </div>
              ) : (
                <div className="mt-3 space-y-4">
                  {/* Pk composite bar */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[10px] text-aegis-muted tracking-wider">Pk (COMPOSITE)</span>
                      <span className="font-mono text-sm font-bold" style={{ color: pkColor(selectedTrack.pk?.pkFinal ?? 0) }}>
                        {(selectedTrack.pk?.pkFinal ?? 0).toFixed(2)}
                      </span>
                    </div>
                    <PkBar value={selectedTrack.pk?.pkFinal ?? 0} />
                  </div>

                  {/* Pk component bars */}
                  <div className="grid grid-cols-3 gap-3">
                    <PkComponent label="P(HIT)" value={selectedTrack.pk?.pkSingleShot ?? 0} />
                    <PkComponent label="P(FUSE)" value={selectedTrack.pk?.pkFusing ?? 0} />
                    <PkComponent label="P(CCM)" value={selectedTrack.pk?.pkCCM ?? 0} />
                  </div>

                  {/* Sensor metrics */}
                  <div className="border border-[#0a1828] p-3 space-y-2">
                    <DataRow label="SPY-1D Quality" value={
                      <span>
                        {selectedTrack.pk?.aegisSensorQuality ?? 0}/7{' '}
                        <QualityDots count={selectedTrack.pk?.aegisSensorQuality ?? 0} max={7} />
                      </span>
                    } />
                    <DataRow label="Geometry" value={(selectedTrack.pk?.engagementGeometry ?? 0).toFixed(2)} />
                    <DataRow label="ECM Degradation" value={(selectedTrack.ecmDegradation ?? 0).toFixed(2)} />
                    <DataRow label="Env Degradation" value={(selectedTrack.pk?.environmentalDeg ?? 0).toFixed(2)} />
                  </div>

                  {/* Target info */}
                  <div className="border border-[#0a1828] p-3 space-y-2">
                    <DataRow label="Target" value={
                      <span className="text-aegis-red">{selectedTrack.platformType ?? 'UNKNOWN'} {selectedTrack.classification ?? ''}</span>
                    } />
                    <DataRow label="Track Source" value={selectedTrack.trackSource} />
                    <DataRow label="Classification" value={
                      <span style={{ color: IFF_COLORS[selectedTrack.iffIdentity] }}>
                        {selectedTrack.iffIdentity}
                      </span>
                    } />
                    <DataRow label="ROE Status" value={<ROEBadge roe={currentROE} />} />
                    <DataRow label="Threat Priority" value={selectedTrack.threatPriority} />
                    <DataRow label="Position" value={
                      `${selectedTrack.lat.toFixed(4)}°N ${selectedTrack.lon.toFixed(4)}°E  FL${Math.round(selectedTrack.altFt / 100)}`
                    } />
                    <DataRow label="Speed / Hdg" value={
                      `${selectedTrack.speedKts} KTS / ${selectedTrack.headingDeg.toFixed(0)}°`
                    } />
                  </div>

                  {/* Designate button */}
                  {!activeDesignation && selectedTrack.iffIdentity === IFFIdentity.HOSTILE && (
                    <button
                      type="button"
                      onClick={() => handleDesignate(selectedTrack.trackId)}
                      disabled={actionLoading !== null || currentROE === ROELevel.WEAPONS_HOLD}
                      className="tactical-btn-primary w-full py-3 text-sm tracking-[0.2em]"
                    >
                      {actionLoading === 'DESIGNATE' ? 'DESIGNATING...' : 'DESIGNATE TARGET'}
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Right: Arsenal Status */}
            <div className="flex-1 overflow-y-auto p-4">
              <PanelHeading>DRONE ARSENAL STATUS <span className="text-aegis-muted text-[9px] ml-2">[from HCS ledger]</span></PanelHeading>

              <div className="mt-3 space-y-3">
                {strikeAssets.map((asset) => (
                  <ArsenalCard key={asset.callsign} asset={asset} />
                ))}
              </div>
            </div>
          </div>

          {/* Bottom: Authorization Chain */}
          <div className="shrink-0 border-t border-[#0a1828] p-4 max-h-[40%] overflow-y-auto">
            <AuthorizationChain
              designation={activeDesignation ?? null}
              confirmation={pendingConfirmation ?? null}
              authorization={authorization ?? null}
              onConfirm={handleConfirm}
              onAuthorize={handleAuthorize}
              onAbort={handleAbort}
              onReAssess={() => setSelectedTrackId(null)}
              actionLoading={actionLoading}
              selectedTrack={selectedTrack ?? null}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Sub-components ────────────────────────────────────────────────── */

function PanelHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="font-mono text-[11px] font-bold tracking-[0.2em] text-aegis-cyan drop-shadow-[0_0_6px_rgba(0,212,255,0.3)] uppercase">
      {children}
    </h2>
  );
}

function pkColor(value: number): string {
  if (value >= 0.8) return '#32d74b';
  if (value >= 0.5) return '#ffd60a';
  return '#ff2d55';
}

function PkBar({ value }: { value: number }) {
  const pct = Math.min(value * 100, 100);
  return (
    <div className="h-3 bg-[#0a1828] w-full relative overflow-hidden">
      <div
        className="h-full transition-all duration-500"
        style={{
          width: `${pct}%`,
          background: `linear-gradient(90deg, #ff2d55 0%, #ffd60a 50%, #32d74b 100%)`,
          backgroundSize: '200% 100%',
          backgroundPosition: `${100 - pct}% 0`,
        }}
      />
      <div className="absolute inset-0 flex items-center justify-end pr-1">
        <span className="font-mono text-[8px] text-white/80 font-bold drop-shadow-[0_0_2px_rgba(0,0,0,1)]">
          {value.toFixed(2)}
        </span>
      </div>
    </div>
  );
}

function PkComponent({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="font-mono text-[9px] text-aegis-muted">{label}</span>
        <span className="font-mono text-[10px] font-semibold" style={{ color: pkColor(value) }}>
          {value.toFixed(2)}
        </span>
      </div>
      <div className="h-1.5 bg-[#0a1828]">
        <div
          className="h-full transition-all duration-500"
          style={{
            width: `${Math.min(value * 100, 100)}%`,
            backgroundColor: pkColor(value),
          }}
        />
      </div>
    </div>
  );
}

function PkMini({ value }: { value: number }) {
  return (
    <span className="font-mono text-[9px] font-bold" style={{ color: pkColor(value) }}>
      Pk {value.toFixed(2)}
    </span>
  );
}

function QualityDots({ count, max }: { count: number; max: number }) {
  return (
    <span className="inline-flex gap-0.5 ml-1">
      {Array.from({ length: max }, (_, i) => (
        <span
          key={i}
          className={`inline-block w-1.5 h-1.5 ${
            i < count ? 'bg-aegis-green' : 'bg-[#0a1828]'
          }`}
        />
      ))}
    </span>
  );
}

function DataRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="font-mono text-[10px] text-aegis-muted tracking-wider">{label}:</span>
      <span className="font-mono text-[11px] text-aegis-text">{value}</span>
    </div>
  );
}

function ROEBadge({ roe }: { roe: ROELevel }) {
  const config: Record<ROELevel, { color: string; label: string }> = {
    [ROELevel.WEAPONS_FREE]: { color: 'text-aegis-red border-aegis-red bg-aegis-red/10', label: 'WEAPONS FREE' },
    [ROELevel.WEAPONS_TIGHT]: { color: 'text-aegis-amber border-aegis-amber bg-aegis-amber/10', label: 'WEAPONS TIGHT' },
    [ROELevel.WEAPONS_HOLD]: { color: 'text-aegis-green border-aegis-green bg-aegis-green/10', label: 'WEAPONS HOLD' },
  };
  const c = config[roe];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 border font-mono text-[9px] tracking-wider ${c.color}`}>
      {c.label}
    </span>
  );
}

function ArsenalCard({ asset }: { asset: typeof STRIKE_PACKAGE[number] }) {
  return (
    <div className="border border-[#0a1828] p-3">
      <div className="flex items-center justify-between mb-2">
        <span className="font-mono text-[11px] font-bold text-aegis-cyan">
          {asset.callsign}
        </span>
        <span className="font-mono text-[10px] text-aegis-muted">
          {asset.platform}
        </span>
      </div>
      <div className="space-y-1">
        {asset.weapons.map((w, i) => (
          <WeaponRow key={`${asset.callsign}-${i}`} weapon={w} isLast={i === asset.weapons.length - 1} />
        ))}
      </div>
      <div className="mt-2 flex items-center justify-between">
        <span className="font-mono text-[9px] text-aegis-muted">
          TOTAL: {asset.weapons.reduce((s, w) => s + w.quantity, 0)} ORDNANCE
        </span>
        <span className="font-mono text-[9px] text-aegis-muted">
          {asset.role}
        </span>
      </div>
    </div>
  );
}

function WeaponRow({ weapon, isLast }: { weapon: WeaponLoadout; isLast: boolean }) {
  return (
    <div className="flex items-center gap-2 pl-2">
      <span className="font-mono text-[10px] text-aegis-muted">{isLast ? '└─' : '├─'}</span>
      <span className="font-mono text-[10px] text-aegis-text flex-1">
        {weapon.weapon}
      </span>
      <span className="font-mono text-[9px] text-aegis-amber">×{weapon.quantity}</span>
      <span className="font-mono text-[9px] text-aegis-muted">
        CEP: {weapon.cepMeters}m
      </span>
      <span className="font-mono text-[9px] text-aegis-muted">
        {weapon.guidance}
      </span>
    </div>
  );
}

/* ─── Authorization Chain ───────────────────────────────────────────── */

interface AuthChainProps {
  designation: TargetDesignation | null;
  confirmation: OperatorConfirmation | null;
  authorization: FireAuthorization | null;
  onConfirm: (id: string) => void;
  onAuthorize: (id: string) => void;
  onAbort: (id: string) => void;
  onReAssess: () => void;
  actionLoading: string | null;
  selectedTrack: HostileTrack | null;
}

function AuthorizationChain({
  designation,
  confirmation,
  authorization,
  onConfirm,
  onAuthorize,
  onAbort,
  onReAssess,
  actionLoading,
  selectedTrack,
}: AuthChainProps) {
  const desigId = designation?.hcsMessageId;

  const step1Status = designation ? 'complete' : 'pending';
  const step2Status = confirmation ? 'complete' : designation ? 'pending' : 'locked';
  const step3Status = authorization?.status === FireAuthStatus.AUTHORIZED
    ? 'complete'
    : authorization?.status === FireAuthStatus.ABORTED
      ? 'failed'
      : confirmation ? 'pending' : 'locked';

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <PanelHeading>AUTHORIZATION CHAIN</PanelHeading>
        {designation && (
          <span className="font-mono text-[9px] text-aegis-muted">
            [Hedera HCS — Topic: {designation.hcsMessageId ?? 'N/A'}]
          </span>
        )}
      </div>

      {!selectedTrack ? (
        <div className="font-mono text-[10px] text-aegis-muted text-center py-4">
          SELECT A TRACK AND DESIGNATE TO BEGIN AUTHORIZATION CHAIN
        </div>
      ) : (
        <div className="space-y-3">
          {/* Step 1 */}
          <AuthStep
            step={1}
            label="Aegis CO Designation"
            status={step1Status}
            hcsRef={designation?.hcsMessageId}
            consensusTs={designation?.consensusTimestamp}
            did={designation?.designatedBy}
          />

          {/* Step 2 */}
          <AuthStep
            step={2}
            label="Operator Confirmation"
            status={step2Status}
            hcsRef={confirmation?.hcsMessageId}
            consensusTs={confirmation?.consensusTimestamp}
            did={confirmation?.operatorDid}
          />

          {/* Step 3 */}
          <AuthStep
            step={3}
            label="FIRE AUTHORIZATION"
            status={step3Status}
            hcsRef={authorization?.hcsMessageId}
            consensusTs={authorization?.consensusTimestamp}
            did={authorization?.authorizedBy?.[0]}
          />

          {/* Action buttons */}
          <div className="flex items-center gap-3 mt-4 pt-3 border-t border-[#0a1828]">
            {/* Show confirm if step 1 done but step 2 not */}
            {designation && !confirmation && (
              <button
                type="button"
                onClick={() => desigId && onConfirm(desigId)}
                disabled={actionLoading !== null}
                className="tactical-btn-primary py-2.5 px-5 text-[11px] tracking-[0.15em]"
              >
                {actionLoading === 'CONFIRM' ? 'CONFIRMING...' : 'CONFIRM DESIGNATION'}
              </button>
            )}

            {/* Show authorize if step 2 done but step 3 not */}
            {confirmation && step3Status === 'pending' && (
              <button
                type="button"
                onClick={() => desigId && onAuthorize(desigId)}
                disabled={actionLoading !== null}
                className="px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.15em] border-2 border-aegis-red text-aegis-red bg-aegis-red/5 hover:bg-aegis-red hover:text-white transition-colors animate-pulse-slow"
              >
                {actionLoading === 'AUTHORIZE' ? 'AUTHORIZING...' : `AUTHORIZE STRIKE — ${designation?.assignedCallsign ?? ''} / ${designation?.pkAssessment?.guidance ?? ''}`}
              </button>
            )}

            {/* Abort always available if there's a designation */}
            {designation && authorization?.status !== FireAuthStatus.ABORTED && (
              <button
                type="button"
                onClick={() => desigId && onAbort(desigId)}
                disabled={actionLoading !== null}
                className="tactical-btn-danger py-2.5 px-5 text-[11px] tracking-[0.15em]"
              >
                {actionLoading === 'ABORT' ? 'ABORTING...' : 'ABORT'}
              </button>
            )}

            {/* Re-assess */}
            {designation && (
              <button
                type="button"
                onClick={onReAssess}
                className="tactical-btn py-2.5 px-5 text-[11px] tracking-[0.15em]"
              >
                RE-ASSESS
              </button>
            )}
          </div>

          {/* Hashscan link */}
          {(designation?.hcsMessageId || authorization?.hcsMessageId) && (
            <div className="mt-2 flex items-center gap-2">
              <span className="font-mono text-[9px] text-aegis-muted">HASHSCAN:</span>
              <a
                href={`https://hashscan.io/testnet/transaction/${authorization?.hcsMessageId ?? designation?.hcsMessageId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-[9px] text-aegis-cyan hover:underline"
              >
                https://hashscan.io/testnet/transaction/{(authorization?.hcsMessageId ?? designation?.hcsMessageId ?? '').slice(0, 24)}...
              </a>
              <span className="font-mono text-[9px] text-aegis-cyan border border-aegis-cyan/30 px-1.5 py-0.5 hover:bg-aegis-cyan/10 cursor-pointer">
                VERIFY ON CHAIN
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function AuthStep({
  step,
  label,
  status,
  hcsRef,
  consensusTs,
  did,
}: {
  step: number;
  label: string;
  status: 'complete' | 'pending' | 'failed' | 'locked';
  hcsRef?: string;
  consensusTs?: string;
  did?: string;
}) {
  const icon = status === 'complete' ? '✓' : status === 'failed' ? '✗' : '○';
  const iconColor =
    status === 'complete'
      ? 'text-aegis-green'
      : status === 'failed'
        ? 'text-aegis-red'
        : status === 'pending'
          ? 'text-aegis-amber'
          : 'text-aegis-muted';
  const labelColor = status === 'locked' ? 'text-aegis-muted/50' : 'text-aegis-text';
  const borderColor =
    status === 'complete'
      ? 'border-aegis-green/30'
      : status === 'failed'
        ? 'border-aegis-red/30'
        : status === 'pending'
          ? 'border-aegis-amber/30'
          : 'border-[#0a1828]';

  return (
    <div className={`border ${borderColor} p-3 ${status === 'locked' ? 'opacity-40' : ''}`}>
      <div className="flex items-start gap-3">
        <span className={`font-mono text-sm font-bold ${iconColor}`}>[{icon}]</span>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={`font-mono text-[10px] tracking-wider ${iconColor}`}>STEP {step}</span>
            <span className={`font-mono text-[11px] font-semibold ${labelColor}`}>{label}</span>
            {status === 'pending' && (
              <span className="font-mono text-[9px] text-aegis-amber tracking-wider animate-pulse">
                PENDING
              </span>
            )}
            {status === 'complete' && (
              <span className="font-mono text-[9px] text-aegis-green tracking-wider">
                VERIFIED
              </span>
            )}
          </div>
          {(hcsRef || did) && (
            <div className="mt-1 space-y-0.5">
              {hcsRef && (
                <div className="font-mono text-[9px] text-aegis-muted">
                  HCS: {hcsRef}@{consensusTs ?? '---'}
                </div>
              )}
              {did && (
                <div className="font-mono text-[9px] text-aegis-muted">
                  DID: {did.length > 40 ? `${did.slice(0, 35)}...` : did}
                  <span className={`ml-2 ${status === 'complete' ? 'text-aegis-green' : 'text-aegis-muted'}`}>
                    Sig: {status === 'complete' ? '✓ VERIFIED' : '...'}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

