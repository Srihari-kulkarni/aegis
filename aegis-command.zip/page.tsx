'use client';

import { useEffect, useState, useRef } from 'react';

const J_MESSAGE_MAP = [
  { code: 'J0.0', desc: 'Initial Entry', npg: 'NPG-1', dir: 'BOTH' },
  { code: 'J2.2', desc: 'PPLI', npg: 'NPG-5/6', dir: 'BOTH' },
  { code: 'J3.2', desc: 'Air Track', npg: 'NPG-7', dir: 'BOTH' },
  { code: 'J3.7', desc: 'EW Product', npg: 'NPG-10', dir: 'RX' },
  { code: 'J6.0', desc: 'Intel Info', npg: 'NPG-14', dir: 'RX' },
  { code: 'J7.0', desc: 'Weapon Coord A', npg: 'NPG-7', dir: 'TX' },
  { code: 'J12.0', desc: 'Mission Assign', npg: 'NPG-12', dir: 'BOTH' },
  { code: 'J12.6', desc: 'Engagement Coord', npg: 'NPG-12', dir: 'BOTH' },
  { code: 'J13.2', desc: 'Platform Status', npg: 'NPG-12', dir: 'TX' },
];

const NPGS = ['NPG-1', 'NPG-5', 'NPG-6', 'NPG-7', 'NPG-10', 'NPG-12', 'NPG-14'];

const CALLSIGNS = [
  'GHOST-01', 'SENTRY-01', 'VIPER-01', 'VIPER-02', 'VIPER-03',
  'REAPER-01', 'REAPER-02', 'ATLAS-01', 'PEGASUS-01', 'PEGASUS-02',
];

const J_TYPES = ['J2.2', 'J3.2', 'J3.7', 'J6.0', 'J7.0', 'J12.0', 'J12.6', 'J13.2'];

interface JMessage {
  id: string;
  timestamp: string;
  type: string;
  callsign: string;
  npg: string;
}

function formatZulu(): string {
  const d = new Date();
  const h = String(d.getUTCHours()).padStart(2, '0');
  const m = String(d.getUTCMinutes()).padStart(2, '0');
  const s = String(d.getUTCSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}Z`;
}

export default function Link16MonitorPage() {
  const [messages, setMessages] = useState<JMessage[]>([]);
  const [ppliTimes, setPpliTimes] = useState<Record<string, string>>({});
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const addMessage = () => {
      const type = J_TYPES[Math.floor(Math.random() * J_TYPES.length)];
      const callsign = CALLSIGNS[Math.floor(Math.random() * CALLSIGNS.length)];
      const npgMap: Record<string, string> = {
        'J2.2': 'NPG-5',
        'J3.2': 'NPG-7',
        'J3.7': 'NPG-10',
        'J6.0': 'NPG-14',
        'J7.0': 'NPG-7',
        'J12.0': 'NPG-12',
        'J12.6': 'NPG-12',
        'J13.2': 'NPG-12',
      };
      const msg: JMessage = {
        id: `j-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        timestamp: formatZulu(),
        type,
        callsign,
        npg: npgMap[type] ?? 'NPG-7',
      };
      setMessages((prev) => [msg, ...prev].slice(0, 50));
      if (type === 'J2.2' && callsign !== 'GHOST-01') {
        setPpliTimes((prev) => ({ ...prev, [callsign]: formatZulu() }));
      }
    };
    addMessage();
    intervalRef.current = setInterval(addMessage, 2000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div className="h-full flex flex-col bg-[#030508] font-mono text-sm overflow-hidden">
      {/* Header */}
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
        <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-[#00d4ff] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
          LINK 16 MONITOR // MIL-STD-6016C TADIL-J
        </h1>
      </header>

      <div className="flex-1 flex min-h-0">
        {/* Left: NPG + J-message mapping */}
        <aside className="w-64 shrink-0 border-r border-[#0a1828] flex flex-col overflow-hidden">
          {/* NPG participation */}
          <div className="shrink-0 p-3 border-b border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-2">
              NPG PARTICIPATION
            </div>
            <div className="flex flex-wrap gap-2">
              {NPGS.map((npg) => (
                <div key={npg} className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-[#00ff99] animate-pulse" />
                  <span className="font-mono text-[10px] text-[#e8eaf0]">{npg}</span>
                </div>
              ))}
            </div>
          </div>

          {/* J-message mapping table */}
          <div className="flex-1 overflow-auto p-3">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-2">
              J-MESSAGE MAPPING
            </div>
            <table className="w-full border-collapse text-[9px]">
              <thead>
                <tr className="border-b border-[#0a1828]">
                  <th className="text-left py-1 text-[#6688aa]">Code</th>
                  <th className="text-left py-1 text-[#6688aa]">Description</th>
                  <th className="text-left py-1 text-[#6688aa]">NPG</th>
                  <th className="text-left py-1 text-[#6688aa]">Dir</th>
                </tr>
              </thead>
              <tbody>
                {J_MESSAGE_MAP.map((row) => (
                  <tr key={row.code} className="border-b border-[#0a1828]/50">
                    <td className="py-1 text-[#00d4ff]">{row.code}</td>
                    <td className="py-1 text-[#e8eaf0]">{row.desc}</td>
                    <td className="py-1 text-[#e8eaf0]">{row.npg}</td>
                    <td className="py-1 text-[#6688aa]">{row.dir}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* PPLI status */}
          <div className="shrink-0 p-3 border-t border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-2">
              PPLI STATUS (12s NPG-5)
            </div>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {CALLSIGNS.map((cs) => (
                <div key={cs} className="flex justify-between items-center">
                  <span className="font-mono text-[9px] text-[#e8eaf0]">{cs}</span>
                  {cs === 'GHOST-01' ? (
                    <span className="font-mono text-[9px] text-[#ff2d55]">EMCON — NO PPLI</span>
                  ) : (
                    <span className="font-mono text-[9px] text-[#00ff99]">
                      {ppliTimes[cs] ?? '—'} / 12s
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Right: Live message feed */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
            <span className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              LIVE MESSAGE FEED
            </span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {messages.length === 0 && (
              <div className="font-mono text-[10px] text-[#6688aa] text-center py-8">
                AWAITING J-MESSAGES...
              </div>
            )}
            {messages.map((m) => (
              <div
                key={m.id}
                className="border border-[#0a1828] bg-[#060b10] px-3 py-2 hover:border-[#0a1828]"
              >
                <div className="flex items-center gap-4 flex-wrap">
                  <span className="font-mono text-[10px] text-[#6688aa]">{m.timestamp}</span>
                  <span className="font-mono text-[10px] text-[#00d4ff] font-semibold">{m.type}</span>
                  <span className="font-mono text-[10px] text-[#e8eaf0]">{m.callsign}</span>
                  <span className="font-mono text-[9px] text-[#00ff99]">{m.npg}</span>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
