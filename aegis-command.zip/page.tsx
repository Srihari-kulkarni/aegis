'use client';

import { useEffect, useState, useCallback, useRef } from 'react';

const POLL_INTERVAL = 3000;
const API_URL = 'http://localhost:4000/api/v1/fire-control/tracks';

const TRACK_SOURCE_LEGEND = [
  { id: 'AEGIS_CEC', label: 'AEGIS CEC', symbol: '◇', color: '#ff1a3c' },
  { id: 'AWACS', label: 'AWACS', symbol: '○', color: '#00d4ff' },
  { id: 'ORGANIC', label: 'ORGANIC', symbol: '×', color: '#00ff88' },
  { id: 'FUSED', label: 'FUSED', symbol: '⊕', color: '#ffffff' },
  { id: 'PPLI', label: 'PPLI', symbol: '▷', color: '#00b4ff' },
  { id: 'SILENT', label: 'SILENT', symbol: '--', color: '#6688aa' },
];

const IFF_COLORS: Record<string, string> = {
  FRIEND: '#00b4ff',
  HOSTILE: '#ff1a3c',
  UNKNOWN: '#ffc800',
  NEUTRAL: '#00ff88',
};

interface Track {
  trackId: string;
  trackSource: string;
  iffIdentity: string;
  lat: number;
  lon: number;
  altFt: number;
  speedKts: number;
  headingDeg: number;
  trackQuality?: number;
  fusionQuality?: number;
  threatPriority?: number;
  pk?: number;
}

const DEMO_TRACKS: Track[] = [
  { trackId: 'TRK-001', trackSource: 'FUSED', iffIdentity: 'HOSTILE', lat: 32.4521, lon: 44.3821, altFt: 25000, speedKts: 420, headingDeg: 185, trackQuality: 6, fusionQuality: 0.92, threatPriority: 1, pk: 0.87 },
  { trackId: 'TRK-002', trackSource: 'AEGIS_CEC', iffIdentity: 'HOSTILE', lat: 32.5102, lon: 44.2103, altFt: 18000, speedKts: 380, headingDeg: 92, trackQuality: 7, fusionQuality: 0.95, threatPriority: 2, pk: 0.91 },
  { trackId: 'TRK-003', trackSource: 'AWACS', iffIdentity: 'UNKNOWN', lat: 32.3890, lon: 44.5501, altFt: 32000, speedKts: 450, headingDeg: 270, trackQuality: 5, fusionQuality: 0.78, threatPriority: 3, pk: 0.62 },
  { trackId: 'TRK-004', trackSource: 'PPLI', iffIdentity: 'FRIEND', lat: 32.4012, lon: 44.3200, altFt: 22000, speedKts: 350, headingDeg: 45, trackQuality: 7, fusionQuality: 1.0, threatPriority: 0, pk: 0 },
  { trackId: 'TRK-005', trackSource: 'ORGANIC', iffIdentity: 'HOSTILE', lat: 32.4789, lon: 44.4123, altFt: 15000, speedKts: 290, headingDeg: 135, trackQuality: 4, fusionQuality: 0.65, threatPriority: 4, pk: 0.54 },
  { trackId: 'TRK-006', trackSource: 'FUSED', iffIdentity: 'NEUTRAL', lat: 32.5201, lon: 44.2809, altFt: 28000, speedKts: 410, headingDeg: 0, trackQuality: 6, fusionQuality: 0.88, threatPriority: 0, pk: 0 },
  { trackId: 'TRK-007', trackSource: 'SILENT', iffIdentity: 'UNKNOWN', lat: 32.4456, lon: 44.3901, altFt: 12000, speedKts: 220, headingDeg: 315, trackQuality: 2, fusionQuality: 0.42, threatPriority: 5, pk: 0.31 },
  { trackId: 'TRK-008', trackSource: 'AEGIS_CEC', iffIdentity: 'HOSTILE', lat: 32.5012, lon: 44.3502, altFt: 20000, speedKts: 360, headingDeg: 180, trackQuality: 7, fusionQuality: 0.94, threatPriority: 1, pk: 0.89 },
];

export default function TrackManagementPage() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [useDemo, setUseDemo] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchTracks = useCallback(async () => {
    try {
      const token = typeof window !== 'undefined' ? localStorage.getItem('aegis_token') : null;
      const res = await fetch(API_URL, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) throw new Error('API error');
      const data = await res.json();
      const trackList = data?.tracks ?? data?.data?.tracks ?? Array.isArray(data) ? data : [];
      if (trackList.length > 0) {
        setTracks(normalizeTracks(trackList));
        setUseDemo(false);
        setError(null);
      } else {
        setTracks(DEMO_TRACKS);
        setUseDemo(true);
      }
    } catch {
      setTracks(DEMO_TRACKS);
      setUseDemo(true);
      setError('LINK DEGRADED — USING DEMO DATA');
    }
  }, []);

  useEffect(() => {
    fetchTracks();
    pollRef.current = setInterval(fetchTracks, POLL_INTERVAL);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [fetchTracks]);

  const hostileCount = tracks.filter((t) => t.iffIdentity === 'HOSTILE').length;
  const fusedCount = tracks.filter((t) => t.trackSource === 'FUSED').length;
  const bySource = tracks.reduce<Record<string, number>>((acc, t) => {
    acc[t.trackSource] = (acc[t.trackSource] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="h-full flex flex-col bg-[#030508] font-mono text-sm overflow-hidden">
      {/* Header */}
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
        <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-[#00d4ff] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
          CEC TRACK MANAGEMENT // AN/USG-2B FUSION ENGINE
        </h1>
      </header>

      {error && (
        <div className="shrink-0 px-4 py-1 bg-[#ff2d55]/10 border-b border-[#ff2d55]/30 font-mono text-[10px] text-[#ff2d55] tracking-wider">
          ⚠ {error}
        </div>
      )}

      {/* Track source legend */}
      <div className="shrink-0 px-4 py-2 border-b border-[#0a1828] flex flex-wrap gap-x-6 gap-y-1">
        {TRACK_SOURCE_LEGEND.map(({ id, label, symbol, color }) => (
          <span key={id} className="font-mono text-[10px] flex items-center gap-1.5">
            <span style={{ color }}>{symbol}</span>
            <span className="text-[#6688aa]">{label}</span>
          </span>
        ))}
      </div>

      {/* Stats row */}
      <div className="shrink-0 px-4 py-2 border-b border-[#0a1828] flex flex-wrap gap-6">
        <span className="font-mono text-[10px] text-[#6688aa]">
          TOTAL: <span className="text-[#00d4ff] font-semibold">{tracks.length}</span>
        </span>
        {Object.entries(bySource).map(([src, count]) => (
          <span key={src} className="font-mono text-[10px] text-[#6688aa]">
            {src}: <span className="text-[#e8eaf0]">{count}</span>
          </span>
        ))}
        <span className="font-mono text-[10px] text-[#6688aa]">
          HOSTILE: <span className="text-[#ff1a3c] font-semibold">{hostileCount}</span>
        </span>
        <span className="font-mono text-[10px] text-[#6688aa]">
          FUSED: <span className="text-[#00ff99] font-semibold">{fusedCount}</span>
        </span>
      </div>

      {/* Track table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse font-mono text-[11px]">
          <thead className="sticky top-0 bg-[#060b10] z-10">
            <tr className="border-b border-[#0a1828]">
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Track ID</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Source</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">IFF</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Lat</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Lon</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Alt(ft)</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Speed(kts)</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Heading</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Quality(0-7)</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Fusion Quality</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Threat Priority</th>
              <th className="text-left px-3 py-2 text-[#00d4ff] font-semibold tracking-wider">Pk</th>
            </tr>
          </thead>
          <tbody>
            {tracks.map((t) => (
              <tr key={t.trackId} className="border-b border-[#0a1828]/50 hover:bg-[#060b10]">
                <td className="px-3 py-2 text-[#e8eaf0]">{t.trackId}</td>
                <td className="px-3 py-2">
                  <span style={{ color: TRACK_SOURCE_LEGEND.find((l) => l.id === t.trackSource)?.color ?? '#6688aa' }}>
                    {TRACK_SOURCE_LEGEND.find((l) => l.id === t.trackSource)?.symbol ?? '?'} {t.trackSource}
                  </span>
                </td>
                <td className="px-3 py-2" style={{ color: IFF_COLORS[t.iffIdentity] ?? '#e8eaf0' }}>
                  {t.iffIdentity}
                </td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.lat.toFixed(4)}</td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.lon.toFixed(4)}</td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.altFt.toLocaleString()}</td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.speedKts}</td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.headingDeg.toFixed(0)}°</td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.trackQuality ?? '—'}</td>
                <td className="px-3 py-2 text-[#e8eaf0]">
                  {t.fusionQuality != null ? t.fusionQuality.toFixed(2) : '—'}
                </td>
                <td className="px-3 py-2 text-[#e8eaf0]">{t.threatPriority ?? '—'}</td>
                <td className="px-3 py-2">
                  {t.pk != null ? (
                    <span className={t.pk >= 0.8 ? 'text-[#00ff99]' : t.pk >= 0.5 ? 'text-[#ffd60a]' : 'text-[#ff2d55]'}>
                      {t.pk.toFixed(2)}
                    </span>
                  ) : (
                    '—'
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function normalizeTracks(raw: unknown[]): Track[] {
  return raw.map((r) => {
    const rec = r as Record<string, unknown>;
    return {
      trackId: String(rec.trackId ?? rec.id ?? 'UNK'),
      trackSource: String(rec.trackSource ?? rec.source ?? 'UNKNOWN'),
      iffIdentity: String(rec.iffIdentity ?? rec.iff ?? 'UNKNOWN'),
      lat: Number(rec.lat ?? 0),
      lon: Number(rec.lon ?? 0),
      altFt: Number(rec.altFt ?? rec.alt ?? 0),
      speedKts: Number(rec.speedKts ?? rec.speed ?? 0),
      headingDeg: Number(rec.headingDeg ?? rec.heading ?? 0),
      trackQuality: rec.trackQuality != null ? Number(rec.trackQuality) : undefined,
      fusionQuality: rec.fusionQuality != null ? Number(rec.fusionQuality) : undefined,
      threatPriority: rec.threatPriority != null ? Number(rec.threatPriority) : undefined,
      pk: rec.pk != null ? Number(rec.pk) : (rec as { pkAssessment?: { pkFinal?: number } }).pkAssessment?.pkFinal,
    };
  });
}
