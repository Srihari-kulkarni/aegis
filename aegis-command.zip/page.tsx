'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/stores/authStore';

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();

  useEffect(() => {
    if (!isLoading) {
      router.replace(isAuthenticated ? '/dashboard' : '/login');
    }
  }, [isAuthenticated, isLoading, router]);

  return (
    <div className="min-h-screen bg-aegis-bg flex items-center justify-center">
      <div className="text-center">
        <div className="text-aegis-cyan font-tactical text-2xl tracking-widest mb-2">AEGIS COMMAND</div>
        <div className="text-aegis-muted text-xs font-mono">INITIALIZING SYSTEMS...</div>
        <div className="mt-4 w-48 h-0.5 bg-aegis-border mx-auto overflow-hidden">
          <div className="h-full bg-aegis-cyan animate-pulse" style={{ width: '60%' }} />
        </div>
      </div>
    </div>
  );
}
