'use client';

const STRIKE_PACKAGE = [
  {
    callsign: 'GHOST-01',
    platform: 'B-2A',
    role: 'SILENT_NODE',
    link16: 'PASSIVE',
    cec: 'NONE',
    tx: 'RECEIVE_ONLY',
    tag: 'S',
    weapons: [
      { name: 'AGM-158 JASSM', qty: 16, cep: 3, guidance: 'GPS/INS' },
      { name: 'GBU-31 JDAM', qty: 16, cep: 3, guidance: 'GPS/INS' },
    ],
    did: 'did:hedera:testnet:z6MkGHOST01...',
    hts: '0.0.8913066',
    serial: 1,
    fuel: 167000,
  },
  {
    callsign: 'SENTRY-01',
    platform: 'E-3G',
    role: 'AEGIS_HEDERA_BRIDGE',
    link16: 'NTR_PRIMARY',
    cec: 'USG-2B',
    tx: 'FULL_TX',
    tag: 'B',
    weapons: [],
    did: 'did:hedera:testnet:z6MkSENTRY01...',
    hts: '0.0.8913066',
    serial: 2,
    fuel: 152000,
  },
  {
    callsign: 'VIPER-01',
    platform: 'F-35A',
    role: 'STRIKE_ISR',
    link16: 'JU_PRIMARY',
    cec: 'USG-3B',
    tx: 'FULL_TX',
    tag: 'A',
    weapons: [
      { name: 'GBU-31 JDAM', qty: 2, cep: 3, guidance: 'GPS/INS' },
      { name: 'GBU-39 SDB', qty: 4, cep: 5, guidance: 'GPS' },
      { name: 'AIM-120 AMRAAM', qty: 2, cep: 0, guidance: 'RADAR' },
    ],
    did: 'did:hedera:testnet:z6MkVIPER01...',
    hts: '0.0.8913066',
    serial: 3,
    fuel: 18480,
  },
  {
    callsign: 'VIPER-02',
    platform: 'F-35A',
    role: 'STRIKE_ISR',
    link16: 'JU_SECONDARY',
    cec: 'USG-3B',
    tx: 'FULL_TX',
    tag: 'A',
    weapons: [
      { name: 'GBU-31 JDAM', qty: 2, cep: 3, guidance: 'GPS/INS' },
      { name: 'GBU-39 SDB', qty: 4, cep: 5, guidance: 'GPS' },
      { name: 'AIM-120 AMRAAM', qty: 2, cep: 0, guidance: 'RADAR' },
    ],
    did: 'did:hedera:testnet:z6MkVIPER02...',
    hts: '0.0.8913066',
    serial: 4,
    fuel: 18480,
  },
  {
    callsign: 'VIPER-03',
    platform: 'F-35B',
    role: 'STRIKE_CAS',
    link16: 'JU_SECONDARY',
    cec: 'USG-3B',
    tx: 'FULL_TX',
    tag: 'A',
    weapons: [
      { name: 'GBU-31 JDAM', qty: 2, cep: 3, guidance: 'GPS/INS' },
      { name: 'GBU-12 Paveway', qty: 2, cep: 3, guidance: 'LASER' },
      { name: 'AIM-120 AMRAAM', qty: 2, cep: 0, guidance: 'RADAR' },
    ],
    did: 'did:hedera:testnet:z6MkVIPER03...',
    hts: '0.0.8913066',
    serial: 5,
    fuel: 13326,
  },
  {
    callsign: 'REAPER-01',
    platform: 'MQ-9B',
    role: 'ISR_STRIKE_SUPPORT',
    link16: 'JU_RELAY',
    cec: 'NONE',
    tx: 'FULL_TX',
    tag: 'A',
    weapons: [
      { name: 'AGM-114 Hellfire', qty: 4, cep: 0.5, guidance: 'LASER' },
      { name: 'GBU-12 Paveway', qty: 2, cep: 3, guidance: 'LASER' },
    ],
    did: 'did:hedera:testnet:z6MkREAPER01...',
    hts: '0.0.8913066',
    serial: 6,
    fuel: 3900,
  },
  {
    callsign: 'REAPER-02',
    platform: 'MQ-9B',
    role: 'ISR_PERSISTENT',
    link16: 'JU_RELAY',
    cec: 'NONE',
    tx: 'FULL_TX',
    tag: 'A',
    weapons: [{ name: 'AGM-114 Hellfire', qty: 4, cep: 0.5, guidance: 'LASER' }],
    did: 'did:hedera:testnet:z6MkREAPER02...',
    hts: '0.0.8913066',
    serial: 7,
    fuel: 3900,
  },
  {
    callsign: 'ATLAS-01',
    platform: 'C-17A',
    role: 'LOGISTICS_CASEVAC',
    link16: 'JU_PASSIVE',
    cec: 'NONE',
    tx: 'RESTRICTED_TX',
    tag: 'L',
    weapons: [],
    did: 'did:hedera:testnet:z6MkATLAS01...',
    hts: '0.0.8913066',
    serial: 8,
    fuel: 181054,
  },
  {
    callsign: 'PEGASUS-01',
    platform: 'KC-46A',
    role: 'AAR_TANKER',
    link16: 'JU_PASSIVE',
    cec: 'NONE',
    tx: 'RESTRICTED_TX',
    tag: 'T',
    weapons: [],
    did: 'did:hedera:testnet:z6MkPEGASUS01...',
    hts: '0.0.8913066',
    serial: 9,
    fuel: 212300,
  },
  {
    callsign: 'PEGASUS-02',
    platform: 'KC-46A',
    role: 'AAR_TANKER',
    link16: 'JU_PASSIVE',
    cec: 'NONE',
    tx: 'RESTRICTED_TX',
    tag: 'T',
    weapons: [],
    did: 'did:hedera:testnet:z6MkPEGASUS02...',
    hts: '0.0.8913066',
    serial: 10,
    fuel: 212300,
  },
];

type Asset = (typeof STRIKE_PACKAGE)[number];

function TxBadge({ tx }: { tx: string }) {
  if (tx === 'FULL_TX') {
    return (
      <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#00ff99] text-[#00ff99]">
        {tx.replace('_', ' ')}
      </span>
    );
  }
  if (tx === 'RESTRICTED_TX') {
    return (
      <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#ffd60a] text-[#ffd60a]">
        {tx.replace('_', ' ')}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#556677] text-[#556677]">
      {tx.replace('_', ' ')}
    </span>
  );
}

function AssetCard({ asset }: { asset: Asset }) {
  const isGhost = asset.callsign === 'GHOST-01';
  const isSentry = asset.callsign === 'SENTRY-01';

  return (
    <div className="bg-[#060b10] border border-[#0a1828] p-4 font-mono">
      {/* Callsign + platform + role tag */}
      <div className="flex items-baseline gap-2 flex-wrap">
        <span className="text-lg font-bold text-[#00d4ff] tracking-wider">{asset.callsign}</span>
        <span className="text-[11px] text-[#556677]">{asset.platform}</span>
        <span className="text-[10px] font-bold text-[#00d4ff]">[{asset.tag}]</span>
      </div>

      {/* Special badges */}
      <div className="flex flex-wrap gap-1.5 mt-2">
        {isGhost && (
          <>
            <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#ff2d55] text-[#ff2d55]">
              [EMCON ALPHA]
            </span>
            <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#556677] text-[#556677]">
              MADL ONLY
            </span>
          </>
        )}
        {isSentry && (
          <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#00d4ff] text-[#00d4ff]">
            NIFC-CA BRIDGE NODE
          </span>
        )}
      </div>

      {/* DID */}
      <div className="mt-2 text-[9px] text-[#556677] font-mono truncate" title={asset.did}>
        {asset.did}
      </div>

      {/* HTS + serial */}
      <div className="flex gap-3 mt-1 text-[9px] text-[#556677]">
        <span>HTS: {asset.hts}</span>
        <span>SN: {asset.serial}</span>
      </div>

      {/* Link-16 + CEC badges */}
      <div className="flex flex-wrap gap-1.5 mt-2">
        <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#0a1828] bg-[#030508] text-[#e8eaf0]">
          L16: {asset.link16}
        </span>
        <span className="inline-flex items-center px-1.5 py-0.5 text-[9px] font-mono uppercase tracking-wider border border-[#0a1828] bg-[#030508] text-[#e8eaf0]">
          CEC: {asset.cec}
        </span>
      </div>

      {/* TX Authority */}
      <div className="mt-2">
        <TxBadge tx={asset.tx} />
      </div>

      {/* Aegis Link Status */}
      <div className="mt-2 flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 bg-[#00ff99] shrink-0" />
        <span className="text-[9px] font-mono uppercase tracking-wider text-[#00ff99]">
          Aegis Link Status: AUTHENTICATED
        </span>
      </div>

      {/* Weapons loadout */}
      {asset.weapons.length > 0 && (
        <div className="mt-3 space-y-0.5">
          {asset.weapons.map((w, i) => (
            <div key={i} className="text-[9px] text-[#e8eaf0] font-mono">
              <span className="text-[#556677]">├─</span> {w.name} ×{w.qty}{' '}
              CEP: {w.cep > 0 ? `${w.cep}m` : '—'} {w.guidance}
            </div>
          ))}
        </div>
      )}

      {/* Fuel */}
      <div className="mt-3 text-[9px] text-[#556677]">
        Fuel: {asset.fuel.toLocaleString()} lbs
      </div>
    </div>
  );
}

export default function AssetsPage() {
  return (
    <div className="min-h-full bg-[#030508] p-6 overflow-auto">
      {/* Header */}
      <header className="mb-6">
        <h1 className="font-mono text-xl font-bold tracking-[0.2em] text-[#00d4ff] uppercase drop-shadow-[0_0_8px_rgba(0,212,255,0.5)]">
          ASSET REGISTRY // HTS NFT COLLECTION // 0.0.8913066
        </h1>
      </header>

      {/* Grid of aircraft cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {STRIKE_PACKAGE.map((asset) => (
          <AssetCard key={asset.callsign} asset={asset} />
        ))}
      </div>
    </div>
  );
}
