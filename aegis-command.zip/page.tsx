'use client';

const OPERATOR_IDENTITIES = [
  { label: 'Aegis CO', did: 'did:hedera:testnet:z6MkCO...', key: 'Ed25519', status: 'AUTHENTICATED' },
  { label: 'Drone Operator 1', did: 'did:hedera:testnet:z6MkOP01...', key: 'Ed25519', status: 'AUTHENTICATED' },
  { label: 'Drone Operator 2', did: 'did:hedera:testnet:z6MkOP02...', key: 'Ed25519', status: 'AUTHENTICATED' },
  { label: 'System Account', did: 'did:hedera:testnet:z6MkSYS...', key: 'Ed25519', status: 'AUTHENTICATED' },
];

const AIRCRAFT_REGISTRY = [
  { callsign: 'GHOST-01', platform: 'B-2A', did: 'did:hedera:testnet:z6MkGH01...', link16Role: 'JT', cecProfile: 'FULL', aegisStatus: 'AUTHENTICATED', txAuthority: 'SILENT', credStatus: 'ACTIVE', badges: ['EMCON ALPHA'] },
  { callsign: 'SENTRY-01', platform: 'E-3G', did: 'did:hedera:testnet:z6MkSN01...', link16Role: 'NCS', cecProfile: 'FULL', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: ['BRIDGE NODE'] },
  { callsign: 'VIPER-01', platform: 'F-35A', did: 'did:hedera:testnet:z6MkVP01...', link16Role: 'JT', cecProfile: 'FULL', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'VIPER-02', platform: 'F-35A', did: 'did:hedera:testnet:z6MkVP02...', link16Role: 'JT', cecProfile: 'FULL', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'VIPER-03', platform: 'F-35B', did: 'did:hedera:testnet:z6MkVP03...', link16Role: 'JT', cecProfile: 'FULL', aegisStatus: 'PENDING', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'REAPER-01', platform: 'MQ-9B', did: 'did:hedera:testnet:z6MkRP01...', link16Role: 'JT', cecProfile: 'LITE', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'REAPER-02', platform: 'MQ-9B', did: 'did:hedera:testnet:z6MkRP02...', link16Role: 'JT', cecProfile: 'LITE', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'ATLAS-01', platform: 'C-17A', did: 'did:hedera:testnet:z6MkAT01...', link16Role: 'JT', cecProfile: 'LITE', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'PEGASUS-01', platform: 'KC-46A', did: 'did:hedera:testnet:z6MkPG01...', link16Role: 'JT', cecProfile: 'LITE', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
  { callsign: 'PEGASUS-02', platform: 'KC-46A', did: 'did:hedera:testnet:z6MkPG02...', link16Role: 'JT', cecProfile: 'LITE', aegisStatus: 'AUTHENTICATED', txAuthority: 'FULL', credStatus: 'ACTIVE', badges: [] },
];

const VC_CAPABILITIES = ['TRANSMIT_PPLI', 'RECEIVE_FIRE_CONTROL', 'SUBMIT_TARGET_REPORT', 'REQUEST_WEAPONS_FREE'];

const DID_DOCUMENT_JSON = `{
  "@context": [
    "https://www.w3.org/ns/did/v1",
    "https://w3id.org/security/suites/ed25519-2020/v1"
  ],
  "id": "did:hedera:testnet:z6MkVP01abc123xyz789",
  "verificationMethod": [
    {
      "id": "did:hedera:testnet:z6MkVP01abc123xyz789#key-1",
      "type": "Ed25519VerificationKey2020",
      "controller": "did:hedera:testnet:z6MkVP01abc123xyz789",
      "publicKeyMultibase": "z6MkVP01abc123xyz789..."
    }
  ],
  "authentication": ["did:hedera:testnet:z6MkVP01abc123xyz789#key-1"],
  "service": [
    {
      "id": "did:hedera:testnet:z6MkVP01abc123xyz789#agent",
      "type": "LinkedDomains",
      "serviceEndpoint": "https://aegis.c2.mil/vp01"
    }
  ]
}`;

export default function IdentityPage() {
  return (
    <div className="h-full flex flex-col bg-[#030508] font-mono text-sm overflow-hidden">
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
        <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-[#00d4ff] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
          DID / VC MANAGER // W3C DID v1.0 // did:hedera
        </h1>
      </header>

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left: Operator/CO identity panel */}
        <aside className="w-72 shrink-0 border-r border-[#0a1828] flex flex-col overflow-hidden">
          <div className="shrink-0 p-3 border-b border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-3">
              OPERATOR / CO IDENTITY
            </div>
            <div className="space-y-3">
              {OPERATOR_IDENTITIES.map((op) => (
                <div key={op.label} className="bg-[#060b10] border border-[#0a1828] p-2 rounded">
                  <div className="font-mono text-[10px] font-bold text-[#e8eaf0]">{op.label}</div>
                  <div className="font-mono text-[9px] text-[#6688aa] break-all mt-0.5">{op.did}</div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="font-mono text-[9px] text-[#6688aa]">{op.key}</span>
                    <span className="font-mono text-[9px] text-[#00ff99] font-semibold">{op.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Verifiable Credentials panel */}
          <div className="flex-1 overflow-auto p-3 border-t border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-2">
              VERIFIABLE CREDENTIALS
            </div>
            <div className="bg-[#060b10] border border-[#0a1828] p-3 rounded space-y-2">
              <div className="font-mono text-[10px] text-[#e8eaf0] font-bold">AegisNetworkCredential</div>
              <div className="font-mono text-[9px] space-y-1">
                <div><span className="text-[#6688aa]">Issuer:</span> <span className="text-[#00d4ff]">CO DID</span></div>
                <div><span className="text-[#6688aa]">Subject:</span> <span className="text-[#00d4ff]">VIPER-01 DID</span></div>
                <div className="text-[#6688aa] mt-1">Capabilities:</div>
                <ul className="list-disc list-inside text-[#00ff99] ml-1">
                  {VC_CAPABILITIES.map((c) => (
                    <li key={c}>{c}</li>
                  ))}
                </ul>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="w-2 h-2 rounded-full bg-[#00ff99] animate-pulse" />
                <span className="font-mono text-[9px] text-[#00ff99] font-semibold">ACTIVE</span>
              </div>
              <div className="flex flex-wrap gap-2 mt-3">
                <button className="px-2 py-1 font-mono text-[9px] bg-[#ff2d55]/20 text-[#ff2d55] border border-[#ff2d55]/50 hover:bg-[#ff2d55]/30 transition-colors">
                  REVOKE CREDENTIAL
                </button>
                <button className="px-2 py-1 font-mono text-[9px] bg-[#00d4ff]/20 text-[#00d4ff] border border-[#00d4ff]/50 hover:bg-[#00d4ff]/30 transition-colors">
                  ISSUE NEW VC
                </button>
                <button className="px-2 py-1 font-mono text-[9px] bg-[#00ff99]/20 text-[#00ff99] border border-[#00ff99]/50 hover:bg-[#00ff99]/30 transition-colors">
                  VERIFY ON CHAIN
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* Center: Aircraft DID Registry table */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
            <span className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              AIRCRAFT DID REGISTRY
            </span>
          </div>
          <div className="flex-1 overflow-auto p-4">
            <table className="w-full border-collapse text-[9px]">
              <thead>
                <tr className="border-b border-[#0a1828]">
                  <th className="text-left py-2 px-2 text-[#6688aa]">Callsign</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">Platform</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">DID</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">Link-16 Role</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">CEC Profile</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">Aegis Link Status</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">TX Authority</th>
                  <th className="text-left py-2 px-2 text-[#6688aa]">Credential Status</th>
                </tr>
              </thead>
              <tbody>
                {AIRCRAFT_REGISTRY.map((row) => (
                  <tr key={row.callsign} className="border-b border-[#0a1828]/50 hover:bg-[#060b10]/50">
                    <td className="py-2 px-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[#e8eaf0] font-semibold">{row.callsign}</span>
                        {row.badges.map((b) => (
                          <span
                            key={b}
                            className={`px-1.5 py-0.5 text-[8px] font-bold ${
                              b === 'EMCON ALPHA'
                                ? 'bg-[#ff2d55]/20 text-[#ff2d55] border border-[#ff2d55]/50'
                                : 'bg-[#00d4ff]/20 text-[#00d4ff] border border-[#00d4ff]/50'
                            }`}
                          >
                            {b}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-2 px-2 text-[#e8eaf0]">{row.platform}</td>
                    <td className="py-2 px-2 text-[#6688aa] font-mono">{row.did}</td>
                    <td className="py-2 px-2 text-[#e8eaf0]">{row.link16Role}</td>
                    <td className="py-2 px-2 text-[#e8eaf0]">{row.cecProfile}</td>
                    <td className="py-2 px-2">
                      <span className={row.aegisStatus === 'AUTHENTICATED' ? 'text-[#00ff99]' : 'text-[#ffd60a]'}>
                        {row.aegisStatus}
                      </span>
                    </td>
                    <td className="py-2 px-2">
                      <span className={row.txAuthority === 'SILENT' ? 'text-[#ff2d55] font-semibold' : 'text-[#00ff99]'}>
                        {row.txAuthority}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-[#00ff99]">{row.credStatus}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>

        {/* Right: DID Document viewer */}
        <aside className="w-80 shrink-0 border-l border-[#0a1828] flex flex-col overflow-hidden">
          <div className="shrink-0 p-3 border-b border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              DID DOCUMENT VIEWER
            </div>
          </div>
          <div className="flex-1 overflow-auto p-3">
            <pre className="font-mono text-[9px] text-[#e8eaf0] whitespace-pre-wrap break-all leading-relaxed">
              {DID_DOCUMENT_JSON}
            </pre>
          </div>
        </aside>
      </div>
    </div>
  );
}
