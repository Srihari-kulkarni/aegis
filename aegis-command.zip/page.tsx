'use client';

import { useEffect, useState, useRef } from 'react';

const CEC_STATS = [
  { label: 'SPY-1D tracks', value: 247, max: 300 },
  { label: 'AWACS tracks', value: 89, max: 120 },
  { label: 'Organic tracks', value: 12, max: 24 },
  { label: 'Fused composites', value: 43, max: 80 },
  { label: 'CEC DDS bandwidth', value: 34.2, max: 40, unit: 'Mbps', suffix: ' / 40 Mbps' },
];

const THREAT_TRACKS = [
  { id: 'H-001', classification: 'MIG-31 FOXHOUND', priority: 'CRITICAL', pk: 0.92, distance: 42, bearing: '045°', closingSpeed: 680, asset: 'VIPER-01' },
  { id: 'H-002', classification: 'SU-35 FLANKER-E', priority: 'CRITICAL', pk: 0.88, distance: 78, bearing: '112°', closingSpeed: 520, asset: 'VIPER-02' },
  { id: 'H-003', classification: 'TU-95 BEAR-H', priority: 'HIGH', pk: 0.76, distance: 156, bearing: '088°', closingSpeed: 420, asset: 'SENTRY-01' },
  { id: 'H-004', classification: 'DF-21D ASBM', priority: 'CRITICAL', pk: 0.94, distance: 12, bearing: '270°', closingSpeed: 3200, asset: 'VIPER-01' },
  { id: 'H-005', classification: 'TYPE-055 DDG', priority: 'MEDIUM', pk: 0.65, distance: 89, bearing: '195°', closingSpeed: 28, asset: 'REAPER-01' },
];

const INTEL_SOURCES = ['SIGINT', 'HUMINT', 'GEOINT', 'MASINT', 'OSINT'] as const;
const CLASSIFICATION_LEVELS = ['SECRET//REL', 'TOP SECRET', 'SECRET', 'CONFIDENTIAL'] as const;

const SAMPLE_SUMMARIES = [
  'Hostile track H-001 maneuvering to intercept. Recommend weapons-free authorization.',
  'New surface contact designated H-005. Classification: TYPE-055 DDG. Bearing 195.',
  'AWACS confirms 4 additional bogeys at 80nm. ETA 12 minutes.',
  'EMCON change detected. Possible hostile radar activation.',
  'SPY-1D tracks fused with AWACS. Composite count increased.',
  'DF-21D launch detected. Track H-004. Inbound.',
  'Jamming detected on Link-16 NPG-7. Degraded comms.',
  'SIGINT intercept: hostile IFF squawk 7500.',
  'GEOINT: New runway construction at grid NK-42.',
  'MASINT: RF signature matches known SU-35 profile.',
  'OSINT: Commercial satellite imagery suggests naval buildup.',
];

interface IntelMessage {
  id: string;
  timestamp: string;
  source: string;
  classification: string;
  summary: string;
}

function formatZulu(): string {
  const d = new Date();
  const h = String(d.getUTCHours()).padStart(2, '0');
  const m = String(d.getUTCMinutes()).padStart(2, '0');
  const s = String(d.getUTCSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}Z`;
}

export default function IntelPage() {
  const [messages, setMessages] = useState<IntelMessage[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const addMessage = () => {
      const source = INTEL_SOURCES[Math.floor(Math.random() * INTEL_SOURCES.length)];
      const classification = CLASSIFICATION_LEVELS[Math.floor(Math.random() * CLASSIFICATION_LEVELS.length)];
      const summary = SAMPLE_SUMMARIES[Math.floor(Math.random() * SAMPLE_SUMMARIES.length)];
      const msg: IntelMessage = {
        id: `intel-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        timestamp: formatZulu(),
        source,
        classification,
        summary,
      };
      setMessages((prev) => [msg, ...prev].slice(0, 20));
    };
    addMessage();
    intervalRef.current = setInterval(addMessage, 3000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const priorityColor = (p: string) => {
    if (p === 'CRITICAL') return 'border-l-[#ff2d55] bg-[#ff2d55]/10';
    if (p === 'HIGH') return 'border-l-[#ffd60a] bg-[#ffd60a]/10';
    return 'border-l-[#ffd60a]/70 bg-[#ffd60a]/5';
  };

  return (
    <div className="h-full flex flex-col bg-[#030508] font-mono text-sm overflow-hidden">
      <header className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
        <h1 className="font-mono text-sm font-bold tracking-[0.3em] text-[#00d4ff] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">
          INTELLIGENCE FEED // J6.0 INTEL // CEC REMOTE TRACKS
        </h1>
      </header>

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left: CEC Status + Environmental */}
        <aside className="w-72 shrink-0 border-r border-[#0a1828] flex flex-col overflow-hidden">
          <div className="shrink-0 p-3 border-b border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-3">
              CEC STATUS PANEL
            </div>
            <div className="space-y-3">
              {CEC_STATS.map((stat) => (
                <div key={stat.label}>
                  <div className="flex justify-between text-[9px] mb-1">
                    <span className="text-[#e8eaf0]">{stat.label}</span>
                    <span className="text-[#00d4ff]">
                      {stat.value}{stat.unit ? ` ${stat.unit}` : ''}{stat.suffix ?? ` / ${stat.max}`}
                    </span>
                  </div>
                  <div className="h-1.5 bg-[#060b10] border border-[#0a1828] rounded overflow-hidden">
                    <div
                      className="h-full bg-[#00d4ff]/60 rounded transition-all duration-300"
                      style={{ width: `${Math.min(100, (stat.value / stat.max) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-auto p-3 border-t border-[#0a1828]">
            <div className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff] mb-3">
              ENVIRONMENTAL FACTORS
            </div>
            <div className="bg-[#060b10] border border-[#0a1828] p-3 rounded space-y-2">
              <div className="flex justify-between text-[9px]">
                <span className="text-[#6688aa]">Sea state</span>
                <span className="text-[#e8eaf0]">3 (Moderate)</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-[#6688aa]">Wind</span>
                <span className="text-[#e8eaf0]">12 kt / 045°</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-[#6688aa]">Visibility</span>
                <span className="text-[#e8eaf0]">10 nm</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-[#6688aa]">ECM activity</span>
                <span className="text-[#ffd60a]">ELEVATED</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-[#6688aa]">Jamming detected</span>
                <span className="text-[#ff2d55] font-semibold">Y</span>
              </div>
              <div className="mt-2 pt-2 border-t border-[#0a1828]">
                <div className="text-[9px] text-[#6688aa]">Pk degradation factor</div>
                <div className="text-[10px] text-[#ffd60a] font-semibold">0.92</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Center: Threat Assessment Board */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden border-r border-[#0a1828]">
          <div className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
            <span className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              THREAT ASSESSMENT BOARD
            </span>
          </div>
          <div className="flex-1 overflow-auto p-4">
            <div className="space-y-2">
              {THREAT_TRACKS.map((t) => (
                <div
                  key={t.id}
                  className={`border-l-4 pl-3 pr-3 py-2 bg-[#060b10] border border-[#0a1828] ${priorityColor(t.priority)}`}
                >
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[9px]">
                    <span className="text-[#00d4ff] font-bold">{t.id}</span>
                    <span className="text-[#e8eaf0]">{t.classification}</span>
                    <span
                      className={`font-semibold ${
                        t.priority === 'CRITICAL' ? 'text-[#ff2d55]' : t.priority === 'HIGH' ? 'text-[#ffd60a]' : 'text-[#ffd60a]/90'
                      }`}
                    >
                      {t.priority}
                    </span>
                    <span className="text-[#00ff99]">Pk {t.pk}</span>
                    <span className="text-[#6688aa]">{t.distance} nm</span>
                    <span className="text-[#6688aa]">{t.bearing}</span>
                    <span className="text-[#6688aa]">{t.closingSpeed} kt</span>
                    <span className="text-[#00d4ff]">→ {t.asset}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>

        {/* Right: Intel Feed Stream */}
        <aside className="w-96 shrink-0 flex flex-col overflow-hidden">
          <div className="shrink-0 px-4 py-2 border-b border-[#0a1828]">
            <span className="font-mono text-[10px] font-bold tracking-wider text-[#00d4ff]">
              INTEL FEED STREAM
            </span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {messages.length === 0 && (
              <div className="font-mono text-[10px] text-[#6688aa] text-center py-8">
                AWAITING J6.0 MESSAGES...
              </div>
            )}
            {messages.map((m) => (
              <div
                key={m.id}
                className="border border-[#0a1828] bg-[#060b10] px-3 py-2 hover:border-[#0a1828]/80 transition-colors"
              >
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="font-mono text-[9px] text-[#6688aa]">{m.timestamp}</span>
                  <span className="font-mono text-[9px] text-[#00d4ff] font-semibold">{m.source}</span>
                  <span className="font-mono text-[8px] text-[#ffd60a] px-1 border border-[#ffd60a]/50">
                    {m.classification}
                  </span>
                </div>
                <div className="font-mono text-[9px] text-[#e8eaf0] leading-relaxed">{m.summary}</div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
