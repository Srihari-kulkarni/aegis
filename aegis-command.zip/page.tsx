'use client';

import { useEffect, useCallback, useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { ClassificationBanner } from '@/components/ClassificationBanner';
import { ZuluClock } from '@/components/ZuluClock';
import { TacticalMap } from '@/components/TacticalMap';
import { useAuthStore } from '@/stores/authStore';
import { useDroneStore } from '@/stores/droneStore';
import { useMissionStore } from '@/stores/missionStore';
import { useFeedStore } from '@/stores/feedStore';
import {
  getConnectionStatus,
  onConnectionStatusChange,
  subscribeToAllDrones,
} from '@/lib/socket';
import { MissionRole, TxAuthLevel, STRIKE_PACKAGE } from '@aegis/shared';

const ROLE_TAG: Record<string, string> = {
  [MissionRole.SILENT_NODE]: 'S',
  [MissionRole.AEGIS_HEDERA_BRIDGE]: 'B',
  [MissionRole.STRIKE_ISR]: 'A',
  [MissionRole.STRIKE_CAS]: 'A',
  [MissionRole.ISR_STRIKE_SUPPORT]: 'I',
  [MissionRole.ISR_PERSISTENT]: 'I',
  [MissionRole.LOGISTICS_CASEVAC]: 'L',
  [MissionRole.AAR_TANKER]: 'T',
  [MissionRole.STRIKE]: 'A',
  [MissionRole.ISR]: 'I',
  [MissionRole.TANKER]: 'T',
  [MissionRole.LOGISTICS]: 'L',
  [MissionRole.C2_BRIDGE]: 'B',
};

const ROLE_COLOR: Record<string, string> = {
  S: 'text-[#6688aa]',
  B: 'text-aegis-cyan',
  A: 'text-aegis-red',
  I: 'text-aegis-green',
  L: 'text-aegis-amber',
  T: 'text-[#c084fc]',
};

function formatZuluShort(iso: string): string {
  try {
    const d = new Date(iso);
    const h = String(d.getUTCHours()).padStart(2, '0');
    const m = String(d.getUTCMinutes()).padStart(2, '0');
    const s = String(d.getUTCSeconds()).padStart(2, '0');
    return `${h}:${m}:${s}Z`;
  } catch {
    return iso;
  }
}

export default function DashboardPage() {
  const router = useRouter();
  const [clickedLocation, setClickedLocation] = useState<{ lat: number; lon: number } | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<
    'connected' | 'connecting' | 'disconnected' | 'degraded'
  >(getConnectionStatus());

  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isLoading = useAuthStore((s) => s.isLoading);
  const operator = useAuthStore((s) => s.operator);
  const logout = useAuthStore((s) => s.logout);

  const fetchDrones = useDroneStore((s) => s.fetchDrones);
  const startTelemetryListener = useDroneStore((s) => s.startTelemetryListener);
  const selectDrone = useDroneStore((s) => s.selectDrone);
  const drones = useDroneStore((s) => s.getFilteredDrones());
  const selectedDroneId = useDroneStore((s) => s.selectedDroneId);

  const fetchMissions = useMissionStore((s) => s.fetchMissions);

  const fetchInitialLog = useFeedStore((s) => s.fetchInitialLog);
  const fetchThreats = useFeedStore((s) => s.fetchThreats);
  const startFeedListeners = useFeedStore((s) => s.startFeedListeners);
  const fetchModelStatus = useFeedStore((s) => s.fetchModelStatus);
  const fetchSpaceWeather = useFeedStore((s) => s.fetchSpaceWeather);
  const fetchIntelFeeds = useFeedStore((s) => s.fetchIntelFeeds);
  const fetchRIStatus = useFeedStore((s) => s.fetchRIStatus);
  const hcsLog = useFeedStore((s) => s.hcsLog);
  const threats = useFeedStore((s) => s.threats);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    if (!isAuthenticated) return;
    fetchDrones();
    fetchMissions();
    fetchInitialLog();
    fetchThreats();
    fetchModelStatus();
    fetchSpaceWeather();
    fetchIntelFeeds();
    fetchRIStatus();
    startTelemetryListener();
    startFeedListeners();
    subscribeToAllDrones();
  }, [
    isAuthenticated,
    fetchDrones,
    fetchMissions,
    fetchInitialLog,
    fetchThreats,
    fetchModelStatus,
    fetchSpaceWeather,
    fetchIntelFeeds,
    fetchRIStatus,
    startTelemetryListener,
    startFeedListeners,
  ]);

  useEffect(() => {
    const unsub = onConnectionStatusChange(setConnectionStatus);
    return unsub;
  }, []);

  const handleLogout = useCallback(async () => {
    await logout();
    router.push('/login');
  }, [logout, router]);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        selectDrone(null);
        setClickedLocation(null);
      }
    },
    [selectDrone]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handleMapClick = useCallback((lat: number, lon: number) => {
    setClickedLocation({ lat, lon });
  }, []);

  const handleSelectAircraft = useCallback(
    (droneId: string) => {
      selectDrone(droneId);
    },
    [selectDrone]
  );

  const assetList = useMemo(() => {
    return STRIKE_PACKAGE.map((ac) => {
      const matched = drones.find(
        (d) => d.callsign === ac.callsign || d.callsign.toUpperCase() === ac.callsign
      );
      return { ...ac, droneState: matched ?? null };
    });
  }, [drones]);

  const trackCounts = useMemo(() => {
    const counts: Record<string, number> = {
      SPY1D: threats.filter((t) => t.active).length,
      AWACS: drones.filter((d) => d.callsign.startsWith('SENTRY')).length,
      CEC: drones.length,
      PPLI: drones.filter((d) => d.linkQuality > 50).length,
    };
    return counts;
  }, [drones, threats]);

  const hostileTracks = useMemo(() => {
    return threats.filter((t) => t.active).map((t) => ({
      id: t.threatId,
      type: t.type,
      confidence: t.confidence,
      pk: Math.min(0.95, t.confidence * 0.85 + 0.1).toFixed(2),
      position: t.position,
    }));
  }, [threats]);

  const arsenalSummary = useMemo(() => {
    let totalWeapons = 0;
    let totalPlatforms = 0;
    STRIKE_PACKAGE.forEach((ac) => {
      if (ac.weapons.length > 0) {
        totalPlatforms++;
        ac.weapons.forEach((w) => {
          totalWeapons += w.quantity;
        });
      }
    });
    return { totalWeapons, totalPlatforms };
  }, []);

  const modelStatus = useFeedStore.getState().modelStatus;
  const riStatus = useFeedStore.getState().riStatus;

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-aegis-bg flex items-center justify-center">
        <div className="font-mono text-aegis-muted text-sm">LOADING AEGIS COMMAND...</div>
      </div>
    );
  }

  const statusDot =
    connectionStatus === 'connected'
      ? 'bg-aegis-green'
      : connectionStatus === 'degraded'
        ? 'bg-aegis-amber'
        : 'bg-aegis-red';

  return (
    <div className="h-screen w-screen overflow-hidden bg-aegis-bg flex flex-col font-mono">
      <ClassificationBanner />

      {/* Top bar — AN/UYQ-70 header */}
      <header className="h-11 shrink-0 flex items-center justify-between px-4 bg-aegis-panel border-b border-aegis-border z-30 font-mono">
        <div className="flex items-center gap-4">
          <span className="text-aegis-cyan text-xs tracking-[0.2em] uppercase">
            // UNCLASSIFIED // FOR OFFICIAL USE ONLY // AEGIS COMMAND //
          </span>
          <ZuluClock />
        </div>
        <div className="flex items-center gap-4">
          {modelStatus && (
            <div className="flex items-center gap-1.5 border border-aegis-border px-2 py-0.5">
              <div className={`w-1.5 h-1.5 ${modelStatus.activeTier === 'RULE_ENGINE' ? 'bg-aegis-amber' : 'bg-aegis-green'} animate-pulse`} />
              <span className="font-mono text-[10px] text-aegis-muted">
                AI: {modelStatus.activeTier}
              </span>
            </div>
          )}
          {riStatus && (
            <div className="flex items-center gap-1.5 border border-aegis-border px-2 py-0.5">
              <div className={`w-1.5 h-1.5 ${riStatus.enabled ? 'bg-aegis-green' : 'bg-aegis-muted'}`} />
              <span className="font-mono text-[10px] text-aegis-muted">
                RI{riStatus.enabled ? ` [${riStatus.totalIterations ?? 0}]` : ' OFF'}
              </span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 ${statusDot}`} title={connectionStatus} />
            <span className="font-mono text-[10px] text-aegis-muted capitalize">{connectionStatus}</span>
          </div>
          <span className="font-mono text-xs text-aegis-cyan font-semibold">
            {operator?.callsign ?? '—'}
          </span>
          <span className="font-mono text-[10px] text-aegis-muted">
            {operator?.role ?? ''}
          </span>
          <button
            type="button"
            onClick={handleLogout}
            className="font-mono text-[10px] text-aegis-muted hover:text-aegis-red transition-colors uppercase tracking-wider"
          >
            LOGOUT
          </button>
        </div>
      </header>

      {/* Three-column body */}
      <div className="flex-1 flex min-h-0">

        {/* LEFT COLUMN — Asset Registry + Fire Control */}
        <aside className="uYQ-left shrink-0 flex flex-col bg-aegis-panel border-r border-aegis-border z-20 overflow-hidden" style={{ width: 200 }}>
          {/* Asset Registry */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="px-2 py-1.5 border-b border-aegis-border">
              <span className="font-tactical font-semibold text-[10px] tracking-widest text-aegis-cyan uppercase">
                ASSET REGISTRY
              </span>
            </div>
            <div className="flex-1 overflow-y-auto min-h-0">
              {assetList.map((ac) => {
                const tag = ROLE_TAG[ac.role] ?? '?';
                const tagColor = ROLE_COLOR[tag] ?? 'text-aegis-muted';
                const ds = ac.droneState;
                const isSelected = ds?.droneId === selectedDroneId;
                const healthColor = ds
                  ? ds.health > 80 ? 'text-aegis-green' : ds.health > 50 ? 'text-aegis-amber' : 'text-aegis-red'
                  : 'text-aegis-muted';
                const statusColor = ds
                  ? ds.status === 'ON_MISSION' || ds.status === 'AIRBORNE'
                    ? 'bg-aegis-green'
                    : ds.status === 'LOST_LINK' || ds.status === 'EMERGENCY'
                      ? 'bg-aegis-red'
                      : 'bg-aegis-amber'
                  : 'bg-aegis-muted/40';

                return (
                  <button
                    key={ac.callsign}
                    type="button"
                    onClick={() => ds && handleSelectAircraft(ds.droneId)}
                    className={`w-full text-left px-2 py-1 border-b border-aegis-border/50 hover:bg-aegis-cyan/5 transition-colors ${
                      isSelected ? 'bg-aegis-cyan/10 border-l-2 border-l-aegis-cyan' : ''
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 ${statusColor} shrink-0`} />
                      <span className="font-mono text-[10px] text-aegis-text truncate">
                        {ac.callsign}
                      </span>
                      <span className={`font-mono text-[10px] font-bold ${tagColor} ml-auto`}>
                        [{tag}]
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="font-mono text-[8px] text-aegis-muted">{ac.platform}</span>
                      {ds && (
                        <span className={`font-mono text-[8px] ${healthColor} ml-auto`}>
                          {ds.status === 'ON_MISSION' ? 'MSN' : ds.status === 'AIRBORNE' ? 'AIR' : ds.status.slice(0, 4)}
                        </span>
                      )}
                      {!ds && (
                        <span className="font-mono text-[8px] text-aegis-muted/50 ml-auto">OFFLINE</span>
                      )}
                    </div>
                    {ac.txAuthority === TxAuthLevel.SILENT && (
                      <div className="font-mono text-[7px] text-[#6688aa] mt-0.5">[SILENT — RX ONLY]</div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Fire Control Summary */}
          <div className="shrink-0 border-t border-aegis-border">
            <div className="px-2 py-1.5 border-b border-aegis-border">
              <span className="font-tactical font-semibold text-[10px] tracking-widest text-aegis-cyan uppercase">
                FIRE CONTROL
              </span>
            </div>
            <div className="px-2 py-2 space-y-1.5">
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">ACTIVE TGT</span>
                <span className="font-mono text-[9px] text-aegis-text">
                  {hostileTracks.length > 0 ? hostileTracks[0].id.slice(0, 8) : 'NONE'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">ROE</span>
                <span className="font-mono text-[9px] text-aegis-amber">WEAPONS TIGHT</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">MULTI-SIG</span>
                <span className="font-mono text-[9px] text-aegis-green">2/3 REQ</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">THREATS</span>
                <span className={`font-mono text-[9px] ${hostileTracks.length > 0 ? 'text-aegis-red' : 'text-aegis-green'}`}>
                  {hostileTracks.length} ACTIVE
                </span>
              </div>
            </div>
          </div>
        </aside>

        {/* CENTER COLUMN — Tactical Map + CEC Status Bar */}
        <div className="flex-1 flex flex-col min-h-0 min-w-0">
          <div className="flex-1 relative min-h-0">
            <TacticalMap
              onMapClick={handleMapClick}
              clickedLocation={clickedLocation}
            />
          </div>

          {/* CEC Status Bar */}
          <div className="shrink-0 h-7 flex items-center gap-4 px-3 bg-aegis-panel border-t border-aegis-border font-mono">
            <span className="font-tactical font-semibold text-[9px] tracking-widest text-aegis-cyan uppercase">CEC STATUS</span>
            <div className="flex items-center gap-3">
              <span className="font-mono text-[9px] text-aegis-muted">
                SPY-1D: <span className="text-aegis-text">{trackCounts.SPY1D}</span> tracks
              </span>
              <span className="font-mono text-[9px] text-aegis-muted">
                AWACS: <span className="text-aegis-text">{trackCounts.AWACS}</span> tracks
              </span>
              <span className="font-mono text-[9px] text-aegis-muted">
                CEC: <span className="text-aegis-text">{trackCounts.CEC}</span> fused
              </span>
              <span className="font-mono text-[9px] text-aegis-muted">
                PPLI: <span className="text-aegis-text">{trackCounts.PPLI}</span> active
              </span>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <span className="font-mono text-[8px] text-aegis-muted">LINK 16</span>
              <div className="w-1.5 h-1.5 bg-aegis-green animate-pulse" />
              <span className="font-mono text-[8px] text-aegis-muted">SATCOM</span>
              <div className="w-1.5 h-1.5 bg-aegis-green" />
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN — HCS Log, Threat Board, Arsenal */}
        <aside className="uYQ-right shrink-0 flex flex-col bg-aegis-panel border-l border-aegis-border z-20 overflow-hidden" style={{ width: 240 }}>
          {/* HCS Event Log */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="px-2 py-1.5 border-b border-aegis-border">
              <span className="font-tactical font-semibold text-[10px] tracking-widest text-aegis-cyan uppercase">
                HCS LOG
              </span>
            </div>
            <div className="flex-1 overflow-y-auto min-h-0">
              {hcsLog.length === 0 && (
                <div className="px-2 py-3 font-mono text-[9px] text-aegis-muted text-center">
                  Awaiting HCS events...
                </div>
              )}
              {hcsLog.slice(0, 50).map((entry, i) => (
                <div
                  key={`${entry.sequenceNumber}-${i}`}
                  className="px-2 py-1 border-b border-aegis-border/30 hover:bg-aegis-cyan/5"
                >
                  <div className="flex items-center gap-1">
                    <span className="font-mono text-[8px] text-aegis-muted">
                      {formatZuluShort(entry.consensusTimestamp)}
                    </span>
                    <span className="font-mono text-[8px] text-aegis-cyan">
                      SEQ:{entry.sequenceNumber}
                    </span>
                  </div>
                  <div className="font-mono text-[8px] text-aegis-text truncate">
                    {entry.actionType.replace(/_/g, ' ')}
                  </div>
                  <div className="font-mono text-[7px] text-aegis-muted truncate">
                    {entry.droneId?.slice(0, 8)} — {entry.missionId?.slice(0, 8) || 'N/A'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Threat Board */}
          <div className="shrink-0 border-t border-aegis-border" style={{ maxHeight: '35%' }}>
            <div className="px-2 py-1.5 border-b border-aegis-border">
              <span className="font-tactical font-semibold text-[10px] tracking-widest text-aegis-red uppercase">
                THREAT BOARD
              </span>
            </div>
            <div className="overflow-y-auto" style={{ maxHeight: 140 }}>
              {hostileTracks.length === 0 && (
                <div className="px-2 py-2 font-mono text-[9px] text-aegis-green text-center">
                  NO ACTIVE THREATS
                </div>
              )}
              {hostileTracks.map((t) => (
                <div key={t.id} className="px-2 py-1 border-b border-aegis-border/30">
                  <div className="flex items-center gap-1">
                    <span className="text-aegis-red text-[10px]">◇</span>
                    <span className="font-mono text-[9px] text-aegis-red">{t.id.slice(0, 10)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-mono text-[8px] text-aegis-muted">{t.type}</span>
                    <span className="font-mono text-[8px] text-aegis-amber">Pk {t.pk}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Arsenal State */}
          <div className="shrink-0 border-t border-aegis-border">
            <div className="px-2 py-1.5 border-b border-aegis-border">
              <span className="font-tactical font-semibold text-[10px] tracking-widest text-aegis-cyan uppercase">
                ARSENAL STATE
              </span>
            </div>
            <div className="px-2 py-2 space-y-1">
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">PLATFORMS</span>
                <span className="font-mono text-[9px] text-aegis-text">{arsenalSummary.totalPlatforms}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[8px] text-aegis-muted">TOTAL ORD</span>
                <span className="font-mono text-[9px] text-aegis-text">{arsenalSummary.totalWeapons}</span>
              </div>
              {STRIKE_PACKAGE.filter((ac) => ac.weapons.length > 0).slice(0, 4).map((ac) => {
                const totalQty = ac.weapons.reduce((s, w) => s + w.quantity, 0);
                return (
                  <div key={ac.callsign} className="flex justify-between">
                    <span className="font-mono text-[7px] text-aegis-muted">{ac.callsign}</span>
                    <span className="font-mono text-[7px] text-aegis-text">{totalQty} rds</span>
                  </div>
                );
              })}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
