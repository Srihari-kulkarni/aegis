'use client';

import { Suspense, useState, useEffect, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthStore } from '@/stores/authStore';

const FAILED_ATTEMPT_WARNING_THRESHOLD = 3;

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-aegis-bg flex items-center justify-center">
        <div className="font-mono text-aegis-muted text-sm">LOADING...</div>
      </div>
    }>
      <LoginContent />
    </Suspense>
  );
}

function LoginContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const login = useAuthStore((s) => s.login);
  const mfaRequired = useAuthStore((s) => s.mfaRequired);
  const error = useAuthStore((s) => s.error);
  const isLoading = useAuthStore((s) => s.isLoading);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [totpCode, setTotpCode] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);

  const showSessionExpired =
    searchParams.get('session_expired') === '1' || searchParams.get('session_expired') === 'true';
  const showFailedAttemptWarning = failedAttempts >= FAILED_ATTEMPT_WARNING_THRESHOLD;

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (isLoading) return;

      const success = await login(username, password, mfaRequired ? totpCode : undefined);
      if (success) {
        router.push('/dashboard');
        return;
      }

      if (!mfaRequired) {
        setFailedAttempts((prev) => prev + 1);
      }
    },
    [username, password, totpCode, mfaRequired, isLoading, login, router]
  );

  useEffect(() => {
    if (isAuthenticated) {
      router.push('/dashboard');
    }
  }, [isAuthenticated, router]);

  return (
    <div className="min-h-screen bg-aegis-bg flex flex-col">
      {/* Classification banner */}
      <div className="w-full py-2 border-b border-aegis-border bg-aegis-panel">
        <p className="text-center text-aegis-amber font-mono text-xs tracking-[0.3em]">
          // UNCLASSIFIED // FOR OFFICIAL USE ONLY //
        </p>
      </div>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Logo / Title */}
          <div className="text-center mb-10">
            <h1 className="font-tactical font-bold text-3xl tracking-[0.2em] text-aegis-text uppercase">
              AEGIS COMMAND
            </h1>
            <p className="font-mono text-aegis-muted text-xs mt-2 tracking-widest uppercase">
              Secure Access Portal
            </p>
          </div>

          {/* Login panel */}
          <div className="tactical-panel p-8 border border-aegis-border">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Session timeout notification */}
              {showSessionExpired && (
                <div className="border border-aegis-amber bg-aegis-bg p-3">
                  <p className="font-mono text-aegis-amber text-xs">
                    SESSION EXPIRED. Please re-authenticate to continue.
                  </p>
                </div>
              )}

              {/* Failed attempt warning */}
              {showFailedAttemptWarning && !mfaRequired && (
                <div className="border border-aegis-red bg-aegis-bg p-3">
                  <p className="font-mono text-aegis-red text-xs">
                    WARNING: Multiple failed attempts detected. Account lockout may occur.
                  </p>
                </div>
              )}

              {/* Error message */}
              {error && (
                <div className="border border-aegis-red bg-aegis-bg p-3">
                  <p className="font-mono text-aegis-red text-xs">{error}</p>
                </div>
              )}

              {/* Username */}
              <div>
                <label htmlFor="username" className="data-label block mb-2">
                  Operator ID
                </label>
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="tactical-input w-full"
                  placeholder="Enter operator ID"
                  autoComplete="username"
                  disabled={isLoading}
                  autoFocus
                />
              </div>

              {/* Password */}
              <div>
                <label htmlFor="password" className="data-label block mb-2">
                  Credentials
                </label>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="tactical-input w-full"
                  placeholder="Enter credentials"
                  autoComplete="current-password"
                  disabled={isLoading}
                />
              </div>

              {/* TOTP MFA field - appears after password validation */}
              {mfaRequired && (
                <div className="opacity-100 transition-opacity duration-200">
                  <label htmlFor="totp" className="data-label block mb-2">
                    Two-Factor Authentication Code
                  </label>
                  <input
                    id="totp"
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={6}
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="tactical-input w-full font-mono text-lg tracking-[0.5em] text-center"
                    placeholder="000000"
                    autoComplete="one-time-code"
                    disabled={isLoading}
                    autoFocus
                  />
                  <p className="data-label mt-2 text-aegis-muted">
                    Enter 6-digit code from authenticator app
                  </p>
                </div>
              )}

              {/* Failed attempts counter */}
              {failedAttempts > 0 && !mfaRequired && (
                <p className="font-mono text-aegis-muted text-xs">
                  Failed attempts: {failedAttempts}
                </p>
              )}

              {/* Submit button */}
              <button
                type="submit"
                className="tactical-btn-primary w-full py-3 font-tactical font-semibold text-sm uppercase tracking-wider"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="animate-pulse">AUTHENTICATING...</span>
                  </span>
                ) : mfaRequired ? (
                  'Verify'
                ) : (
                  'Authenticate'
                )}
              </button>
            </form>
          </div>

          {/* Footer */}
          <p className="text-center font-mono text-aegis-muted text-[10px] mt-6 tracking-widest">
            Authorized Personnel Only · All Access Logged
          </p>
        </div>
      </main>
    </div>
  );
}
