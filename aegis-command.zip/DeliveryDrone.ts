import {
  DroneClass,
  DroneStatus,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export type BayStatus = 'LOADED' | 'EMPTY' | 'JETTISONED';

export interface PayloadBay {
  bay: number;
  status: BayStatus;
  weightKg: number;
}

export interface DeliveryDroneConfig extends DroneConfig {
  payloadBays?: PayloadBay[];
  deliveryAccuracy?: number;
}

export class DeliveryDrone extends DroneBase {
  payloadBays: PayloadBay[];
  casevacMode: boolean;
  deliveryAccuracy: number;

  private deliveryLog: Array<{ bay: number; action: string; timestamp: number }> = [];

  constructor(cfg: DeliveryDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.DELIVERY });
    this.payloadBays = cfg.payloadBays ?? [
      { bay: 1, status: 'EMPTY', weightKg: 0 },
      { bay: 2, status: 'EMPTY', weightKg: 0 },
    ];
    this.casevacMode = false;
    this.deliveryAccuracy = cfg.deliveryAccuracy ?? 5.0;
  }

  loadBay(bayNumber: number, weightKg: number): { success: boolean; reason: string } {
    const bay = this.payloadBays.find((b) => b.bay === bayNumber);
    if (!bay) {
      return { success: false, reason: `Bay ${bayNumber} does not exist` };
    }
    if (bay.status === 'JETTISONED') {
      return { success: false, reason: `Bay ${bayNumber} has been jettisoned and is unavailable` };
    }
    if (bay.status === 'LOADED') {
      return { success: false, reason: `Bay ${bayNumber} is already loaded` };
    }
    bay.status = 'LOADED';
    bay.weightKg = weightKg;
    this.deliveryLog.push({ bay: bayNumber, action: 'LOADED', timestamp: Date.now() });
    return { success: true, reason: `Bay ${bayNumber} loaded with ${weightKg}kg` };
  }

  deliverBay(bayNumber: number): { success: boolean; reason: string } {
    const bay = this.payloadBays.find((b) => b.bay === bayNumber);
    if (!bay) {
      return { success: false, reason: `Bay ${bayNumber} does not exist` };
    }
    if (bay.status !== 'LOADED') {
      return { success: false, reason: `Bay ${bayNumber} is ${bay.status}, cannot deliver` };
    }
    bay.status = 'EMPTY';
    bay.weightKg = 0;
    this.deliveryLog.push({ bay: bayNumber, action: 'DELIVERED', timestamp: Date.now() });
    return { success: true, reason: `Bay ${bayNumber} payload delivered` };
  }

  jettisonBay(bayNumber: number): { success: boolean; reason: string } {
    const bay = this.payloadBays.find((b) => b.bay === bayNumber);
    if (!bay) {
      return { success: false, reason: `Bay ${bayNumber} does not exist` };
    }
    if (bay.status === 'JETTISONED') {
      return { success: false, reason: `Bay ${bayNumber} already jettisoned` };
    }
    bay.status = 'JETTISONED';
    bay.weightKg = 0;
    this.deliveryLog.push({ bay: bayNumber, action: 'JETTISONED', timestamp: Date.now() });
    return { success: true, reason: `Bay ${bayNumber} jettisoned` };
  }

  enableCasevacMode(): void {
    this.casevacMode = true;
  }

  disableCasevacMode(): void {
    this.casevacMode = false;
  }

  getTotalPayloadKg(): number {
    return this.payloadBays.reduce((sum, bay) => sum + bay.weightKg, 0);
  }

  getLoadedBayCount(): number {
    return this.payloadBays.filter((b) => b.status === 'LOADED').length;
  }

  private emergencyJettisonAll(): void {
    for (const bay of this.payloadBays) {
      if (bay.status === 'LOADED') {
        bay.status = 'JETTISONED';
        bay.weightKg = 0;
        this.deliveryLog.push({ bay: bay.bay, action: 'EMERGENCY_JETTISON', timestamp: Date.now() });
      }
    }
  }

  getTypeMetrics(): TypeMetrics {
    return {
      payloadBays: this.payloadBays.map((b) => ({ ...b })),
      casevacMode: this.casevacMode,
      deliveryAccuracy: this.deliveryAccuracy,
      totalPayloadKg: this.getTotalPayloadKg(),
      loadedBayCount: this.getLoadedBayCount(),
      totalBays: this.payloadBays.length,
      deliveriesCompleted: this.deliveryLog.filter((e) => e.action === 'DELIVERED').length,
    };
  }

  getAIContextDescriptor(): string {
    const baysSummary = this.payloadBays
      .map((b) => `B${b.bay}:${b.status}(${b.weightKg}kg)`)
      .join(', ');
    return [
      `DELIVERY drone ${this.callsign} (${this.model})`,
      `Bays: [${baysSummary}] | Total: ${this.getTotalPayloadKg()}kg`,
      `CASEVAC: ${this.casevacMode ? 'ACTIVE' : 'OFF'} | Accuracy: ${this.deliveryAccuracy}m CEP`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'PRECISION_DELIVERY',
        available: false,
        degradedMode: 'No precision drop without active link; payload held onboard',
      },
      {
        capability: 'CASEVAC_OPERATIONS',
        available: this.casevacMode,
        degradedMode: 'Autonomous flight to pre-loaded CASEVAC LZ; no rerouting',
      },
      {
        capability: 'ROUTE_REPLANNING',
        available: false,
        degradedMode: 'Follows pre-loaded waypoint route only; no dynamic reroute',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS/GPS RTB with emergency jettison if altitude drops below safety threshold',
      },
      {
        capability: 'BAY_MANAGEMENT',
        available: true,
        degradedMode: 'Emergency jettison capability retained; no selective delivery',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;

    if (this.health < 0.3 || this.batteryPercent < 15) {
      this.emergencyJettisonAll();
      this.status = DroneStatus.EMERGENCY;
    }
  }
}

export default DeliveryDrone;
