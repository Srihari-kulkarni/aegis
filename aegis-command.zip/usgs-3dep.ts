import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, USGS3DEP } from '../types';

const CACHE_KEY = 'intel:usgs3dep';
const TTL = 86400;

export async function fetchUSGS3DEP(locations: Array<{ lat: number; lon: number }>): Promise<IntelFeedResult<USGS3DEP[]>> {
  if (locations.length === 0) {
    return { success: true, data: [], source: 'usgs-3dep', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  const locKey = locations.map((l) => `${l.lat.toFixed(4)}_${l.lon.toFixed(4)}`).join(':');
  const cacheKey = `${CACHE_KEY}:${Buffer.from(locKey).toString('base64').slice(0, 40)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'usgs-3dep', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const results: USGS3DEP[] = [];
    for (const loc of locations.slice(0, 10)) {
      const url = `https://epqs.nationalmap.gov/v1/json?x=${loc.lon}&y=${loc.lat}&wkid=4326&units=Meters&includeDate=false`;
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (!res.ok) continue;
      const json = await res.json() as { value: number };
      results.push({ lat: loc.lat, lon: loc.lon, elevationM: json.value ?? 0, resolution: '1/3 arc-second', dataset: '3DEP' });
    }

    if (results.length > 0) {
      await redis.set(cacheKey, JSON.stringify(results), 'EX', TTL);
      return { success: true, data: results, source: 'usgs-3dep', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
    }
    throw new Error('No results');
  } catch (err) {
    logger.warn({ err }, 'USGS 3DEP fetch failed — using simulated data');
    const sim = locations.map((l) => ({ lat: l.lat, lon: l.lon, elevationM: 30 + Math.random() * 400, resolution: 'simulated', dataset: 'simulated' }));
    return { success: true, data: sim, source: 'usgs-3dep-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}
