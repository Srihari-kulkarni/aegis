import { create } from 'zustand';
import { DroneClass, DroneStatus } from '@aegis/shared';
import { apiGet } from '@/lib/api';
import { getSocket } from '@/lib/socket';

interface DroneState {
  droneId: string;
  callsign: string;
  droneClass: DroneClass;
  model: string;
  manufacturer: string;
  serialNumber: string;
  status: DroneStatus;
  health: number;
  batteryPercent: number;
  fuelPercent: number;
  position: { lat: number; lon: number; alt: number };
  heading: number;
  speedKnots: number;
  altitude: number;
  linkQuality: number;
  currentMissionId: string | null;
  htsTokenId: string | null;
  htsSerialNumber: number | null;
  typeMetrics: Record<string, unknown>;
}

interface DroneStoreState {
  drones: Map<string, DroneState>;
  selectedDroneId: string | null;
  filter: { droneClass: DroneClass | null; status: DroneStatus | null };
  isLoading: boolean;
  fetchDrones: () => Promise<void>;
  selectDrone: (droneId: string | null) => void;
  updateDroneTelemetry: (droneId: string, data: Partial<DroneState>) => void;
  setFilter: (filter: Partial<DroneStoreState['filter']>) => void;
  getFilteredDrones: () => DroneState[];
  getSelectedDrone: () => DroneState | null;
  startTelemetryListener: () => void;
}

export const useDroneStore = create<DroneStoreState>((set, get) => ({
  drones: new Map(),
  selectedDroneId: null,
  filter: { droneClass: null, status: null },
  isLoading: false,

  fetchDrones: async () => {
    set({ isLoading: true });
    try {
      const res = await apiGet<{ drones: DroneState[]; total: number }>('/api/v1/drones');
      if (res.success && res.data) {
        const droneMap = new Map<string, DroneState>();
        const droneList = Array.isArray(res.data) ? res.data : (res.data.drones ?? []);
        for (const drone of droneList) {
          droneMap.set(drone.droneId, drone);
        }
        set({ drones: droneMap, isLoading: false });
      } else {
        set({ isLoading: false });
      }
    } catch {
      set({ isLoading: false });
    }
  },

  selectDrone: (droneId) => {
    set({ selectedDroneId: droneId });
  },

  updateDroneTelemetry: (droneId, data) => {
    const drones = new Map(get().drones);
    const existing = drones.get(droneId);
    if (existing) {
      drones.set(droneId, { ...existing, ...data });
      set({ drones });
    }
  },

  setFilter: (filter) => {
    set({ filter: { ...get().filter, ...filter } });
  },

  getFilteredDrones: () => {
    const { drones, filter } = get();
    let result = Array.from(drones.values());
    if (filter.droneClass) {
      result = result.filter((d) => d.droneClass === filter.droneClass);
    }
    if (filter.status) {
      result = result.filter((d) => d.status === filter.status);
    }
    return result;
  },

  getSelectedDrone: () => {
    const { drones, selectedDroneId } = get();
    if (!selectedDroneId) return null;
    return drones.get(selectedDroneId) ?? null;
  },

  startTelemetryListener: () => {
    const socket = getSocket('telemetry');
    if (!socket) return;

    socket.on('telemetry:update', (data: Record<string, unknown> & { droneId: string }) => {
      const update: Partial<DroneState> = {};
      if (data.position) update.position = data.position as DroneState['position'];
      if (data.heading != null) update.heading = data.heading as number;
      if (data.speedKnots != null) update.speedKnots = data.speedKnots as number;
      if (data.altitude != null) update.altitude = data.altitude as number;
      if (data.batteryPercent != null) update.batteryPercent = data.batteryPercent as number;
      if (data.fuelPercent != null) update.fuelPercent = data.fuelPercent as number;
      if (data.health != null) update.health = data.health as number;
      if (data.linkQuality != null) update.linkQuality = data.linkQuality as number;
      if (data.status) update.status = data.status as DroneStatus;
      if ('currentMissionId' in data) update.currentMissionId = (data.currentMissionId as string) || null;
      get().updateDroneTelemetry(data.droneId, update);
    });
  },
}));
