import {
  DroneClass,
  DroneStatus,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export interface RelayDroneConfig extends DroneConfig {
  manetProtocol?: string;
  loiterAltitude?: number;
  tethered?: boolean;
}

export class RelayDrone extends DroneBase {
  meshPeers: number;
  manetProtocol: string;
  satcomBridge: boolean;
  bandwidthUtilization: number;
  tethered: boolean;
  loiterAltitude: number;

  private connectedPeerIds: Set<string> = new Set();
  private relayUptimeStart: number;

  constructor(cfg: RelayDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.RELAY });
    this.meshPeers = 0;
    this.manetProtocol = cfg.manetProtocol ?? 'WAVE_RELAY';
    this.satcomBridge = false;
    this.bandwidthUtilization = 0;
    this.tethered = cfg.tethered ?? false;
    this.loiterAltitude = cfg.loiterAltitude ?? 3000;
    this.relayUptimeStart = Date.now();
  }

  addPeer(peerId: string): boolean {
    if (this.connectedPeerIds.has(peerId)) {
      return false;
    }
    this.connectedPeerIds.add(peerId);
    this.meshPeers = this.connectedPeerIds.size;
    return true;
  }

  removePeer(peerId: string): boolean {
    const removed = this.connectedPeerIds.delete(peerId);
    this.meshPeers = this.connectedPeerIds.size;
    return removed;
  }

  getConnectedPeers(): string[] {
    return Array.from(this.connectedPeerIds);
  }

  enableSatcomBridge(): void {
    this.satcomBridge = true;
  }

  disableSatcomBridge(): void {
    this.satcomBridge = false;
  }

  updateBandwidthUtilization(percent: number): void {
    this.bandwidthUtilization = Math.max(0, Math.min(100, percent));
  }

  setLoiterAltitude(altitudeFt: number): void {
    this.loiterAltitude = altitudeFt;
  }

  getRelayUptimeHours(): number {
    return (Date.now() - this.relayUptimeStart) / 3_600_000;
  }

  resetUptimeCounter(): void {
    this.relayUptimeStart = Date.now();
  }

  isCriticalRelay(): boolean {
    return this.meshPeers >= 3 || this.satcomBridge;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      meshPeers: this.meshPeers,
      connectedPeerIds: this.getConnectedPeers(),
      manetProtocol: this.manetProtocol,
      satcomBridge: this.satcomBridge,
      bandwidthUtilization: this.bandwidthUtilization,
      tethered: this.tethered,
      loiterAltitude: this.loiterAltitude,
      relayUptimeHours: this.getRelayUptimeHours(),
      criticalRelay: this.isCriticalRelay(),
    };
  }

  getAIContextDescriptor(): string {
    return [
      `RELAY drone ${this.callsign} (${this.model})`,
      `MANET: ${this.manetProtocol} | Peers: ${this.meshPeers}`,
      `SATCOM bridge: ${this.satcomBridge ? 'ACTIVE' : 'OFF'}`,
      `Bandwidth: ${this.bandwidthUtilization.toFixed(1)}%`,
      `Tethered: ${this.tethered} | Loiter alt: ${this.loiterAltitude}ft`,
      `Uptime: ${this.getRelayUptimeHours().toFixed(2)}h`,
      `Critical relay: ${this.isCriticalRelay()}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'MESH_RELAY',
        available: true,
        degradedMode: 'Maintains MANET mesh forwarding autonomously; no new peer registration',
      },
      {
        capability: 'SATCOM_BRIDGE',
        available: this.satcomBridge,
        degradedMode: 'SATCOM uplink maintained on last-configured transponder; no reconfiguration',
      },
      {
        capability: 'BANDWIDTH_MANAGEMENT',
        available: true,
        degradedMode: 'QoS rules applied from last-known config; priority traffic forwarded first',
      },
      {
        capability: 'POSITION_HOLD',
        available: true,
        degradedMode: this.tethered
          ? 'Tethered station-keeping; altitude maintained by tether'
          : `Autonomous loiter at ${this.loiterAltitude}ft on GPS/INS`,
      },
      {
        capability: 'PEER_DISCOVERY',
        available: true,
        degradedMode: 'Passive peer discovery via MANET beacons; no command-link peer adds',
      },
      {
        capability: 'TELEMETRY_FORWARD',
        available: true,
        degradedMode: 'Continues forwarding telemetry from mesh peers to any available uplink',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;

    if (this.satcomBridge) {
      this.linkQuality = Math.max(this.linkQuality, 0.3);
    }
  }
}

export default RelayDrone;
