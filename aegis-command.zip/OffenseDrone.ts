import {
  ArmingState,
  DroneClass,
  DroneStatus,
  OperatorRole,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

const VALID_ARMING_TRANSITIONS: Record<ArmingState, ArmingState[]> = {
  [ArmingState.SAFE]:           [ArmingState.MASTER_ARM_ON],
  [ArmingState.MASTER_ARM_ON]:  [ArmingState.SEEKER_ACTIVE, ArmingState.SAFE],
  [ArmingState.SEEKER_ACTIVE]:  [ArmingState.LOCKED, ArmingState.MASTER_ARM_ON],
  [ArmingState.LOCKED]:         [ArmingState.RELEASED, ArmingState.SEEKER_ACTIVE, ArmingState.SAFE],
  [ArmingState.RELEASED]:       [ArmingState.SAFE],
};

const WEAPON_COMMANDS = new Set<string>([
  'ARM', 'DISARM', 'WEAPON_RELEASE', 'SEEKER_ACTIVATE', 'MASTER_ARM',
]);

const AUTHORIZED_ROLES = new Set<string>([
  OperatorRole.MISSION_COMMANDER,
  OperatorRole.SUPER_ADMIN,
]);

export interface OffenseDroneConfig extends DroneConfig {
  payloadKg?: number;
  loiteringMunition?: boolean;
}

export class OffenseDrone extends DroneBase {
  armingState: ArmingState;
  payloadKg: number;
  seekerLocked: boolean;
  loiteringMunition: boolean;
  dualOperatorConfirmed: boolean;

  private armingLog: Array<{ from: ArmingState; to: ArmingState; timestamp: number }> = [];

  constructor(cfg: OffenseDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.OFFENSE });
    this.armingState = ArmingState.SAFE;
    this.payloadKg = cfg.payloadKg ?? 0;
    this.seekerLocked = false;
    this.loiteringMunition = cfg.loiteringMunition ?? false;
    this.dualOperatorConfirmed = false;
  }

  transitionArmingState(target: ArmingState): { success: boolean; reason: string } {
    const allowed = VALID_ARMING_TRANSITIONS[this.armingState];
    if (!allowed.includes(target)) {
      return {
        success: false,
        reason: `Invalid arming transition: ${this.armingState} → ${target}`,
      };
    }

    if (target === ArmingState.RELEASED && !this.dualOperatorConfirmed) {
      return {
        success: false,
        reason: 'Dual-operator confirmation required before weapon release',
      };
    }

    if (target === ArmingState.LOCKED && !this.seekerLocked) {
      return {
        success: false,
        reason: 'Seeker has not achieved lock; cannot transition to LOCKED',
      };
    }

    const previous = this.armingState;
    this.armingState = target;
    this.armingLog.push({ from: previous, to: target, timestamp: Date.now() });

    if (target === ArmingState.SAFE) {
      this.seekerLocked = false;
      this.dualOperatorConfirmed = false;
    }
    if (target === ArmingState.RELEASED) {
      this.payloadKg = 0;
      this.seekerLocked = false;
      this.dualOperatorConfirmed = false;
    }

    return { success: true, reason: `Arming state: ${previous} → ${target}` };
  }

  confirmDualOperator(): void {
    this.dualOperatorConfirmed = true;
  }

  setSeekerLock(locked: boolean): void {
    this.seekerLocked = locked;
    if (!locked && this.armingState === ArmingState.LOCKED) {
      this.armingState = ArmingState.SEEKER_ACTIVE;
      this.armingLog.push({
        from: ArmingState.LOCKED,
        to: ArmingState.SEEKER_ACTIVE,
        timestamp: Date.now(),
      });
    }
  }

  emergencySafe(): void {
    const previous = this.armingState;
    this.armingState = ArmingState.SAFE;
    this.seekerLocked = false;
    this.dualOperatorConfirmed = false;
    this.armingLog.push({ from: previous, to: ArmingState.SAFE, timestamp: Date.now() });
  }

  override validateCommand(
    command: string,
    operatorRole: string,
  ): { valid: boolean; reason: string } {
    const baseResult = super.validateCommand(command, operatorRole);
    if (!baseResult.valid) {
      return baseResult;
    }

    if (WEAPON_COMMANDS.has(command) && !AUTHORIZED_ROLES.has(operatorRole)) {
      return {
        valid: false,
        reason: `Role ${operatorRole} is not authorized for weapon command ${command}. Requires MISSION_COMMANDER or SUPER_ADMIN.`,
      };
    }

    if (command === 'WEAPON_RELEASE' && this.armingState !== ArmingState.LOCKED) {
      return {
        valid: false,
        reason: `Cannot release weapon: arming state is ${this.armingState}, requires LOCKED`,
      };
    }

    if (command === 'WEAPON_RELEASE' && !this.dualOperatorConfirmed) {
      return {
        valid: false,
        reason: 'Cannot release weapon: dual-operator confirmation not received',
      };
    }

    return { valid: true, reason: 'OK' };
  }

  getTypeMetrics(): TypeMetrics {
    return {
      armingState: this.armingState,
      payloadKg: this.payloadKg,
      seekerLocked: this.seekerLocked,
      loiteringMunition: this.loiteringMunition,
      dualOperatorConfirmed: this.dualOperatorConfirmed,
      armingTransitions: this.armingLog.length,
    };
  }

  getAIContextDescriptor(): string {
    return [
      `OFFENSE drone ${this.callsign} (${this.model})`,
      `Arming: ${this.armingState} | Seeker: ${this.seekerLocked ? 'LOCKED' : 'UNLOCKED'}`,
      `Payload: ${this.payloadKg}kg | Loitering munition: ${this.loiteringMunition}`,
      `Dual-op confirm: ${this.dualOperatorConfirmed}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'WEAPON_RELEASE',
        available: false,
        degradedMode: 'Weapon release prohibited without active command link',
      },
      {
        capability: 'SEEKER_TRACKING',
        available: false,
        degradedMode: 'Seeker deactivated; arming state forced to SAFE',
      },
      {
        capability: 'LOITER',
        available: this.loiteringMunition,
        degradedMode: 'Autonomous loiter on last known orbit; no engagement authority',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS-based RTB on pre-loaded route; weapons SAFE',
      },
      {
        capability: 'TELEMETRY_BROADCAST',
        available: true,
        degradedMode: 'Reduced-rate transponder beacon for recovery',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.emergencySafe();
  }
}

export default OffenseDrone;
