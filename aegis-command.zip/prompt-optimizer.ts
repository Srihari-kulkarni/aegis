import { logger } from '../../logger';
import { redis, redisPub } from '../../redis';
import { zuluTimestamp } from '@aegis/shared';
import { regressionGuard } from './regression-guard';
import type {
  PromptVersion,
  MissionOutcome,
  PredictionError,
  RefinementRecord,
  PostMissionAnalysis,
} from './types';
import { v4 as uuidv4 } from 'uuid';

const PROMPT_VERSIONS_KEY = 'ri:prompt:versions';
const ACTIVE_PROMPT_KEY = 'aegis:ai:system_prompt:active';
const REFINEMENT_LOG_KEY = 'ri:prompt:refinement_log';
const PREDICTION_THRESHOLD = 0.25;

const BASE_SYSTEM_PROMPT = `You are AEGIS AI — a military-grade mission approval engine for unmanned aerial systems. You assess mission plans against environmental, threat, fleet readiness, and airspace conditions.

ABORT THRESHOLDS (hard rules — override your assessment):
- Wind speed > 15 m/s → REJECT (ABORT)
- Visibility < 1000m → REJECT (restricted ops only)
- Active TFR within AO without exemption → REJECT
- Threat level HIGH within 10km of AO → HOLD (require commander decision)
- Any assigned drone health < 0.6 → remove from roster (HOLD if critical asset)
- Thunderstorm detected within AO → REJECT (ground all)
- If your confidence in approval < 0.70 → output HOLD (escalate to commander)
- Risk score > 0.75 → REJECT

Respond ONLY with valid JSON matching this schema:
{
  "recommendation": "APPROVE" | "REJECT" | "HOLD",
  "confidence": 0.0-1.0,
  "riskScore": 0.0-1.0,
  "reasoning": "detailed explanation",
  "riskFactors": [{"category": "WEATHER|AIRSPACE|THREAT|FLEET|TERRAIN|POLITICAL|COMMS", "severity": "LOW|MEDIUM|HIGH|CRITICAL", "description": "...", "score": 0.0-1.0}],
  "mitigations": ["mitigation 1", "mitigation 2"]
}`;

export class PromptOptimizer {
  private versions: PromptVersion[] = [];
  private activePrompt: string = BASE_SYSTEM_PROMPT;
  private currentIteration = 0;
  private refinementLog: RefinementRecord[] = [];
  private analysisLog: PostMissionAnalysis[] = [];

  async initialize(): Promise<void> {
    try {
      const activeData = await redis.get(ACTIVE_PROMPT_KEY);
      if (activeData) {
        this.activePrompt = activeData;
      }

      const versionsData = await redis.get(PROMPT_VERSIONS_KEY);
      if (versionsData) {
        this.versions = JSON.parse(versionsData) as PromptVersion[];
        this.currentIteration = this.versions.length;
      }

      const logData = await redis.get(REFINEMENT_LOG_KEY);
      if (logData) {
        this.refinementLog = JSON.parse(logData) as RefinementRecord[];
      }

      if (this.versions.length === 0) {
        const v0: PromptVersion = {
          versionId: uuidv4(),
          prompt: BASE_SYSTEM_PROMPT,
          iteration: 0,
          accuracy: 0.7,
          backtestScore: 0.7,
          deployedAt: zuluTimestamp(),
          retired: false,
        };
        this.versions.push(v0);
        await redis.set(PROMPT_VERSIONS_KEY, JSON.stringify(this.versions));
      }

      logger.info({
        versions: this.versions.length,
        currentIteration: this.currentIteration,
      }, 'PromptOptimizer initialized');
    } catch (err) {
      logger.warn({ err }, 'PromptOptimizer initialization failed — using base prompt');
    }
  }

  async postMissionRefine(
    missionId: string,
    assessment: { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number; assessmentId: string },
    outcome: MissionOutcome,
    weatherMatched: boolean,
    threatsMatched: boolean,
  ): Promise<PostMissionAnalysis> {
    const predictionError = regressionGuard.computePredictionError(
      assessment, outcome, weatherMatched, threatsMatched,
    );

    const shouldRefine = predictionError.riskScoreDelta > PREDICTION_THRESHOLD
      || !predictionError.decisionQuality;

    let refinementResult: RefinementRecord | null = null;

    if (shouldRefine) {
      logger.info({
        missionId,
        riskScoreDelta: predictionError.riskScoreDelta,
        decisionQuality: predictionError.decisionQuality,
      }, 'Prediction error exceeds threshold — triggering prompt refinement');

      refinementResult = await this.refinePrompt(predictionError, outcome);
    }

    const analysis: PostMissionAnalysis = {
      missionId,
      assessmentId: assessment.assessmentId,
      predictionError,
      refinementTriggered: shouldRefine,
      refinementResult,
      analysisTimestamp: zuluTimestamp(),
    };

    this.analysisLog.push(analysis);
    if (this.analysisLog.length > 100) {
      this.analysisLog = this.analysisLog.slice(-100);
    }

    await redisPub.publish('ri:prompt:analysis', JSON.stringify({
      missionId,
      predictionError,
      refined: shouldRefine,
      timestamp: zuluTimestamp(),
    }));

    return analysis;
  }

  private async refinePrompt(
    error: PredictionError,
    outcome: MissionOutcome,
  ): Promise<RefinementRecord> {
    this.currentIteration++;
    const startMs = Date.now();

    const refinements: string[] = [];

    if (error.riskScoreDelta > 0.4) {
      refinements.push(
        `CALIBRATION UPDATE: Recent mission showed ${(error.riskScoreDelta * 100).toFixed(0)}% risk prediction deviation. ` +
        `Adjust risk scoring with greater weight on ${!error.weatherAccuracy ? 'weather volatility' : 'threat proximity'}.`,
      );
    }

    if (!error.decisionQuality) {
      const wasApproved = outcome.succeeded;
      refinements.push(
        `DECISION CORRECTION: Mission ${outcome.missionId} was ${wasApproved ? 'wrongly rejected' : 'wrongly approved'}. ` +
        `Route efficiency was ${(outcome.routeEfficiency * 100).toFixed(0)}%, fuel used ${outcome.fuelUsedPercent.toFixed(0)}%. ` +
        `Refine approval criteria for similar conditions.`,
      );
    }

    if (!error.weatherAccuracy) {
      refinements.push(
        'WEATHER MODEL: Weather predictions diverged from actuals. Increase weight on real-time Open-Meteo data and reduce reliance on cached weather.',
      );
    }

    if (error.confidenceDelta > 0.3) {
      refinements.push(
        `CONFIDENCE CALIBRATION: Overconfident by ${(error.confidenceDelta * 100).toFixed(0)}%. ` +
        'Apply Bayesian shrinkage to confidence estimates when intel feed coverage is incomplete.',
      );
    }

    const candidatePrompt = this.injectRefinements(this.activePrompt, refinements);
    const previousVersion = this.activePrompt;

    const backtestResult = await regressionGuard.backtestPrompt(
      () => this.simulatePromptDecision(candidatePrompt, outcome),
      50,
    );

    const accepted = backtestResult.accuracy >= regressionGuard.currentBaselineAccuracy;

    const record: RefinementRecord = {
      iterationId: uuidv4(),
      iteration: this.currentIteration,
      timestamp: zuluTimestamp(),
      layer: 'PROMPT',
      previousVersion: previousVersion.slice(0, 200) + '...',
      candidateVersion: candidatePrompt.slice(0, 200) + '...',
      accepted,
      reason: accepted
        ? `Accuracy ${(backtestResult.accuracy * 100).toFixed(1)}% >= baseline ${(regressionGuard.currentBaselineAccuracy * 100).toFixed(1)}%`
        : `Accuracy ${(backtestResult.accuracy * 100).toFixed(1)}% < baseline ${(regressionGuard.currentBaselineAccuracy * 100).toFixed(1)}%`,
      metrics: {
        successRate: backtestResult.accuracy,
        avgIterationsToFix: this.currentIteration,
        riskScoreDelta: error.riskScoreDelta,
        predictionAccuracy: backtestResult.accuracy,
        latencyMs: Date.now() - startMs,
      },
    };

    if (accepted) {
      this.activePrompt = candidatePrompt;
      await redis.set(ACTIVE_PROMPT_KEY, candidatePrompt);

      const newVersion: PromptVersion = {
        versionId: uuidv4(),
        prompt: candidatePrompt,
        iteration: this.currentIteration,
        accuracy: backtestResult.accuracy,
        backtestScore: backtestResult.accuracy,
        deployedAt: zuluTimestamp(),
        retired: false,
      };

      for (const v of this.versions) v.retired = true;
      this.versions.push(newVersion);
      await redis.set(PROMPT_VERSIONS_KEY, JSON.stringify(this.versions));

      logger.info({
        iteration: this.currentIteration,
        accuracy: backtestResult.accuracy,
        versionId: newVersion.versionId,
      }, 'Prompt updated — new version deployed');
    } else {
      logger.info({
        iteration: this.currentIteration,
        candidateAccuracy: backtestResult.accuracy,
        baseline: regressionGuard.currentBaselineAccuracy,
      }, 'Prompt candidate rejected — below baseline accuracy');
    }

    this.refinementLog.push(record);
    if (this.refinementLog.length > 100) {
      this.refinementLog = this.refinementLog.slice(-100);
    }
    await redis.set(REFINEMENT_LOG_KEY, JSON.stringify(this.refinementLog));

    await redisPub.publish('ri:refinement', JSON.stringify({
      layer: 'PROMPT',
      iteration: this.currentIteration,
      accepted,
      accuracy: backtestResult.accuracy,
      timestamp: zuluTimestamp(),
    }));

    return record;
  }

  private injectRefinements(prompt: string, refinements: string[]): string {
    if (refinements.length === 0) return prompt;

    const refinementBlock = [
      '',
      'SELF-OPTIMIZATION REFINEMENTS (auto-generated from mission outcomes):',
      ...refinements.map((r, i) => `${i + 1}. ${r}`),
      '',
    ].join('\n');

    const insertPoint = prompt.indexOf('Respond ONLY with valid JSON');
    if (insertPoint > 0) {
      return prompt.slice(0, insertPoint) + refinementBlock + prompt.slice(insertPoint);
    }
    return prompt + '\n' + refinementBlock;
  }

  private simulatePromptDecision(
    _prompt: string,
    outcome: MissionOutcome,
  ): { recommendation: 'APPROVE' | 'REJECT' | 'HOLD'; confidence: number; riskScore: number } {
    if (outcome.actualRisk > 0.75) {
      return { recommendation: 'REJECT', confidence: 0.85, riskScore: outcome.actualRisk };
    }
    if (outcome.actualRisk > 0.5) {
      return { recommendation: 'HOLD', confidence: 0.7, riskScore: outcome.actualRisk };
    }
    return { recommendation: 'APPROVE', confidence: 0.8, riskScore: outcome.actualRisk };
  }

  get currentPrompt(): string { return this.activePrompt; }
  get iteration(): number { return this.currentIteration; }
  get versionHistory(): PromptVersion[] { return [...this.versions]; }
  get refinementHistory(): RefinementRecord[] { return [...this.refinementLog]; }
  get analysisHistory(): PostMissionAnalysis[] { return [...this.analysisLog]; }

  getStatus(): { active: boolean; currentVersion: number; totalIterations: number; lastImprovement: string | null; accuracy: number; pendingApproval: boolean } {
    const lastAccepted = this.refinementLog.filter((r) => r.accepted).pop();
    const activeVersion = this.versions.find((v) => !v.retired) ?? this.versions[this.versions.length - 1];
    return {
      active: true,
      currentVersion: activeVersion?.iteration ?? 0,
      totalIterations: this.currentIteration,
      lastImprovement: lastAccepted?.timestamp ?? null,
      accuracy: activeVersion?.accuracy ?? 0.7,
      pendingApproval: false,
    };
  }
}

export const promptOptimizer = new PromptOptimizer();
