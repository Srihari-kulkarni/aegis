import { logger } from '../../logger';
import { zuluTimestamp, type GeoPosition, type Threat } from '@aegis/shared';
import type { GPConfig, RouteGene, RouteFitness, GPGenerationReport } from './types';
import { v4 as uuidv4 } from 'uuid';

const DEFAULT_GP_CONFIG: GPConfig = {
  populationSize: 200,
  maxGenerations: 150,
  maxDepth: 12,
  crossoverRate: 0.7,
  mutationRate: 0.03,
  elitismPercent: 5,
  parsimonyCoefficient: 0.001,
  tournamentSize: 5,
};

interface RouteContext {
  origin: GeoPosition;
  destination: GeoPosition;
  threats: Threat[];
  terrain: TerrainPoint[];
  maxFlightTimeMin: number;
  cruiseSpeedKnots: number;
  fuelCapacityPercent: number;
}

interface TerrainPoint {
  position: GeoPosition;
  elevationM: number;
  canMask: boolean;
}

export class GeneticEngine {
  private config: GPConfig;
  private population: (RouteGene & { id: string })[] = [];
  private generationReports: GPGenerationReport[] = [];
  private bestEver: (RouteGene & { id: string }) | null = null;
  private context: RouteContext | null = null;

  constructor(config?: Partial<GPConfig>) {
    this.config = { ...DEFAULT_GP_CONFIG, ...config };
  }

  evolve(context: RouteContext, existingRoute?: GeoPosition[]): RouteGene {
    this.context = context;
    this.generationReports = [];

    this.initializePopulation(context, existingRoute);
    this.bestEver = null;

    for (let gen = 0; gen < this.config.maxGenerations; gen++) {
      this.evaluateFitness();

      const sorted = this.population.sort((a, b) => b.fitness - a.fitness);
      const best = sorted[0];

      if (!this.bestEver || best.fitness > this.bestEver.fitness) {
        this.bestEver = { ...best };
      }

      const report = this.buildGenerationReport(gen);
      this.generationReports.push(report);

      if (gen % 25 === 0) {
        logger.debug({
          generation: gen,
          bestFitness: best.fitness.toFixed(4),
          avgFitness: report.avgFitness.toFixed(4),
        }, 'GP generation report');
      }

      if (best.fitness > 0.98) {
        logger.info({ generation: gen, fitness: best.fitness }, 'GP converged early');
        break;
      }

      this.population = this.nextGeneration(sorted);
    }

    this.evaluateFitness();
    const finalBest = this.population.sort((a, b) => b.fitness - a.fitness)[0];

    if (!this.bestEver || finalBest.fitness > this.bestEver.fitness) {
      this.bestEver = { ...finalBest };
    }

    return this.bestEver;
  }

  private initializePopulation(context: RouteContext, seedRoute?: GeoPosition[]): void {
    this.population = [];

    if (seedRoute && seedRoute.length > 0) {
      for (let i = 0; i < Math.min(10, Math.floor(this.config.populationSize * 0.05)); i++) {
        const mutated = this.perturbRoute(seedRoute, 0.05 * (i + 1));
        this.population.push({
          id: uuidv4(),
          waypoints: mutated,
          fitness: 0,
          generation: 0,
          parentIds: null,
        });
      }
    }

    while (this.population.length < this.config.populationSize) {
      const route = this.generateRandomRoute(context);
      this.population.push({
        id: uuidv4(),
        waypoints: route,
        fitness: 0,
        generation: 0,
        parentIds: null,
      });
    }
  }

  private generateRandomRoute(context: RouteContext): GeoPosition[] {
    const numWaypoints = 3 + Math.floor(Math.random() * (this.config.maxDepth - 3));
    const waypoints: GeoPosition[] = [{ ...context.origin }];

    for (let i = 1; i < numWaypoints - 1; i++) {
      const t = i / (numWaypoints - 1);
      const lat = context.origin.lat + (context.destination.lat - context.origin.lat) * t + (Math.random() - 0.5) * 0.1;
      const lon = context.origin.lon + (context.destination.lon - context.origin.lon) * t + (Math.random() - 0.5) * 0.1;
      const alt = 100 + Math.random() * 5000;
      waypoints.push({ lat, lon, alt });
    }

    waypoints.push({ ...context.destination });
    return waypoints;
  }

  private perturbRoute(route: GeoPosition[], magnitude: number): GeoPosition[] {
    return route.map((wp, i) => {
      if (i === 0 || i === route.length - 1) return { ...wp };
      return {
        lat: wp.lat + (Math.random() - 0.5) * magnitude,
        lon: wp.lon + (Math.random() - 0.5) * magnitude,
        alt: Math.max(50, wp.alt + (Math.random() - 0.5) * magnitude * 10000),
      };
    });
  }

  private evaluateFitness(): void {
    if (!this.context) return;

    for (const individual of this.population) {
      const fitness = this.computeFitness(individual.waypoints, this.context);
      individual.fitness = fitness.total;
    }
  }

  computeFitness(waypoints: GeoPosition[], context: RouteContext): RouteFitness {
    const totalDistKm = this.computeTotalDistance(waypoints);
    const directDistKm = this.haversineDistance(context.origin, context.destination);
    const distanceRatio = directDistKm / Math.max(totalDistKm, 0.01);
    const fuelEfficiency = Math.min(1, distanceRatio);

    let threatExposureScore = 1.0;
    for (const wp of waypoints) {
      for (const threat of context.threats) {
        const dist = this.haversineDistance(wp, threat.position);
        if (dist < threat.radiusKm) {
          threatExposureScore -= (0.3 * threat.confidence * (1 - dist / threat.radiusKm));
        } else if (dist < threat.radiusKm * 2) {
          threatExposureScore -= (0.05 * threat.confidence);
        }
      }
    }
    threatExposureScore = Math.max(0, threatExposureScore);

    let terrainMasking = 0;
    if (context.terrain.length > 0) {
      let maskablePoints = 0;
      for (const wp of waypoints) {
        const nearestTerrain = context.terrain.reduce((best, t) => {
          const d = this.haversineDistance(wp, t.position);
          return d < this.haversineDistance(wp, best.position) ? t : best;
        }, context.terrain[0]);
        if (nearestTerrain.canMask && wp.alt < nearestTerrain.elevationM + 200) {
          maskablePoints++;
        }
      }
      terrainMasking = waypoints.length > 0 ? maskablePoints / waypoints.length : 0;
    } else {
      terrainMasking = 0.5;
    }

    const estTimeMin = (totalDistKm / (context.cruiseSpeedKnots * 1.852)) * 60;
    const etaRatio = context.maxFlightTimeMin / Math.max(estTimeMin, 1);
    const etaAccuracy = Math.min(1, Math.max(0, 1 - Math.abs(1 - etaRatio) * 2));

    const sizePenalty = this.config.parsimonyCoefficient * waypoints.length;

    const total = (
      fuelEfficiency * 0.25 +
      threatExposureScore * 0.35 +
      terrainMasking * 0.20 +
      etaAccuracy * 0.20
    ) - sizePenalty;

    return {
      total: Math.max(0, Math.min(1, total)),
      fuelEfficiency,
      threatExposure: threatExposureScore,
      terrainMasking,
      etaAccuracy,
      distancePenalty: sizePenalty,
    };
  }

  private nextGeneration(sorted: (RouteGene & { id: string })[]): (RouteGene & { id: string })[] {
    const next: (RouteGene & { id: string })[] = [];
    const gen = (sorted[0]?.generation ?? 0) + 1;
    const eliteCount = Math.max(1, Math.floor(this.config.populationSize * this.config.elitismPercent / 100));

    for (let i = 0; i < eliteCount && i < sorted.length; i++) {
      next.push({ ...sorted[i], generation: gen });
    }

    while (next.length < this.config.populationSize) {
      const parentA = this.tournamentSelect(sorted);
      const parentB = this.tournamentSelect(sorted);

      let childWaypoints: GeoPosition[];

      if (Math.random() < this.config.crossoverRate) {
        childWaypoints = this.crossover(parentA.waypoints, parentB.waypoints);
      } else {
        childWaypoints = [...parentA.waypoints.map((wp) => ({ ...wp }))];
      }

      if (Math.random() < this.config.mutationRate) {
        childWaypoints = this.mutate(childWaypoints);
      }

      if (childWaypoints.length > this.config.maxDepth) {
        childWaypoints = this.enforceDepthLimit(childWaypoints);
      }

      next.push({
        id: uuidv4(),
        waypoints: childWaypoints,
        fitness: 0,
        generation: gen,
        parentIds: [parentA.id, parentB.id],
      });
    }

    return next;
  }

  private tournamentSelect(population: (RouteGene & { id: string })[]): RouteGene & { id: string } {
    let best = population[Math.floor(Math.random() * population.length)];
    for (let i = 1; i < this.config.tournamentSize; i++) {
      const challenger = population[Math.floor(Math.random() * population.length)];
      if (challenger.fitness > best.fitness) {
        best = challenger;
      }
    }
    return best;
  }

  private crossover(parentA: GeoPosition[], parentB: GeoPosition[]): GeoPosition[] {
    const cutA = 1 + Math.floor(Math.random() * (parentA.length - 2));
    const cutB = 1 + Math.floor(Math.random() * (parentB.length - 2));

    const child = [
      ...parentA.slice(0, cutA).map((wp) => ({ ...wp })),
      ...parentB.slice(cutB).map((wp) => ({ ...wp })),
    ];

    return child.length >= 2 ? child : parentA.map((wp) => ({ ...wp }));
  }

  private mutate(waypoints: GeoPosition[]): GeoPosition[] {
    const result = waypoints.map((wp) => ({ ...wp }));
    const mutationType = Math.random();

    if (mutationType < 0.4 && result.length > 2) {
      const idx = 1 + Math.floor(Math.random() * (result.length - 2));
      result[idx] = {
        lat: result[idx].lat + (Math.random() - 0.5) * 0.05,
        lon: result[idx].lon + (Math.random() - 0.5) * 0.05,
        alt: Math.max(50, result[idx].alt + (Math.random() - 0.5) * 1000),
      };
    } else if (mutationType < 0.7 && result.length < this.config.maxDepth) {
      const idx = 1 + Math.floor(Math.random() * (result.length - 1));
      const prev = result[idx - 1];
      const next = result[idx];
      const newWp: GeoPosition = {
        lat: (prev.lat + next.lat) / 2 + (Math.random() - 0.5) * 0.02,
        lon: (prev.lon + next.lon) / 2 + (Math.random() - 0.5) * 0.02,
        alt: (prev.alt + next.alt) / 2 + (Math.random() - 0.5) * 500,
      };
      result.splice(idx, 0, newWp);
    } else if (result.length > 3) {
      const idx = 1 + Math.floor(Math.random() * (result.length - 2));
      result.splice(idx, 1);
    }

    return result;
  }

  private enforceDepthLimit(waypoints: GeoPosition[]): GeoPosition[] {
    if (waypoints.length <= this.config.maxDepth) return waypoints;
    const keepIndices = new Set([0, waypoints.length - 1]);
    const step = (waypoints.length - 2) / (this.config.maxDepth - 2);
    for (let i = 0; keepIndices.size < this.config.maxDepth; i++) {
      keepIndices.add(Math.min(Math.round(1 + i * step), waypoints.length - 2));
    }
    return waypoints.filter((_, i) => keepIndices.has(i));
  }

  private buildGenerationReport(gen: number): GPGenerationReport {
    const fitnesses = this.population.map((p) => p.fitness);
    const best = Math.max(...fitnesses);
    const worst = Math.min(...fitnesses);
    const avg = fitnesses.reduce((a, b) => a + b, 0) / fitnesses.length;

    const uniqueRoutes = new Set(this.population.map((p) =>
      p.waypoints.map((w) => `${w.lat.toFixed(4)},${w.lon.toFixed(4)}`).join('|')
    ));

    return {
      generation: gen,
      bestFitness: best,
      avgFitness: avg,
      worstFitness: worst,
      diversity: uniqueRoutes.size / this.population.length,
      eliteCount: Math.floor(this.config.populationSize * this.config.elitismPercent / 100),
      mutationCount: 0,
      crossoverCount: 0,
      timestamp: zuluTimestamp(),
    };
  }

  private computeTotalDistance(waypoints: GeoPosition[]): number {
    let total = 0;
    for (let i = 1; i < waypoints.length; i++) {
      total += this.haversineDistance(waypoints[i - 1], waypoints[i]);
    }
    return total;
  }

  private haversineDistance(a: GeoPosition, b: GeoPosition): number {
    const R = 6371;
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLon = (b.lon - a.lon) * Math.PI / 180;
    const lat1 = a.lat * Math.PI / 180;
    const lat2 = b.lat * Math.PI / 180;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  }

  get reports(): GPGenerationReport[] { return [...this.generationReports]; }
  get bestRoute(): RouteGene | null { return this.bestEver; }
  get currentConfig(): GPConfig { return { ...this.config }; }
  setConfig(config: Partial<GPConfig>): void { this.config = { ...this.config, ...config }; }
}

export const geneticEngine = new GeneticEngine();
