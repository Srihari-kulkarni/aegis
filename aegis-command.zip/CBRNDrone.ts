import {
  DroneClass,
  DroneStatus,
  GeoJSON,
  GeoPosition,
  zuluTimestamp,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export type ChemicalAgent = 'Sarin' | 'VX' | 'Mustard' | 'Novichok';

export interface CBRNAlert {
  alertId: string;
  agent: ChemicalAgent | string;
  detectedAt: string;
  position: GeoPosition;
  concentrationLevel: 'TRACE' | 'LOW' | 'MODERATE' | 'HIGH' | 'LETHAL';
  radiationMsv: number;
}

export interface CBRNDroneConfig extends DroneConfig {
  bioSamplerCount?: number;
}

export class CBRNDrone extends DroneBase {
  chemicalDetectors: Record<ChemicalAgent, boolean>;
  bioSamplerCount: number;
  radiationMsv: number;
  contaminationZone: GeoJSON.Polygon | null;

  private alerts: CBRNAlert[] = [];
  private samplingActive: boolean = false;
  private samplesCollected: number = 0;
  private alertSequence: number = 0;

  constructor(cfg: CBRNDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.CBRN });
    this.chemicalDetectors = {
      Sarin: true,
      VX: true,
      Mustard: true,
      Novichok: true,
    };
    this.bioSamplerCount = cfg.bioSamplerCount ?? 8;
    this.radiationMsv = 0;
    this.contaminationZone = null;
  }

  enableDetector(agent: ChemicalAgent): void {
    this.chemicalDetectors[agent] = true;
  }

  disableDetector(agent: ChemicalAgent): void {
    this.chemicalDetectors[agent] = false;
  }

  getActiveDetectors(): ChemicalAgent[] {
    return (Object.keys(this.chemicalDetectors) as ChemicalAgent[]).filter(
      (agent) => this.chemicalDetectors[agent],
    );
  }

  startSampling(): void {
    this.samplingActive = true;
  }

  stopSampling(): void {
    this.samplingActive = false;
  }

  collectSample(): boolean {
    if (!this.samplingActive || this.samplesCollected >= this.bioSamplerCount) {
      return false;
    }
    this.samplesCollected++;
    return true;
  }

  getSamplesRemaining(): number {
    return this.bioSamplerCount - this.samplesCollected;
  }

  updateRadiation(msv: number): void {
    this.radiationMsv = msv;
  }

  setContaminationZone(polygon: GeoJSON.Polygon): void {
    this.contaminationZone = polygon;
  }

  clearContaminationZone(): void {
    this.contaminationZone = null;
  }

  generateAlert(
    agent: ChemicalAgent | string,
    concentrationLevel: CBRNAlert['concentrationLevel'],
  ): CBRNAlert {
    this.alertSequence++;
    const alert: CBRNAlert = {
      alertId: `CBRN-${this.callsign}-${this.alertSequence}`,
      agent,
      detectedAt: zuluTimestamp(),
      position: { ...this.position },
      concentrationLevel,
      radiationMsv: this.radiationMsv,
    };
    this.alerts.push(alert);
    return alert;
  }

  getAlerts(): CBRNAlert[] {
    return [...this.alerts];
  }

  getLatestAlert(): CBRNAlert | null {
    return this.alerts.length > 0 ? this.alerts[this.alerts.length - 1] : null;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      chemicalDetectors: { ...this.chemicalDetectors },
      activeDetectorCount: this.getActiveDetectors().length,
      bioSamplerCount: this.bioSamplerCount,
      samplesCollected: this.samplesCollected,
      samplesRemaining: this.getSamplesRemaining(),
      radiationMsv: this.radiationMsv,
      contaminationZoneDefined: this.contaminationZone !== null,
      samplingActive: this.samplingActive,
      alertCount: this.alerts.length,
      latestAlert: this.getLatestAlert(),
    };
  }

  getAIContextDescriptor(): string {
    const activeDetectors = this.getActiveDetectors().join(', ') || 'NONE';
    const latestAlert = this.getLatestAlert();
    const alertInfo = latestAlert
      ? `ALERT: ${latestAlert.agent} (${latestAlert.concentrationLevel}) @ ${latestAlert.detectedAt}`
      : 'No active alerts';

    return [
      `CBRN drone ${this.callsign} (${this.model})`,
      `Detectors: [${activeDetectors}]`,
      `Radiation: ${this.radiationMsv} mSv`,
      `Bio-samplers: ${this.samplesCollected}/${this.bioSamplerCount} used | Sampling: ${this.samplingActive ? 'ACTIVE' : 'OFF'}`,
      `Contamination zone: ${this.contaminationZone ? 'DEFINED' : 'NONE'}`,
      alertInfo,
      `Total alerts: ${this.alerts.length}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'CHEMICAL_DETECTION',
        available: true,
        degradedMode: 'Continuous detection with onboard storage; alerts queued for uplink on reconnect',
      },
      {
        capability: 'BIO_SAMPLING',
        available: this.getSamplesRemaining() > 0,
        degradedMode: 'Autonomous sampling at pre-planned waypoints; samples stored onboard',
      },
      {
        capability: 'RADIATION_MONITORING',
        available: true,
        degradedMode: 'Continuous radiation level logging; dose-rate map built onboard',
      },
      {
        capability: 'CONTAMINATION_MAPPING',
        available: true,
        degradedMode: 'Autonomous boundary tracing using onboard sensor fusion; map stored locally',
      },
      {
        capability: 'ALERT_BROADCAST',
        available: false,
        degradedMode: 'Alerts stored onboard; broadcast queued for reconnection',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS dead-reckoning on pre-planned survey grid; area marked for hazard',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.startSampling();

    if (!this.contaminationZone) {
      const offset = 0.005;
      this.contaminationZone = {
        type: 'Polygon',
        coordinates: [[
          [this.position.lon - offset, this.position.lat - offset],
          [this.position.lon + offset, this.position.lat - offset],
          [this.position.lon + offset, this.position.lat + offset],
          [this.position.lon - offset, this.position.lat + offset],
          [this.position.lon - offset, this.position.lat - offset],
        ]],
      };
    }
  }
}

export default CBRNDrone;
