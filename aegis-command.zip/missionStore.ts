import { create } from 'zustand';
import { MissionStatus, MissionType } from '@aegis/shared';
import { apiGet, apiPost } from '@/lib/api';

interface MissionState {
  missionId: string;
  name: string;
  type: MissionType;
  status: MissionStatus;
  commanderId: string;
  commanderCallsign: string;
  description: string;
  assignedDroneIds: string[];
  hcsTopicId: string | null;
  aiAssessmentId: string | null;
  plannedStartTime: string;
  plannedEndTime: string;
  clearanceLevel: string;
  createdAt: string;
}

interface AIAssessmentState {
  assessmentId: string;
  missionId: string;
  recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
  confidence: number;
  riskScore: number;
  reasoning: string;
  riskFactors: Array<{ category: string; severity: string; description: string; score: number }>;
  mitigations: string[];
  assessedAt: string;
}

interface MissionStoreState {
  missions: MissionState[];
  selectedMissionId: string | null;
  selectedAssessment: AIAssessmentState | null;
  isLoading: boolean;
  statusFilter: MissionStatus | null;
  fetchMissions: () => Promise<void>;
  selectMission: (missionId: string | null) => void;
  createMission: (data: Record<string, unknown>) => Promise<boolean>;
  approveMission: (missionId: string) => Promise<boolean>;
  abortMission: (missionId: string) => Promise<boolean>;
  overrideMission: (missionId: string, reason: string, mfaCode: string) => Promise<boolean>;
  fetchAssessment: (missionId: string) => Promise<void>;
  setStatusFilter: (status: MissionStatus | null) => void;
  getSelectedMission: () => MissionState | null;
  getFilteredMissions: () => MissionState[];
}

export const useMissionStore = create<MissionStoreState>((set, get) => ({
  missions: [],
  selectedMissionId: null,
  selectedAssessment: null,
  isLoading: false,
  statusFilter: null,

  fetchMissions: async () => {
    set({ isLoading: true });
    try {
      const params = get().statusFilter ? `?status=${get().statusFilter}` : '';
      const res = await apiGet<{ data: MissionState[] }>(`/api/v1/missions${params}`);
      if (res.success && res.data) {
        set({ missions: res.data.data ?? (res.data as unknown as MissionState[]), isLoading: false });
      } else {
        set({ isLoading: false });
      }
    } catch {
      set({ isLoading: false });
    }
  },

  selectMission: (missionId) => {
    set({ selectedMissionId: missionId, selectedAssessment: null });
    if (missionId) {
      get().fetchAssessment(missionId);
    }
  },

  createMission: async (data) => {
    try {
      const res = await apiPost<MissionState>('/api/v1/missions', data);
      if (res.success) {
        await get().fetchMissions();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  approveMission: async (missionId) => {
    try {
      const res = await apiPost(`/api/v1/missions/${missionId}/approve`);
      if (res.success) {
        await get().fetchMissions();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  abortMission: async (missionId) => {
    try {
      const res = await apiPost(`/api/v1/missions/${missionId}/abort`);
      if (res.success) {
        await get().fetchMissions();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  overrideMission: async (missionId, reason, mfaCode) => {
    try {
      const res = await apiPost(`/api/v1/missions/${missionId}/override`, { reason, mfaCode });
      if (res.success) {
        await get().fetchMissions();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

  fetchAssessment: async (missionId) => {
    try {
      const res = await apiGet<{ mission: MissionState; assessment: AIAssessmentState }>(`/api/v1/missions/${missionId}`);
      if (res.success && res.data?.assessment) {
        set({ selectedAssessment: res.data.assessment });
      }
    } catch {
      // Assessment may not exist yet
    }
  },

  setStatusFilter: (status) => {
    set({ statusFilter: status });
    get().fetchMissions();
  },

  getSelectedMission: () => {
    const { missions, selectedMissionId } = get();
    if (!selectedMissionId) return null;
    return missions.find((m) => m.missionId === selectedMissionId) ?? null;
  },

  getFilteredMissions: () => {
    const { missions, statusFilter } = get();
    if (!statusFilter) return missions;
    return missions.filter((m) => m.status === statusFilter);
  },
}));
