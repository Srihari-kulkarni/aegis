import { io, Socket } from 'socket.io-client';
import { getAccessToken } from './api';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? 'http://localhost:4000';

interface SocketInstances {
  telemetry: Socket | null;
  missionFeed: Socket | null;
  aiIntel: Socket | null;
  threats: Socket | null;
}

const sockets: SocketInstances = {
  telemetry: null,
  missionFeed: null,
  aiIntel: null,
  threats: null,
};

let connectionStatus: 'connected' | 'connecting' | 'disconnected' | 'degraded' = 'disconnected';
let statusListeners: Array<(status: typeof connectionStatus) => void> = [];

function createSocket(namespace: string): Socket {
  const token = getAccessToken();
  const socket = io(`${WS_URL}${namespace}`, {
    auth: { token },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 10000,
    timeout: 10000,
    autoConnect: false,
  });

  socket.on('connect', () => {
    updateConnectionStatus();
  });

  socket.on('disconnect', () => {
    updateConnectionStatus();
  });

  socket.on('connect_error', () => {
    updateConnectionStatus();
  });

  return socket;
}

function updateConnectionStatus(): void {
  const allSockets = Object.values(sockets).filter((s): s is Socket => s !== null);
  if (allSockets.length === 0) {
    connectionStatus = 'disconnected';
  } else {
    const connected = allSockets.filter((s) => s.connected).length;
    if (connected === allSockets.length) {
      connectionStatus = 'connected';
    } else if (connected > 0) {
      connectionStatus = 'degraded';
    } else {
      connectionStatus = 'disconnected';
    }
  }
  statusListeners.forEach((fn) => fn(connectionStatus));
}

export function connectAll(): void {
  if (!getAccessToken()) return;

  connectionStatus = 'connecting';
  statusListeners.forEach((fn) => fn(connectionStatus));

  sockets.telemetry = createSocket('/telemetry');
  sockets.missionFeed = createSocket('/mission-feed');
  sockets.aiIntel = createSocket('/ai-intel');
  sockets.threats = createSocket('/threats');

  Object.values(sockets).forEach((s) => s?.connect());
}

export function disconnectAll(): void {
  Object.values(sockets).forEach((s) => s?.disconnect());
  sockets.telemetry = null;
  sockets.missionFeed = null;
  sockets.aiIntel = null;
  sockets.threats = null;
  connectionStatus = 'disconnected';
  statusListeners.forEach((fn) => fn(connectionStatus));
}

export function getSocket(namespace: keyof SocketInstances): Socket | null {
  return sockets[namespace];
}

export function getConnectionStatus(): typeof connectionStatus {
  return connectionStatus;
}

export function onConnectionStatusChange(listener: (status: typeof connectionStatus) => void): () => void {
  statusListeners.push(listener);
  return () => {
    statusListeners = statusListeners.filter((fn) => fn !== listener);
  };
}

export function subscribeToDrone(droneId: string): void {
  sockets.telemetry?.emit('subscribe:drone', droneId);
}

export function unsubscribeFromDrone(droneId: string): void {
  sockets.telemetry?.emit('unsubscribe:drone', droneId);
}

export function subscribeToAllDrones(): void {
  sockets.telemetry?.emit('subscribe:all');
}

export function subscribeToMission(missionId: string): void {
  sockets.missionFeed?.emit('subscribe:mission', missionId);
}

export function subscribeToAllMissions(): void {
  sockets.missionFeed?.emit('subscribe:all');
}
