import { Router, Request, Response } from 'express';
import { authMiddleware, rbacGuard } from '../auth/middleware';
import { aiEngine } from '../ai/AIMissionApprovalEngine';
import { continuousIntelFeed } from '../ai/ContinuousIntelFeed';
import { modelRouter } from '../ai/model-router';
import { feedManager } from '../intel/feed-manager';
import { riSystem } from '../ai/recursive-improvement';
import { DroneClass } from '@aegis/shared';
import { redis } from '../redis';
import { query } from '../db/pool';
import { logger } from '../logger';

const router = Router();

router.get('/weather', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const lat = parseFloat(req.query.lat as string) || 34.052;
    const lon = parseFloat(req.query.lon as string) || -118.244;

    const weather = await aiEngine.fetchWeatherData(lat, lon);

    res.json({
      success: true,
      data: weather,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch weather');
    res.status(500).json({ success: false, error: 'Weather fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/threats', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const lat = parseFloat(req.query.lat as string) || 34.052;
    const lon = parseFloat(req.query.lon as string) || -118.244;

    const threats = await aiEngine.fetchThreatData(lat, lon);

    res.json({
      success: true,
      data: threats,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch threats');
    res.status(500).json({ success: false, error: 'Threat fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/airspace', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const lat = parseFloat(req.query.lat as string) || 34.052;
    const lon = parseFloat(req.query.lon as string) || -118.244;

    const airspace = await aiEngine.fetchAirspaceData(lat, lon);

    const nfzResult = await query(
      `SELECT zone_id, name, polygon, floor_ft, ceiling_ft, permanent, active_from, active_to, reason
       FROM no_fly_zones
       WHERE permanent = TRUE OR (active_from <= NOW() AND active_to >= NOW())`
    );

    res.json({
      success: true,
      data: {
        ...airspace,
        noFlyZones: nfzResult.rows,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch airspace');
    res.status(500).json({ success: false, error: 'Airspace fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/risk-history/:missionId', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const { missionId } = req.params;
    const history = continuousIntelFeed.getRiskHistory(missionId);

    if (!history) {
      res.json({
        success: true,
        data: { missionId, scores: [], timestamps: [], message: 'No risk history available for this mission' },
        timestamp: new Date().toISOString(),
      });
      return;
    }

    res.json({
      success: true,
      data: history,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch risk history');
    res.status(500).json({ success: false, error: 'Risk history fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/feeds', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const lat = parseFloat(req.query.lat as string) || 34.052;
    const lon = parseFloat(req.query.lon as string) || -118.244;

    const feeds = await feedManager.fetchAllFeeds(lat, lon);

    const summary = {
      openSky: { available: !!feeds.openSky, source: feeds.openSky?.source, count: feeds.openSky?.data?.length ?? 0 },
      adsbExchange: { available: !!feeds.adsbExchange, source: feeds.adsbExchange?.source, count: feeds.adsbExchange?.data?.length ?? 0 },
      openMeteo: { available: !!feeds.openMeteo, source: feeds.openMeteo?.source },
      openWeatherMap: { available: !!feeds.openWeatherMap, source: feeds.openWeatherMap?.source },
      noaaWeather: { available: !!feeds.noaaWeather, source: feeds.noaaWeather?.source, alerts: feeds.noaaWeather?.data?.length ?? 0 },
      faaTFR: { available: !!feeds.faaTFR, source: feeds.faaTFR?.source, tfrs: feeds.faaTFR?.data?.length ?? 0 },
      noaaSpaceWeather: { available: !!feeds.noaaSpaceWeather, source: feeds.noaaSpaceWeather?.source, kpIndex: feeds.noaaSpaceWeather?.data?.kpIndex },
      openTopo: { available: !!feeds.openTopo, source: feeds.openTopo?.source },
      usgs3dep: { available: !!feeds.usgs3dep, source: feeds.usgs3dep?.source },
      radioRef: { available: !!feeds.radioRef, source: feeds.radioRef?.source, frequencies: feeds.radioRef?.data?.length ?? 0 },
      airLabs: { available: !!feeds.airLabs, source: feeds.airLabs?.source, flights: feeds.airLabs?.data?.length ?? 0 },
      airspaceLink: { available: !!feeds.airspaceLink, source: feeds.airspaceLink?.source },
      aloftLAANC: { available: !!feeds.aloftLAANC, source: feeds.aloftLAANC?.source },
    };

    res.json({
      success: true,
      data: { feeds, summary },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch intel feeds');
    res.status(500).json({ success: false, error: 'Intel feeds fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/model-status', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const tier = modelRouter.activeTier;
    const routingData = await redis.get('ai:routing:current');
    const routing = routingData ? JSON.parse(routingData) : null;

    res.json({
      success: true,
      data: {
        activeTier: tier,
        lastRouting: routing,
        tiers: {
          CLOUD_GPT4O: { status: tier === 'CLOUD_GPT4O' ? 'ACTIVE' : 'STANDBY' },
          LOCAL_70B: { status: tier === 'LOCAL_70B' ? 'ACTIVE' : 'STANDBY' },
          LOCAL_7B: { status: tier === 'LOCAL_7B' ? 'ACTIVE' : 'STANDBY' },
          RULE_ENGINE: { status: tier === 'RULE_ENGINE' ? 'ACTIVE' : 'FALLBACK' },
        },
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch model status');
    res.status(500).json({ success: false, error: 'Model status fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/space-weather', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const { fetchNOAASpaceWeather } = await import('../intel/feeds/noaa-space-weather');
    const result = await fetchNOAASpaceWeather();
    res.json({ success: true, data: result.data, source: result.source, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch space weather');
    res.status(500).json({ success: false, error: 'Space weather fetch failed', timestamp: new Date().toISOString() });
  }
});

// ── Recursive Improvement endpoints ──

router.get('/ri/status', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const status = riSystem.getSystemStatus();
    res.json({ success: true, data: status, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch RI status');
    res.status(500).json({ success: false, error: 'RI status fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/ri/history', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const history = riSystem.getRefinementHistory();
    res.json({ success: true, data: history, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch RI history');
    res.status(500).json({ success: false, error: 'RI history fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/ri/capabilities', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const descriptors = riSystem.getCapabilityDescriptors();
    res.json({ success: true, data: descriptors, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch capabilities');
    res.status(500).json({ success: false, error: 'Capabilities fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/ri/capabilities/:droneClass', authMiddleware(), rbacGuard('intel:read'), async (req: Request, res: Response): Promise<void> => {
  try {
    const droneClass = req.params.droneClass as DroneClass;
    const descriptor = riSystem.getCapabilityDescriptor(droneClass);
    if (!descriptor) {
      res.status(404).json({ success: false, error: `No capability descriptor for ${droneClass}`, timestamp: new Date().toISOString() });
      return;
    }
    res.json({ success: true, data: descriptor, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch capability descriptor');
    res.status(500).json({ success: false, error: 'Capability fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/ri/safety', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const events = riSystem.getSafetyEvents();
    res.json({ success: true, data: events, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch safety events');
    res.status(500).json({ success: false, error: 'Safety events fetch failed', timestamp: new Date().toISOString() });
  }
});

router.get('/ri/prompts', authMiddleware(), rbacGuard('intel:read'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const versions = riSystem.getPromptVersions();
    res.json({ success: true, data: versions, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to fetch prompt versions');
    res.status(500).json({ success: false, error: 'Prompt versions fetch failed', timestamp: new Date().toISOString() });
  }
});

router.post('/ri/toggle', authMiddleware(), rbacGuard('mission:override'), async (req: Request, res: Response): Promise<void> => {
  try {
    const { enabled } = req.body as { enabled: boolean };
    await riSystem.setEnabled(enabled);
    res.json({ success: true, data: { enabled }, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to toggle RI system');
    res.status(500).json({ success: false, error: 'RI toggle failed', timestamp: new Date().toISOString() });
  }
});

router.post('/ri/optimize-route', authMiddleware(), rbacGuard('mission:create'), async (req: Request, res: Response): Promise<void> => {
  try {
    const { missionId, origin, destination, waypoints, threats, terrain, maxFlightTimeMin, cruiseSpeedKnots, fuelCapacityPercent } = req.body as {
      missionId: string; origin: { lat: number; lon: number; alt: number }; destination: { lat: number; lon: number; alt: number };
      waypoints: Array<{ lat: number; lon: number; alt: number }>; threats: unknown[]; terrain: unknown[];
      maxFlightTimeMin: number; cruiseSpeedKnots: number; fuelCapacityPercent: number;
    };
    const result = await riSystem.optimizeMissionRoute(
      missionId, origin, destination, waypoints,
      (threats ?? []) as Parameters<typeof riSystem.optimizeMissionRoute>[4],
      (terrain ?? []) as Parameters<typeof riSystem.optimizeMissionRoute>[5],
      maxFlightTimeMin ?? 120, cruiseSpeedKnots ?? 80, fuelCapacityPercent ?? 100,
    );
    res.json({ success: true, data: result, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to optimize route');
    res.status(500).json({ success: false, error: 'Route optimization failed', timestamp: new Date().toISOString() });
  }
});

router.post('/ri/safety/approve', authMiddleware(), rbacGuard('mission:override'), async (req: Request, res: Response): Promise<void> => {
  try {
    const { eventId, approvedBy } = req.body as { eventId: string; approvedBy: string };
    const result = await riSystem.approveSafetyEvent(eventId, approvedBy);
    res.json({ success: true, data: { approved: result }, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Failed to approve safety event');
    res.status(500).json({ success: false, error: 'Safety approval failed', timestamp: new Date().toISOString() });
  }
});

export { router as intelRouter };
