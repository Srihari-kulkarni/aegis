-- AEGIS COMMAND — Full PostgreSQL + TimescaleDB Schema
-- Execute against PostgreSQL 16 with TimescaleDB extension

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================================
-- OPERATORS
-- ============================================================
CREATE TABLE operators (
    operator_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username      VARCHAR(64) UNIQUE NOT NULL,
    callsign      VARCHAR(32) UNIQUE NOT NULL,
    role          VARCHAR(32) NOT NULL CHECK (role IN (
        'SUPER_ADMIN','MISSION_COMMANDER','OPERATOR','ANALYST','AI_SYSTEM','AUDITOR','GUEST'
    )),
    clearance_level VARCHAR(32) NOT NULL DEFAULT 'UNCLASSIFIED' CHECK (clearance_level IN (
        'UNCLASSIFIED','CONFIDENTIAL','SECRET','TOP_SECRET','SCI'
    )),
    email         VARCHAR(256) NOT NULL,
    mfa_enabled   BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_secret    TEXT,
    password_hash TEXT NOT NULL,
    active        BOOLEAN NOT NULL DEFAULT TRUE,
    last_login    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_operators_username ON operators(username);
CREATE INDEX idx_operators_role ON operators(role);

-- ============================================================
-- OPERATOR SESSIONS
-- ============================================================
CREATE TABLE operator_sessions (
    session_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    operator_id     UUID NOT NULL REFERENCES operators(operator_id) ON DELETE CASCADE,
    token_hash      TEXT NOT NULL,
    ip_address      INET,
    user_agent      TEXT,
    issued_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    mfa_verified_at TIMESTAMPTZ,
    revoked         BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_operator ON operator_sessions(operator_id);
CREATE INDEX idx_sessions_token_hash ON operator_sessions(token_hash);
CREATE INDEX idx_sessions_expires ON operator_sessions(expires_at) WHERE revoked = FALSE;

-- ============================================================
-- DRONES
-- ============================================================
CREATE TABLE drones (
    drone_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    callsign        VARCHAR(32) UNIQUE NOT NULL,
    drone_class     VARCHAR(32) NOT NULL CHECK (drone_class IN (
        'RECON','OFFENSE','DELIVERY','EW','RELAY','SWARM','CBRN','UNDERWATER','LARGE_ALTITUDE','MICRO'
    )),
    model           VARCHAR(128) NOT NULL,
    manufacturer    VARCHAR(128) NOT NULL,
    serial_number   VARCHAR(128) UNIQUE NOT NULL,
    status          VARCHAR(32) NOT NULL DEFAULT 'STANDBY' CHECK (status IN (
        'STANDBY','PREFLIGHT','AIRBORNE','ON_MISSION','RETURNING','LANDED',
        'MAINTENANCE','LOST_LINK','EMERGENCY','DESTROYED','DECOMMISSIONED'
    )),
    health          NUMERIC(4,3) NOT NULL DEFAULT 1.000 CHECK (health >= 0 AND health <= 1),
    battery_percent NUMERIC(5,2) NOT NULL DEFAULT 100.00,
    fuel_percent    NUMERIC(5,2) NOT NULL DEFAULT 100.00,
    position_lat    DOUBLE PRECISION NOT NULL DEFAULT 0,
    position_lon    DOUBLE PRECISION NOT NULL DEFAULT 0,
    position_alt    DOUBLE PRECISION NOT NULL DEFAULT 0,
    heading         DOUBLE PRECISION NOT NULL DEFAULT 0,
    speed_knots     DOUBLE PRECISION NOT NULL DEFAULT 0,
    altitude        DOUBLE PRECISION NOT NULL DEFAULT 0,
    link_quality    NUMERIC(4,3) NOT NULL DEFAULT 1.000,
    current_mission UUID REFERENCES missions(mission_id) ON DELETE SET NULL,
    hts_token_id    VARCHAR(32),
    hts_serial      INTEGER,
    type_metrics    JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_drones_class ON drones(drone_class);
CREATE INDEX idx_drones_status ON drones(status);
CREATE INDEX idx_drones_mission ON drones(current_mission) WHERE current_mission IS NOT NULL;

-- ============================================================
-- MISSIONS
-- ============================================================
CREATE TABLE missions (
    mission_id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name                VARCHAR(256) NOT NULL,
    type                VARCHAR(64) NOT NULL CHECK (type IN (
        'ISR','STRIKE','LOGISTICS','ELECTRONIC_WARFARE','RELAY_COMMS',
        'SWARM_OPS','CBRN_SURVEY','MINE_COUNTERMEASURES','PERSISTENT_SURVEILLANCE',
        'SEARCH_AND_RESCUE','CASEVAC'
    )),
    status              VARCHAR(32) NOT NULL DEFAULT 'DRAFT' CHECK (status IN (
        'DRAFT','PENDING_AI_REVIEW','AI_APPROVED','AI_REJECTED','COMMANDER_APPROVED',
        'ACTIVE','PAUSED','COMPLETED','ABORTED','FAILED'
    )),
    commander_id        UUID NOT NULL REFERENCES operators(operator_id),
    commander_callsign  VARCHAR(32) NOT NULL,
    description         TEXT NOT NULL DEFAULT '',
    area_of_operations  JSONB,
    waypoints           JSONB NOT NULL DEFAULT '[]',
    assigned_drone_ids  UUID[] NOT NULL DEFAULT '{}',
    hcs_topic_id        VARCHAR(32),
    ai_assessment_id    UUID,
    planned_start_time  TIMESTAMPTZ NOT NULL,
    planned_end_time    TIMESTAMPTZ NOT NULL,
    actual_start_time   TIMESTAMPTZ,
    actual_end_time     TIMESTAMPTZ,
    clearance_level     VARCHAR(32) NOT NULL DEFAULT 'UNCLASSIFIED',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_missions_status ON missions(status);
CREATE INDEX idx_missions_commander ON missions(commander_id);
CREATE INDEX idx_missions_type ON missions(type);
CREATE INDEX idx_missions_planned ON missions(planned_start_time, planned_end_time);

-- Fix circular reference: drones.current_mission -> missions
-- (missions table must be created before drones in actual execution)
-- Re-add foreign key after both tables exist
ALTER TABLE drones ADD CONSTRAINT fk_drones_mission
    FOREIGN KEY (current_mission) REFERENCES missions(mission_id) ON DELETE SET NULL;

-- ============================================================
-- MISSION DRONES (join table)
-- ============================================================
CREATE TABLE mission_drones (
    mission_id UUID NOT NULL REFERENCES missions(mission_id) ON DELETE CASCADE,
    drone_id   UUID NOT NULL REFERENCES drones(drone_id) ON DELETE CASCADE,
    role       VARCHAR(32) NOT NULL DEFAULT 'PRIMARY',
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (mission_id, drone_id)
);

-- ============================================================
-- HCS ACTION LOG (immutable ledger mirror)
-- ============================================================
CREATE TABLE hcs_action_log (
    id                  BIGSERIAL PRIMARY KEY,
    sequence_number     BIGINT NOT NULL,
    consensus_timestamp TIMESTAMPTZ NOT NULL,
    topic_id            VARCHAR(32) NOT NULL,
    transaction_id      VARCHAR(64) NOT NULL,
    drone_id            UUID,
    action_type         VARCHAR(64) NOT NULL,
    operator_id         UUID,
    mission_id          UUID,
    ai_confidence       NUMERIC(4,3),
    payload             JSONB NOT NULL DEFAULT '{}',
    compliance_log      TEXT NOT NULL,
    hashscan_url        TEXT GENERATED ALWAYS AS (
        'https://hashscan.io/testnet/transaction/' || transaction_id
    ) STORED,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Immutability: only INSERT allowed via RLS
ALTER TABLE hcs_action_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY hcs_log_insert_only ON hcs_action_log FOR INSERT WITH CHECK (true);
CREATE POLICY hcs_log_select ON hcs_action_log FOR SELECT USING (true);

CREATE INDEX idx_hcs_log_mission ON hcs_action_log(mission_id);
CREATE INDEX idx_hcs_log_drone ON hcs_action_log(drone_id);
CREATE INDEX idx_hcs_log_action ON hcs_action_log(action_type);
CREATE INDEX idx_hcs_log_topic_seq ON hcs_action_log(topic_id, sequence_number);
CREATE INDEX idx_hcs_log_timestamp ON hcs_action_log(consensus_timestamp DESC);

-- ============================================================
-- TELEMETRY (TimescaleDB hypertable)
-- ============================================================
CREATE TABLE telemetry (
    time              TIMESTAMPTZ NOT NULL,
    drone_id          UUID NOT NULL,
    position_lat      DOUBLE PRECISION NOT NULL,
    position_lon      DOUBLE PRECISION NOT NULL,
    position_alt      DOUBLE PRECISION NOT NULL,
    heading           DOUBLE PRECISION NOT NULL,
    speed_knots       DOUBLE PRECISION NOT NULL,
    altitude          DOUBLE PRECISION NOT NULL,
    battery_percent   NUMERIC(5,2) NOT NULL,
    fuel_percent      NUMERIC(5,2) NOT NULL,
    health            NUMERIC(4,3) NOT NULL,
    link_quality      NUMERIC(4,3) NOT NULL,
    satellite_count   INTEGER NOT NULL DEFAULT 0,
    ambient_temp_c    DOUBLE PRECISION,
    wind_speed_ms     DOUBLE PRECISION,
    wind_direction    DOUBLE PRECISION,
    vibration_level   DOUBLE PRECISION,
    cpu_temp_c        DOUBLE PRECISION,
    memory_usage_pct  DOUBLE PRECISION,
    class_specific    JSONB NOT NULL DEFAULT '{}'
);

SELECT create_hypertable('telemetry', 'time', chunk_time_interval => INTERVAL '1 day');

CREATE INDEX idx_telemetry_drone ON telemetry(drone_id, time DESC);

-- Continuous aggregates
CREATE MATERIALIZED VIEW telemetry_1min
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 minute', time) AS bucket,
    drone_id,
    AVG(position_lat) AS avg_lat,
    AVG(position_lon) AS avg_lon,
    AVG(altitude) AS avg_altitude,
    AVG(speed_knots) AS avg_speed,
    AVG(battery_percent) AS avg_battery,
    AVG(health) AS avg_health,
    AVG(link_quality) AS avg_link_quality,
    MIN(health) AS min_health,
    MAX(speed_knots) AS max_speed,
    COUNT(*) AS sample_count
FROM telemetry
GROUP BY bucket, drone_id
WITH NO DATA;

SELECT add_continuous_aggregate_policy('telemetry_1min',
    start_offset => INTERVAL '1 hour',
    end_offset => INTERVAL '1 minute',
    schedule_interval => INTERVAL '1 minute'
);

CREATE MATERIALIZED VIEW telemetry_1hour
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', time) AS bucket,
    drone_id,
    AVG(position_lat) AS avg_lat,
    AVG(position_lon) AS avg_lon,
    AVG(altitude) AS avg_altitude,
    AVG(speed_knots) AS avg_speed,
    AVG(battery_percent) AS avg_battery,
    AVG(health) AS avg_health,
    AVG(link_quality) AS avg_link_quality,
    MIN(health) AS min_health,
    MAX(speed_knots) AS max_speed,
    COUNT(*) AS sample_count
FROM telemetry
GROUP BY bucket, drone_id
WITH NO DATA;

SELECT add_continuous_aggregate_policy('telemetry_1hour',
    start_offset => INTERVAL '1 day',
    end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);

-- ============================================================
-- AI ASSESSMENTS
-- ============================================================
CREATE TABLE ai_assessments (
    assessment_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mission_id          UUID NOT NULL REFERENCES missions(mission_id),
    recommendation      VARCHAR(16) NOT NULL CHECK (recommendation IN ('APPROVE','REJECT','HOLD')),
    confidence          NUMERIC(4,3) NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
    risk_score          NUMERIC(4,3) NOT NULL CHECK (risk_score >= 0 AND risk_score <= 1),
    reasoning           TEXT NOT NULL,
    risk_factors        JSONB NOT NULL DEFAULT '[]',
    mitigations         JSONB NOT NULL DEFAULT '[]',
    weather_data        JSONB,
    airspace_data       JSONB,
    threat_data         JSONB,
    fleet_status        JSONB NOT NULL DEFAULT '[]',
    model_version       VARCHAR(32) NOT NULL DEFAULT 'gpt-4o',
    hcs_transaction_id  VARCHAR(64),
    assessed_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ai_assessments_mission ON ai_assessments(mission_id);

-- ============================================================
-- THREATS
-- ============================================================
CREATE TABLE threats (
    threat_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type           VARCHAR(32) NOT NULL,
    position_lat   DOUBLE PRECISION NOT NULL,
    position_lon   DOUBLE PRECISION NOT NULL,
    position_alt   DOUBLE PRECISION NOT NULL DEFAULT 0,
    radius_km      DOUBLE PRECISION NOT NULL DEFAULT 1,
    confidence     NUMERIC(4,3) NOT NULL DEFAULT 0.500,
    hostile_unit_id VARCHAR(64),
    description    TEXT NOT NULL DEFAULT '',
    first_detected TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_updated   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_threats_active ON threats(active) WHERE active = TRUE;

-- ============================================================
-- NO-FLY ZONES
-- ============================================================
CREATE TABLE no_fly_zones (
    zone_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(256) NOT NULL,
    polygon     JSONB NOT NULL,
    floor_ft    INTEGER NOT NULL DEFAULT 0,
    ceiling_ft  INTEGER NOT NULL DEFAULT 60000,
    permanent   BOOLEAN NOT NULL DEFAULT FALSE,
    active_from TIMESTAMPTZ,
    active_to   TIMESTAMPTZ,
    reason      TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- AUDIT LOG
-- ============================================================
CREATE TABLE audit_log (
    audit_id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name  VARCHAR(64) NOT NULL,
    record_id   TEXT NOT NULL,
    action      VARCHAR(10) NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
    old_data    JSONB,
    new_data    JSONB,
    operator_id UUID,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_log_table ON audit_log(table_name, created_at DESC);
CREATE INDEX idx_audit_log_record ON audit_log(record_id);

-- ============================================================
-- TRIGGERS: auto-update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at BEFORE UPDATE ON operators
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON drones
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON missions
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON no_fly_zones
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- ============================================================
-- TRIGGERS: audit log on sensitive tables
-- ============================================================
CREATE OR REPLACE FUNCTION trigger_audit_log()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (table_name, record_id, action, new_data)
        VALUES (TG_TABLE_NAME, NEW.mission_id::text, 'INSERT', to_jsonb(NEW));
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (table_name, record_id, action, old_data, new_data)
        VALUES (TG_TABLE_NAME, NEW.mission_id::text, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW));
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (table_name, record_id, action, old_data)
        VALUES (TG_TABLE_NAME, OLD.mission_id::text, 'DELETE', to_jsonb(OLD));
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_missions AFTER INSERT OR UPDATE OR DELETE ON missions
    FOR EACH ROW EXECUTE FUNCTION trigger_audit_log();
