'use client';

import { useDroneStore } from '@/stores/droneStore';
import { DroneClass, DroneStatus } from '@aegis/shared';

const COMPASS_DIRECTIONS = [
  'N',
  'NE',
  'E',
  'SE',
  'S',
  'SW',
  'W',
  'NW',
] as const;

function headingToCompass(degrees: number): string {
  const idx = Math.round(((degrees % 360) + 360) % 360 / 45) % 8;
  return `${degrees}° ${COMPASS_DIRECTIONS[idx]}`;
}

function truncateUuid(uuid: string): string {
  if (uuid.length <= 12) return uuid;
  return `${uuid.slice(0, 8)}…${uuid.slice(-4)}`;
}

function getStatusBadgeColor(status: DroneStatus): string {
  switch (status) {
    case DroneStatus.STANDBY:
    case DroneStatus.PREFLIGHT:
    case DroneStatus.LANDED:
    case DroneStatus.DECOMMISSIONED:
      return 'border-aegis-muted text-aegis-muted';
    case DroneStatus.AIRBORNE:
      return 'border-aegis-cyan text-aegis-cyan';
    case DroneStatus.ON_MISSION:
      return 'border-aegis-green text-aegis-green';
    case DroneStatus.RETURNING:
    case DroneStatus.MAINTENANCE:
      return 'border-aegis-amber text-aegis-amber';
    case DroneStatus.EMERGENCY:
    case DroneStatus.LOST_LINK:
    case DroneStatus.DESTROYED:
      return 'border-aegis-red text-aegis-red';
    default:
      return 'border-aegis-muted text-aegis-muted';
  }
}

function getGaugeColor(value: number, thresholds: { green: number; amber: number }): string {
  if (value >= thresholds.green) return 'bg-aegis-green';
  if (value >= thresholds.amber) return 'bg-aegis-amber';
  return 'bg-aegis-red';
}

function GaugeBar({
  value,
  max = 100,
  colorClass,
}: {
  value: number;
  max?: number;
  colorClass: string;
}) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="h-1.5 w-full bg-aegis-bg">
      <div
        className={`h-full ${colorClass}`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function SignalBars({ quality }: { quality: number }) {
  const filled = Math.min(5, Math.ceil(quality * 5));
  return (
    <div className="flex gap-0.5">
      {[0, 1, 2, 3, 4].map((i) => (
        <div
          key={i}
          className={`w-1.5 h-3 ${i < filled ? 'bg-aegis-cyan' : 'bg-aegis-bg'}`}
        />
      ))}
    </div>
  );
}

function DataRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="py-2 border-b border-aegis-border last:border-b-0">
      <p className="data-label">{label}</p>
      <div className="data-value mt-0.5">{value}</div>
    </div>
  );
}

function ClassSectionRecon({ tm }: { tm: Record<string, unknown> }) {
  const sensors = tm.sensors as string[] | undefined;
  const stealthMode = tm.stealthMode as boolean | undefined;
  const recordingHours = tm.recordingHours as number | undefined;
  const groundResolutionCm = tm.groundResolutionCm as number | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">RECON</p>
      <div className="space-y-2">
        {sensors?.length ? (
          <DataRow label="Active sensors" value={sensors.join(', ')} />
        ) : null}
        <DataRow
          label="Stealth mode"
          value={
            <span
              className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                stealthMode ? 'border-aegis-cyan text-aegis-cyan' : 'border-aegis-muted text-aegis-muted'
              }`}
            >
              {stealthMode ? 'ON' : 'OFF'}
            </span>
          }
        />
        {recordingHours != null && (
          <DataRow label="Recording" value={`${recordingHours}h`} />
        )}
        {groundResolutionCm != null && (
          <DataRow label="Ground resolution" value={`${groundResolutionCm} cm`} />
        )}
      </div>
    </div>
  );
}

function ClassSectionOffense({ tm }: { tm: Record<string, unknown> }) {
  const armingState = tm.armingState as string | undefined;
  const seekerLocked = tm.seekerLocked as boolean | undefined;
  const payloadKg = tm.payloadKg as number | undefined;
  const armColor =
    armingState === 'SAFE'
      ? 'border-aegis-green text-aegis-green'
      : armingState === 'MASTER_ARM_ON' || armingState === 'SEEKER_ACTIVE'
        ? 'border-aegis-amber text-aegis-amber'
        : 'border-aegis-red text-aegis-red';
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">OFFENSE</p>
      <div className="space-y-2">
        {armingState && (
          <DataRow
            label="Arming state"
            value={
              <span className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${armColor}`}>
                {armingState}
              </span>
            }
          />
        )}
        <DataRow label="Seeker lock" value={seekerLocked ? 'LOCKED' : 'UNLOCKED'} />
        {payloadKg != null && <DataRow label="Payload" value={`${payloadKg} kg`} />}
      </div>
    </div>
  );
}

function ClassSectionDelivery({ tm }: { tm: Record<string, unknown> }) {
  const payloadBays = tm.payloadBays as Array<{ bay: number; status: string; weightKg: number }> | undefined;
  const casevacMode = tm.casevacMode as boolean | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">DELIVERY</p>
      <div className="space-y-2">
        {casevacMode != null && (
          <DataRow
            label="CASEVAC mode"
            value={
              <span
                className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                  casevacMode ? 'border-aegis-red text-aegis-red' : 'border-aegis-muted text-aegis-muted'
                }`}
              >
                {casevacMode ? 'ACTIVE' : 'OFF'}
              </span>
            }
          />
        )}
        {payloadBays?.length ? (
          <div>
            <p className="data-label mb-1">Payload bays</p>
            <div className="border border-aegis-border">
              <table className="w-full text-[10px] font-mono">
                <thead>
                  <tr className="border-b border-aegis-border">
                    <th className="text-left py-1 px-2 text-aegis-muted">Bay</th>
                    <th className="text-left py-1 px-2 text-aegis-muted">Status</th>
                    <th className="text-right py-1 px-2 text-aegis-muted">kg</th>
                  </tr>
                </thead>
                <tbody>
                  {payloadBays.map((b) => (
                    <tr key={b.bay} className="border-b border-aegis-border last:border-b-0">
                      <td className="py-1 px-2 text-aegis-text">{b.bay}</td>
                      <td className="py-1 px-2 text-aegis-text">{b.status}</td>
                      <td className="py-1 px-2 text-right text-aegis-text">{b.weightKg}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function ClassSectionEW({ tm }: { tm: Record<string, unknown> }) {
  const jammingActive = tm.jammingActive as boolean | undefined;
  const activeBands = tm.activeBands as string[] | undefined;
  const eirpWatts = tm.eirpWatts as number | undefined;
  const targetsInRange = tm.targetsInRange as number | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">EW</p>
      <div className="space-y-2">
        <DataRow
          label="Jamming"
          value={
            <span
              className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                jammingActive ? 'border-aegis-red text-aegis-red' : 'border-aegis-muted text-aegis-muted'
              }`}
            >
              {jammingActive ? 'ACTIVE' : 'STANDBY'}
            </span>
          }
        />
        {activeBands?.length ? (
          <DataRow label="Active bands" value={activeBands.join(', ')} />
        ) : null}
        {eirpWatts != null && <DataRow label="EIRP" value={`${eirpWatts} W`} />}
        {targetsInRange != null && (
          <DataRow label="Targets in range" value={String(targetsInRange)} />
        )}
      </div>
    </div>
  );
}

function ClassSectionRelay({ tm }: { tm: Record<string, unknown> }) {
  const meshPeers = tm.meshPeers as number | undefined;
  const bandwidthUtilization = tm.bandwidthUtilization as number | undefined;
  const satcomBridge = tm.satcomBridge as boolean | undefined;
  const loiterAlt = tm.loiterAlt as number | undefined;
  const bwPct = bandwidthUtilization != null ? bandwidthUtilization * 100 : 0;
  const bwColor = getGaugeColor(bwPct, { green: 50, amber: 20 });
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">RELAY</p>
      <div className="space-y-2">
        {meshPeers != null && <DataRow label="Mesh peers" value={String(meshPeers)} />}
        {bandwidthUtilization != null && (
          <div>
            <p className="data-label mb-1">Bandwidth utilization</p>
            <GaugeBar value={bwPct} colorClass={bwColor} />
            <p className="font-mono text-[10px] text-aegis-muted mt-0.5">{(bwPct).toFixed(0)}%</p>
          </div>
        )}
        {satcomBridge != null && (
          <DataRow label="SATCOM bridge" value={satcomBridge ? 'ACTIVE' : 'OFF'} />
        )}
        {loiterAlt != null && (
          <DataRow label="Loiter altitude" value={`${loiterAlt} ft`} />
        )}
      </div>
    </div>
  );
}

function ClassSectionSwarm({ tm }: { tm: Record<string, unknown> }) {
  const swarmId = tm.swarmId as string | undefined;
  const nodeIndex = tm.nodeIndex as number | undefined;
  const neighborCount = tm.neighborCount as number | undefined;
  const autonomyLevel = tm.autonomyLevel as string | undefined;
  const syncLatencyMs = tm.syncLatencyMs as number | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">SWARM</p>
      <div className="space-y-2">
        {swarmId && <DataRow label="Swarm ID" value={swarmId} />}
        {nodeIndex != null && <DataRow label="Node index" value={String(nodeIndex)} />}
        {neighborCount != null && <DataRow label="Neighbors" value={String(neighborCount)} />}
        {autonomyLevel && (
          <DataRow
            label="Autonomy"
            value={
              <span className="inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border border-aegis-cyan text-aegis-cyan">
                {autonomyLevel}
              </span>
            }
          />
        )}
        {syncLatencyMs != null && (
          <DataRow label="Sync latency" value={`${syncLatencyMs} ms`} />
        )}
      </div>
    </div>
  );
}

function ClassSectionCBRN({ tm }: { tm: Record<string, unknown> }) {
  const chemicalDetectors = tm.chemicalDetectors as Record<string, boolean> | undefined;
  const radiationMsv = tm.radiationMsv as number | undefined;
  const bioSamplerCount = tm.bioSamplerCount as number | undefined;
  const chemicals = ['Sarin', 'VX', 'Mustard', 'Novichok'] as const;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">CBRN</p>
      <div className="space-y-2">
        {chemicalDetectors && (
          <div>
            <p className="data-label mb-1">Chemical alerts</p>
            <div className="flex flex-wrap gap-1">
              {chemicals.map((c) => {
                const detected = chemicalDetectors[c] ?? false;
                return (
                  <span
                    key={c}
                    className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                      detected ? 'border-aegis-red text-aegis-red' : 'border-aegis-muted text-aegis-muted'
                    }`}
                  >
                    {c}
                  </span>
                );
              })}
            </div>
          </div>
        )}
        {radiationMsv != null && (
          <DataRow label="Radiation" value={`${radiationMsv} mSv`} />
        )}
        {bioSamplerCount != null && (
          <DataRow label="Bio samplers" value={String(bioSamplerCount)} />
        )}
      </div>
    </div>
  );
}

function ClassSectionUnderwater({ tm }: { tm: Record<string, unknown> }) {
  const depthMeters = tm.depthMeters as number | undefined;
  const sonarActive = tm.sonarActive as boolean | undefined;
  const mineDetectionConfidence = tm.mineDetectionConfidence as number | undefined;
  const subsurfaceComms = tm.subsurfaceComms as string | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">UNDERWATER</p>
      <div className="space-y-2">
        {depthMeters != null && <DataRow label="Depth" value={`${depthMeters} m`} />}
        {sonarActive != null && (
          <DataRow
            label="Sonar"
            value={
              <span
                className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                  sonarActive ? 'border-aegis-cyan text-aegis-cyan' : 'border-aegis-muted text-aegis-muted'
                }`}
              >
                {sonarActive ? 'ACTIVE' : 'OFF'}
              </span>
            }
          />
        )}
        {mineDetectionConfidence != null && (
          <DataRow label="Mine detection" value={`${(mineDetectionConfidence * 100).toFixed(0)}%`} />
        )}
        {subsurfaceComms && (
          <DataRow label="Subsurface comms" value={subsurfaceComms} />
        )}
      </div>
    </div>
  );
}

function ClassSectionLargeAltitude({ tm }: { tm: Record<string, unknown> }) {
  const classification = tm.classification as string | undefined;
  const serviceCeilingFt = tm.serviceCeilingFt as number | undefined;
  const persistentISRHours = tm.persistentISRHours as number | undefined;
  const strategicRelay = tm.strategicRelay as boolean | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">LARGE ALTITUDE</p>
      <div className="space-y-2">
        {classification && (
          <DataRow label="Classification" value={classification} />
        )}
        {serviceCeilingFt != null && (
          <DataRow label="Service ceiling" value={`${serviceCeilingFt} ft`} />
        )}
        {persistentISRHours != null && (
          <DataRow label="Persistent ISR" value={`${persistentISRHours} h`} />
        )}
        {strategicRelay != null && (
          <DataRow label="Strategic relay" value={strategicRelay ? 'ACTIVE' : 'OFF'} />
        )}
      </div>
    </div>
  );
}

function ClassSectionMicro({ tm }: { tm: Record<string, unknown> }) {
  const urbanMode = tm.urbanMode as boolean | undefined;
  const covertOps = tm.covertOps as boolean | undefined;
  const acousticSignatureDb = tm.acousticSignatureDb as number | undefined;
  const singleUse = tm.singleUse as boolean | undefined;
  return (
    <div className="border-b border-aegis-border py-3">
      <p className="data-label mb-2">MICRO</p>
      <div className="space-y-2">
        {urbanMode != null && (
          <DataRow
            label="Urban mode"
            value={
              <span
                className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                  urbanMode ? 'border-aegis-cyan text-aegis-cyan' : 'border-aegis-muted text-aegis-muted'
                }`}
              >
                {urbanMode ? 'ON' : 'OFF'}
              </span>
            }
          />
        )}
        {covertOps != null && (
          <DataRow
            label="Covert ops"
            value={
              <span
                className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                  covertOps ? 'border-aegis-cyan text-aegis-cyan' : 'border-aegis-muted text-aegis-muted'
                }`}
              >
                {covertOps ? 'ON' : 'OFF'}
              </span>
            }
          />
        )}
        {acousticSignatureDb != null && (
          <DataRow label="Acoustic signature" value={`${acousticSignatureDb} dB`} />
        )}
        {singleUse != null && (
          <DataRow
            label="Single-use"
            value={
              <span
                className={`inline-flex px-2 py-0.5 text-[10px] font-mono uppercase border ${
                  singleUse ? 'border-aegis-amber text-aegis-amber' : 'border-aegis-muted text-aegis-muted'
                }`}
              >
                {singleUse ? 'YES' : 'NO'}
              </span>
            }
          />
        )}
      </div>
    </div>
  );
}

function ClassSpecificSection({
  droneClass,
  typeMetrics,
}: {
  droneClass: DroneClass;
  typeMetrics: Record<string, unknown>;
}) {
  switch (droneClass) {
    case DroneClass.RECON:
      return <ClassSectionRecon tm={typeMetrics} />;
    case DroneClass.OFFENSE:
      return <ClassSectionOffense tm={typeMetrics} />;
    case DroneClass.DELIVERY:
      return <ClassSectionDelivery tm={typeMetrics} />;
    case DroneClass.EW:
      return <ClassSectionEW tm={typeMetrics} />;
    case DroneClass.RELAY:
      return <ClassSectionRelay tm={typeMetrics} />;
    case DroneClass.SWARM:
      return <ClassSectionSwarm tm={typeMetrics} />;
    case DroneClass.CBRN:
      return <ClassSectionCBRN tm={typeMetrics} />;
    case DroneClass.UNDERWATER:
      return <ClassSectionUnderwater tm={typeMetrics} />;
    case DroneClass.LARGE_ALTITUDE:
      return <ClassSectionLargeAltitude tm={typeMetrics} />;
    case DroneClass.MICRO:
      return <ClassSectionMicro tm={typeMetrics} />;
    default:
      return null;
  }
}

export function DroneDetailPanel() {
  const getSelectedDrone = useDroneStore((s) => s.getSelectedDrone);
  const selectDrone = useDroneStore((s) => s.selectDrone);
  const drones = useDroneStore((s) => s.getFilteredDrones());
  const drone = getSelectedDrone();

  if (!drone) {
    return (
      <div className="w-[380px] h-full flex flex-col bg-aegis-panel border-l border-aegis-border shrink-0">
        <div className="shrink-0 p-3 border-b border-aegis-border">
          <p className="font-tactical text-aegis-muted text-sm uppercase tracking-widest">
            NO ASSET SELECTED
          </p>
        </div>
        <div className="flex-1 overflow-auto p-3">
          <p className="data-label mb-2">Select asset</p>
          {drones.length === 0 ? (
            <p className="font-mono text-aegis-muted text-xs">No drones</p>
          ) : (
            <div className="space-y-1">
              {drones.map((d) => (
                <button
                  key={d.droneId}
                  type="button"
                  onClick={() => selectDrone(d.droneId)}
                  className="block w-full text-left px-3 py-2 border border-aegis-border hover:border-aegis-cyan text-aegis-text font-mono text-xs"
                >
                  {d.callsign} ({d.droneClass})
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  const healthNorm = drone.health <= 1 ? drone.health : drone.health / 100;
  const healthPct = healthNorm * 100;
  const healthColor = getGaugeColor(healthPct, { green: 80, amber: 50 });

  const batteryPct = drone.batteryPercent <= 1 ? drone.batteryPercent * 100 : drone.batteryPercent;
  const batteryColor = getGaugeColor(batteryPct, { green: 50, amber: 20 });

  const fuelPct = drone.fuelPercent <= 1 ? drone.fuelPercent * 100 : drone.fuelPercent;
  const fuelColor = getGaugeColor(fuelPct, { green: 50, amber: 20 });

  const linkQ = drone.linkQuality <= 1 ? drone.linkQuality : drone.linkQuality / 100;
  const altFt = drone.altitude ?? drone.position.alt;

  return (
    <div className="w-[380px] h-full flex flex-col bg-aegis-panel border-l border-aegis-border shrink-0">
      <div className="shrink-0 p-3 border-b border-aegis-border flex items-center justify-between">
        <h2 className="font-tactical text-aegis-cyan text-lg font-bold tracking-wider">
          {drone.callsign}
        </h2>
        <button
          type="button"
          onClick={() => selectDrone(null)}
          className="font-mono text-aegis-muted hover:text-aegis-text text-sm px-2 py-0.5 transition-colors"
          aria-label="Close"
        >
          ✕
        </button>
      </div>

      <div className="flex-1 overflow-auto min-h-0">
        <div className="p-3 space-y-0">
          <div className="font-mono text-[10px] text-aegis-muted truncate mb-2">
            {truncateUuid(drone.droneId)}
          </div>

          <div className="border-b border-aegis-border py-3">
            <DataRow label="Model" value={`${drone.model} · ${drone.manufacturer}`} />
            <div className="py-2 border-b border-aegis-border last:border-b-0">
              <p className="data-label">Status</p>
              <span
                className={`inline-flex mt-0.5 px-2 py-0.5 text-[10px] font-mono uppercase border ${getStatusBadgeColor(drone.status)}`}
              >
                {drone.status}
              </span>
            </div>
          </div>

          <div className="border-b border-aegis-border py-3">
            <div className="py-2">
              <p className="data-label">Health</p>
              <GaugeBar value={healthPct} colorClass={healthColor} />
              <p className="font-mono text-[10px] text-aegis-muted mt-0.5">
                {healthPct.toFixed(0)}%
              </p>
            </div>
            <div className="py-2">
              <p className="data-label">Battery</p>
              <GaugeBar value={batteryPct} colorClass={batteryColor} />
              <p className="font-mono text-[10px] text-aegis-muted mt-0.5">
                {batteryPct.toFixed(0)}%
              </p>
            </div>
            <div className="py-2">
              <p className="data-label">Fuel</p>
              <GaugeBar value={fuelPct} colorClass={fuelColor} />
              <p className="font-mono text-[10px] text-aegis-muted mt-0.5">
                {fuelPct.toFixed(0)}%
              </p>
            </div>
          </div>

          <div className="border-b border-aegis-border py-3">
            <DataRow label="Altitude" value={`${altFt.toLocaleString()} ft`} />
            <DataRow label="Speed" value={`${drone.speedKnots} kts`} />
            <DataRow label="Heading" value={headingToCompass(drone.heading)} />
          </div>

          <div className="border-b border-aegis-border py-3">
            <div className="py-2">
              <p className="data-label">Link quality</p>
              <div className="mt-0.5 flex items-center gap-2">
                <SignalBars quality={linkQ} />
                <span className="font-mono text-[10px] text-aegis-muted">
                  {(linkQ * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          </div>

          <div className="border-b border-aegis-border py-3">
            <DataRow
              label="GPS"
              value={`${drone.position.lat.toFixed(6)}, ${drone.position.lon.toFixed(6)}`}
            />
          </div>

          <div className="border-b border-aegis-border py-3">
            <DataRow
              label="Mission"
              value={drone.currentMissionId ?? 'UNASSIGNED'}
            />
          </div>

          {drone.htsTokenId && (
            <div className="border-b border-aegis-border py-3">
              <p className="data-label">HTS NFT</p>
              <a
                href={`https://hashscan.io/testnet/token/${drone.htsTokenId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="data-value mt-0.5 block text-aegis-cyan hover:underline truncate"
              >
                {drone.htsTokenId}
              </a>
            </div>
          )}

          <ClassSpecificSection
            droneClass={drone.droneClass}
            typeMetrics={drone.typeMetrics ?? {}}
          />
        </div>
      </div>
    </div>
  );
}
