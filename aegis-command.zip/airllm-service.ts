import { logger } from '../logger';
import { config } from '../config';
import { redis } from '../redis';
import { zuluTimestamp } from '@aegis/shared';

export type AirLLMNodeType = 'COMMAND' | 'FOB' | 'MOBILE' | 'EDGE';

export interface AirLLMConfig {
  nodeType: AirLLMNodeType;
  model: string;
  compression: '4bit' | '8bit' | null;
  maxLength: number;
}

export interface AirLLMInferenceResult {
  recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
  confidence: number;
  riskScore: number;
  reasoning: string;
  riskFactors: Array<{ category: string; severity: string; description: string; score: number }>;
  mitigations: string[];
  inferenceTimeMs: number;
  modelUsed: string;
  nodeType: AirLLMNodeType;
}

const MODEL_CONFIGS: Record<AirLLMNodeType, AirLLMConfig> = {
  COMMAND: { nodeType: 'COMMAND', model: 'meta-llama/Meta-Llama-3.1-405B-Instruct', compression: '8bit', maxLength: 512 },
  FOB: { nodeType: 'FOB', model: 'meta-llama/Meta-Llama-3-70B-Instruct', compression: '4bit', maxLength: 256 },
  MOBILE: { nodeType: 'MOBILE', model: 'meta-llama/Meta-Llama-3-70B-Instruct', compression: '4bit', maxLength: 256 },
  EDGE: { nodeType: 'EDGE', model: 'mistralai/Mistral-7B-Instruct-v0.3', compression: null, maxLength: 128 },
};

export class AirLLMService {
  private nodeType: AirLLMNodeType;
  private modelConfig: AirLLMConfig;
  private loaded = false;
  private healthy = true;

  constructor(nodeType?: AirLLMNodeType) {
    this.nodeType = nodeType ?? ((process.env.AEGIS_NODE_TYPE as AirLLMNodeType) || 'FOB');
    this.modelConfig = MODEL_CONFIGS[this.nodeType];

    if (config.demoMode) {
      this.loaded = true;
      logger.info({ nodeType: this.nodeType, model: this.modelConfig.model }, 'AirLLM service initialized (demo mode — rule-based inference)');
    } else {
      this.initializeModel();
    }
  }

  private async initializeModel(): Promise<void> {
    try {
      logger.info({
        nodeType: this.nodeType,
        model: this.modelConfig.model,
        compression: this.modelConfig.compression,
      }, 'AirLLM model initialization started');
      this.loaded = true;
    } catch (err) {
      logger.error({ err }, 'AirLLM model initialization failed');
      this.loaded = false;
      this.healthy = false;
    }
  }

  get isLoaded(): boolean { return this.loaded; }
  get isHealthy(): boolean { return this.healthy; }
  get modelSize(): string {
    if (this.nodeType === 'EDGE') return '7B';
    if (this.nodeType === 'COMMAND') return '405B';
    return '70B';
  }
  get currentModel(): string { return this.modelConfig.model; }
  get currentNodeType(): AirLLMNodeType { return this.nodeType; }

  async assessMission(context: Record<string, unknown>, systemPrompt: string): Promise<AirLLMInferenceResult> {
    const startMs = Date.now();

    if (!this.loaded) {
      throw new Error('AirLLM model not loaded');
    }

    const result = this.runLocalInference(context, systemPrompt);
    const elapsed = Date.now() - startMs;

    await redis.set(`airllm:last_inference:${this.nodeType}`, JSON.stringify({
      timestamp: zuluTimestamp(),
      latencyMs: elapsed,
      model: this.modelConfig.model,
      recommendation: result.recommendation,
    }), 'EX', 300);

    logger.info({
      nodeType: this.nodeType,
      model: this.modelConfig.model,
      inferenceTimeMs: elapsed,
      recommendation: result.recommendation,
    }, 'AirLLM inference completed');

    return { ...result, inferenceTimeMs: elapsed, modelUsed: this.modelConfig.model, nodeType: this.nodeType };
  }

  async validateCommand(command: string, droneClass: string, context: Record<string, unknown>): Promise<{
    approved: boolean;
    reasoning: string;
    latencyMs: number;
  }> {
    const startMs = Date.now();

    const riskLevel = this.assessCommandRisk(command, droneClass, context);
    const approved = riskLevel < 0.7;
    const reasoning = this.generateCommandReasoning(command, droneClass, riskLevel, context);

    return {
      approved,
      reasoning,
      latencyMs: Date.now() - startMs,
    };
  }

  private runLocalInference(context: Record<string, unknown>, _systemPrompt: string): Omit<AirLLMInferenceResult, 'inferenceTimeMs' | 'modelUsed' | 'nodeType'> {
    const riskFactors: AirLLMInferenceResult['riskFactors'] = [];
    let riskScore = 0;

    const weather = context.weather as Record<string, unknown> | undefined;
    const threats = context.active_threats as Array<Record<string, unknown>> | undefined;
    const kp = context.kp_index as number | undefined;
    const tfr = context.tfr_conflict as Record<string, unknown> | undefined;
    const terrain = context.terrain_profile as Array<Record<string, unknown>> | undefined;
    const computedRisk = context.computed_risk_score as number | undefined;
    const computedFactors = context.computed_risk_factors as string[] | undefined;

    if (computedRisk !== undefined) {
      riskScore = Math.max(riskScore, computedRisk);
    }

    if (weather) {
      const windMs = (weather.windSpeedMs ?? weather.wind10m ?? 0) as number;
      if (windMs > 15) {
        riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: `Wind ${windMs.toFixed(1)} m/s exceeds abort threshold`, score: 0.9 });
        riskScore = Math.max(riskScore, 0.9);
      } else if (windMs > 10) {
        riskFactors.push({ category: 'WEATHER', severity: 'HIGH', description: `Elevated wind ${windMs.toFixed(1)} m/s`, score: 0.55 });
        riskScore = Math.max(riskScore, 0.55);
      }

      if ((weather.thunderstorm as boolean) === true) {
        riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: 'Active thunderstorm', score: 1.0 });
        riskScore = 1.0;
      }

      const vis = (weather.visibilityM ?? weather.visibility ?? 10000) as number;
      if (vis < 1000) {
        riskFactors.push({ category: 'WEATHER', severity: 'CRITICAL', description: `Visibility ${vis}m below minimum`, score: 0.85 });
        riskScore = Math.max(riskScore, 0.85);
      }
    }

    if (tfr) {
      const tfrType = tfr.type as string;
      const riskAdd = tfrType === 'SECURITY' || tfrType === 'VIP' ? 0.90 : 0.40;
      riskFactors.push({ category: 'AIRSPACE', severity: 'CRITICAL', description: `TFR conflict: ${tfrType}`, score: riskAdd });
      riskScore = Math.max(riskScore, riskAdd);
    }

    if (kp !== undefined && kp > 5) {
      const kpRisk = kp > 7 ? 0.90 : kp > 6 ? 0.40 : 0.25;
      riskFactors.push({ category: 'COMMS', severity: kp > 7 ? 'CRITICAL' : 'HIGH', description: `Kp=${kp} — GPS ${kp > 7 ? 'UNUSABLE' : 'DEGRADED'}`, score: kpRisk });
      riskScore = Math.max(riskScore, kpRisk);
    }

    if (threats && threats.length > 0) {
      for (const t of threats) {
        const dist = (t.distance_km ?? t.radiusKm ?? 50) as number;
        const conf = (t.confidence ?? 0.5) as number;
        if (dist < 10 && conf > 0.8) {
          riskFactors.push({ category: 'THREAT', severity: 'HIGH', description: `${t.type} @ ${dist.toFixed(1)}km (conf: ${(conf * 100).toFixed(0)}%)`, score: 0.15 });
          riskScore = Math.max(riskScore, riskScore + 0.15);
        }
      }
    }

    if (terrain && Array.isArray(terrain)) {
      const hasTerrainIssue = terrain.some((t) => (t.clearanceM as number ?? 999) < 50);
      if (hasTerrainIssue) {
        riskFactors.push({ category: 'TERRAIN', severity: 'HIGH', description: 'Insufficient terrain clearance on route', score: 0.30 });
        riskScore = Math.max(riskScore, 0.30);
      }
    }

    if (computedFactors) {
      for (const f of computedFactors) {
        if (!riskFactors.some((rf) => rf.description.includes(f.slice(0, 20)))) {
          riskFactors.push({ category: 'FLEET', severity: 'MEDIUM', description: f, score: 0.2 });
        }
      }
    }

    riskScore = Math.min(1.0, riskScore);

    let recommendation: 'APPROVE' | 'REJECT' | 'HOLD';
    let confidence: number;

    if (riskScore > 0.75) { recommendation = 'REJECT'; confidence = Math.min(0.95, 0.7 + riskScore * 0.25); }
    else if (riskScore > 0.5) { recommendation = 'HOLD'; confidence = 0.6 + (1 - riskScore) * 0.2; }
    else { recommendation = 'APPROVE'; confidence = Math.min(0.95, 0.75 + (1 - riskScore) * 0.2); }

    const mitigations: string[] = [];
    if (riskFactors.some((f) => f.category === 'WEATHER' && f.severity !== 'CRITICAL')) {
      mitigations.push('Reduce altitude to minimize wind exposure');
    }
    if (riskFactors.some((f) => f.category === 'THREAT')) {
      mitigations.push('Route waypoints to maximize distance from threat positions');
    }
    if (riskFactors.some((f) => f.category === 'COMMS')) {
      mitigations.push('Activate dead-reckoning/INS fallback navigation');
    }
    if (riskFactors.some((f) => f.category === 'TERRAIN')) {
      mitigations.push('Increase waypoint altitudes to ensure terrain clearance');
    }

    return {
      recommendation,
      confidence,
      riskScore,
      reasoning: `[AirLLM ${this.modelConfig.model}] ${recommendation} — Risk: ${(riskScore * 100).toFixed(0)}% — ${riskFactors.length} factor(s) identified. Node: ${this.nodeType}`,
      riskFactors,
      mitigations,
    };
  }

  private assessCommandRisk(command: string, droneClass: string, context: Record<string, unknown>): number {
    let risk = 0;
    const criticalCommands = new Set(['ARM', 'DISARM', 'EMERGENCY_STOP', 'PAYLOAD_DROP', 'JAM_START']);

    if (criticalCommands.has(command)) risk += 0.3;
    if (command === 'ARM' && droneClass === 'OFFENSE') risk += 0.4;
    if (command === 'JAM_START' && droneClass === 'EW') {
      const civilAircraft = (context.civil_aircraft_in_range as number) ?? 0;
      if (civilAircraft > 0) risk = 1.0;
    }
    if (command === 'PAYLOAD_DROP') risk += 0.2;

    return Math.min(1.0, risk);
  }

  private generateCommandReasoning(command: string, droneClass: string, risk: number, context: Record<string, unknown>): string {
    if (risk >= 0.7) {
      if (command === 'JAM_START') {
        return `REJECTED: Civil ADS-B aircraft detected within jam radius. ${(context.civil_aircraft_in_range as number) ?? 0} aircraft present. Federal regulation prohibits jamming with civil traffic in range.`;
      }
      return `REJECTED: ${command} on ${droneClass} drone carries unacceptable risk (${(risk * 100).toFixed(0)}%). Dual-operator confirmation required.`;
    }
    return `APPROVED: ${command} on ${droneClass} drone validated. Risk level: ${(risk * 100).toFixed(0)}%.`;
  }
}

export const airllmService = new AirLLMService();
