import {
  Client,
  TokenCreateTransaction,
  TokenMintTransaction,
  TransferTransaction,
  TokenId,
  AccountId,
  PrivateKey,
  Hbar,
  TokenType,
  TokenSupplyType,
  NftId,
  TokenNftInfoQuery,
} from '@hashgraph/sdk';
import { config } from '../config';
import { query } from '../db/pool';
import { logger } from '../logger';
import { DroneBase } from '../drones/DroneBase';

export class HTSDroneRegistry {
  private client: Client | null = null;
  private demoMode: boolean;
  private collectionTokenId: string | null = null;
  private demoSerialCounter: number = 0;

  constructor() {
    this.demoMode = config.demoMode;

    if (!this.demoMode && config.hedera.accountId !== '0.0.0000' && config.hedera.privateKey) {
      try {
        this.client = Client.forTestnet();
        this.client.setOperator(
          AccountId.fromString(config.hedera.accountId),
          PrivateKey.fromStringDer(config.hedera.privateKey)
        );
        this.client.setDefaultMaxTransactionFee(new Hbar(10));
        logger.info('HTS Drone Registry client initialized');
      } catch (err) {
        logger.warn({ err }, 'HTS client init failed — demo mode');
        this.demoMode = true;
      }
    }
  }

  async initializeCollection(): Promise<string> {
    if (this.demoMode || !this.client) {
      this.collectionTokenId = `0.0.${Math.floor(5000000 + Math.random() * 5000000)}`;
      logger.info({ tokenId: this.collectionTokenId }, 'Demo HTS collection initialized');
      return this.collectionTokenId;
    }

    const supplyKey = PrivateKey.fromStringDer(config.hedera.privateKey);

    const transaction = new TokenCreateTransaction()
      .setTokenName('AEGIS Drone Fleet Registry')
      .setTokenSymbol('AEGIS-DRONE')
      .setTokenType(TokenType.NonFungibleUnique)
      .setSupplyType(TokenSupplyType.Infinite)
      .setDecimals(0)
      .setInitialSupply(0)
      .setTreasuryAccountId(AccountId.fromString(config.hedera.accountId))
      .setSupplyKey(supplyKey)
      .setAdminKey(supplyKey)
      .setTokenMemo('AEGIS COMMAND — Drone Fleet Digital Twin Registry');

    const txResponse = await transaction.execute(this.client);
    const receipt = await txResponse.getReceipt(this.client);
    this.collectionTokenId = receipt.tokenId?.toString() ?? '';

    logger.info({ tokenId: this.collectionTokenId }, 'HTS NFT collection created on Hedera testnet');
    return this.collectionTokenId;
  }

  async mintDroneNFT(drone: DroneBase): Promise<{ tokenId: string; serialNumber: number }> {
    const tokenId = this.collectionTokenId;
    if (!tokenId) {
      throw new Error('HTS collection not initialized — call initializeCollection() first');
    }

    const metadata = {
      droneId: drone.droneId,
      callsign: drone.callsign,
      class: drone.droneClass,
      model: drone.model,
      manufacturer: drone.manufacturer,
      serialNumber: drone.serialNumber,
      mintedAt: new Date().toISOString(),
      typeMetrics: drone.getTypeMetrics(),
    };

    const metadataBytes = Buffer.from(JSON.stringify(metadata), 'utf-8');

    if (this.demoMode || !this.client) {
      this.demoSerialCounter += 1;
      const serial = this.demoSerialCounter;

      await query(
        'UPDATE drones SET hts_token_id = $1, hts_serial = $2 WHERE drone_id = $3',
        [tokenId, serial, drone.droneId]
      );

      drone.htsTokenId = tokenId;
      drone.htsSerialNumber = serial;

      logger.info({ droneId: drone.droneId, tokenId, serial }, 'Demo drone NFT minted');
      return { tokenId, serialNumber: serial };
    }

    const supplyKey = PrivateKey.fromStringDer(config.hedera.privateKey);

    const mintTx = new TokenMintTransaction()
      .setTokenId(TokenId.fromString(tokenId))
      .addMetadata(metadataBytes)
      .freezeWith(this.client);

    const signedTx = await mintTx.sign(supplyKey);
    const txResponse = await signedTx.execute(this.client);
    const receipt = await txResponse.getReceipt(this.client);
    const serialNumbers = receipt.serials;
    const serial = serialNumbers[0]?.toNumber() ?? 0;

    await query(
      'UPDATE drones SET hts_token_id = $1, hts_serial = $2 WHERE drone_id = $3',
      [tokenId, serial, drone.droneId]
    );

    drone.htsTokenId = tokenId;
    drone.htsSerialNumber = serial;

    logger.info({ droneId: drone.droneId, tokenId, serial }, 'Drone NFT minted on Hedera testnet');
    return { tokenId, serialNumber: serial };
  }

  async transferDroneOwnership(droneId: string, toAccountId: string): Promise<void> {
    const result = await query<{ hts_token_id: string; hts_serial: number }>(
      'SELECT hts_token_id, hts_serial FROM drones WHERE drone_id = $1',
      [droneId]
    );

    if (result.rows.length === 0 || !result.rows[0].hts_token_id) {
      throw new Error(`Drone ${droneId} has no HTS NFT registered`);
    }

    const { hts_token_id: tokenIdStr, hts_serial: serial } = result.rows[0];

    if (this.demoMode || !this.client) {
      logger.info({ droneId, toAccountId, tokenId: tokenIdStr, serial }, 'Demo drone ownership transferred');
      return;
    }

    const fromAccountId = AccountId.fromString(config.hedera.accountId);
    const tokenId = TokenId.fromString(tokenIdStr);
    const nftId = new NftId(tokenId, serial);
    const operatorKey = PrivateKey.fromStringDer(config.hedera.privateKey);

    const transferTx = new TransferTransaction()
      .addNftTransfer(nftId, fromAccountId, AccountId.fromString(toAccountId))
      .freezeWith(this.client);

    const signedTx = await transferTx.sign(operatorKey);
    const txResponse = await signedTx.execute(this.client);
    await txResponse.getReceipt(this.client);

    logger.info({ droneId, toAccountId, tokenId: tokenIdStr, serial }, 'Drone ownership transferred on Hedera');
  }

  async getDroneNFTMetadata(tokenIdStr: string, serialNumber: number): Promise<Record<string, unknown>> {
    if (this.demoMode || !this.client) {
      const result = await query<{ callsign: string; drone_class: string; model: string; manufacturer: string; type_metrics: Record<string, unknown> }>(
        'SELECT callsign, drone_class, model, manufacturer, type_metrics FROM drones WHERE hts_token_id = $1 AND hts_serial = $2',
        [tokenIdStr, serialNumber]
      );

      if (result.rows.length === 0) {
        return { error: 'NFT not found in demo registry' };
      }

      const row = result.rows[0];
      return {
        callsign: row.callsign,
        class: row.drone_class,
        model: row.model,
        manufacturer: row.manufacturer,
        typeMetrics: row.type_metrics,
        tokenId: tokenIdStr,
        serialNumber,
        registry: 'DEMO',
      };
    }

    const tokenId = TokenId.fromString(tokenIdStr);
    const nftId = new NftId(tokenId, serialNumber);
    const nftInfo = await new TokenNftInfoQuery()
      .setNftId(nftId)
      .execute(this.client);

    const info = nftInfo[0];
    if (!info?.metadata) {
      return { error: 'No metadata on NFT' };
    }

    const metadataStr = Buffer.from(info.metadata).toString('utf-8');
    return JSON.parse(metadataStr) as Record<string, unknown>;
  }
}

export const htsDroneRegistry = new HTSDroneRegistry();
