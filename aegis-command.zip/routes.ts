import { Router, Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import { z } from 'zod';
import { config } from '../config';
import { query } from '../db/pool';
import { redis } from '../redis';
import { logger } from '../logger';
import { authMiddleware, JWTPayload, sessionRevoke } from './middleware';
import { OperatorRole } from '@aegis/shared';

const router = Router();

const loginSchema = z.object({
  username: z.string().min(1).max(64),
  password: z.string().min(1),
  totpCode: z.string().length(6).optional(),
});

const mfaVerifySchema = z.object({
  totpCode: z.string().length(6),
});

function generateTokens(payload: Omit<JWTPayload, 'iat' | 'exp' | 'type'>): {
  accessToken: string;
  refreshToken: string;
} {
  const accessToken = jwt.sign(
    { ...payload, type: 'access' },
    config.jwt.privateKey,
    { algorithm: 'RS256', expiresIn: config.jwt.accessTokenExpiry }
  );

  const refreshToken = jwt.sign(
    { ...payload, type: 'refresh' },
    config.jwt.privateKey,
    { algorithm: 'RS256', expiresIn: config.jwt.refreshTokenExpiry }
  );

  return { accessToken, refreshToken };
}

router.post('/login', async (req: Request, res: Response): Promise<void> => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ success: false, error: 'Invalid request body', details: parsed.error.flatten(), timestamp: new Date().toISOString() });
      return;
    }

    const { username, password, totpCode } = parsed.data;

    const DEMO_ACCOUNTS: Record<string, { operator_id: string; callsign: string; role: OperatorRole; clearance_level: string; email: string; mfa_enabled: boolean; mfa_secret: string | null; password: string }> = {
      'commander': { operator_id: 'demo-cmd-001', callsign: 'VIPER-6', role: OperatorRole.MISSION_COMMANDER, clearance_level: 'TOP_SECRET', email: 'commander@aegis.mil', mfa_enabled: false, mfa_secret: null, password: 'aegis2025' },
      'pilot': { operator_id: 'demo-plt-001', callsign: 'EAGLE-1', role: OperatorRole.OPERATOR, clearance_level: 'SECRET', email: 'pilot@aegis.mil', mfa_enabled: false, mfa_secret: null, password: 'aegis2025' },
      'analyst': { operator_id: 'demo-anl-001', callsign: 'ORACLE-1', role: OperatorRole.ANALYST, clearance_level: 'SECRET', email: 'analyst@aegis.mil', mfa_enabled: false, mfa_secret: null, password: 'aegis2025' },
      'admin': { operator_id: 'demo-adm-001', callsign: 'ADMIN-1', role: OperatorRole.SUPER_ADMIN, clearance_level: 'TOP_SECRET', email: 'admin@aegis.mil', mfa_enabled: false, mfa_secret: null, password: 'aegis2025' },
    };

    const result = await query<{
      operator_id: string; username: string; callsign: string; role: OperatorRole;
      clearance_level: string; email: string; mfa_enabled: boolean; mfa_secret: string | null;
      password_hash: string; active: boolean;
    }>(
      'SELECT operator_id, username, callsign, role, clearance_level, email, mfa_enabled, mfa_secret, password_hash, active FROM operators WHERE username = $1',
      [username]
    );

    let operator: {
      operator_id: string; username: string; callsign: string; role: OperatorRole;
      clearance_level: string; email: string; mfa_enabled: boolean; mfa_secret: string | null;
      password_hash: string; active: boolean;
    };

    if (result.rows.length > 0) {
      operator = result.rows[0];
    } else if (config.demoMode && DEMO_ACCOUNTS[username]) {
      const demo = DEMO_ACCOUNTS[username];
      if (password !== demo.password) {
        res.status(401).json({ success: false, error: 'Invalid credentials', timestamp: new Date().toISOString() });
        return;
      }
      operator = {
        operator_id: demo.operator_id,
        username,
        callsign: demo.callsign,
        role: demo.role,
        clearance_level: demo.clearance_level,
        email: demo.email,
        mfa_enabled: demo.mfa_enabled,
        mfa_secret: demo.mfa_secret,
        password_hash: await bcrypt.hash(demo.password, 10),
        active: true,
      };
    } else {
      res.status(401).json({ success: false, error: 'Invalid credentials', timestamp: new Date().toISOString() });
      return;
    }

    if (!operator.active) {
      res.status(403).json({ success: false, error: 'Account deactivated', timestamp: new Date().toISOString() });
      return;
    }

    const validPassword = config.demoMode && DEMO_ACCOUNTS[username]
      ? password === DEMO_ACCOUNTS[username].password
      : await bcrypt.compare(password, operator.password_hash);
    if (!validPassword) {
      logger.warn({ username }, 'Failed login attempt');
      res.status(401).json({ success: false, error: 'Invalid credentials', timestamp: new Date().toISOString() });
      return;
    }

    if (operator.mfa_enabled && operator.mfa_secret) {
      if (!totpCode) {
        res.status(200).json({
          success: true,
          data: { mfaRequired: true },
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const verified = speakeasy.totp.verify({
        secret: operator.mfa_secret,
        encoding: 'base32',
        token: totpCode,
        window: 1,
      });

      if (!verified) {
        res.status(401).json({ success: false, error: 'Invalid MFA code', timestamp: new Date().toISOString() });
        return;
      }
    }

    const sessionId = uuidv4();
    const tokenPayload = {
      sub: operator.operator_id,
      username: operator.username,
      callsign: operator.callsign,
      role: operator.role,
      clearanceLevel: operator.clearance_level,
      sessionId,
    };

    const { accessToken, refreshToken } = generateTokens(tokenPayload);

    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

    const sessionKey = `session:${operator.operator_id}:${sessionId}`;
    await redis.hset(sessionKey, {
      token_hash: tokenHash,
      ip_address: req.ip ?? 'unknown',
      user_agent: req.headers['user-agent'] ?? 'unknown',
      issued_at: new Date().toISOString(),
      mfa_verified_at: operator.mfa_enabled ? new Date().toISOString() : '',
    });
    await redis.expire(sessionKey, 8 * 60 * 60);

    await query(
      `INSERT INTO operator_sessions (session_id, operator_id, token_hash, ip_address, user_agent, expires_at, mfa_verified_at)
       VALUES ($1, $2, $3, $4, $5, NOW() + INTERVAL '8 hours', $6)`,
      [sessionId, operator.operator_id, tokenHash, req.ip, req.headers['user-agent'], operator.mfa_enabled ? new Date().toISOString() : null]
    );

    await query('UPDATE operators SET last_login = NOW() WHERE operator_id = $1', [operator.operator_id]);

    logger.info({ operatorId: operator.operator_id, callsign: operator.callsign }, 'Operator logged in');

    res.json({
      success: true,
      data: {
        accessToken,
        refreshToken,
        operator: {
          operatorId: operator.operator_id,
          username: operator.username,
          callsign: operator.callsign,
          role: operator.role,
          clearanceLevel: operator.clearance_level,
          email: operator.email,
          mfaEnabled: operator.mfa_enabled,
        },
        mfaRequired: false,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Login error');
    res.status(500).json({ success: false, error: 'Internal server error', timestamp: new Date().toISOString() });
  }
});

router.post('/refresh', async (req: Request, res: Response): Promise<void> => {
  try {
    const { refreshToken } = req.body as { refreshToken?: string };
    if (!refreshToken) {
      res.status(400).json({ success: false, error: 'Refresh token required', timestamp: new Date().toISOString() });
      return;
    }

    const decoded = jwt.verify(refreshToken, config.jwt.publicKey, { algorithms: ['RS256'] }) as JWTPayload;
    if (decoded.type !== 'refresh') {
      res.status(401).json({ success: false, error: 'Invalid token type', timestamp: new Date().toISOString() });
      return;
    }

    const sessionKey = `session:${decoded.sub}:${decoded.sessionId}`;
    const exists = await redis.exists(sessionKey);
    if (!exists) {
      res.status(401).json({ success: false, error: 'Session expired or revoked', timestamp: new Date().toISOString() });
      return;
    }

    const newSessionId = uuidv4();
    const tokenPayload = {
      sub: decoded.sub,
      username: decoded.username,
      callsign: decoded.callsign,
      role: decoded.role,
      clearanceLevel: decoded.clearanceLevel,
      sessionId: newSessionId,
    };

    const tokens = generateTokens(tokenPayload);

    await redis.del(sessionKey);
    const newSessionKey = `session:${decoded.sub}:${newSessionId}`;
    const newTokenHash = crypto.createHash('sha256').update(tokens.refreshToken).digest('hex');
    await redis.hset(newSessionKey, {
      token_hash: newTokenHash,
      issued_at: new Date().toISOString(),
    });
    await redis.expire(newSessionKey, 8 * 60 * 60);

    res.json({
      success: true,
      data: { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'Token refresh error');
    res.status(401).json({ success: false, error: 'Invalid refresh token', timestamp: new Date().toISOString() });
  }
});

router.post('/logout', authMiddleware(), async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const sessionKey = `session:${req.operator.sub}:${req.operator.sessionId}`;
    await redis.del(sessionKey);

    await query(
      'UPDATE operator_sessions SET revoked = TRUE WHERE operator_id = $1 AND session_id = $2',
      [req.operator.sub, req.operator.sessionId]
    );

    logger.info({ operatorId: req.operator.sub }, 'Operator logged out');
    res.json({ success: true, message: 'Logged out', timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Logout error');
    res.status(500).json({ success: false, error: 'Logout failed', timestamp: new Date().toISOString() });
  }
});

router.post('/mfa/setup', authMiddleware(), async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const secret = speakeasy.generateSecret({
      name: `AEGIS COMMAND (${req.operator.callsign})`,
      issuer: 'AEGIS-COMMAND',
      length: 32,
    });

    await query('UPDATE operators SET mfa_secret = $1 WHERE operator_id = $2', [secret.base32, req.operator.sub]);

    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url ?? '');

    res.json({
      success: true,
      data: {
        secret: secret.base32,
        otpauthUrl: secret.otpauth_url,
        qrCode: qrCodeUrl,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    logger.error({ err }, 'MFA setup error');
    res.status(500).json({ success: false, error: 'MFA setup failed', timestamp: new Date().toISOString() });
  }
});

router.post('/mfa/verify', authMiddleware(), async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const parsed = mfaVerifySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ success: false, error: 'Invalid MFA code format', timestamp: new Date().toISOString() });
      return;
    }

    const result = await query<{ mfa_secret: string | null }>(
      'SELECT mfa_secret FROM operators WHERE operator_id = $1',
      [req.operator.sub]
    );

    const mfaSecret = result.rows[0]?.mfa_secret;
    if (!mfaSecret) {
      res.status(400).json({ success: false, error: 'MFA not set up', timestamp: new Date().toISOString() });
      return;
    }

    const verified = speakeasy.totp.verify({
      secret: mfaSecret,
      encoding: 'base32',
      token: parsed.data.totpCode,
      window: 1,
    });

    if (!verified) {
      res.status(401).json({ success: false, error: 'Invalid MFA code', timestamp: new Date().toISOString() });
      return;
    }

    await query('UPDATE operators SET mfa_enabled = TRUE WHERE operator_id = $1', [req.operator.sub]);

    const sessionKey = `session:${req.operator.sub}:${req.operator.sessionId}`;
    await redis.hset(sessionKey, { mfa_verified_at: new Date().toISOString() });

    res.json({ success: true, message: 'MFA verified and enabled', timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'MFA verify error');
    res.status(500).json({ success: false, error: 'MFA verification failed', timestamp: new Date().toISOString() });
  }
});

router.get('/me', authMiddleware(), async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.operator) {
      res.status(401).json({ success: false, error: 'Not authenticated', timestamp: new Date().toISOString() });
      return;
    }

    const result = await query(
      `SELECT operator_id, username, callsign, role, clearance_level, email, mfa_enabled, active, last_login, created_at
       FROM operators WHERE operator_id = $1`,
      [req.operator.sub]
    );

    if (result.rows.length === 0) {
      if (config.demoMode) {
        res.json({
          success: true,
          data: {
            operatorId: req.operator.sub,
            username: req.operator.username,
            callsign: req.operator.callsign,
            role: req.operator.role,
            clearanceLevel: req.operator.clearanceLevel,
            email: `${req.operator.username}@aegis.mil`,
            mfaEnabled: false,
          },
          timestamp: new Date().toISOString(),
        });
        return;
      }
      res.status(404).json({ success: false, error: 'Operator not found', timestamp: new Date().toISOString() });
      return;
    }

    res.json({ success: true, data: result.rows[0], timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error({ err }, 'Get profile error');
    res.status(500).json({ success: false, error: 'Failed to fetch profile', timestamp: new Date().toISOString() });
  }
});

export { router as authRouter, sessionRevoke };
