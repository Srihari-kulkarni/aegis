'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useDroneStore } from '@/stores/droneStore';
import { useFeedStore } from '@/stores/feedStore';
import { useMissionStore } from '@/stores/missionStore';
import { DroneStatus } from '@aegis/shared';
import type { GeoJSON } from '@aegis/shared';
import type { Waypoint } from '@aegis/shared';
import { apiGet } from '@/lib/api';

const DEFAULT_CENTER: [number, number] = [34.052, -118.244];
const DEFAULT_ZOOM = 11;

const TILE_LAYERS = {
  streets: {
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; <a href="https://osm.org/">OSM</a>',
    label: 'STREETS',
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '&copy; Esri',
    label: 'SATELLITE',
  },
  dark: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
    label: 'DARK',
  },
};

type MapStyle = keyof typeof TILE_LAYERS;

const RANGE_RINGS_KM = [5, 10, 20];

type DroneMarkerColor = 'green' | 'amber' | 'red' | 'cyan' | 'gray';

function getDroneMarkerColor(status: DroneStatus): DroneMarkerColor {
  switch (status) {
    case DroneStatus.ON_MISSION:
    case DroneStatus.RETURNING:
    case DroneStatus.LANDED:
      return 'green';
    case DroneStatus.PREFLIGHT:
    case DroneStatus.MAINTENANCE:
      return 'amber';
    case DroneStatus.LOST_LINK:
    case DroneStatus.EMERGENCY:
    case DroneStatus.DESTROYED:
      return 'red';
    case DroneStatus.AIRBORNE:
      return 'cyan';
    case DroneStatus.STANDBY:
    case DroneStatus.DECOMMISSIONED:
    default:
      return 'gray';
  }
}

const DRONE_COLORS: Record<DroneMarkerColor, string> = {
  green: '#32d74b',
  amber: '#ffd60a',
  red: '#ff2d55',
  cyan: '#00d4ff',
  gray: '#4a5568',
};

interface NoFlyZoneRow {
  zone_id: string;
  name: string;
  polygon: GeoJSON.Polygon;
  floor_ft: number;
  ceiling_ft: number;
  permanent: boolean;
  active_from: string | null;
  active_to: string | null;
  reason: string;
}

interface AirspaceResponse {
  noFlyZones?: NoFlyZoneRow[];
}

interface TacticalMapProps {
  onMapClick?: (lat: number, lon: number) => void;
  clickedLocation?: { lat: number; lon: number } | null;
}

export function TacticalMap({ onMapClick, clickedLocation }: TacticalMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const threatsLayerRef = useRef<L.LayerGroup | null>(null);
  const noFlyLayerRef = useRef<L.LayerGroup | null>(null);
  const missionAreasLayerRef = useRef<L.LayerGroup | null>(null);
  const rangeRingsLayerRef = useRef<L.LayerGroup | null>(null);
  const waypointPathLayerRef = useRef<L.LayerGroup | null>(null);
  const clickMarkerRef = useRef<L.Marker | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const [mounted, setMounted] = useState(false);
  const [noFlyZones, setNoFlyZones] = useState<NoFlyZoneRow[]>([]);
  const [mapStyle, setMapStyle] = useState<MapStyle>('streets');
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<Array<{ lat: number; lon: number; label: string }>>([]);
  const [showSearch, setShowSearch] = useState(false);

  const drones = useDroneStore((s) => s.getFilteredDrones());
  const selectedDroneId = useDroneStore((s) => s.selectedDroneId);
  const selectDrone = useDroneStore((s) => s.selectDrone);
  const selectedDrone = useDroneStore((s) => s.getSelectedDrone());
  const threats = useFeedStore((s) => s.threats);
  const missions = useMissionStore((s) => s.missions);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    apiGet<AirspaceResponse>('/api/v1/intel/airspace')
      .then((res) => {
        if (res.success && res.data?.noFlyZones) {
          setNoFlyZones(res.data.noFlyZones);
        }
      })
      .catch(() => {});
  }, [mounted]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted || !mapContainerRef.current || mapRef.current) return;

    const initMap = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      await import('leaflet/dist/leaflet.css');

      const map = L.map(mapContainerRef.current!, {
        center: DEFAULT_CENTER,
        zoom: DEFAULT_ZOOM,
        zoomControl: false,
      });

      const tileConfig = TILE_LAYERS.streets;
      const tileLayer = L.tileLayer(tileConfig.url, {
        attribution: tileConfig.attribution,
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (onMapClick) {
          onMapClick(
            parseFloat(e.latlng.lat.toFixed(6)),
            parseFloat(e.latlng.lng.toFixed(6))
          );
        }
      });

      mapRef.current = map;
      tileLayerRef.current = tileLayer;
      markersLayerRef.current = L.layerGroup().addTo(map);
      threatsLayerRef.current = L.layerGroup().addTo(map);
      noFlyLayerRef.current = L.layerGroup().addTo(map);
      missionAreasLayerRef.current = L.layerGroup().addTo(map);
      rangeRingsLayerRef.current = L.layerGroup().addTo(map);
      waypointPathLayerRef.current = L.layerGroup().addTo(map);
    };

    initMap();

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
      markersLayerRef.current = null;
      threatsLayerRef.current = null;
      noFlyLayerRef.current = null;
      missionAreasLayerRef.current = null;
      rangeRingsLayerRef.current = null;
      waypointPathLayerRef.current = null;
      clickMarkerRef.current = null;
      tileLayerRef.current = null;
    };
  }, [mounted, onMapClick]);

  // Switch tile layer on style change
  useEffect(() => {
    if (!mapRef.current || !tileLayerRef.current) return;
    const switchTiles = async () => {
      const L = (await import('leaflet')).default;
      tileLayerRef.current!.remove();
      const cfg = TILE_LAYERS[mapStyle];
      tileLayerRef.current = L.tileLayer(cfg.url, {
        attribution: cfg.attribution,
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(mapRef.current!);
    };
    switchTiles();
  }, [mapStyle]);

  // Clicked location marker
  useEffect(() => {
    if (!mounted || !mapRef.current) return;
    const updateClickMarker = async () => {
      const L = (await import('leaflet')).default;
      if (clickMarkerRef.current) {
        clickMarkerRef.current.remove();
        clickMarkerRef.current = null;
      }
      if (clickedLocation) {
        const icon = L.divIcon({
          className: 'click-marker-icon',
          html: `<div style="width:24px;height:24px;background:#00d4ff;border:3px solid #fff;border-radius:50%;box-shadow:0 0 12px rgba(0,212,255,0.6);transform:translate(-12px,-12px)"></div>
                 <div style="width:2px;height:16px;background:#00d4ff;margin-left:8px;box-shadow:0 0 6px rgba(0,212,255,0.4)"></div>`,
          iconSize: [24, 40],
          iconAnchor: [12, 40],
        });
        const marker = L.marker([clickedLocation.lat, clickedLocation.lon], { icon });
        marker.bindTooltip(
          `${clickedLocation.lat.toFixed(6)}, ${clickedLocation.lon.toFixed(6)}`,
          { permanent: true, direction: 'top', className: 'click-tooltip', offset: [0, -42] }
        );
        marker.addTo(mapRef.current!);
        clickMarkerRef.current = marker;
      }
    };
    updateClickMarker();
  }, [mounted, clickedLocation]);

  // Update drone markers
  useEffect(() => {
    if (!mounted || !markersLayerRef.current || !mapRef.current) return;

    const updateMarkers = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      const layer = markersLayerRef.current!;
      layer.clearLayers();

      for (const drone of drones) {
        const { position, callsign, status, droneId } = drone;
        const lat = position?.lat ?? 34.052;
        const lon = position?.lon ?? -118.244;
        const color = getDroneMarkerColor(status);
        const fillColor = DRONE_COLORS[color];
        const isSelected = droneId === selectedDroneId;

        const icon = L.divIcon({
          className: 'drone-marker-icon',
          html: `<div style="
            width:${isSelected ? 18 : 14}px;
            height:${isSelected ? 18 : 14}px;
            background:${fillColor};
            border:2px solid ${isSelected ? '#fff' : 'rgba(255,255,255,0.6)'};
            border-radius:50%;
            box-shadow:0 0 ${isSelected ? 12 : 6}px ${fillColor}80;
            transform:translate(-${isSelected ? 9 : 7}px,-${isSelected ? 9 : 7}px);
          "></div>`,
          iconSize: [isSelected ? 18 : 14, isSelected ? 18 : 14],
        });

        const marker = L.marker([lat, lon], { icon });

        marker.bindTooltip(`${callsign} — ${status}`, {
          permanent: false,
          direction: 'top',
          className: 'tactical-tooltip',
        });

        marker.on('click', () => {
          selectDrone(droneId);
        });

        layer.addLayer(marker);
      }
    };

    updateMarkers();
  }, [mounted, drones, selectDrone, selectedDroneId]);

  // Update threat markers
  useEffect(() => {
    if (!mounted || !threatsLayerRef.current) return;

    const updateThreats = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      const layer = threatsLayerRef.current!;
      layer.clearLayers();

      for (const threat of threats) {
        if (!threat.active) continue;
        const lat = threat.position?.lat ?? 34.052;
        const lon = threat.position?.lon ?? -118.244;
        const radiusKm = threat.radiusKm ?? 1;

        const circle = L.circle([lat, lon], {
          radius: radiusKm * 1000,
          color: '#ff2d55',
          fillColor: '#ff2d55',
          fillOpacity: 0.15,
          weight: 2,
          className: 'threat-pulse-circle',
        });

        layer.addLayer(circle);
      }
    };

    updateThreats();
  }, [mounted, threats]);

  // Update no-fly zone polygons
  useEffect(() => {
    if (!mounted || !noFlyLayerRef.current) return;

    const updateNoFly = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      const layer = noFlyLayerRef.current!;
      layer.clearLayers();

      for (const nfz of noFlyZones) {
        const poly = nfz.polygon;
        if (!poly || poly.type !== 'Polygon' || !poly.coordinates?.[0]) continue;

        const latLngs: [number, number][] = poly.coordinates[0].map((c) => [c[1], c[0]] as [number, number]);

        const polygon = L.polygon(latLngs, {
          color: '#ff2d55',
          fillColor: '#ff2d55',
          fillOpacity: 0.2,
          weight: 2,
        });

        polygon.bindTooltip(nfz.name, { permanent: false });
        layer.addLayer(polygon);
      }
    };

    updateNoFly();
  }, [mounted, noFlyZones]);

  // Update mission area polygons
  useEffect(() => {
    if (!mounted || !missionAreasLayerRef.current) return;

    const updateMissionAreas = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      const layer = missionAreasLayerRef.current!;
      layer.clearLayers();

      for (const mission of missions) {
        const aoo = (mission as { areaOfOperations?: GeoJSON.Polygon | null }).areaOfOperations;
        if (!aoo || aoo.type !== 'Polygon' || !aoo.coordinates?.[0]) continue;

        const latLngs: [number, number][] = aoo.coordinates[0].map((c) => [c[1], c[0]] as [number, number]);

        const polygon = L.polygon(latLngs, {
          color: '#00d4ff',
          fillColor: '#00d4ff',
          fillOpacity: 0.08,
          weight: 2,
          dashArray: '6, 4',
        });

        polygon.bindTooltip((mission as { name?: string }).name ?? 'Mission Area', { permanent: false });
        layer.addLayer(polygon);
      }
    };

    updateMissionAreas();
  }, [mounted, missions]);

  // Update range rings and waypoint path for selected drone
  useEffect(() => {
    if (!mounted || !rangeRingsLayerRef.current || !waypointPathLayerRef.current) return;

    const updateSelectedOverlays = async (): Promise<void> => {
      const L = (await import('leaflet')).default;
      const rangeLayer = rangeRingsLayerRef.current!;
      const pathLayer = waypointPathLayerRef.current!;
      rangeLayer.clearLayers();
      pathLayer.clearLayers();

      if (!selectedDrone) return;

      const lat = selectedDrone.position?.lat ?? 34.052;
      const lon = selectedDrone.position?.lon ?? -118.244;

      for (const km of RANGE_RINGS_KM) {
        const circle = L.circle([lat, lon], {
          radius: km * 1000,
          color: '#00d4ff',
          fillColor: 'transparent',
          fillOpacity: 0,
          weight: 1,
          dashArray: '4, 4',
          opacity: 0.4,
        });
        rangeLayer.addLayer(circle);
      }

      const missionId = selectedDrone.currentMissionId;
      if (missionId) {
        const mission = missions.find((m) => m.missionId === missionId);
        const waypoints = (mission as { waypoints?: Waypoint[] } | undefined)?.waypoints;
        if (waypoints && waypoints.length > 1) {
          const pathPoints: [number, number][] = waypoints.map((wp) => [
            wp.position.lat,
            wp.position.lon,
          ] as [number, number]);
          const polyline = L.polyline(pathPoints, {
            color: '#00d4ff',
            weight: 2,
            dashArray: '8, 4',
          });
          pathLayer.addLayer(polyline);
        }
      }
    };

    updateSelectedOverlays();
  }, [mounted, selectedDrone, missions]);

  // Search with Nominatim geocoding
  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim() || !mapRef.current) return;
    setSearching(true);
    setSearchResults([]);
    try {
      const q = encodeURIComponent(searchQuery.trim());
      const resp = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${q}&limit=5`);
      const data = await resp.json() as Array<{ lat: string; lon: string; display_name: string }>;
      if (data.length > 0) {
        const results = data.map((d) => ({
          lat: parseFloat(d.lat),
          lon: parseFloat(d.lon),
          label: d.display_name,
        }));
        setSearchResults(results);
        mapRef.current!.flyTo([results[0].lat, results[0].lon], 14, { duration: 1.2 });
      }
    } catch {
      // geocoding failed silently
    } finally {
      setSearching(false);
    }
  }, [searchQuery]);

  const handleSearchResultClick = useCallback((result: { lat: number; lon: number; label: string }) => {
    if (!mapRef.current) return;
    mapRef.current.flyTo([result.lat, result.lon], 15, { duration: 1 });
    if (onMapClick) {
      onMapClick(
        parseFloat(result.lat.toFixed(6)),
        parseFloat(result.lon.toFixed(6))
      );
    }
    setSearchResults([]);
    setShowSearch(false);
    setSearchQuery('');
  }, [onMapClick]);

  if (!mounted) {
    return (
      <div className="h-full w-full bg-aegis-panel flex items-center justify-center">
        <span className="font-mono text-aegis-muted text-xs">Loading map...</span>
      </div>
    );
  }

  return (
    <div className="h-full w-full relative">
      <div ref={mapContainerRef} className="h-full w-full" />

      {/* Map controls overlay — top left */}
      <div className="absolute top-3 left-3 z-[1000] flex flex-col gap-2">
        {/* Search bar */}
        <div className="flex flex-col">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setShowSearch(!showSearch)}
              className="bg-white shadow-lg border border-gray-200 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              title="Search location"
            >
              🔍
            </button>
            {showSearch && (
              <div className="flex items-center bg-white shadow-lg border border-gray-200">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Search location, pincode..."
                  className="px-3 py-2 text-sm text-gray-800 w-64 outline-none bg-transparent"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={handleSearch}
                  disabled={searching}
                  className="px-3 py-2 text-sm text-gray-600 hover:text-gray-900 border-l border-gray-200"
                >
                  {searching ? '...' : 'GO'}
                </button>
              </div>
            )}
          </div>

          {/* Search results dropdown */}
          {searchResults.length > 0 && (
            <div className="mt-1 bg-white shadow-lg border border-gray-200 max-h-48 overflow-y-auto">
              {searchResults.map((r, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSearchResultClick(r)}
                  className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-blue-50 border-b border-gray-100 last:border-b-0"
                >
                  <div className="font-medium truncate">{r.label}</div>
                  <div className="text-gray-400 text-[10px] mt-0.5">{r.lat.toFixed(4)}, {r.lon.toFixed(4)}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Map style switcher — top right */}
      <div className="absolute top-3 right-3 z-[1000] flex gap-0 bg-white shadow-lg border border-gray-200 overflow-hidden">
        {(Object.keys(TILE_LAYERS) as MapStyle[]).map((style) => (
          <button
            key={style}
            type="button"
            onClick={() => setMapStyle(style)}
            className={`px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider transition-colors ${
              mapStyle === style
                ? 'bg-blue-500 text-white'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {TILE_LAYERS[style].label}
          </button>
        ))}
      </div>

      {/* Coordinate display — bottom left */}
      {clickedLocation && (
        <div className="absolute bottom-8 left-3 z-[1000] bg-aegis-panel/95 border border-aegis-border px-3 py-2 font-mono text-xs">
          <span className="text-aegis-muted">SELECTED: </span>
          <span className="text-aegis-cyan">{clickedLocation.lat.toFixed(6)}</span>
          <span className="text-aegis-muted">, </span>
          <span className="text-aegis-cyan">{clickedLocation.lon.toFixed(6)}</span>
        </div>
      )}

      {/* Drone count — bottom left */}
      <div className="absolute bottom-8 right-14 z-[1000] bg-aegis-panel/90 border border-aegis-border px-2 py-1 font-mono text-[10px] text-aegis-muted">
        {drones.length} DRONES TRACKED
      </div>
    </div>
  );
}
