import {
  DroneClass,
  DroneStatus,
  SensorType,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export type AltitudeClassification = 'HALE' | 'MALE';

export interface LargeAltitudeDroneConfig extends DroneConfig {
  classification?: AltitudeClassification;
  serviceCeilingFt?: number;
  persistentISRHours?: number;
}

export class LargeAltitudeDrone extends DroneBase {
  classification: AltitudeClassification;
  serviceCeilingFt: number;
  persistentISRHours: number;
  strategicRelay: boolean;
  blosCertified: boolean;

  private isrPatternActive: boolean = false;
  private isrStartTime: number | null = null;
  private totalISRHoursLogged: number = 0;
  private activeSensors: Set<SensorType> = new Set();
  private awaitingBlosReconnect: boolean = false;

  constructor(cfg: LargeAltitudeDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.LARGE_ALTITUDE });
    this.classification = cfg.classification ?? 'MALE';
    this.serviceCeilingFt = cfg.serviceCeilingFt ?? (this.classification === 'HALE' ? 60000 : 30000);
    this.persistentISRHours = cfg.persistentISRHours ?? (this.classification === 'HALE' ? 36 : 24);
    this.strategicRelay = false;
    this.blosCertified = false;
  }

  enableStrategicRelay(): void {
    this.strategicRelay = true;
  }

  disableStrategicRelay(): void {
    this.strategicRelay = false;
  }

  certifyBLOS(): void {
    this.blosCertified = true;
  }

  startISRPattern(): void {
    if (!this.isrPatternActive) {
      this.isrPatternActive = true;
      this.isrStartTime = Date.now();
    }
  }

  stopISRPattern(): number {
    if (this.isrStartTime !== null) {
      const elapsed = (Date.now() - this.isrStartTime) / 3_600_000;
      this.totalISRHoursLogged += elapsed;
      this.isrStartTime = null;
    }
    this.isrPatternActive = false;
    return this.getTotalISRHours();
  }

  getTotalISRHours(): number {
    if (this.isrStartTime !== null) {
      return this.totalISRHoursLogged + (Date.now() - this.isrStartTime) / 3_600_000;
    }
    return this.totalISRHoursLogged;
  }

  getRemainingISRHours(): number {
    return Math.max(0, this.persistentISRHours - this.getTotalISRHours());
  }

  activateSensor(sensor: SensorType): void {
    this.activeSensors.add(sensor);
  }

  deactivateSensor(sensor: SensorType): void {
    this.activeSensors.delete(sensor);
  }

  getActiveSensors(): SensorType[] {
    return Array.from(this.activeSensors);
  }

  isAtServiceCeiling(): boolean {
    return this.altitude >= this.serviceCeilingFt;
  }

  isAwaitingBlosReconnect(): boolean {
    return this.awaitingBlosReconnect;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      classification: this.classification,
      serviceCeilingFt: this.serviceCeilingFt,
      persistentISRHours: this.persistentISRHours,
      totalISRHoursLogged: this.getTotalISRHours(),
      remainingISRHours: this.getRemainingISRHours(),
      isrPatternActive: this.isrPatternActive,
      strategicRelay: this.strategicRelay,
      blosCertified: this.blosCertified,
      activeSensors: this.getActiveSensors(),
      activeSensorCount: this.activeSensors.size,
      atServiceCeiling: this.isAtServiceCeiling(),
      awaitingBlosReconnect: this.awaitingBlosReconnect,
    };
  }

  getAIContextDescriptor(): string {
    const sensorList = this.getActiveSensors().join(', ') || 'NONE';
    return [
      `${this.classification} drone ${this.callsign} (${this.model})`,
      `Class: ${this.classification} | Ceiling: ${this.serviceCeilingFt}ft`,
      `ISR: ${this.isrPatternActive ? 'ACTIVE' : 'OFF'} | Logged: ${this.getTotalISRHours().toFixed(2)}h / ${this.persistentISRHours}h`,
      `Remaining ISR: ${this.getRemainingISRHours().toFixed(2)}h`,
      `Sensors: [${sensorList}]`,
      `Strategic relay: ${this.strategicRelay ? 'ACTIVE' : 'OFF'} | BLOS: ${this.blosCertified ? 'CERTIFIED' : 'NO'}`,
      `BLOS reconnect wait: ${this.awaitingBlosReconnect}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Fuel: ${this.fuelPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'PERSISTENT_ISR',
        available: true,
        degradedMode: 'Continues autonomous ISR orbit on pre-loaded pattern; imagery stored onboard',
      },
      {
        capability: 'STRATEGIC_RELAY',
        available: this.strategicRelay,
        degradedMode: 'Relay maintained on last-configured frequencies; no remote reconfiguration',
      },
      {
        capability: 'BLOS_COMMS',
        available: this.blosCertified,
        degradedMode: 'Awaiting BLOS satellite reconnect; SATCOM handshake attempts every 60s',
      },
      {
        capability: 'SENSOR_OPERATION',
        available: true,
        degradedMode: 'All active sensors continue collection; data buffered onboard',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'GPS/INS navigation maintained; autonomous orbit hold on last-assigned track',
      },
      {
        capability: 'LIVE_DOWNLINK',
        available: false,
        degradedMode: 'No live downlink; high-priority imagery queued for burst transmission on reconnect',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;

    if (!this.isrPatternActive) {
      this.startISRPattern();
    }

    if (this.blosCertified) {
      this.awaitingBlosReconnect = true;
    }
  }
}

export default LargeAltitudeDrone;
