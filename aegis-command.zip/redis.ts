import { EventEmitter } from 'events';
import { config } from './config';
import { logger } from './logger';

type RedisLike = {
  hset(key: string, data: Record<string, string>): Promise<number>;
  hget(key: string, field: string): Promise<string | null>;
  hgetall(key: string): Promise<Record<string, string>>;
  set(key: string, value: string, ...args: (string | number)[]): Promise<string>;
  get(key: string): Promise<string | null>;
  del(...keys: string[]): Promise<number>;
  exists(key: string): Promise<number>;
  expire(key: string, seconds: number): Promise<number>;
  keys(pattern: string): Promise<string[]>;
  incr(key: string): Promise<number>;
  publish(channel: string, message: string): Promise<number>;
  subscribe(...channels: string[]): Promise<void>;
  psubscribe(...patterns: string[]): Promise<void>;
  on(event: string, listener: (...args: unknown[]) => void): void;
  connect(): Promise<void>;
  connected: boolean;
};

class InMemoryRedis extends EventEmitter implements RedisLike {
  private store = new Map<string, string>();
  private hashes = new Map<string, Map<string, string>>();
  private ttls = new Map<string, ReturnType<typeof setTimeout>>();
  connected = false;
  private static pubSubBus = new EventEmitter();

  async connect(): Promise<void> {
    this.connected = true;
    this.emit('connect');
  }

  async hset(key: string, data: Record<string, string>): Promise<number> {
    let hash = this.hashes.get(key);
    if (!hash) { hash = new Map(); this.hashes.set(key, hash); }
    let count = 0;
    for (const [f, v] of Object.entries(data)) { hash.set(f, v); count++; }
    return count;
  }

  async hget(key: string, field: string): Promise<string | null> {
    return this.hashes.get(key)?.get(field) ?? null;
  }

  async hgetall(key: string): Promise<Record<string, string>> {
    const hash = this.hashes.get(key);
    if (!hash) return {};
    const result: Record<string, string> = {};
    hash.forEach((v, k) => { result[k] = v; });
    return result;
  }

  async set(key: string, value: string, ...args: (string | number)[]): Promise<string> {
    this.store.set(key, value);
    if (args[0] === 'EX' && typeof args[1] === 'number') {
      this.clearTTL(key);
      this.ttls.set(key, setTimeout(() => { this.store.delete(key); this.ttls.delete(key); }, args[1] * 1000));
    }
    return 'OK';
  }

  async get(key: string): Promise<string | null> { return this.store.get(key) ?? null; }

  async del(...keys: string[]): Promise<number> {
    let count = 0;
    for (const k of keys) {
      if (this.store.delete(k) || this.hashes.delete(k)) count++;
      this.clearTTL(k);
    }
    return count;
  }

  async exists(key: string): Promise<number> {
    return (this.store.has(key) || this.hashes.has(key)) ? 1 : 0;
  }

  async expire(key: string, seconds: number): Promise<number> {
    if (!this.store.has(key) && !this.hashes.has(key)) return 0;
    this.clearTTL(key);
    this.ttls.set(key, setTimeout(() => { this.store.delete(key); this.hashes.delete(key); this.ttls.delete(key); }, seconds * 1000));
    return 1;
  }

  async keys(pattern: string): Promise<string[]> {
    const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
    const all = [...this.store.keys(), ...this.hashes.keys()];
    return all.filter((k) => regex.test(k));
  }

  async incr(key: string): Promise<number> {
    const val = parseInt(this.store.get(key) ?? '0', 10) + 1;
    this.store.set(key, val.toString());
    return val;
  }

  async publish(channel: string, message: string): Promise<number> {
    InMemoryRedis.pubSubBus.emit('message', channel, message);
    InMemoryRedis.pubSubBus.emit('pmessage', '*', channel, message);
    return 1;
  }

  async subscribe(...channels: string[]): Promise<void> {
    for (const ch of channels) {
      InMemoryRedis.pubSubBus.on('message', (c: string, m: string) => {
        if (c === ch) this.emit('message', c, m);
      });
    }
  }

  async psubscribe(..._patterns: string[]): Promise<void> {
    InMemoryRedis.pubSubBus.on('pmessage', (_p: string, ch: string, m: string) => {
      this.emit('pmessage', '*', ch, m);
    });
  }

  private clearTTL(key: string): void {
    const t = this.ttls.get(key);
    if (t) { clearTimeout(t); this.ttls.delete(key); }
  }
}

let redisInstance: RedisLike;
let redisSubInstance: RedisLike;
let redisPubInstance: RedisLike;
let useInMemory = false;

try {
  if (config.demoMode || !config.redisUrl || config.redisUrl === 'redis://localhost:6379') {
    throw new Error('Using in-memory Redis for demo mode');
  }
  const Redis = require('ioredis') as typeof import('ioredis').default;
  redisInstance = new Redis(config.redisUrl, { maxRetriesPerRequest: 3, lazyConnect: true }) as unknown as RedisLike;
  redisSubInstance = new Redis(config.redisUrl, { maxRetriesPerRequest: 3, lazyConnect: true }) as unknown as RedisLike;
  redisPubInstance = new Redis(config.redisUrl, { maxRetriesPerRequest: 3, lazyConnect: true }) as unknown as RedisLike;
} catch {
  useInMemory = true;
  redisInstance = new InMemoryRedis();
  redisSubInstance = new InMemoryRedis();
  redisPubInstance = new InMemoryRedis();
  logger.info('Using in-memory Redis substitute (demo mode)');
}

export const redis = redisInstance;
export const redisSub = redisSubInstance;
export const redisPub = redisPubInstance;

export async function connectRedis(): Promise<void> {
  if (useInMemory) {
    await redis.connect();
    await redisSub.connect();
    await redisPub.connect();
    logger.info('In-memory Redis connected (demo mode)');
    return;
  }
  try {
    await Promise.all([redis.connect(), redisSub.connect(), redisPub.connect()]);
    logger.info('Redis connections established');
  } catch (err) {
    logger.warn({ err }, 'Redis connection failed — falling back to in-memory');
    const mem = new InMemoryRedis();
    await mem.connect();
  }
}

/*
 * Redis key schema:
 *   drone:live:{droneId}           HASH    — live telemetry (TTL: 5min)
 *   drone:status:{droneId}         STRING  — current status enum
 *   mission:active:{missionId}     HASH    — mission state
 *   hcs:topic:{missionId}          STRING  — HCS topic ID
 *   session:{operatorId}:{hash}    STRING  — session token (TTL: 8h)
 *   telemetry:{droneId}            PUBSUB  — live telemetry channel
 *   mission:actions                PUBSUB  — HCS action log channel
 *   mission:ai_decision            PUBSUB  — AI decisions channel
 *   rate:cmd:{operatorId}          STRING  — command rate limiter (TTL: 1min)
 */
