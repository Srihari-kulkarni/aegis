import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, OpenMeteoWind } from '../types';

const CACHE_KEY = 'intel:openmeteo';
const TTL = 300;

export async function fetchOpenMeteo(lat: number, lon: number): Promise<IntelFeedResult<OpenMeteoWind>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(2)}_${lon.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'open-meteo', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=windspeed_10m,windspeed_80m,windspeed_120m,windgusts_10m,visibility,precipitation,weathercode&windspeed_unit=ms&current_weather=true&timezone=UTC`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`Open-Meteo HTTP ${res.status}`);

    const json = await res.json() as {
      current_weather: { windspeed: number; weathercode: number };
      hourly: {
        windspeed_10m: number[]; windspeed_80m: number[]; windspeed_120m: number[];
        windgusts_10m: number[]; visibility: number[]; precipitation: number[];
        weathercode: number[];
      };
    };

    const h = json.hourly;
    const nowIdx = Math.min(new Date().getUTCHours(), (h.windspeed_10m?.length ?? 1) - 1);

    const result: OpenMeteoWind = {
      lat, lon,
      wind10m: h.windspeed_10m?.[nowIdx] ?? json.current_weather.windspeed,
      wind80m: h.windspeed_80m?.[nowIdx] ?? json.current_weather.windspeed * 1.2,
      wind120m: h.windspeed_120m?.[nowIdx] ?? json.current_weather.windspeed * 1.4,
      gusts10m: h.windgusts_10m?.[nowIdx] ?? json.current_weather.windspeed * 1.5,
      visibility: h.visibility?.[nowIdx] ?? 10000,
      precipitation: h.precipitation?.[nowIdx] ?? 0,
      weatherCode: h.weathercode?.[nowIdx] ?? json.current_weather.weathercode,
      fetchedAt: zuluTimestamp(),
    };

    await redis.set(cacheKey, JSON.stringify(result), 'EX', TTL);
    logger.debug({ wind10m: result.wind10m, wind80m: result.wind80m }, 'Open-Meteo fetched');
    return { success: true, data: result, source: 'open-meteo', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'Open-Meteo fetch failed — using simulated data');
    return { success: true, data: simulateOpenMeteo(lat, lon), source: 'open-meteo-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateOpenMeteo(lat: number, lon: number): OpenMeteoWind {
  const base = 3 + Math.random() * 10;
  return {
    lat, lon,
    wind10m: base,
    wind80m: base * (1.1 + Math.random() * 0.3),
    wind120m: base * (1.2 + Math.random() * 0.4),
    gusts10m: base * (1.3 + Math.random() * 0.5),
    visibility: 3000 + Math.random() * 12000,
    precipitation: Math.random() > 0.7 ? Math.random() * 4 : 0,
    weatherCode: Math.random() > 0.8 ? 61 : 0,
    fetchedAt: zuluTimestamp(),
  };
}
