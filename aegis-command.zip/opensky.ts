import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { BoundingBox, IntelFeedResult, OpenSkyState } from '../types';

const CACHE_KEY = 'intel:opensky';
const TTL = 10;

export async function fetchOpenSky(bbox: BoundingBox): Promise<IntelFeedResult<OpenSkyState[]>> {
  const cacheKey = `${CACHE_KEY}:${bbox.lamin.toFixed(2)}_${bbox.lomin.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'opensky-network', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = `https://opensky-network.org/api/states/all?lamin=${bbox.lamin}&lomin=${bbox.lomin}&lamax=${bbox.lamax}&lomax=${bbox.lomax}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`OpenSky HTTP ${res.status}`);

    const json = await res.json() as { states: (string | number | boolean | null)[][] | null };
    const states: OpenSkyState[] = (json.states ?? []).map((s) => ({
      icao24: String(s[0] ?? ''),
      callsign: s[1] ? String(s[1]).trim() : null,
      originCountry: String(s[2] ?? ''),
      longitude: s[5] as number | null,
      latitude: s[6] as number | null,
      baroAltitude: s[7] as number | null,
      velocity: s[9] as number | null,
      trueTrack: s[10] as number | null,
      verticalRate: s[11] as number | null,
      onGround: Boolean(s[8]),
      squawk: s[14] ? String(s[14]) : null,
    }));

    await redis.set(cacheKey, JSON.stringify(states), 'EX', TTL);
    logger.debug({ count: states.length }, 'OpenSky fetched');
    return { success: true, data: states, source: 'opensky-network', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'OpenSky fetch failed — using simulated data');
    return { success: true, data: simulateOpenSky(bbox), source: 'opensky-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateOpenSky(bbox: BoundingBox): OpenSkyState[] {
  const count = 2 + Math.floor(Math.random() * 6);
  return Array.from({ length: count }, (_, i) => ({
    icao24: `A${(40000 + i).toString(16).toUpperCase().padStart(6, '0')}`,
    callsign: `UAL${1000 + Math.floor(Math.random() * 9000)}`,
    originCountry: 'United States',
    longitude: bbox.lomin + Math.random() * (bbox.lomax - bbox.lomin),
    latitude: bbox.lamin + Math.random() * (bbox.lamax - bbox.lamin),
    baroAltitude: 3000 + Math.random() * 10000,
    velocity: 80 + Math.random() * 200,
    trueTrack: Math.random() * 360,
    verticalRate: (Math.random() - 0.5) * 10,
    onGround: false,
    squawk: `${1200 + Math.floor(Math.random() * 6600)}`,
  }));
}
