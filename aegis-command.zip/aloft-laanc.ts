import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { AloftLAANC, IntelFeedResult } from '../types';

const CACHE_KEY = 'intel:aloft_laanc';
const TTL = 600;

export async function fetchAloftLAANC(lat: number, lon: number, _apiKey?: string): Promise<IntelFeedResult<AloftLAANC>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(3)}_${lon.toFixed(3)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'aloft-laanc', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  const result = simulateLAANC(lat, lon);
  await redis.set(cacheKey, JSON.stringify(result), 'EX', TTL);
  logger.debug({ facilityId: result.facilityId }, 'Aloft LAANC data generated (simulated)');
  return { success: true, data: result, source: 'aloft-laanc-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
}

function simulateLAANC(lat: number, lon: number): AloftLAANC {
  const gridNum = Math.abs(Math.floor(lat * 100) + Math.floor(lon * 100));
  return {
    facilityId: `K${String.fromCharCode(65 + (gridNum % 26))}${String.fromCharCode(65 + ((gridNum + 7) % 26))}${String.fromCharCode(65 + ((gridNum + 13) % 26))}`,
    gridId: `GRID-${gridNum % 10000}`,
    maxAltFt: [100, 200, 300, 400][gridNum % 4],
    laancAvailable: Math.random() > 0.3,
    autoApproveBelow: [100, 200][gridNum % 2],
    furtherCoordinationRequired: Math.random() > 0.7,
  };
}
