import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, NOAAAlert } from '../types';

const CACHE_KEY = 'intel:noaa_alerts';
const TTL = 300;

export async function fetchNOAAWeatherAlerts(lat: number, lon: number): Promise<IntelFeedResult<NOAAAlert[]>> {
  const cacheKey = `${CACHE_KEY}:${lat.toFixed(1)}_${lon.toFixed(1)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'noaa-alerts', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const pointUrl = `https://api.weather.gov/points/${lat.toFixed(4)},${lon.toFixed(4)}`;
    const pointRes = await fetch(pointUrl, { signal: AbortSignal.timeout(5000), headers: { 'User-Agent': 'AEGIS-Command/1.0' } });
    if (!pointRes.ok) throw new Error(`NOAA point HTTP ${pointRes.status}`);

    const pointJson = await pointRes.json() as { properties: { county: string } };
    const zoneUrl = pointJson.properties?.county;

    if (zoneUrl) {
      const alertUrl = `https://api.weather.gov/alerts/active?zone=${zoneUrl.split('/').pop()}`;
      const alertRes = await fetch(alertUrl, { signal: AbortSignal.timeout(5000), headers: { 'User-Agent': 'AEGIS-Command/1.0' } });
      if (alertRes.ok) {
        const alertJson = await alertRes.json() as { features: Array<{ properties: { id: string; event: string; severity: string; headline: string; description: string; areaDesc: string; onset: string; expires: string } }> };
        const alerts: NOAAAlert[] = (alertJson.features ?? []).map((f) => ({
          id: f.properties.id,
          event: f.properties.event,
          severity: f.properties.severity as NOAAAlert['severity'],
          headline: f.properties.headline,
          description: f.properties.description?.slice(0, 500) ?? '',
          areaDesc: f.properties.areaDesc,
          onset: f.properties.onset,
          expires: f.properties.expires,
        }));

        await redis.set(cacheKey, JSON.stringify(alerts), 'EX', TTL);
        logger.debug({ count: alerts.length }, 'NOAA Weather Alerts fetched');
        return { success: true, data: alerts, source: 'noaa-alerts', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
      }
    }
    throw new Error('No zone found');
  } catch (err) {
    logger.warn({ err }, 'NOAA Weather Alerts fetch failed — using simulated data');
    return { success: true, data: simulateAlerts(), source: 'noaa-alerts-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateAlerts(): NOAAAlert[] {
  if (Math.random() > 0.75) {
    return [{
      id: `SIM-ALERT-${Date.now()}`,
      event: Math.random() > 0.5 ? 'High Wind Warning' : 'Thunderstorm Warning',
      severity: Math.random() > 0.7 ? 'Severe' : 'Moderate',
      headline: 'SIMULATED: Weather advisory in effect',
      description: 'Simulated weather alert for AEGIS demo mode. Conditions may affect drone operations.',
      areaDesc: 'Demo area of operations',
      onset: new Date().toISOString(),
      expires: new Date(Date.now() + 7200000).toISOString(),
    }];
  }
  return [];
}
