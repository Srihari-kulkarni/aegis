import { logger } from '../../logger';
import { redis, redisPub } from '../../redis';
import { zuluTimestamp, DroneClass } from '@aegis/shared';
import type {
  CapabilityDescriptor,
  CapabilityEvidence,
  DronePerformanceLog,
  RefinementRecord,
} from './types';
import { v4 as uuidv4 } from 'uuid';

const CAPABILITY_KEY = 'ri:capability:descriptors';
const PERFORMANCE_LOG_KEY = 'ri:capability:perf_log';
const REFINEMENT_LOG_KEY = 'ri:capability:refinement_log';
const DEVIATION_THRESHOLD = 0.15;
const MIN_SAMPLES = 5;

const DEFAULT_CAPABILITIES: Record<DroneClass, Omit<CapabilityDescriptor, 'version' | 'updatedAt' | 'updatedBy' | 'evidence'>> = {
  [DroneClass.MICRO]: { droneClass: DroneClass.MICRO, maxWindToleranceMs: 10, operationalCeilingFt: 500, minHealthThreshold: 0.6, effectiveRangeKm: 5, sensorAccuracy: 0.85 },
  [DroneClass.RECON]: { droneClass: DroneClass.RECON, maxWindToleranceMs: 18, operationalCeilingFt: 25000, minHealthThreshold: 0.5, effectiveRangeKm: 150, sensorAccuracy: 0.92 },
  [DroneClass.OFFENSE]: { droneClass: DroneClass.OFFENSE, maxWindToleranceMs: 20, operationalCeilingFt: 35000, minHealthThreshold: 0.7, effectiveRangeKm: 200, sensorAccuracy: 0.88 },
  [DroneClass.DELIVERY]: { droneClass: DroneClass.DELIVERY, maxWindToleranceMs: 12, operationalCeilingFt: 5000, minHealthThreshold: 0.6, effectiveRangeKm: 50, sensorAccuracy: 0.80 },
  [DroneClass.EW]: { droneClass: DroneClass.EW, maxWindToleranceMs: 15, operationalCeilingFt: 30000, minHealthThreshold: 0.65, effectiveRangeKm: 100, sensorAccuracy: 0.90, jamEffectiveness: 0.75 },
  [DroneClass.RELAY]: { droneClass: DroneClass.RELAY, maxWindToleranceMs: 18, operationalCeilingFt: 40000, minHealthThreshold: 0.5, effectiveRangeKm: 300, sensorAccuracy: 0.85 },
  [DroneClass.SWARM]: { droneClass: DroneClass.SWARM, maxWindToleranceMs: 14, operationalCeilingFt: 10000, minHealthThreshold: 0.55, effectiveRangeKm: 30, sensorAccuracy: 0.78, swarmCoherenceScore: 0.85 },
  [DroneClass.CBRN]: { droneClass: DroneClass.CBRN, maxWindToleranceMs: 12, operationalCeilingFt: 5000, minHealthThreshold: 0.7, effectiveRangeKm: 25, sensorAccuracy: 0.95, plumeModelAccuracy: 0.80 },
  [DroneClass.UNDERWATER]: { droneClass: DroneClass.UNDERWATER, maxWindToleranceMs: 999, operationalCeilingFt: 0, minHealthThreshold: 0.6, effectiveRangeKm: 20, sensorAccuracy: 0.88 },
  [DroneClass.LARGE_ALTITUDE]: { droneClass: DroneClass.LARGE_ALTITUDE, maxWindToleranceMs: 25, operationalCeilingFt: 60000, minHealthThreshold: 0.5, effectiveRangeKm: 500, sensorAccuracy: 0.94 },
};

export class CapabilityAssessor {
  private descriptors = new Map<DroneClass, CapabilityDescriptor>();
  private performanceLogs: DronePerformanceLog[] = [];
  private refinementLog: RefinementRecord[] = [];
  private currentIteration = 0;

  async initialize(): Promise<void> {
    try {
      const data = await redis.get(CAPABILITY_KEY);
      if (data) {
        const parsed = JSON.parse(data) as CapabilityDescriptor[];
        for (const d of parsed) {
          this.descriptors.set(d.droneClass, d);
        }
      }

      const perfData = await redis.get(PERFORMANCE_LOG_KEY);
      if (perfData) {
        this.performanceLogs = JSON.parse(perfData) as DronePerformanceLog[];
      }

      const refData = await redis.get(REFINEMENT_LOG_KEY);
      if (refData) {
        this.refinementLog = JSON.parse(refData) as RefinementRecord[];
        this.currentIteration = this.refinementLog.length;
      }
    } catch (err) {
      logger.warn({ err }, 'CapabilityAssessor: Failed to load from Redis');
    }

    for (const [cls, defaults] of Object.entries(DEFAULT_CAPABILITIES)) {
      const droneClass = cls as DroneClass;
      if (!this.descriptors.has(droneClass)) {
        this.descriptors.set(droneClass, {
          ...defaults,
          version: 0,
          updatedAt: zuluTimestamp(),
          updatedBy: 'SYSTEM',
          evidence: [],
        });
      }
    }

    logger.info({ classes: this.descriptors.size }, 'CapabilityAssessor initialized');
  }

  async logPerformance(log: DronePerformanceLog): Promise<void> {
    this.performanceLogs.push(log);
    if (this.performanceLogs.length > 1000) {
      this.performanceLogs = this.performanceLogs.slice(-1000);
    }
    await redis.set(PERFORMANCE_LOG_KEY, JSON.stringify(this.performanceLogs));
  }

  async assessAndUpdate(droneClass: DroneClass): Promise<RefinementRecord | null> {
    const current = this.descriptors.get(droneClass);
    if (!current) return null;

    const classLogs = this.performanceLogs.filter((l) => l.droneClass === droneClass);
    if (classLogs.length < MIN_SAMPLES) {
      logger.debug({ droneClass, samples: classLogs.length }, 'Insufficient samples for capability assessment');
      return null;
    }

    const metricGroups = new Map<string, DronePerformanceLog[]>();
    for (const log of classLogs) {
      const existing = metricGroups.get(log.metric) ?? [];
      existing.push(log);
      metricGroups.set(log.metric, existing);
    }

    const updates: Array<{ metric: string; oldValue: number; newValue: number; evidence: CapabilityEvidence }> = [];

    for (const [metric, logs] of metricGroups) {
      if (logs.length < MIN_SAMPLES) continue;

      const avgDelta = logs.reduce((sum, l) => sum + l.delta, 0) / logs.length;
      const absDelta = Math.abs(avgDelta);

      if (absDelta > DEVIATION_THRESHOLD) {
        const field = this.metricToField(metric);
        if (!field) continue;

        const oldValue = (current as unknown as Record<string, number>)[field] ?? 0;
        const adjustment = avgDelta * 0.3;
        const newValue = Math.max(0, Math.min(1, oldValue + adjustment));

        const evidence: CapabilityEvidence = {
          missionId: logs[logs.length - 1].missionId,
          metric,
          predicted: oldValue,
          actual: oldValue + avgDelta,
          delta: avgDelta,
          timestamp: zuluTimestamp(),
        };

        updates.push({ metric, oldValue, newValue, evidence });
      }
    }

    if (updates.length === 0) return null;

    this.currentIteration++;
    const previousDescriptor = JSON.stringify(current);

    for (const update of updates) {
      const field = this.metricToField(update.metric);
      if (field) {
        (current as unknown as Record<string, unknown>)[field] = update.newValue;
      }
      current.evidence.push(update.evidence);
      if (current.evidence.length > 50) {
        current.evidence = current.evidence.slice(-50);
      }
    }

    current.version++;
    current.updatedAt = zuluTimestamp();
    current.updatedBy = 'AIRLLM';

    this.descriptors.set(droneClass, current);
    await this.persist();

    const record: RefinementRecord = {
      iterationId: uuidv4(),
      iteration: this.currentIteration,
      timestamp: zuluTimestamp(),
      layer: 'CAPABILITY',
      previousVersion: previousDescriptor.slice(0, 200) + '...',
      candidateVersion: JSON.stringify(current).slice(0, 200) + '...',
      accepted: true,
      reason: `Updated ${updates.length} capability metrics for ${droneClass}: ${updates.map((u) => `${u.metric} ${u.oldValue.toFixed(3)}→${u.newValue.toFixed(3)}`).join(', ')}`,
      metrics: {
        successRate: 1,
        avgIterationsToFix: 1,
        riskScoreDelta: updates.reduce((s, u) => s + Math.abs(u.newValue - u.oldValue), 0) / updates.length,
        predictionAccuracy: 1 - updates.reduce((s, u) => s + Math.abs(u.evidence.delta), 0) / updates.length,
        latencyMs: 0,
      },
    };

    this.refinementLog.push(record);
    if (this.refinementLog.length > 100) {
      this.refinementLog = this.refinementLog.slice(-100);
    }
    await redis.set(REFINEMENT_LOG_KEY, JSON.stringify(this.refinementLog));

    await redisPub.publish('ri:refinement', JSON.stringify({
      layer: 'CAPABILITY',
      droneClass,
      iteration: this.currentIteration,
      updates: updates.length,
      timestamp: zuluTimestamp(),
    }));

    logger.info({
      droneClass,
      updates: updates.length,
      iteration: this.currentIteration,
    }, 'Capability descriptors updated');

    return record;
  }

  getDescriptor(droneClass: DroneClass): CapabilityDescriptor | undefined {
    return this.descriptors.get(droneClass);
  }

  getAllDescriptors(): CapabilityDescriptor[] {
    return Array.from(this.descriptors.values());
  }

  private metricToField(metric: string): string | null {
    const mapping: Record<string, string> = {
      'wind_tolerance': 'maxWindToleranceMs',
      'sensor_accuracy': 'sensorAccuracy',
      'health_threshold': 'minHealthThreshold',
      'effective_range': 'effectiveRangeKm',
      'plume_accuracy': 'plumeModelAccuracy',
      'jam_effectiveness': 'jamEffectiveness',
      'swarm_coherence': 'swarmCoherenceScore',
    };
    return mapping[metric] ?? null;
  }

  private async persist(): Promise<void> {
    const all = Array.from(this.descriptors.values());
    await redis.set(CAPABILITY_KEY, JSON.stringify(all));
  }

  getStatus(): { active: boolean; currentVersion: number; totalIterations: number; lastImprovement: string | null; accuracy: number; pendingApproval: boolean } {
    const lastRecord = this.refinementLog[this.refinementLog.length - 1];
    return {
      active: true,
      currentVersion: this.currentIteration,
      totalIterations: this.currentIteration,
      lastImprovement: lastRecord?.timestamp ?? null,
      accuracy: lastRecord?.metrics.predictionAccuracy ?? 0.8,
      pendingApproval: false,
    };
  }

  get history(): RefinementRecord[] { return [...this.refinementLog]; }
  get perfLogs(): DronePerformanceLog[] { return [...this.performanceLogs]; }
}

export const capabilityAssessor = new CapabilityAssessor();
