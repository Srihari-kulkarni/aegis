import {
  DroneClass,
  DroneStatus,
  GeoPosition,
  AutonomyLevel,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export type ConsensusProtocol = 'RAFT' | 'PAXOS' | 'CUSTOM';

export interface SwarmDroneConfig extends DroneConfig {
  swarmId?: string;
  nodeIndex?: number;
  consensusProtocol?: ConsensusProtocol;
  autonomyLevel?: AutonomyLevel;
}

export class SwarmDrone extends DroneBase {
  swarmId: string;
  nodeIndex: number;
  consensusProtocol: ConsensusProtocol;
  cooperativeTargetingActive: boolean;
  collisionAvoidanceZones: GeoPosition[];
  autonomyLevel: AutonomyLevel;
  neighborCount: number;
  syncLatencyMs: number;

  private collisionAvoidanceRadiusM: number = 50;
  private consensusFallbackActive: boolean = false;

  constructor(cfg: SwarmDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.SWARM });
    this.swarmId = cfg.swarmId ?? '';
    this.nodeIndex = cfg.nodeIndex ?? 0;
    this.consensusProtocol = cfg.consensusProtocol ?? 'RAFT';
    this.cooperativeTargetingActive = false;
    this.collisionAvoidanceZones = [];
    this.autonomyLevel = cfg.autonomyLevel ?? AutonomyLevel.SUPERVISED;
    this.neighborCount = 0;
    this.syncLatencyMs = 0;
  }

  joinSwarm(swarmId: string, index: number): void {
    this.swarmId = swarmId;
    this.nodeIndex = index;
    this.consensusFallbackActive = false;
  }

  leaveSwarm(): void {
    this.swarmId = '';
    this.nodeIndex = -1;
    this.cooperativeTargetingActive = false;
    this.neighborCount = 0;
  }

  enableCooperativeTargeting(): void {
    this.cooperativeTargetingActive = true;
  }

  disableCooperativeTargeting(): void {
    this.cooperativeTargetingActive = false;
  }

  addCollisionAvoidanceZone(zone: GeoPosition): void {
    this.collisionAvoidanceZones.push(zone);
  }

  clearCollisionAvoidanceZones(): void {
    this.collisionAvoidanceZones = [];
  }

  updateNeighborCount(count: number): void {
    this.neighborCount = count;
  }

  updateSyncLatency(latencyMs: number): void {
    this.syncLatencyMs = latencyMs;
  }

  isSwarmLeader(): boolean {
    return this.nodeIndex === 0;
  }

  getCollisionAvoidanceRadiusM(): number {
    return this.collisionAvoidanceRadiusM;
  }

  getTypeMetrics(): TypeMetrics {
    return {
      swarmId: this.swarmId,
      nodeIndex: this.nodeIndex,
      consensusProtocol: this.consensusProtocol,
      cooperativeTargetingActive: this.cooperativeTargetingActive,
      collisionAvoidanceZoneCount: this.collisionAvoidanceZones.length,
      collisionAvoidanceRadiusM: this.collisionAvoidanceRadiusM,
      autonomyLevel: this.autonomyLevel,
      neighborCount: this.neighborCount,
      syncLatencyMs: this.syncLatencyMs,
      isSwarmLeader: this.isSwarmLeader(),
      consensusFallbackActive: this.consensusFallbackActive,
    };
  }

  getAIContextDescriptor(): string {
    return [
      `SWARM drone ${this.callsign} (${this.model})`,
      `Swarm: ${this.swarmId || 'NONE'} | Node: ${this.nodeIndex} | Leader: ${this.isSwarmLeader()}`,
      `Consensus: ${this.consensusProtocol} | Fallback: ${this.consensusFallbackActive}`,
      `Autonomy: ${this.autonomyLevel} | Neighbors: ${this.neighborCount}`,
      `Sync latency: ${this.syncLatencyMs}ms`,
      `Cooperative targeting: ${this.cooperativeTargetingActive ? 'ACTIVE' : 'OFF'}`,
      `Collision avoidance zones: ${this.collisionAvoidanceZones.length} | Radius: ${this.collisionAvoidanceRadiusM}m`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'SWARM_COORDINATION',
        available: true,
        degradedMode: 'Peer-to-peer consensus via mesh; no GCS arbitration',
      },
      {
        capability: 'COOPERATIVE_TARGETING',
        available: this.cooperativeTargetingActive,
        degradedMode: 'Last-known target tracks shared via mesh consensus; no new designations from GCS',
      },
      {
        capability: 'COLLISION_AVOIDANCE',
        available: true,
        degradedMode: 'Expanded collision avoidance radius; autonomous deconfliction with neighbors',
      },
      {
        capability: 'FORMATION_CONTROL',
        available: true,
        degradedMode: 'Maintains last-commanded formation using consensus protocol',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS dead-reckoning with swarm-shared position corrections',
      },
      {
        capability: 'MISSION_EXECUTION',
        available: this.autonomyLevel !== AutonomyLevel.MANUAL,
        degradedMode: 'Continues pre-loaded mission plan via swarm consensus; MANUAL autonomy halts',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.consensusFallbackActive = true;
    this.collisionAvoidanceRadiusM = Math.max(this.collisionAvoidanceRadiusM * 2, 100);

    if (this.autonomyLevel === AutonomyLevel.MANUAL) {
      this.autonomyLevel = AutonomyLevel.SUPERVISED;
    }
  }
}

export default SwarmDrone;
