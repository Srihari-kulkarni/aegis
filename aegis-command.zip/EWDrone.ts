import {
  DroneClass,
  DroneStatus,
  JamBand,
} from '@aegis/shared';

import {
  DroneBase,
  DroneConfig,
  TypeMetrics,
  DegradedCapability,
} from './DroneBase';

export interface DeconflictionZone {
  centerLat: number;
  centerLon: number;
  radiusKm: number;
  restrictedBands: JamBand[];
}

export interface EWDroneConfig extends DroneConfig {
  eirpWatts?: number;
  deconflictionZones?: DeconflictionZone[];
}

export class EWDrone extends DroneBase {
  jammingActive: boolean;
  activeBands: JamBand[];
  drfmSpoofing: boolean;
  eirpWatts: number;
  targetsInRange: number;

  private deconflictionZones: DeconflictionZone[];
  private sweepRunning: boolean = false;
  private sweepBandQueue: JamBand[] = [];

  constructor(cfg: EWDroneConfig) {
    super({ ...cfg, droneClass: DroneClass.EW });
    this.jammingActive = false;
    this.activeBands = [];
    this.drfmSpoofing = false;
    this.eirpWatts = cfg.eirpWatts ?? 500;
    this.targetsInRange = 0;
    this.deconflictionZones = cfg.deconflictionZones ?? [];
  }

  startJamming(bands: JamBand[]): { success: boolean; reason: string; activatedBands: JamBand[] } {
    const restricted = this.getRestrictedBandsAtCurrentPosition();
    const allowed = bands.filter((b) => !restricted.includes(b));
    const blocked = bands.filter((b) => restricted.includes(b));

    if (allowed.length === 0) {
      return {
        success: false,
        reason: `All requested bands [${bands.join(', ')}] are restricted in current deconfliction zone`,
        activatedBands: [],
      };
    }

    for (const band of allowed) {
      if (!this.activeBands.includes(band)) {
        this.activeBands.push(band);
      }
    }
    this.jammingActive = this.activeBands.length > 0;

    const reason = blocked.length > 0
      ? `Activated [${allowed.join(', ')}]; blocked by deconfliction: [${blocked.join(', ')}]`
      : `Jamming active on [${allowed.join(', ')}]`;

    return { success: true, reason, activatedBands: [...allowed] };
  }

  stopJamming(bands?: JamBand[]): void {
    if (!bands) {
      this.activeBands = [];
      this.jammingActive = false;
      return;
    }
    this.activeBands = this.activeBands.filter((b) => !bands.includes(b));
    this.jammingActive = this.activeBands.length > 0;
  }

  enableDRFM(): void {
    this.drfmSpoofing = true;
  }

  disableDRFM(): void {
    this.drfmSpoofing = false;
  }

  startFrequencySweep(bands: JamBand[], dwellMs: number): { started: boolean; reason: string } {
    if (this.sweepRunning) {
      return { started: false, reason: 'Frequency sweep already in progress' };
    }
    if (bands.length === 0) {
      return { started: false, reason: 'No bands specified for sweep' };
    }
    if (dwellMs < 50) {
      return { started: false, reason: 'Dwell time must be >= 50ms' };
    }
    this.sweepRunning = true;
    this.sweepBandQueue = [...bands];
    return { started: true, reason: `Sweep started across [${bands.join(', ')}] with ${dwellMs}ms dwell` };
  }

  stopFrequencySweep(): void {
    this.sweepRunning = false;
    this.sweepBandQueue = [];
  }

  addDeconflictionZone(zone: DeconflictionZone): void {
    this.deconflictionZones.push(zone);
    const restricted = this.getRestrictedBandsAtCurrentPosition();
    this.activeBands = this.activeBands.filter((b) => !restricted.includes(b));
    this.jammingActive = this.activeBands.length > 0;
  }

  removeDeconflictionZone(centerLat: number, centerLon: number): boolean {
    const before = this.deconflictionZones.length;
    this.deconflictionZones = this.deconflictionZones.filter(
      (z) => z.centerLat !== centerLat || z.centerLon !== centerLon,
    );
    return this.deconflictionZones.length < before;
  }

  updateTargetsInRange(count: number): void {
    this.targetsInRange = count;
  }

  private getRestrictedBandsAtCurrentPosition(): JamBand[] {
    const restricted: Set<JamBand> = new Set();
    for (const zone of this.deconflictionZones) {
      const distKm = this.haversineKm(
        this.position.lat, this.position.lon,
        zone.centerLat, zone.centerLon,
      );
      if (distKm <= zone.radiusKm) {
        for (const band of zone.restrictedBands) {
          restricted.add(band);
        }
      }
    }
    return Array.from(restricted);
  }

  private haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  getTypeMetrics(): TypeMetrics {
    return {
      jammingActive: this.jammingActive,
      activeBands: [...this.activeBands],
      drfmSpoofing: this.drfmSpoofing,
      eirpWatts: this.eirpWatts,
      targetsInRange: this.targetsInRange,
      sweepRunning: this.sweepRunning,
      sweepBandQueue: [...this.sweepBandQueue],
      deconflictionZoneCount: this.deconflictionZones.length,
      restrictedBandsHere: this.getRestrictedBandsAtCurrentPosition(),
    };
  }

  getAIContextDescriptor(): string {
    const bandsStr = this.activeBands.length > 0 ? this.activeBands.join(', ') : 'NONE';
    return [
      `EW drone ${this.callsign} (${this.model})`,
      `Jamming: ${this.jammingActive ? 'ACTIVE' : 'INACTIVE'} | Bands: [${bandsStr}]`,
      `DRFM: ${this.drfmSpoofing ? 'ON' : 'OFF'} | EIRP: ${this.eirpWatts}W`,
      `Targets in range: ${this.targetsInRange}`,
      `Sweep: ${this.sweepRunning ? 'RUNNING' : 'IDLE'}`,
      `Deconfliction zones: ${this.deconflictionZones.length}`,
      `Position: ${this.position.lat.toFixed(6)},${this.position.lon.toFixed(6)} @ ${this.altitude}ft`,
      `Link quality: ${(this.linkQuality * 100).toFixed(0)}% | Battery: ${this.batteryPercent}%`,
      `Status: ${this.status}`,
    ].join(' | ');
  }

  getDegradedModeCapabilities(): DegradedCapability[] {
    return [
      {
        capability: 'ACTIVE_JAMMING',
        available: true,
        degradedMode: 'Continues jamming on last-commanded bands; no remote band changes',
      },
      {
        capability: 'DRFM_SPOOFING',
        available: this.drfmSpoofing,
        degradedMode: 'DRFM replay continues on cached threat profiles; no profile updates',
      },
      {
        capability: 'FREQUENCY_SWEEP',
        available: this.sweepRunning,
        degradedMode: 'Sweep continues on queued bands; results stored onboard',
      },
      {
        capability: 'DECONFLICTION_UPDATES',
        available: false,
        degradedMode: 'Uses last-known deconfliction zones; no live updates',
      },
      {
        capability: 'NAVIGATION',
        available: true,
        degradedMode: 'INS-based orbit on last assigned station; autonomous RTB on timer',
      },
      {
        capability: 'TARGET_TRACKING',
        available: false,
        degradedMode: 'No updated target count; maintains posture on last known threat data',
      },
    ];
  }

  handleLinkLoss(): void {
    this.status = DroneStatus.LOST_LINK;
    this.stopFrequencySweep();
  }
}

export default EWDrone;
