import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';
import { query, withTransaction } from '../db/pool';
import { redis } from '../redis';
import { authMiddleware, rbacGuard } from '../auth/middleware';
import { hcsService } from '../hedera/HCSService';
import { htsDroneRegistry } from '../hedera/HTSDroneRegistry';
import { logger } from '../logger';
import {
  ActionType,
  DroneClass,
  DroneStatus,
  OperatorRole,
  zuluTimestamp,
  CRITICAL_COMMANDS,
  type Drone,
  type Telemetry,
} from '@aegis/shared';
import { commandValidator } from '../ai/command-validator';

const router = Router();

// ---------------------------------------------------------------------------
// Zod schemas
// ---------------------------------------------------------------------------

const droneListQuerySchema = z.object({
  class: z.nativeEnum(DroneClass).optional(),
  status: z.nativeEnum(DroneStatus).optional(),
});

const droneCommandSchema = z.object({
  command: z.enum([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'ARM', 'DISARM', 'ACTIVATE_SENSOR', 'DEACTIVATE_SENSOR',
    'JAM_START', 'JAM_STOP', 'PAYLOAD_DROP', 'SWARM_JOIN', 'SWARM_LEAVE',
  ]),
  parameters: z.record(z.unknown()).optional(),
  mfaCode: z.string().length(6).optional(),
});

const geoPositionSchema = z.object({
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  alt: z.number(),
  mgrs: z.string().optional(),
});

const registerDroneSchema = z.object({
  callsign: z.string().min(1).max(50).regex(/^[A-Z0-9-]+$/, 'Callsign must be uppercase alphanumeric with dashes'),
  droneClass: z.nativeEnum(DroneClass),
  model: z.string().min(1).max(100),
  manufacturer: z.string().min(1).max(100),
  serialNumber: z.string().min(1).max(100),
  position: geoPositionSchema.optional(),
  typeMetrics: z.record(z.unknown()).optional(),
});

// ---------------------------------------------------------------------------
// Command-class constraint matrix: which commands each drone class may accept
// ---------------------------------------------------------------------------

const CLASS_COMMAND_RESTRICTIONS: Partial<Record<DroneClass, Set<string>>> = {
  [DroneClass.EW]: new Set([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'JAM_START', 'JAM_STOP', 'ACTIVATE_SENSOR', 'DEACTIVATE_SENSOR',
  ]),
  [DroneClass.OFFENSE]: new Set([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'ARM', 'DISARM', 'ACTIVATE_SENSOR', 'DEACTIVATE_SENSOR',
    'PAYLOAD_DROP',
  ]),
  [DroneClass.SWARM]: new Set([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'SWARM_JOIN', 'SWARM_LEAVE',
  ]),
  [DroneClass.DELIVERY]: new Set([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'PAYLOAD_DROP',
  ]),
  [DroneClass.UNDERWATER]: new Set([
    'LAUNCH', 'LAND', 'RTB', 'HOLD_POSITION', 'GOTO_WAYPOINT',
    'EMERGENCY_STOP', 'ACTIVATE_SENSOR', 'DEACTIVATE_SENSOR',
  ]),
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function apiResponse<T>(data: T, success = true) {
  return { success, data, timestamp: new Date().toISOString() };
}

function apiError(error: string, status: number, res: Response): void {
  res.status(status).json({ success: false, error, timestamp: new Date().toISOString() });
}

function dbRowToDrone(row: Record<string, unknown>): Drone {
  return {
    droneId: row.drone_id as string,
    callsign: row.callsign as string,
    droneClass: row.drone_class as DroneClass,
    model: row.model as string,
    manufacturer: row.manufacturer as string,
    serialNumber: row.serial_number as string,
    status: row.status as DroneStatus,
    health: parseFloat(String(row.health ?? 1)),
    batteryPercent: parseFloat(String(row.battery_percent ?? 100)),
    fuelPercent: parseFloat(String(row.fuel_percent ?? 100)),
    position: {
      lat: parseFloat(String(row.position_lat ?? 0)),
      lon: parseFloat(String(row.position_lon ?? 0)),
      alt: parseFloat(String(row.position_alt ?? 0)),
    },
    heading: parseFloat(String(row.heading ?? 0)),
    speedKnots: parseFloat(String(row.speed_knots ?? 0)),
    altitude: parseFloat(String(row.altitude ?? 0)),
    linkQuality: parseFloat(String(row.link_quality ?? 1)),
    currentMissionId: (row.current_mission_id as string) ?? null,
    htsTokenId: (row.hts_token_id as string) ?? null,
    htsSerialNumber: row.hts_serial != null ? parseInt(String(row.hts_serial), 10) : null,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
    typeMetrics: (row.type_metrics as Record<string, unknown>) ?? {},
  };
}

function mergeLiveData(drone: Drone, live: Record<string, string>): Drone {
  return {
    ...drone,
    status: (live.status as DroneStatus) || drone.status,
    health: live.health ? parseFloat(live.health) : drone.health,
    batteryPercent: live.batteryPercent ? parseFloat(live.batteryPercent) : drone.batteryPercent,
    fuelPercent: live.fuelPercent ? parseFloat(live.fuelPercent) : drone.fuelPercent,
    position: {
      lat: live.lat ? parseFloat(live.lat) : drone.position.lat,
      lon: live.lon ? parseFloat(live.lon) : drone.position.lon,
      alt: live.alt ? parseFloat(live.alt) : drone.position.alt,
    },
    heading: live.heading ? parseFloat(live.heading) : drone.heading,
    speedKnots: live.speedKnots ? parseFloat(live.speedKnots) : drone.speedKnots,
    linkQuality: live.linkQuality ? parseFloat(live.linkQuality) : drone.linkQuality,
  };
}

// ---------------------------------------------------------------------------
// GET /api/v1/drones — fleet list merging live Redis data with DB data
// ---------------------------------------------------------------------------

router.get(
  '/',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = droneListQuerySchema.safeParse(req.query);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Invalid query parameters',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { class: droneClass, status } = parsed.data;
      const conditions: string[] = [];
      const params: unknown[] = [];
      let paramIdx = 1;

      if (droneClass) {
        conditions.push(`drone_class = $${paramIdx++}`);
        params.push(droneClass);
      }
      if (status) {
        conditions.push(`status = $${paramIdx++}`);
        params.push(status);
      }

      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      const dbResult = await query(
        `SELECT * FROM drones ${whereClause} ORDER BY callsign ASC`,
        params,
      );

      const drones: Drone[] = [];

      if (dbResult.rows.length > 0) {
        for (const row of dbResult.rows) {
          const drone = dbRowToDrone(row as Record<string, unknown>);
          const liveData = await redis.hgetall(`drone:live:${drone.droneId}`);
          if (liveData && Object.keys(liveData).length > 0) {
            drones.push(mergeLiveData(drone, liveData));
          } else {
            drones.push(drone);
          }
        }
      } else {
        const liveKeys = await redis.keys('drone:live:*');
        for (const key of liveKeys) {
          const liveData = await redis.hgetall(key);
          if (liveData && liveData.droneId) {
            drones.push({
              droneId: liveData.droneId,
              callsign: liveData.callsign ?? 'UNKNOWN',
              droneClass: (liveData.droneClass as DroneClass) ?? DroneClass.RECON,
              model: liveData.model ?? 'Demo',
              manufacturer: 'Demo',
              serialNumber: liveData.droneId,
              status: (liveData.status as DroneStatus) ?? DroneStatus.AIRBORNE,
              health: parseFloat(liveData.health ?? '1'),
              batteryPercent: parseFloat(liveData.batteryPercent ?? '100'),
              fuelPercent: parseFloat(liveData.fuelPercent ?? '100'),
              position: {
                lat: parseFloat(liveData.lat ?? '0'),
                lon: parseFloat(liveData.lon ?? '0'),
                alt: parseFloat(liveData.alt ?? '0'),
              },
              heading: parseFloat(liveData.heading ?? '0'),
              speedKnots: parseFloat(liveData.speedKnots ?? '0'),
              altitude: parseFloat(liveData.altitude ?? '0'),
              linkQuality: parseFloat(liveData.linkQuality ?? '1'),
              currentMissionId: liveData.currentMissionId || null,
              htsTokenId: null,
              htsSerialNumber: null,
              createdAt: new Date().toISOString(),
              updatedAt: liveData.updatedAt ?? new Date().toISOString(),
              typeMetrics: liveData.typeMetrics ? JSON.parse(liveData.typeMetrics) as Record<string, unknown> : {},
            });
          }
        }
      }

      let filtered = drones;
      if (status) filtered = filtered.filter((d) => d.status === status);
      if (droneClass) filtered = filtered.filter((d) => d.droneClass === droneClass);

      res.json(apiResponse({ drones: filtered, total: filtered.length }));
    } catch (err) {
      logger.error({ err }, 'List drones error');
      apiError('Failed to list drones', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// GET /api/v1/drones/:id — full drone detail + recent telemetry
// ---------------------------------------------------------------------------

router.get(
  '/:id',
  authMiddleware(),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;

      const dbResult = await query('SELECT * FROM drones WHERE drone_id = $1', [id]);
      if (!dbResult.rows.length) {
        const liveData = await redis.hgetall(`drone:live:${id}`);
        if (liveData && liveData.droneId) {
          res.json(apiResponse({
            drone: {
              droneId: liveData.droneId,
              callsign: liveData.callsign ?? 'UNKNOWN',
              droneClass: liveData.droneClass ?? 'RECON',
              model: liveData.model ?? 'Demo',
              manufacturer: 'Demo',
              status: liveData.status ?? 'AIRBORNE',
              health: parseFloat(liveData.health ?? '1'),
              batteryPercent: parseFloat(liveData.batteryPercent ?? '100'),
              fuelPercent: parseFloat(liveData.fuelPercent ?? '100'),
              position: { lat: parseFloat(liveData.lat ?? '0'), lon: parseFloat(liveData.lon ?? '0'), alt: parseFloat(liveData.alt ?? '0') },
              heading: parseFloat(liveData.heading ?? '0'),
              speedKnots: parseFloat(liveData.speedKnots ?? '0'),
              linkQuality: parseFloat(liveData.linkQuality ?? '1'),
              typeMetrics: liveData.typeMetrics ? JSON.parse(liveData.typeMetrics) : {},
            },
            telemetry: [],
          }));
          return;
        }
        apiError('Drone not found', 404, res);
        return;
      }

      let drone = dbRowToDrone(dbResult.rows[0] as Record<string, unknown>);

      const liveData = await redis.hgetall(`drone:live:${id}`);
      if (liveData && Object.keys(liveData).length > 0) {
        drone = mergeLiveData(drone, liveData);
      }

      let recentTelemetry: Telemetry[] = [];
      try {
        const telResult = await query<Record<string, unknown>>(
          `SELECT time, drone_id, position_lat, position_lon, position_alt,
                  heading, speed_knots, altitude, battery_percent, fuel_percent,
                  health, link_quality, satellite_count, ambient_temp_c,
                  wind_speed_ms, wind_direction, vibration_level,
                  cpu_temp_c, memory_usage_percent, class_specific
           FROM telemetry
           WHERE drone_id = $1
           ORDER BY time DESC
           LIMIT 50`,
          [id],
        );

        recentTelemetry = telResult.rows.map((r) => ({
          time: r.time as string,
          droneId: r.drone_id as string,
          position: {
            lat: parseFloat(String(r.position_lat)),
            lon: parseFloat(String(r.position_lon)),
            alt: parseFloat(String(r.position_alt)),
          },
          heading: parseFloat(String(r.heading)),
          speedKnots: parseFloat(String(r.speed_knots)),
          altitude: parseFloat(String(r.altitude)),
          batteryPercent: parseFloat(String(r.battery_percent)),
          fuelPercent: parseFloat(String(r.fuel_percent)),
          health: parseFloat(String(r.health)),
          linkQuality: parseFloat(String(r.link_quality)),
          satelliteCount: parseInt(String(r.satellite_count), 10),
          ambientTempC: parseFloat(String(r.ambient_temp_c)),
          windSpeedMs: parseFloat(String(r.wind_speed_ms)),
          windDirection: parseFloat(String(r.wind_direction)),
          vibrationLevel: parseFloat(String(r.vibration_level)),
          cpuTempC: parseFloat(String(r.cpu_temp_c)),
          memoryUsagePercent: parseFloat(String(r.memory_usage_percent)),
          classSpecific: (r.class_specific as Record<string, unknown>) ?? {},
        }));
      } catch (telErr) {
        logger.warn({ err: telErr, droneId: id }, 'Telemetry query failed — table may not exist yet');
      }

      res.json(apiResponse({ drone, recentTelemetry }));
    } catch (err) {
      logger.error({ err }, 'Get drone detail error');
      apiError('Failed to retrieve drone', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /api/v1/drones/:id/command — issue command to drone
// ---------------------------------------------------------------------------

router.post(
  '/:id/command',
  authMiddleware(),
  rbacGuard('drone:command'),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const { id } = req.params;
      const operator = req.operator!;

      const parsed = droneCommandSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Invalid command payload',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { command, parameters } = parsed.data;

      if (CRITICAL_COMMANDS.has(command)) {
        const sessionKey = `session:${operator.sub}:${operator.sessionId}`;
        const mfaVerified = await redis.hget(sessionKey, 'mfa_verified_at');

        if (!mfaVerified) {
          apiError('MFA verification required for critical command', 403, res);
          return;
        }

        const verifiedAt = new Date(mfaVerified).getTime();
        if (verifiedAt < Date.now() - 5 * 60 * 1000) {
          apiError('MFA re-verification required — verification expired', 403, res);
          return;
        }
      }

      const rateKey = `rate:cmd:${operator.sub}`;
      const cmdCount = await redis.incr(rateKey);
      if (cmdCount === 1) {
        await redis.expire(rateKey, 60);
      }
      if (cmdCount > 30) {
        apiError('Command rate limit exceeded (30/min)', 429, res);
        return;
      }

      const dbResult = await query<Record<string, unknown>>(
        'SELECT * FROM drones WHERE drone_id = $1',
        [id],
      );
      if (dbResult.rowCount === 0) {
        apiError('Drone not found', 404, res);
        return;
      }

      const drone = dbRowToDrone(dbResult.rows[0]);
      const droneClass = drone.droneClass;

      const allowed = CLASS_COMMAND_RESTRICTIONS[droneClass];
      if (allowed && !allowed.has(command)) {
        apiError(
          `Command '${command}' is not permitted for drone class '${droneClass}'`,
          400,
          res,
        );
        return;
      }

      if (drone.status === DroneStatus.DESTROYED || drone.status === DroneStatus.DECOMMISSIONED) {
        apiError(`Drone ${drone.callsign} is ${drone.status} — cannot accept commands`, 409, res);
        return;
      }

      if (drone.status === DroneStatus.LOST_LINK && command !== 'EMERGENCY_STOP') {
        apiError(`Drone ${drone.callsign} has LOST_LINK — only EMERGENCY_STOP accepted`, 409, res);
        return;
      }

      if (command === 'LAUNCH') {
        if (drone.status !== DroneStatus.STANDBY && drone.status !== DroneStatus.PREFLIGHT) {
          apiError(`Cannot launch: drone is ${drone.status}`, 409, res);
          return;
        }
        if (drone.health < 0.3) {
          apiError('Health too low for launch', 409, res);
          return;
        }
        if (drone.batteryPercent < 10) {
          apiError('Battery too low for launch', 409, res);
          return;
        }
      }

      if (command === 'LAND') {
        const landable = [DroneStatus.AIRBORNE, DroneStatus.ON_MISSION, DroneStatus.RETURNING];
        if (!landable.includes(drone.status)) {
          apiError(`Cannot land: drone is ${drone.status}`, 409, res);
          return;
        }
      }

      const validation = await commandValidator.validate(
        command, id, droneClass, operator.sub, drone.currentMissionId, parameters,
      );

      if (!validation.approved) {
        logger.warn({
          droneId: id, command, reason: validation.reasoning, validatedBy: validation.validatedBy,
        }, 'Command rejected by AirLLM validator');
        res.status(403).json({
          success: false,
          error: 'Command rejected by AI validator',
          validation: {
            approved: false,
            reasoning: validation.reasoning,
            validatedBy: validation.validatedBy,
            riskLevel: validation.riskLevel,
            latencyMs: validation.latencyMs,
          },
          timestamp: new Date().toISOString(),
        });
        return;
      }

      let topicId: string | null = null;
      if (drone.currentMissionId) {
        const cached = await redis.get(`hcs:topic:${drone.currentMissionId}`);
        if (cached) {
          topicId = cached;
        } else {
          const mResult = await query<{ hcs_topic_id: string | null }>(
            'SELECT hcs_topic_id FROM missions WHERE mission_id = $1',
            [drone.currentMissionId],
          );
          topicId = mResult.rows[0]?.hcs_topic_id ?? null;
        }
      }

      if (!topicId) {
        topicId = await hcsService.createMissionTopic(`cmd-${id}-${Date.now()}`, operator.sub);
      }

      const hcsRecord = await hcsService.submitAction({
        topicId,
        droneId: id,
        actionType: ActionType.DRONE_COMMAND,
        operatorId: operator.sub,
        missionId: drone.currentMissionId ?? `ad-hoc-${id}`,
        payload: { command, parameters: parameters ?? {}, issuedBy: operator.callsign },
      });

      const statusTransitions: Partial<Record<string, DroneStatus>> = {
        LAUNCH: DroneStatus.AIRBORNE,
        LAND: DroneStatus.LANDED,
        RTB: DroneStatus.RETURNING,
        EMERGENCY_STOP: DroneStatus.EMERGENCY,
      };

      const newStatus = statusTransitions[command];
      if (newStatus) {
        await query('UPDATE drones SET status = $1, updated_at = NOW() WHERE drone_id = $2', [newStatus, id]);
        await redis.hset(`drone:live:${id}`, { status: newStatus });
      }

      logger.info(
        { droneId: id, command, operatorId: operator.sub, callsign: drone.callsign },
        'Drone command issued',
      );

      res.json(apiResponse({
        droneId: id,
        callsign: drone.callsign,
        command,
        newStatus: newStatus ?? drone.status,
        hcsRecord,
        validation: {
          approved: true,
          validatedBy: validation.validatedBy,
          riskLevel: validation.riskLevel,
          latencyMs: validation.latencyMs,
        },
      }));
    } catch (err) {
      logger.error({ err }, 'Drone command error');
      apiError('Failed to issue drone command', 500, res);
    }
  },
);

// ---------------------------------------------------------------------------
// POST /api/v1/drones — register new drone + mint HTS NFT
// ---------------------------------------------------------------------------

router.post(
  '/',
  authMiddleware(OperatorRole.SUPER_ADMIN),
  rbacGuard('drone:register'),
  async (req: Request, res: Response): Promise<void> => {
    try {
      const parsed = registerDroneSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: parsed.error.flatten(),
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const operator = req.operator!;
      const body = parsed.data;
      const droneId = uuidv4();

      const duplicate = await query<{ drone_id: string }>(
        'SELECT drone_id FROM drones WHERE callsign = $1 OR serial_number = $2',
        [body.callsign, body.serialNumber],
      );
      if (duplicate.rowCount! > 0) {
        apiError('Drone with this callsign or serial number already exists', 409, res);
        return;
      }

      const position = body.position ?? { lat: 0, lon: 0, alt: 0 };

      const insertResult = await withTransaction(async (client) => {
        const result = await client.query(
          `INSERT INTO drones
           (drone_id, callsign, drone_class, model, manufacturer, serial_number,
            position_lat, position_lon, position_alt, type_metrics, status)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
           RETURNING *`,
          [
            droneId,
            body.callsign,
            body.droneClass,
            body.model,
            body.manufacturer,
            body.serialNumber,
            position.lat,
            position.lon,
            position.alt,
            JSON.stringify(body.typeMetrics ?? {}),
            DroneStatus.STANDBY,
          ],
        );
        return result.rows[0];
      });

      let nftResult: { tokenId: string; serialNumber: number } | null = null;
      try {
        const mintableDrone = {
          droneId,
          callsign: body.callsign,
          droneClass: body.droneClass,
          model: body.model,
          manufacturer: body.manufacturer,
          serialNumber: body.serialNumber,
          htsTokenId: null as string | null,
          htsSerialNumber: null as number | null,
          getTypeMetrics: () => body.typeMetrics ?? {},
        };

        nftResult = await htsDroneRegistry.mintDroneNFT(mintableDrone as any);
      } catch (nftErr) {
        logger.error({ err: nftErr, droneId }, 'HTS NFT mint failed — drone registered without NFT');
      }

      await redis.hset(`drone:live:${droneId}`, {
        droneId,
        callsign: body.callsign,
        droneClass: body.droneClass,
        model: body.model,
        status: DroneStatus.STANDBY,
        health: '1',
        batteryPercent: '100',
        fuelPercent: '100',
        lat: String(position.lat),
        lon: String(position.lon),
        alt: String(position.alt),
        heading: '0',
        speedKnots: '0',
        linkQuality: '1',
        updatedAt: zuluTimestamp(),
      });
      await redis.expire(`drone:live:${droneId}`, 300);

      logger.info(
        { droneId, callsign: body.callsign, droneClass: body.droneClass, registeredBy: operator.callsign },
        'New drone registered',
      );

      const drone = dbRowToDrone(insertResult as Record<string, unknown>);

      res.status(201).json(apiResponse({
        drone,
        nft: nftResult,
      }));
    } catch (err) {
      logger.error({ err }, 'Register drone error');
      apiError('Failed to register drone', 500, res);
    }
  },
);

export { router as droneRouter };
