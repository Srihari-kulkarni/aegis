import { logger } from '../../logger';
import { redis, redisPub } from '../../redis';
import { zuluTimestamp } from '@aegis/shared';
import type { SafetyEvent, RefinementRecord } from './types';
import { v4 as uuidv4 } from 'uuid';

const SAFETY_LOG_KEY = 'ri:safety:events';
const ROLLBACK_KEY = 'ri:safety:rollbacks';

const PROTECTED_MODULES = new Set([
  'safety-monitor',
  'regression-guard',
  'auth/middleware',
  'auth/routes',
]);

const MAX_REFINEMENTS_PER_HOUR = 20;
const MAX_FAILED_REFINEMENTS_CONSECUTIVE = 5;

export class SafetyMonitor {
  private events: SafetyEvent[] = [];
  private rollbackCount = 0;
  private containmentIntact = true;
  private goalInvariant = true;
  private refinementTimestamps: number[] = [];
  private consecutiveFailures = 0;

  async initialize(): Promise<void> {
    try {
      const data = await redis.get(SAFETY_LOG_KEY);
      if (data) {
        this.events = JSON.parse(data) as SafetyEvent[];
      }
      const rbData = await redis.get(ROLLBACK_KEY);
      if (rbData) {
        this.rollbackCount = parseInt(rbData, 10) || 0;
      }
    } catch (err) {
      logger.warn({ err }, 'SafetyMonitor initialization failed');
    }
    logger.info({ events: this.events.length, rollbacks: this.rollbackCount }, 'SafetyMonitor initialized');
  }

  checkContainment(layer: string, targetModules: string[]): boolean {
    for (const mod of targetModules) {
      if (PROTECTED_MODULES.has(mod)) {
        const event = this.createEvent(
          'CONTAINMENT_BREACH',
          layer as SafetyEvent['layer'],
          'CRITICAL',
          `Attempted modification of protected module: ${mod}. RI system cannot modify safety infrastructure.`,
        );
        this.recordEvent(event);
        this.containmentIntact = false;
        return false;
      }
    }
    return true;
  }

  checkRateLimit(): boolean {
    const now = Date.now();
    const oneHourAgo = now - 3600000;
    this.refinementTimestamps = this.refinementTimestamps.filter((t) => t > oneHourAgo);

    if (this.refinementTimestamps.length >= MAX_REFINEMENTS_PER_HOUR) {
      const event = this.createEvent(
        'CONTAINMENT_BREACH',
        'SAFETY',
        'WARNING',
        `Rate limit exceeded: ${this.refinementTimestamps.length} refinements in the last hour (limit: ${MAX_REFINEMENTS_PER_HOUR})`,
      );
      this.recordEvent(event);
      return false;
    }

    this.refinementTimestamps.push(now);
    return true;
  }

  verifyGoalInvariance(
    originalObjective: (context: Record<string, unknown>) => number,
    candidateObjective: (context: Record<string, unknown>) => number,
    testInputs: Record<string, unknown>[],
  ): boolean {
    for (const input of testInputs) {
      const originalResult = originalObjective(input);
      const candidateResult = candidateObjective(input);
      const delta = Math.abs(originalResult - candidateResult);

      if (delta > 0.01) {
        const event = this.createEvent(
          'GOAL_DRIFT',
          'SAFETY',
          'CRITICAL',
          `Goal invariance violation: objective function diverged by ${(delta * 100).toFixed(2)}% on test input. Original: ${originalResult.toFixed(4)}, Candidate: ${candidateResult.toFixed(4)}`,
        );
        this.recordEvent(event);
        this.goalInvariant = false;
        return false;
      }
    }
    return true;
  }

  recordRefinementOutcome(record: RefinementRecord): void {
    if (!record.accepted) {
      this.consecutiveFailures++;
      if (this.consecutiveFailures >= MAX_FAILED_REFINEMENTS_CONSECUTIVE) {
        const event = this.createEvent(
          'TREACHEROUS_TURN_DETECTED',
          record.layer as SafetyEvent['layer'],
          'EMERGENCY',
          `${this.consecutiveFailures} consecutive refinement failures detected. Possible optimization instability or adversarial drift in layer ${record.layer}.`,
        );
        this.recordEvent(event);
      }
    } else {
      this.consecutiveFailures = 0;
    }
  }

  async triggerRollback(layer: string, reason: string): Promise<void> {
    this.rollbackCount++;
    await redis.set(ROLLBACK_KEY, this.rollbackCount.toString());

    const event = this.createEvent(
      'ROLLBACK_TRIGGERED',
      layer as SafetyEvent['layer'],
      'WARNING',
      `Rollback triggered for layer ${layer}: ${reason}`,
    );
    this.recordEvent(event);

    await redisPub.publish('ri:safety', JSON.stringify({
      type: 'ROLLBACK',
      layer,
      reason,
      rollbackCount: this.rollbackCount,
      timestamp: zuluTimestamp(),
    }));

    logger.warn({ layer, reason, rollbackCount: this.rollbackCount }, 'RI rollback triggered');
  }

  requiresHumanApproval(layer: string, record: RefinementRecord): boolean {
    if (layer === 'CAPABILITY') return true;
    if (layer === 'ROUTING') return true;
    if (layer === 'PROMPT' && !record.accepted) return true;
    return false;
  }

  async approveRefinement(eventId: string, approvedBy: string): Promise<boolean> {
    const event = this.events.find((e) => e.eventId === eventId);
    if (event && event.type === 'HUMAN_GATE_REQUIRED') {
      event.resolved = true;
      event.resolvedBy = approvedBy;
      await this.persist();
      return true;
    }
    return false;
  }

  checkShadowMode(
    productionOutput: { recommendation: string; riskScore: number },
    shadowOutput: { recommendation: string; riskScore: number },
    tolerance = 0.2,
  ): boolean {
    if (productionOutput.recommendation !== shadowOutput.recommendation) {
      const event = this.createEvent(
        'TREACHEROUS_TURN_DETECTED',
        'SAFETY',
        'CRITICAL',
        `Shadow mode divergence: production=${productionOutput.recommendation} vs shadow=${shadowOutput.recommendation}. Risk delta: ${Math.abs(productionOutput.riskScore - shadowOutput.riskScore).toFixed(3)}`,
      );
      this.recordEvent(event);
      return false;
    }

    const riskDelta = Math.abs(productionOutput.riskScore - shadowOutput.riskScore);
    if (riskDelta > tolerance) {
      const event = this.createEvent(
        'GOAL_DRIFT',
        'SAFETY',
        'WARNING',
        `Shadow mode risk score divergence: ${riskDelta.toFixed(3)} exceeds tolerance ${tolerance}`,
      );
      this.recordEvent(event);
      return false;
    }

    return true;
  }

  private createEvent(
    type: SafetyEvent['type'],
    layer: SafetyEvent['layer'],
    severity: SafetyEvent['severity'],
    description: string,
  ): SafetyEvent {
    return {
      eventId: uuidv4(),
      type,
      layer,
      severity,
      description,
      timestamp: zuluTimestamp(),
      resolved: false,
    };
  }

  private recordEvent(event: SafetyEvent): void {
    this.events.push(event);
    if (this.events.length > 500) {
      this.events = this.events.slice(-500);
    }

    logger[event.severity === 'EMERGENCY' ? 'error' : event.severity === 'CRITICAL' ? 'warn' : 'info'](
      { eventId: event.eventId, type: event.type, layer: event.layer },
      `Safety event: ${event.description}`,
    );

    redisPub.publish('ri:safety', JSON.stringify(event)).catch(() => {});
    this.persist().catch(() => {});
  }

  private async persist(): Promise<void> {
    await redis.set(SAFETY_LOG_KEY, JSON.stringify(this.events));
  }

  get isContainmentIntact(): boolean { return this.containmentIntact; }
  get isGoalInvariant(): boolean { return this.goalInvariant; }
  get pendingHumanGates(): number { return this.events.filter((e) => e.type === 'HUMAN_GATE_REQUIRED' && !e.resolved).length; }
  get totalRollbacks(): number { return this.rollbackCount; }
  get safetyEvents(): SafetyEvent[] { return [...this.events]; }
  get recentEvents(): SafetyEvent[] { return this.events.slice(-20); }
}

export const safetyMonitor = new SafetyMonitor();
