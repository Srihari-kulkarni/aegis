import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { IntelFeedResult, TopoElevation } from '../types';

const CACHE_KEY = 'intel:opentopo';
const TTL = 86400;

export async function fetchOpenTopoData(locations: Array<{ lat: number; lon: number }>): Promise<IntelFeedResult<TopoElevation[]>> {
  if (locations.length === 0) {
    return { success: true, data: [], source: 'open-topo', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  const locStr = locations.map((l) => `${l.lat.toFixed(6)},${l.lon.toFixed(6)}`).join('|');
  const cacheKey = `${CACHE_KEY}:${Buffer.from(locStr).toString('base64').slice(0, 40)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'open-topo', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = `https://api.opentopodata.org/v1/srtm30m?locations=${locStr}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error(`OpenTopo HTTP ${res.status}`);

    const json = await res.json() as { results: Array<{ elevation: number; location: { lat: number; lng: number }; dataset: string }> };
    const elevations: TopoElevation[] = (json.results ?? []).map((r) => ({
      lat: r.location.lat,
      lon: r.location.lng,
      elevationM: r.elevation ?? 0,
      dataset: r.dataset ?? 'srtm30m',
    }));

    await redis.set(cacheKey, JSON.stringify(elevations), 'EX', TTL);
    logger.debug({ count: elevations.length }, 'OpenTopo fetched');
    return { success: true, data: elevations, source: 'open-topo', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'OpenTopo fetch failed — using simulated data');
    const sim = locations.map((l) => ({ lat: l.lat, lon: l.lon, elevationM: 50 + Math.random() * 500, dataset: 'simulated' }));
    return { success: true, data: sim, source: 'open-topo-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}
