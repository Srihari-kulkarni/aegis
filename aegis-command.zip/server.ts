import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HTTPServer } from 'http';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { redis, redisSub } from '../redis';
import { logger } from '../logger';
import { JWTPayload } from '../auth/middleware';

export function initWebSocketServer(httpServer: HTTPServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: config.cors.origin,
      methods: ['GET', 'POST'],
      credentials: true,
    },
    pingTimeout: 30000,
    pingInterval: 10000,
  });

  io.use((socket: Socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined
      ?? socket.handshake.headers?.authorization?.replace('Bearer ', '');

    if (!token) {
      next(new Error('Authentication required'));
      return;
    }

    try {
      const decoded = jwt.verify(token, config.jwt.publicKey, { algorithms: ['RS256'] }) as JWTPayload;
      if (decoded.type !== 'access') {
        next(new Error('Invalid token type'));
        return;
      }
      (socket as Socket & { operator: JWTPayload }).operator = decoded;
      next();
    } catch {
      next(new Error('Invalid or expired token'));
    }
  });

  const telemetryNs = io.of('/telemetry');
  const missionFeedNs = io.of('/mission-feed');
  const aiIntelNs = io.of('/ai-intel');
  const threatsNs = io.of('/threats');

  for (const ns of [telemetryNs, missionFeedNs, aiIntelNs, threatsNs]) {
    ns.use((socket: Socket, next) => {
      const token = socket.handshake.auth?.token as string | undefined
        ?? socket.handshake.headers?.authorization?.replace('Bearer ', '');

      if (!token) {
        next(new Error('Authentication required'));
        return;
      }

      try {
        const decoded = jwt.verify(token, config.jwt.publicKey, { algorithms: ['RS256'] }) as JWTPayload;
        (socket as Socket & { operator: JWTPayload }).operator = decoded;
        next();
      } catch {
        next(new Error('Invalid token'));
      }
    });
  }

  telemetryNs.on('connection', (socket: Socket) => {
    const op = (socket as Socket & { operator: JWTPayload }).operator;
    logger.debug({ operatorId: op.sub, callsign: op.callsign }, 'Telemetry WS connected');

    socket.on('subscribe:drone', (droneId: string) => {
      socket.join(`drone:${droneId}`);
      logger.debug({ droneId, operatorId: op.sub }, 'Subscribed to drone telemetry');
    });

    socket.on('unsubscribe:drone', (droneId: string) => {
      socket.leave(`drone:${droneId}`);
    });

    socket.on('subscribe:all', () => {
      socket.join('all-drones');
    });

    socket.on('disconnect', () => {
      logger.debug({ operatorId: op.sub }, 'Telemetry WS disconnected');
    });
  });

  missionFeedNs.on('connection', (socket: Socket) => {
    const op = (socket as Socket & { operator: JWTPayload }).operator;
    logger.debug({ operatorId: op.sub }, 'Mission feed WS connected');

    socket.on('subscribe:mission', (missionId: string) => {
      socket.join(`mission:${missionId}`);
    });

    socket.on('unsubscribe:mission', (missionId: string) => {
      socket.leave(`mission:${missionId}`);
    });

    socket.on('subscribe:all', () => {
      socket.join('all-missions');
    });

    socket.on('disconnect', () => {
      logger.debug({ operatorId: op.sub }, 'Mission feed WS disconnected');
    });
  });

  aiIntelNs.on('connection', (socket: Socket) => {
    const op = (socket as Socket & { operator: JWTPayload }).operator;
    logger.debug({ operatorId: op.sub }, 'AI intel WS connected');

    socket.on('subscribe:mission', (missionId: string) => {
      socket.join(`ai:${missionId}`);
    });

    socket.join('ai-global');

    socket.on('disconnect', () => {
      logger.debug({ operatorId: op.sub }, 'AI intel WS disconnected');
    });
  });

  threatsNs.on('connection', (socket: Socket) => {
    const op = (socket as Socket & { operator: JWTPayload }).operator;
    logger.debug({ operatorId: op.sub }, 'Threats WS connected');
    socket.join('threats-global');

    socket.on('disconnect', () => {
      logger.debug({ operatorId: op.sub }, 'Threats WS disconnected');
    });
  });

  setupRedisSubscriptions(telemetryNs, missionFeedNs, aiIntelNs, threatsNs);

  logger.info('WebSocket server initialized with namespaces: /telemetry, /mission-feed, /ai-intel, /threats');
  return io;
}

function setupRedisSubscriptions(
  telemetryNs: ReturnType<SocketIOServer['of']>,
  missionFeedNs: ReturnType<SocketIOServer['of']>,
  aiIntelNs: ReturnType<SocketIOServer['of']>,
  threatsNs: ReturnType<SocketIOServer['of']>
): void {
  const handleMessage = (channel: string, message: string): void => {
    try {
      const data = JSON.parse(message) as Record<string, unknown>;

      if (channel.startsWith('telemetry:')) {
        const droneId = channel.replace('telemetry:', '');
        telemetryNs.to(`drone:${droneId}`).emit('telemetry:update', data);
        telemetryNs.to('all-drones').emit('telemetry:update', data);
      }

      if (channel === 'mission:actions') {
        const missionId = data.missionId as string;
        missionFeedNs.to(`mission:${missionId}`).emit('action:new', data);
        missionFeedNs.to('all-missions').emit('action:new', data);
      }

      if (channel === 'mission:ai_decision') {
        const missionId = data.missionId as string;
        aiIntelNs.to(`ai:${missionId}`).emit('ai:update', data);
        aiIntelNs.to('ai-global').emit('ai:update', data);
      }

      if (channel === 'threats:update') {
        threatsNs.to('threats-global').emit('threat:update', data);
      }

      if (channel === 'ai:tier_change') {
        aiIntelNs.to('ai-global').emit('ai:tier_change', data);
      }

      if (channel === 'command:validation') {
        const droneId = data.droneId as string;
        telemetryNs.to(`drone:${droneId}`).emit('command:validation', data);
        missionFeedNs.to('all-missions').emit('command:validation', data);
      }

      if (channel === 'ri:status') {
        aiIntelNs.to('ai-global').emit('ri:status', data);
      }

      if (channel === 'ri:refinement') {
        aiIntelNs.to('ai-global').emit('ri:refinement', data);
      }

      if (channel === 'ri:safety') {
        aiIntelNs.to('ai-global').emit('ri:safety', data);
      }

      if (channel === 'ri:prompt:analysis') {
        aiIntelNs.to('ai-global').emit('ri:prompt_analysis', data);
      }
    } catch (err) {
      logger.error({ err, channel }, 'Error processing Redis message for WebSocket relay');
    }
  };

  redisSub.on('message', ((...args: unknown[]) => {
    handleMessage(args[0] as string, args[1] as string);
  }) as (...args: unknown[]) => void);

  redisSub.subscribe(
    'mission:actions',
    'mission:ai_decision',
    'threats:update',
    'ai:tier_change',
    'command:validation',
    'ri:status',
    'ri:refinement',
    'ri:safety',
    'ri:prompt:analysis'
  ).catch((err: Error) => {
    logger.error({ err }, 'Failed to subscribe to Redis channels');
  });

  redisSub.psubscribe('telemetry:*').catch((err: Error) => {
    logger.error({ err }, 'Failed to psubscribe to telemetry channels');
  });

  redisSub.on('pmessage', ((...args: unknown[]) => {
    const channel = args[1] as string;
    const message = args[2] as string;
    try {
      const data = JSON.parse(message) as Record<string, unknown>;
      if (channel.startsWith('telemetry:')) {
        const droneId = channel.replace('telemetry:', '');
        telemetryNs.to(`drone:${droneId}`).emit('telemetry:update', data);
        telemetryNs.to('all-drones').emit('telemetry:update', data);
      }
    } catch (err) {
      logger.error({ err, channel }, 'Error processing Redis pmessage');
    }
  }) as (...args: unknown[]) => void);
}
