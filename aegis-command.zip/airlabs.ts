import { redis } from '../../redis';
import { logger } from '../../logger';
import { zuluTimestamp } from '@aegis/shared';
import type { AirLabsFlight, BoundingBox, IntelFeedResult } from '../types';

const CACHE_KEY = 'intel:airlabs';
const TTL = 15;

export async function fetchAirLabs(bbox: BoundingBox, apiKey?: string): Promise<IntelFeedResult<AirLabsFlight[]>> {
  const cacheKey = `${CACHE_KEY}:${bbox.lamin.toFixed(2)}_${bbox.lomin.toFixed(2)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return { success: true, data: JSON.parse(cached), source: 'airlabs', cached: true, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  if (!apiKey) {
    return { success: true, data: simulateAirLabs(bbox), source: 'airlabs-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }

  try {
    const url = `https://airlabs.co/api/v9/flights?api_key=${apiKey}&bbox=${bbox.lamin},${bbox.lomin},${bbox.lamax},${bbox.lomax}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`AirLabs HTTP ${res.status}`);

    const json = await res.json() as { response: Array<{ flight_iata: string; airline_icao: string; aircraft_icao: string; lat: number; lng: number; alt: number; speed: number; dir: number; status: string }> };
    const flights: AirLabsFlight[] = (json.response ?? []).map((f) => ({
      flightIata: f.flight_iata ?? '',
      airlineIcao: f.airline_icao ?? '',
      aircraftIcao: f.aircraft_icao ?? '',
      lat: f.lat, lng: f.lng, alt: f.alt, speed: f.speed, dir: f.dir,
      status: f.status ?? 'en-route',
    }));

    await redis.set(cacheKey, JSON.stringify(flights), 'EX', TTL);
    return { success: true, data: flights, source: 'airlabs', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  } catch (err) {
    logger.warn({ err }, 'AirLabs fetch failed');
    return { success: true, data: simulateAirLabs(bbox), source: 'airlabs-simulated', cached: false, fetchedAt: zuluTimestamp(), ttlSeconds: TTL };
  }
}

function simulateAirLabs(bbox: BoundingBox): AirLabsFlight[] {
  const count = 1 + Math.floor(Math.random() * 3);
  return Array.from({ length: count }, (_, i) => ({
    flightIata: `AA${100 + i}`,
    airlineIcao: 'AAL',
    aircraftIcao: 'B738',
    lat: bbox.lamin + Math.random() * (bbox.lamax - bbox.lamin),
    lng: bbox.lomin + Math.random() * (bbox.lomax - bbox.lomin),
    alt: 8000 + Math.random() * 30000,
    speed: 200 + Math.random() * 300,
    dir: Math.random() * 360,
    status: 'en-route',
  }));
}
